package com.bdbizviz.restassured.platform.AccessDenied;

import com.bdbizviz.restassured.platform.DataCenter.DataCenterHelper;
import com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper;
import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.Utils;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper.getlistview;
import static com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper.*;
import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;

/**
 * Created by bizviz on 16/2/18.
 */
public class AccessDenied extends AccessDeniedHelper {
    private static final Logger LOGGER = Logger.getLogger( AccessDenied.class.getName() );
    String update = "";

    String commit = "";

    @BeforeClass
    public static void setup() {
        //NonAdmin user
        user = Helper.getCustomerKey(emailid_admin,space_admin);
        userauth = Helper.getAuthToken(emailid_admin,pass_admin,space_admin);
        spaceKey = user.getSpacekey();
        uid = user.getId();
        authToken = userauth.getAuthToken();
    }

    //Called on click on Every Modules
    @Test(description = "getUserInfoByToken called on click of Every Modules")
    public void getUserInfoByTokenTestCase() {
        try {
            getUserInfoByToken(authToken, HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    //HomePage
    @Test(description = "getAllMenuContext called on click of HomePage ")
    public void getAllMenuContext() {
        try {
            getAllMenuContext(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Bizviz notifications
    @Test(description = "pluginServiceNotification")
    public void pluginServiceNotification() {
        try {
            pluginServiceLogin(uid,authToken,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Admin.java Module
    @Test(description = "Get permission by category ")
    public void adminModule() {
        try {
            adminModule(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Admin.java Module
    @Test(description = "Get all Users ")
    public void getAllUsers() {
        try {
            getAllUsers(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //UserManagement
    @Test(description = "getuserlist called on click of UserManagement")
    public void getuserlist() {
        try {
            getuserlist(spaceKey,uid,authToken, Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getusergrouplist called on click of UserManagement")
    public void getusergrouplist() {
        try {
            getusergrouplist(spaceKey,uid,authToken,Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //DataCenter
    @Test(description = "getDataSourceInfoByType called on click of DataCenter")
    public void getDataSourceInfoByType() {
        try {
            DataCenterHelper.getDataSourceInfoByType(spaceKey,uid,authToken,"",HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Sentiment
    @Test(description = "pluginServiceSentiment called on click of Sentiment")
    public void pluginServiceSentiment() {
        try {
            pluginServiceSentiment(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //SMB
    @Test(description = "pluginServiceSMB called on click of SMB")
    public void pluginServiceSMB() {
        try {
            pluginServiceSMB(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "pluginServiceSMB1 called on click of SMB module and inside it on SMB")
    public void pluginServiceSMB1() {
        try {
            pluginServiceSMB1(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Play
    @Test(description = "getAllPlayWorkspaceAndContent")
    public void getAllPlayWorkspaceAndContent() {
        try {
            getAllPlayWorkspaceAndContent(spaceKey,uid,authToken);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //predictive
    @Test(description = "pluginServicePredictive called on click of predictive")
    public void pluginServicepredictive() {
        try {
            String data = "{\"id\":\"\",\"type\":12,\"status\":1,\"spaceKey\":\""+spaceKey+"\",\"settings\":\"\"}";
            pluginServicePredictive(spaceKey,uid,authToken,data);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //predictive-Rserver
    @Test(description = "pluginServicePredictive called on click of predictive RServer settings")
    public void pluginServicepredictiveRServer() {
        try {
            pluginServicepredictiveRServer(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //predictive-getAllWorkflows
    @Test(description = "pluginServicepredictiveGetAllWorkflows")
    public void pluginServicepredictiveGetAllWorkflows() {
        try {
            pluginServicepredictiveGetAllWorkflows(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Geo Settings
    @Test(description = "GetGeoSpatial Settings")
    public void getAllGeoSpatialSettings() {
        try {
            getAllGeoSpatialSettings(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Dashboard
    @Test(description = "Dashboard")
    public void getAllWorkspaceAndDashboard() {
        try {
            getAllWorkspaceAndDashboard(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Survey
    @Test(description = "Survey")
    public void surveyPluginService() {
        try {
            String data = "{\"consumerName\":\"SURVEY\",\"customerId\":null,\"ut\":null,\"email\":null,\"params\":\"\",\"userid\":"+uid+",\"userType\":1}";
            surveyPluginService(spaceKey,uid,authToken,data);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    //-------HomeUI services to track the access denied--------//

    @Test(description ="creating the Folder and deleting it")
    public static void copyFolder(){
        try{
            //getUserInfoToken
            getUserInfoByToken(authToken);

            //CreateFolder
            createFolderInHomeUi(uid, HomeUiHelper.myDocumentId, position,authToken,spaceKey,HttpStatus.SC_OK);
            String dashboardType = Utils.getproperty("dashboardType");

            copyPaste(folderid_Home,copyTitle,myDocumentId,Integer.valueOf(dashboardType),uid,spaceKey,authToken, HttpStatus.SC_OK);

            //Deleting the created folder
            removeNode(uid,folderid_Home, authToken, spaceKey,HttpStatus.SC_OK);

            //getListView to get copyid
            getlistview(spaceKey,uid,authToken,HttpStatus.SC_OK);

            //Deleting the copied folder
            removeNode(uid,copyId, authToken, spaceKey,HttpStatus.SC_OK);
        }
        catch(Exception e){
            e.printStackTrace();
        }

    }

    @Test(description ="creating the Story")
    public static void createStoryHomeUi(){
        try{
            //createStory
           createStoryInFolderMyDoc(Utils.getproperty("consumerNameCreateStory"),Utils.getproperty("serviceNameCreateStory"),spaceKey,authToken,uid, HttpStatus.SC_OK);

            //Deleting Story
            removeNode(uid,storyId.toString(), authToken, spaceKey,HttpStatus.SC_OK);
        }catch (Exception e){
            e.printStackTrace();
        }

    }

}