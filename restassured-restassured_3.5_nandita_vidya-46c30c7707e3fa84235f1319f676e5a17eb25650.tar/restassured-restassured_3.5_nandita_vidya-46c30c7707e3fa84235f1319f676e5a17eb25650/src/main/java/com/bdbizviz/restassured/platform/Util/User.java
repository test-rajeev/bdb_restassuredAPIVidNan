package com.bdbizviz.restassured.platform.Util;

/**
 * Created by bizviz on 2/2/18.
 */
public class User {

    private static String id;
    private static String spacekey;
    private static String authToken;
    private static String customerKey;


    public static String getId() {
        return id;
    }

    public static void setId(String id) {
        User.id = id;
    }

    public static String getSpacekey() {
        return spacekey;
    }

    public static void setSpacekey(String spacekey) {
        User.spacekey = spacekey;
    }

    public static String getAuthToken() {
        return authToken;
    }

    public static void setAuthToken(String authToken) {
        User.authToken = authToken;
    }

    public static String getCustomerKey() {
        return customerKey;
    }

    public static void setCustomerKey(String customerKey) {
        User.customerKey = customerKey;
    }
}