package com.bdbizviz.restassured.platform.BS;
//todo here
import com.bdbizviz.restassured.platform.Designer.DesignerHelper;

import org.json.JSONArray;
import org.json.simple.JSONObject;

import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.Jdbc_connection;
import com.bdbizviz.restassured.platform.Util.Utils;

import io.restassured.response.Response;

import static com.bdbizviz.restassured.platform.DataCenter.DataCenterHelper.cubeid;
import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;

import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.apache.http.HttpStatus;

import org.testng.Assert;

public class BusinessStoryHelper  {
    public static JSONObject prop = null;
    public static String spaceKey;
    public static String uid;
    public static String authToken;
    public static int storyId;
    public static int savedStoryId;
    public static String alertId;
    public static int viewId;
    Thread t1 =new Thread();
    public static String cbid;
    public static String storyname="Test_"+generateRandomString();


    public void getCubeID(){

        try {
            t1.sleep(30000);
            System.out.println("CubeIdBIStory:" + cubeid);
            cbid=cubeid.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //Generation of Random Strings
    public static String generateRandomString() {
        char[] chars = "abcdefghijklmnopqrstuvwxyz".toCharArray();
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 3; i++) {
            char c = chars[random.nextInt(chars.length)];
            sb.append(c);
        }
        return sb.toString();
    }
    public static void createStoryInFolderMyDoc(String dataStr){
        try{
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", Utils.getproperty("isSecure2"))
                            .param("consumerName", Utils.getproperty("bsconsumerName"))
                            .param("serviceName", Utils.getproperty("saveBsServiceName"))
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("pluginurl"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees = from(response.asString()).get("");
            storyId=(Integer) trees.get("id");
            System.out.println("storyId is ==" +storyId);
            String storyName1=(String) trees.get("name");

            Assert.assertNotNull(storyName1);
            Assert.assertEquals(storyName1,storyname);
        }catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void saveStoryData() {
        try {
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            .param("position", 0)
                            .param("type", "file")
                            .param("parentid", DesignerHelper.myDocumentId)
                            .param("id", 0)
                            .param("dashboardtype", 12)
                            .param("imagename", "")
                            .param("title", storyname)
                            .param("description", "")
                            .param("file", "")
                            .param("treeRel", storyId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("saveStoryData"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> trees = from(response.asString()).get("trees");
            HashMap<String, Object> tree = (HashMap) trees.get("tree");
            savedStoryId = (Integer) tree.get("id");
            String savedStoryName = (String) tree.get("title");
            String savedStoryspaceKey = (String) tree.get("spaceKey");
            String savedStorydocVersion = (String) tree.get("documentVersion");
            int savedStorydashboardType = (Integer) tree.get("dashboardType");

            Assert.assertNotNull(savedStoryId);
            Assert.assertEquals(savedStoryName, storyname);
            Assert.assertEquals(savedStoryspaceKey, spaceKey);
           // Assert.assertEquals(savedStorydocVersion, Utils.getproperty("docVersion"));
            Assert.assertEquals("Successfully save the dashboard", trees.get("message").toString());
            Assert.assertEquals(savedStorydashboardType, 12);
            String sql1="select id from dashboard where title= '"+storyname+"'";
            Assert.assertEquals(String.valueOf(savedStoryId),Jdbc_connection.jdbcResult(sql1,"id","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72"));
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void saveStoryInFolderMyDoc(){
        try{
            String dataStr ="{\"spaceKey\":\""+spaceKey+"\",\"storyDefenition\":\"{\\\"theme\\\":\\\"none\\\",\\\"version\\\":\\\""+Utils.getproperty("docVersion")+"\\\",\\\"story\\\":[],\\\"storyProperties\\\":{\\\"viewOrder\\\":[],\\\"viewCfg\\\":{},\\\"theme\\\":0},\\\"action\\\":{}}\",\"name\":\""+storyname+"\",\"id\":"+storyId+",\"isActive\":0,\"createdDate\":null,\"lastUpdatedDate\":null}";
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", Utils.getproperty("isSecure2"))
                            .param("consumerName", Utils.getproperty("bsconsumerName"))
                            .param("serviceName", Utils.getproperty("saveBsServiceName"))
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("pluginurl"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> trees = from(response.asString()).get("");
            System.out.println((Integer) trees.get("id"));


        }catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void getDataStoreDetails() {
        try {
            JSONObject data = new JSONObject();
            data.put("id",0);
            data.put("datasourcetype","all");
            String dataStr =  data.toString();
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", Utils.getproperty("isSecure2"))
                            .param("consumerName", Utils.getproperty("bsconsumerName"))
                            .param("serviceName", Utils.getproperty("getDSServiceName"))
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("pluginurl"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> resp = from(response.asString()).get("");
            List< HashMap<String, Object> >  bizvizCubes = (List<HashMap<String, Object>>) resp.get("bizvizCubes");
            System.out.println(resp.toString());
            String success= resp.get("success").toString();
            //****Asserting for create document****//
            Assert.assertEquals("true", success);
            String sql1="select ID from bizvizcube where name='RestAutomationDataStore' order by id desc limit 5";
            Assert.assertEquals(String.valueOf(bizvizCubes.get(0).get("id")), Jdbc_connection.jdbcResult(sql1,"ID","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void getdeliveryresultbyownerid(){
        try {
            JSONObject data = new JSONObject();
            data.put("ownerId",uid);
            String dataStr =  data.toString();
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", Utils.getproperty("isSecure2"))
                            .param("consumerName", Utils.getproperty("bsalartconsumername"))
                            .param("serviceName", Utils.getproperty("getDeliveryResultByOwnerId"))
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("pluginurl"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            System.out.println(from(response.asString()).get(""));
            HashMap<String, Object> resp = from(response.asString()).get("");
            List< HashMap<String, Object> >  bizvizresp = (List<HashMap<String, Object>>) resp.get("resp");

            String sql1="select ALERT_ID,CUBE_ID from bizvizcubeAlert where OWNER_ID="+uid;
            Assert.assertEquals(String.valueOf(bizvizresp.get(0).get("alertId")), Jdbc_connection.jdbcResult(sql1,"ALERT_ID","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void savecubealart(){
        try {
            String cubename="alart2";
            String measurename="UNITCOST";
            String dataStr =  "{\"ownerId\":"+uid+",\"createdDate\":1518601481,\"lastUpdatedDate\":1518601481,\"status\":1,\"owner\":1,\"alertId\":null,\"cubeId\":{\"id\":"+cbid+"},\"upperThreshold\":100,\"lowerThreshold\":0,\"definition\":\"{\\\"filter\\\":{},\\\"category\\\":[],\\\"series\\\":[{\\\"measure\\\":\\\""+measurename+"\\\",\\\"op\\\":\\\"sum\\\"}],\\\"timeField\\\":\\\"DATEKEY\\\",\\\"interval\\\":\\\"daily\\\",\\\"properties\\\":{\\\"isPrepared\\\":true,\\\"markerRange\\\":[{\\\"value\\\":\\\"Lower Threshold\\\",\\\"color\\\":\\\"#00d66c\\\"},{\\\"value\\\":\\\"Upper Threshold\\\",\\\"color\\\":\\\"#ffff99\\\"},{\\\"value\\\":\\\"100\\\",\\\"color\\\":\\\"#ff3333\\\"}]},\\\"defaultChartClass\\\":\\\"SemiGauge\\\",\\\"chartProperties\\\":{\\\"Object.SemiGauge.minValue\\\":-25,\\\"Object.SemiGauge.maxValue\\\":125,\\\"Object.SemiGauge.targetvalue\\\":\\\"\\\",\\\"Object.SemiGauge.ratios\\\":\\\"0,100,125\\\",\\\"Object.SemiGauge.colors\\\":\\\"#00d66c,#ffff99,#ff3333\\\"}}\",\"data\":\"{\\\"measure\\\":[{\\\"name\\\":\\\""+measurename+"\\\",\\\"op\\\":\\\"sum\\\"}],\\\"dimension\\\":[],\\\"facts\\\":{\\\"DATEKEY\\\":{\\\"from\\\":\\\"now-1d/d\\\",\\\"to\\\":\\\"now-1d\\\"}},\\\"transDim\\\":\\\"\\\",\\\"elasticSearch\\\":{\\\"isEnabled\\\":true},\\\"limit\\\":[\\\"0\\\"]}\",\"displayComponent\":\"\",\"description\":\""+cubename+"\",\"favouriteValue\":\"upper\",\"isShared\":1,\"type\":1,\"spaceKey\":\""+spaceKey+"\"}";
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", Utils.getproperty("isSecure2"))
                            .param("consumerName", Utils.getproperty("bsalartconsumername"))
                            .param("serviceName", Utils.getproperty("bsalartserviceName"))
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("pluginurl"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> resp = from(response.asString()).get("bizvizCubeAlert");
            System.out.println(from(response.asString()).get(""));
            org.json.JSONObject obj = new org.json.JSONObject(resp);
            alertId=obj.get("alertId").toString();
            
            String sql1="select ALERT_ID,DATA,DEFINITION,DESCRIPTION from bizvizcubeAlert where ALERT_ID="+alertId;
            Assert.assertEquals(alertId, Jdbc_connection.jdbcResult(sql1,"ALERT_ID","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
            Assert.assertEquals(obj.get("data").toString(), Jdbc_connection.jdbcResult(sql1,"DATA","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
            Assert.assertEquals(obj.get("definition").toString(), Jdbc_connection.jdbcResult(sql1,"DEFINITION","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
            Assert.assertEquals(obj.get("description").toString(), Jdbc_connection.jdbcResult(sql1,"DESCRIPTION","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void deletecubealert(){
        BusinessStoryHelper.savecubealart();
        try {
            JSONObject data = new JSONObject();
            data.put("alertId",alertId);
            String dataStr =  data.toString();
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", Utils.getproperty("isSecure2"))
                            .param("consumerName", Utils.getproperty("bsalartconsumername"))
                            .param("serviceName", Utils.getproperty("bsdelalertserviceName"))
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("pluginurl"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            
            String sql1="select status from bizvizcubeAlert where ALERT_ID="+alertId;
            Assert.assertEquals("0",Jdbc_connection.jdbcResult(sql1,"status","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*public static void getDSData( String dataStr) {
        String serviceName=cubeid+spaceKey;
        try{
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("consumerName", Utils.getproperty("bsconsumerName"))
                            .param("serviceName", serviceName)
                            .param("data", "{}")
                            .param("facts", "{}")
                            .param("viewId", 0)
                            .param("viewInfo", dataStr)
                            .param("isSecure", Utils.getproperty("isSecure2"))
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getDsData"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

        }catch (Exception e){
            e.printStackTrace();
        }
    }*/

    public static List<HashMap<String, Object>> getDSData( String dataStr) {
		String serviceName=cbid+spaceKey;
        try{
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("consumerName", Utils.getproperty("bsconsumerName"))
                            .param("serviceName", serviceName)
                            .param("data", "{}")
                            .param("facts", "{}")
                            .param("viewId", 0)
                            .param("viewInfo", dataStr)
                            .param("isSecure", Utils.getproperty("isSecure2"))
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getDsData"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>>resp = from(response.asString()).get("");
            System.out.println(resp);
            
         return resp;  
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    
    public static void getStoryById() {
        try {
            JSONObject data = new JSONObject();
            Integer id = storyId;
            data.put("id",id);

            String dataStr =  data.toString();
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure",  Utils.getproperty("isSecure2"))
                            .param("consumerName", Utils.getproperty("bsconsumerName"))
                            .param("serviceName", Utils.getproperty("getStoryIDBsServiceName"))
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("pluginurl"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees = from(response.asString()).get("");
            HashMap<String, Object> businessStory = (HashMap<String, Object>) trees.get("businessStory");
           
            Assert.assertEquals(spaceKey, trees.get("spaceKey").toString());
            Assert.assertEquals(businessStory.get("name").toString(), storyname);

            String sql1="select STORY_DEFENITION from bizvizstory where id="+storyId;
            Assert.assertEquals(businessStory.get("storyDefenition").toString(),Jdbc_connection.jdbcResult(sql1,"STORY_DEFENITION","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    public static void getCubeInfo() {
        try {
            JSONObject data = new JSONObject();
            data.put("id",cubeid);
            String dataStr =  data.toString();
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure",  Utils.getproperty("isSecure2"))
                            .param("consumerName", Utils.getproperty("bsconsumerName"))
                            .param("serviceName", Utils.getproperty("getCubeInfoBsServiceName"))
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("pluginurl"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> resp = from(response.asString()).get("");
            HashMap<String, Object> bizvizCube = (HashMap<String, Object>) resp.get("bizvizCube");
            
            String sql1="select CUBEINFO,DATASOURCE,DEFENITION,SYNONYM,LASTRUNDATE from bizvizcube where ID="+cbid;
            
            Assert.assertEquals(bizvizCube.get("cubeOptions"),Jdbc_connection.jdbcResult(sql1,"CUBEINFO","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72"));
            Assert.assertEquals(bizvizCube.get("datasource"),Jdbc_connection.jdbcResult(sql1,"DATASOURCE","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72"));
            Assert.assertEquals(bizvizCube.get("defenition"),Jdbc_connection.jdbcResult(sql1,"DEFENITION","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72"));
            Assert.assertEquals(bizvizCube.get("lastRunDate").toString(),Jdbc_connection.jdbcResult(sql1,"LASTRUNDATE","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
            Assert.assertEquals(bizvizCube.get("synonym"),Jdbc_connection.jdbcResult(sql1,"SYNONYM","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void CreateViewLog() {
        try {
            String dataStr =  "{\"viewLogList\":[{\"bizvizStrory\":"+storyId+",\"cubeId\":"+cubeid+",\"viewId\":"+viewId+"}]}";
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure",  Utils.getproperty("isSecure2"))
                            .param("consumerName", Utils.getproperty("bsconsumerName"))
                            .param("serviceName", Utils.getproperty("CreateViewLog"))
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("pluginurl"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> resp = from(response.asString()).get("");

            Assert.assertEquals(resp.get("success").toString(),"true");
            Assert.assertEquals(resp.get("status").toString(), "true");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void DeleteViewLog() {
        try {
            String dataStr =  "{\"storyId\":"+storyId+",\"viewId\":"+viewId+"}";
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure",  Utils.getproperty("isSecure2"))
                            .param("consumerName", Utils.getproperty("bsconsumerName"))
                            .param("serviceName", Utils.getproperty("DeleteViewLog"))
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("pluginurl"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> resp = from(response.asString()).get("");
            
            Assert.assertEquals(resp.get("success").toString(),"true");
            Assert.assertEquals(resp.get("status").toString(), "true");
            String sql1="select IS_ACTIVE from bizvizcubeview where CUBE_ID="+viewId;
            Assert.assertEquals("0", Jdbc_connection.jdbcResult(sql1,"CUBE_ID","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void getDistinctDimName() {
        try {
            String dataStr =  "{\"filter\":{},\"dimForFilter\":[\"Location_Id\"],\"dimension\":[{\"name\":\"Location_Id\",\"interval\":\"\"}],\"measure\":[],\"facts\":{},\"elasticSearch\":{\"isEnabled\":true},\"limit\":[\"0\"]}";
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("consumerName", Utils.getproperty("cubedosconsumername"))
                            .param("serviceName", Utils.getproperty("getDistinctDimName"))
                            .param("data", dataStr)
                            .param("isSecure",  Utils.getproperty("isSecure2"))
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getDistinctDimName"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<Object> resp =  from(response.asString()).get("");
            
            String sql1="select LOCATION_ID from orders where total_amount>0 and TOTAL_COMMISSION>0";
            Assert.assertEquals(resp.get(0).toString(), Jdbc_connection.jdbcResult(sql1,"LOCATION_ID","192.168.1.10:3306","BizViz_Automation_WT","automation_user","Auto%987").toString());
            Assert.assertNotNull(response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void saveCubeView(String data) {
        try {
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", "true")
                            .param("consumerName", Utils.getproperty("bsconsumerName"))
                            .param("serviceName", "saveCubeView")
                            .param("data", data)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("pluginurl"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> resp = from(response.asString()).get("");
            HashMap<String, Object> bizvizCube=(HashMap<String, Object> ) resp.get("bizvizCube");
            List<HashMap<String, Object> > cubeViews = ( List<HashMap<String, Object> > ) bizvizCube.get("cubeViews");
            viewId = (Integer)cubeViews.get(0).get("id");
       
            Assert.assertNotNull(viewId);
            Assert.assertEquals(storyname, bizvizCube.get("name"));
            String sql1="select CUBE_ID from bizvizcubeview where CUBE_ID="+viewId;
            Assert.assertEquals(String.valueOf(viewId), Jdbc_connection.jdbcResult(sql1,"CUBE_ID","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
           
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void ExecuteBSRScript() {
        try {
            String dataStr =  "{\"filterDetails\":{\"measure\":[],\"dimension\":[],\"facts\":{},\"transDim\":\"\",\"elasticSearch\":{\"isEnabled\":true}},\"scriptDetails\":{\"script\":\"main <- function(mpg)\\n{\\n\\n# load package and data\\nlibrary(ggplot2)\\ndata(mpg, package=\\\"ggplot2\\\")\\n# mpg <- read.csv(\\\"http://goo.gl/uEeRGu\\\")\\n\\nmpg_select <- mpg[mpg$manufacturer %in% c(\\\"audi\\\", \\\"ford\\\", \\\"honda\\\", \\\"hyundai\\\"), ]\\n\\n# Scatterplot\\ntheme_set(theme_bw())  # pre-set the bw theme.\\ng <- ggplot(mpg_select, aes(displ, cty)) + \\n  labs(subtitle=\\\"mpg: Displacement vs City Mileage\\\",\\n       title=\\\"Bubble chart\\\")\\n\\ng + geom_jitter(aes(col=manufacturer, size=hwy)) + \\n  geom_smooth(aes(col=manufacturer), method=\\\"lm\\\", se=F)\\n\\n}\",\"function_call\":\"main(mpg)\",\"input_df_name\":\"mpg\"},\"cubeId\":\"3262382292774\"}";
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure",  Utils.getproperty("isSecure2"))
                            .param("consumerName", Utils.getproperty("bsconsumerName"))
                            .param("serviceName", Utils.getproperty("ExecuteBSRScript"))
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("pluginurl"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            System.out.println(from(response.asString()).get("").toString());
            //****Asserting for create document****
            //  Assert.assertEquals("Story_4thJuly", name);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void getNLP(String nlpquery) {
        //BusinessStoryHelper.getCubeInfo();
        try {
            String dataStr =  "{\"cubeId\":\""+cubeid+"\",\"userText\":\""+nlpquery+"\"}";
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure",  Utils.getproperty("isSecure2"))
                            .param("consumerName", Utils.getproperty("bsconsumerName"))
                            .param("serviceName", Utils.getproperty("getNLP"))
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("pluginurl"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> resp = from(response.asString()).get("");
            JSONArray arr  = new JSONArray(resp.get("data").toString());
         	
            Assert.assertEquals(resp.get("cubeid"), cbid);
            String sql1="select sum(TOTAL_AMOUNT) from orders where total_amount>0 and TOTAL_COMMISSION>0 and LOCATION_ID="+arr.getJSONObject(0).get("Location_Id")+" limit 500";
            Assert.assertEquals(arr.getJSONObject(0).get("sum_Order_Amount").toString(), Jdbc_connection.jdbcResult(sql1,"sum(TOTAL_AMOUNT)","192.168.1.10:3306","BizViz_Automation_WT","automation_user","Auto%987").toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void saveFormulaOperation(){
        try{
            String dataStr ="{\"name\":\""+Helper.generateRandomString()+"\",\"data\":\"{\\\"expression\\\":\\\"[Order_Amount]+[Commission]\\\",\\\"script\\\":\\\"doc['Order_Amount'].value+doc['Commission'].value\\\",\\\"type\\\":\\\"measures\\\"}\",\"referenceId\":\""+cubeid+"\",\"type\":\"1\",\"status\":\"1\",\"isShared\":\"0\"}";
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", Utils.getproperty("isSecure2"))
                            .param("consumerName", Utils.getproperty("bsconsumerName"))
                            .param("serviceName", Utils.getproperty("saveFormulaOperation"))
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("pluginurl"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees = from(response.asString()).get("");
            
            String sql1="select FORMULA_ID,NAME,REFERENCEID,DATA from bizvizformula where FORMULA_ID="+trees.get("id");
            Assert.assertEquals(trees.get("id").toString(), Jdbc_connection.jdbcResult(sql1,"FORMULA_ID","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
            Assert.assertEquals(trees.get("name").toString(), Jdbc_connection.jdbcResult(sql1,"NAME","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
            Assert.assertEquals(trees.get("referenceId").toString(), Jdbc_connection.jdbcResult(sql1,"REFERENCEID","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
            Assert.assertEquals(trees.get("data").toString(), Jdbc_connection.jdbcResult(sql1,"DATA","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
        }catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void listAllFormula(){
        try{
            String dataStr ="{\"type\":\"1\",\"referenceId\":\""+cubeid+"\"}";
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", Utils.getproperty("isSecure2"))
                            .param("consumerName", Utils.getproperty("bsconsumerName"))
                            .param("serviceName", Utils.getproperty("listAllFormula"))
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("pluginurl"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String,Object>> formulas =  from(response.asString()).get("");
            HashMap<String,Object> mapp = formulas.get(0);
             
          String sql1="select FORMULA_ID,NAME,REFERENCEID,DATA from bizvizformula where FORMULA_ID="+mapp.get("id");
          Assert.assertEquals(mapp.get("id").toString(), Jdbc_connection.jdbcResult(sql1,"FORMULA_ID","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
          Assert.assertEquals(mapp.get("name").toString(), Jdbc_connection.jdbcResult(sql1,"NAME","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
          Assert.assertEquals(mapp.get("referenceId").toString(), Jdbc_connection.jdbcResult(sql1,"REFERENCEID","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
          Assert.assertEquals(mapp.get("data").toString(), Jdbc_connection.jdbcResult(sql1,"DATA","192.168.1.6:3306","bizviz_repo","qa_user","qa@Bi#72").toString());
        }catch (Exception e) {
            e.printStackTrace();
        }
    }




}