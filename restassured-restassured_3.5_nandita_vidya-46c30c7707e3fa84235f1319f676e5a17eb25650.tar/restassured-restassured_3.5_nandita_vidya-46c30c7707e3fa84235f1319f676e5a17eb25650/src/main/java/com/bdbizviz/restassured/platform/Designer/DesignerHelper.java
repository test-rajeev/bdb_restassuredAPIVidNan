package com.bdbizviz.restassured.platform.Designer;

import com.bdbizviz.restassured.platform.DataCenter.DataCenterHelper;
import com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper;
import com.bdbizviz.restassured.platform.Util.Jdbc_connection;
import com.bdbizviz.restassured.platform.Util.Utils;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.XML;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

import java.util.*;
import java.util.logging.Logger;

import static com.bdbizviz.restassured.platform.BS.BusinessStoryHelper.generateRandomString;
import static com.bdbizviz.restassured.platform.Designer.DesignerImpl.designerDashName;
import static com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper.dashName;
import static com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper.urlpluginService;
import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;

public class DesignerHelper extends DataCenterHelper {
    public static final Logger LOGGER = Logger.getLogger( DesignerHelper.class.getName() );
    public static String workspaceName_WebService;
    public static String workspaceName_Advanced;
    public static String workspaceName_New;
    public static String workspaceId = null;
    public static String workspaceJSON;
    public static String dashboardName = "WebServiceDashboard_" + generateRandomString();
    public static String dashboardNameMssql = "MssqlDashboard_" + generateRandomString();
    public static String dashboardName_Advanced;
    public static String urlCrtWS;
    public static String urlCrtDB;
    public static String urlsaveDB;
    public static String dashboardId = null;
    public static String urlgetEndpointUrl;
    public static String urlgetRecords;
    public static String urlgetFieldValues;
    public static String urluploadDB;
    public static String urlopenDB;
    public static String typefile;
    public static String imagename;
    public static String originalfilename;
    public static String originalfilenameMssql;
    public static String originalfilenameMysql;
    public static String originalfilenameOracle;
    public static String originalfilenameSparkSql;
    public static String originalfilenameOData;
    public static String array;
    public static String dashboardtype;
    public static String publishDashboardId;
    public static String urlgetdocumentinfobyid;
    public static String urlUserPreferences;
    public static String urlgetAllWorkspaceAndDashboard;
    public static String urlgettrashitems;
    public static String urlupdateDashboardOrWorkspace;
    public static String urltrashdashboard;
    public static String urldeleteDashboardPermanently;
    public static String urlrestoredashboardfromtrash;
    public static String getWorkSpaceId;
    public static String moveRestWorkSpace;
    public static Long position;
    public static String urlgetUserInfoByToken;
    public static String myDocumentId;
    public static String publicDocumentId;
    public static String shareDocumentId;
    public static String endPointUrl;
    public static Integer bizvizCubeId;
    public static String urlgetDataDashboard;
    public static String JDBC_dbip;
    public static String JDBC_dbname;
    public static String JDBC_dbuser;
    public static String JDBC_dbpass;
    public static String urlgetAllFilter;

    public  String wrkSpaceId = null;
    public  String dashId = null;
    public  String publishDashId = null;

    public String params_deleteDashPermnant;
    public JSONArray actualgetRecordsData;
    public static String JDBC_dbipMssql;
    public static String JDBC_dbnameMssql;
    public static String JDBC_dbuserMssql;
    public static String JDBC_dbpassMssql;

    public String JDBC_dbipOracle;
    public String JDBC_dbuserOracle;
    public String JDBC_dbpassOracle;

    public String JDBC_dbipSparkSql;
    public String JDBC_dbuserSparkSql;
    public String JDBC_dbpassSparkSql;
    public String urlsaveorupdateuserdesignerpreferences;
    public static String designerDashName;
    public static String workspaceNameMssql;
    public static String workspaceNameMysql;
    public String workspaceNameOracle;
    public String workspaceNameSparkSql;
    public String workspaceNameOData;
    public String workspaceNameFilter;
    public String originalfilenameMysqlFilter;
    String commit = "";
    Date dt = new Date();
    public  String didtime = "dashboard" + dt.getTime();
    Long epoch  = System.currentTimeMillis();


    //getuserInfoToken
    public static void getUserInfoByToken(String authToken ) {
        try {
            Response response = given()
                    .param("token", authToken)
                    .when()
                    .post(urlgetUserInfoByToken)
                    .then()
                    .statusCode(HttpStatus.SC_OK)
                    .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            List<HashMap<String, Object>> treesList = (ArrayList<HashMap<String, Object>>) users.get("trees");
            for (HashMap treesList_Obj :treesList) {
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("My Documents")){
                    myDocumentId = treesList_Obj.get("id").toString();
                }
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Public Documents")) {
                    publicDocumentId = treesList_Obj.get("id").toString();
                }
                else if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Shared Documents")) {
                    shareDocumentId = treesList_Obj.get("id").toString();
                }
            }


            LOGGER.info(("ShareDocumentId is==" +shareDocumentId));
            LOGGER.info(("MyDocumentId is==" +myDocumentId));
            LOGGER.info(("PublicDocumentId is==" +publicDocumentId));

            //****To assert checking id's are not null***//
            List<Integer> ids = from(response.asString()).get("users.trees.id");
            for (Integer id : ids) {
                Assert.assertNotNull(id);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //getuserdesignerpreferences
    public static void getuserdesignerpreferences(String uid, String spaceKey, String authToken, int statusCode) {
        try {
            Response response =
                    given()
                            .header("userid", uid)
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //params
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlUserPreferences)
                            .then()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK ) {
                HashMap<String, Object> DesignerResp = from(response.asString()).get("DesignerResp");
                HashMap<String, Object> designerPreferences = (HashMap) DesignerResp.get("designerPreferences");
                String success = designerPreferences.get("success").toString();
                System.out.println("DesignerResp:" + DesignerResp);

                //Assertions
                Assert.assertNotNull(designerPreferences.get("id"));
                Assert.assertEquals(success, true);
            }
            LOGGER.info("successful execution");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //listQueryServices
    public static void listQueryServices(String uid, String spaceKey, String authToken, int statusCode) {
        try {
            Response response =
                    given()
                            .header("userid", uid)
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //params
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlUserPreferences)
                            .then()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK ) {
                HashMap<String, Object> DesignerResp = from(response.asString()).get("DesignerResp");
                HashMap<String, Object> designerPreferences = (HashMap) DesignerResp.get("designerPreferences");
                String success = designerPreferences.get("success").toString();
                System.out.println("DesignerResp:" + DesignerResp);

                //Assertions
                Assert.assertNotNull(designerPreferences.get("id"));
                Assert.assertEquals(success, true);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //getFieldValues
    public static void getFieldValues(String uid, String spaceKey, String authToken, int statusCode) {
        try {
            String from = "0";
            String rows = "9999";
            Response response =
                    given()
                            .header("userid", uid)
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //params
                            .param("queryServiceId", seriveiddatasetNew)
                            .param("userid", uid)
                            .param("from", from)
                            .param("rows", rows)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetFieldValues)
                            .then()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK ) {
                HashMap<String, Object> resp = from(response.asString()).get("queryServices");
                String success = resp.get("success").toString();
                System.out.println("responsee:" + resp);

                //Assertions
                Assert.assertEquals(success, true);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //getAllFilter
    public static void getAllFilter(String datasetId,String uid, String spaceKey, String authToken, int statusCode) {
        try {
            String from = "0";
            String rows = "9999";
            Response response =
                    given()
                            .header("userID", uid)
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //params
                            .param("id", datasetId)
                            .param("userid", uid)
                            .param("from", from)
                            .param("rows", rows)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetAllFilter)
                            .then()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK ) {
                HashMap<String, Object> resp_QueryServices = from(response.asString()).get("queryServices");
                List<HashMap<String, Object>> fieldName = (ArrayList<HashMap<String,Object>>)resp_QueryServices.get("fieldName");

                //Asserting to check fields are not empty
                for (HashMap fieldNameObj:fieldName) {
                    Assert.assertNotNull(fieldNameObj);
                }
                String success = resp_QueryServices.get("success").toString();
                System.out.println("response_QueryService:" + resp_QueryServices);

                //Assertions
                Assert.assertEquals(success, "true");

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //getAllFilter
    public static void getFieldValues(String queryServiceId,String uid, String spaceKey, String authToken, int statusCode) {
        try {
           /* queryServiceId: 158990393
            token: 16c0f834fcd1817123a2b7406609f2816354
            spacekey: 6354
            userid: 158630010
            from: 0
            rows: 9999*/
            String from = "0";
            String rows = "9999";
            Response response =
                    given()
                            .header("userID", uid)
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //params
                            .param("queryServiceId", queryServiceId)
                            .param("userid", uid)
                            .param("from", from)
                            .param("rows", rows)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetFieldValues)
                            .then()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK ) {
                HashMap<String, Object> resp_QueryServices = from(response.asString()).get("queryServices");
                List<HashMap<String, Object>> fieldName = (ArrayList<HashMap<String,Object>>)resp_QueryServices.get("fieldName");

                String success = resp_QueryServices.get("success").toString();
                System.out.println("response_QueryService:" + resp_QueryServices);

                //Assertions
                Assert.assertEquals(success, "true");

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //getAllWorkspaceAndDashboard
    public static void getAllWorkspaceAndDashboard(String uid, String spaceKey, String authToken,int statusCode) {
        try {
            Response response =
                    given()
                            .header("userid", uid)
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //params
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetAllWorkspaceAndDashboard)
                            .then()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK ) {
                HashMap<String, Object> DesignerResp = from(response.asString()).get("DesignerResp");
                List<HashMap<String, Object>> dashboards = (ArrayList<HashMap<String, Object>>) DesignerResp.get("dashboards");
                String success = DesignerResp.get("success").toString();
                System.out.println("DesignerResp:" + DesignerResp);

                //Assertions
                for (HashMap<String, Object> dashboardsObj : dashboards) {
                    if (dashboardsObj.containsKey("dashboardName") && dashboardsObj.get("dashboardName").toString().equals(moveRestWorkSpace))
                        getWorkSpaceId = dashboardsObj.get("dashboardId").toString();
                    Assert.assertNotNull(dashboardsObj.get("dashboardId"));
                }
                Assert.assertEquals(success, "true");
            }
            LOGGER.info("successful execution");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //gettrashitems
    public static void gettrashitems(String uid, String spaceKey, String authToken, int statusCode) {
        try {
            Response response =
                    given()
                            .header("userid", uid)
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //params
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgettrashitems)
                            .then()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> DesignerResp = from(response.asString()).get("DesignerResp");
                List<HashMap<String, Object>> dashboards = (ArrayList<HashMap<String, Object>>) DesignerResp.get("dashboards");
                String success = DesignerResp.get("success").toString();
                LOGGER.info("getTrahItemsDesignerResp:" + DesignerResp);

                //Assertions
                for (HashMap dashboardsObj : dashboards) {
                    Assert.assertNotNull(dashboardsObj.get("dashboardId"));
                }
                Assert.assertEquals(success, "true");
            }
            LOGGER.info("successful execution");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //create workspace and getting workspace id
    public static void fetchWorkspace(String uid, String spaceKey, String authToken, String workspaceName, String workspaceJSON, int statusCode) {
        try {
            Response response =
                    given()
                            .header("userid", uid)
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            .param("workspaceName", workspaceName)
                            .param("workspaceJSON", workspaceJSON)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlCrtWS)
                            .then()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> responseMap = from(response.asString()).get("");
                HashMap<String, Object> DesignerResp = (HashMap) responseMap.get("DesignerResp");
                String success = DesignerResp.get("success").toString();
                Object params = DesignerResp.get("params");
                JSONParser parser = new JSONParser();
                JSONObject object = (JSONObject) parser.parse(params.toString());
                workspaceId = object.get("id").toString();
                System.out.println("params:" + params);
                System.out.println("workspaceId is" + workspaceId);

                //Assertions
                Assert.assertNotNull(workspaceId);
                Assert.assertEquals(success, "true");
            }
            LOGGER.info("successful execution");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //rename workspace
    public static void renameOrmoveWorkspace(String dashboardParameters,String uid, String spaceKey, String authToken,int statusCode) {
        try {
            Response response =
                    given()
                            .header("userid", uid)
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //params
                            .param("dashboardParameters", dashboardParameters)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlupdateDashboardOrWorkspace)
                            .then()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> DesignerResp = from(response.asString()).get("DesignerResp");
                String success = DesignerResp.get("success").toString();
                Object params = DesignerResp.get("params");
                JSONParser parser = new JSONParser();
                JSONObject object = (JSONObject) parser.parse(params.toString());
                dashboardId = object.get("dashboardId").toString();
                System.out.println("params:" + params);
                LOGGER.info("renameworkspaceId is" + dashboardId);
                System.out.println("renameDesignerResp:" + DesignerResp);

                //Assertions
                Assert.assertEquals(success, "true");
                Assert.assertNotNull(workspaceId);
            }

            LOGGER.info("Successfull execution");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //trash workspace
    public  void trashWorkspace(String dashboardParameters,String uid, String spaceKey, String authToken,int statusCode) {
        try {
            Response response =
                    given()
                            .header("userid", uid)
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //params
                            .param("dashboardParameters", dashboardParameters)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urltrashdashboard)
                            .then()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> DesignerResp = from(response.asString()).get("DesignerResp");
                String success = DesignerResp.get("success").toString();
                Object params = DesignerResp.get("params");
                JSONParser parser = new JSONParser();
                JSONObject object = (JSONObject) parser.parse(params.toString());
                wrkSpaceId = object.get("workspaceId").toString();
                System.out.println("params:" + params);
                LOGGER.info("deleteworkspaceId is" + wrkSpaceId);
                System.out.println("deleteDesignerResp:" + DesignerResp);

                //Assertions
                Assert.assertEquals(success, "true");
                Assert.assertNotNull(wrkSpaceId, "Workspace moved to Trash!....");
            }
            LOGGER.info("successful execution");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //Delete dashboard or worksapce permanently
    public  String deleteDashboardPermanently(String dashboardParameters,String uid, String spaceKey, String authToken,int statusCode) {
        try {
            Response response =
                    given()
                            .header("userid", uid)
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //params
                            .param("dashboardParameters", dashboardParameters)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urldeleteDashboardPermanently)
                            .then()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> DesignerResp = from(response.asString()).get("DesignerResp");
                String success = DesignerResp.get("success").toString();
                params_deleteDashPermnant = (String) DesignerResp.get("params");
                System.out.println("params:" + params_deleteDashPermnant);
                System.out.println("deleteworkspacepermanentlyDesignerResp:" + DesignerResp);

                //Assertions
                Assert.assertEquals(success, "true");
            }

            LOGGER.info("Successfull execution");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return params_deleteDashPermnant;
    }

    //Restore Workspace
    public  void restoredashboardfromtrash(String dashboardParameters,String uid, String spaceKey, String authToken,int statusCode) {
        try {
            Response response =
                    given()
                            .header("userid", uid)
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //params
                            .param("dashboardParameters", dashboardParameters)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlrestoredashboardfromtrash)
                            .then()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> DesignerResp = from(response.asString()).get("DesignerResp");
                String success = DesignerResp.get("success").toString();
                Object params = DesignerResp.get("params");
                JSONParser parser = new JSONParser();
                JSONObject object = (JSONObject) parser.parse(params.toString());
                workspaceId = object.get("workspaceId").toString();
                System.out.println("params:" + params);
                LOGGER.info("RestoreworkspaceId is" + workspaceId);
                System.out.println("RestoreDesignerResp:" + DesignerResp);

                //Assertions
                Assert.assertEquals(success, "true");
                Assert.assertNotNull(workspaceId);
            }
            LOGGER.info("successful execution");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // createWeb- service dashboard
    public static  void fetchDashboardWebservice(String dashboardParameters, String uid, String spaceKey, String authToken,int statusCode) {
        try {
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userid", uid)
                            .header("authtoken", authToken)
                            //Param
                            .param("dashboardParameters", dashboardParameters)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlCrtDB)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> responseMap = from(response.asString()).get("");
                HashMap<String, Object> DesignerResp = (HashMap) responseMap.get("DesignerResp");

                Object obj = DesignerResp.get("params");
                System.out.println(obj);

                JSONParser parser = new JSONParser();
                JSONObject object = (JSONObject) parser.parse(obj.toString());
                dashboardId = object.get("dashboardId").toString();
                System.out.println("dashboardIdCreate is=====:" + dashboardId);

                //Assertion
                Assert.assertEquals(DesignerResp.get("success"), true);
                Assert.assertNotNull(dashboardId);

            }
            Date dt = new Date();
            String didtime = "dashboard" + dt.getTime();

            if(statusCode == HttpStatus.SC_OK) {
                //Save Dashboard
                String dashboardParameters2 = "{\"workspaceId\":\""+ workspaceId+"\",\"dashboardId\":\""+dashboardId+"\",\"dashboardName\":\""+designerDashName+"\",\"dashboardJSON\":\"{\\\"Dashboard\\\":{\\\"id\\\":\\\""+didtime+"\\\",\\\"backendId\\\":\\\""+dashboardId +"\\\",\\\"workspaceId\\\":\\\""+ workspaceId+"\\\",\\\"DashboardOptions\\\":{\\\"publishWSDLServer\\\":\\\"\\\",\\\"expiryDate\\\":\\\"\\\",\\\"hasExpiry\\\":\\\"\\\"},\\\"versionDetails\\\":{\\\"author\\\":\\\"BizViz Technologies Pvt. Ltd.\\\",\\\"edittedBy\\\":\\\"\\\",\\\"lastUpdate\\\":\\\""+dt +"\\\",\\\"dashboardVersion\\\":\\\"3.2.1\\\",\\\"publishDocId\\\":\\\"\\\",\\\"lastPublishedVersion\\\":\\\"\\\",\\\"createdDesignerVersion\\\":\\\"\\\",\\\"lastUpdatedDesignerVersion\\\":\\\"3.x-F1002\\\",\\\"lastUpdatedDesignerDate\\\":\\\"12/01/2018\\\"},\\\"FlashVars\\\":{\\\"Param\\\":[{\\\"name\\\":\\\"token\\\",\\\"value\\\":\\\""+authToken+"\\\"}]},\\\"AuthProfiles\\\":{\\\"Profile\\\":[]},\\\"DataProviders\\\":{\\\"DataURL\\\":[{\\\"FieldSet\\\":[{\\\"name\\\":\\\"meal_size\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true},{\\\"name\\\":\\\"order_detail_id\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true},{\\\"name\\\":\\\"space_key\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true},{\\\"name\\\":\\\"total_cost\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true},{\\\"name\\\":\\\"total_tax\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true}],\\\"WhereClause\\\":{\\\"Con\\\":{\\\"Clause\\\":\\\"\\\",\\\"ClauseMap\\\":{}}},\\\"dataType\\\":\\\"JSON\\\",\\\"variable\\\":{\\\"Key\\\":\\\"C_1\\\",\\\"userScript\\\":{\\\"value\\\":\\\"\\\"},\\\"DefaultValues\\\":{\\\"DefaultValue\\\":[]}},\\\"refreshMinutes\\\":5,\\\"timelyRefresh\\\":\\\"false\\\",\\\"profileName\\\":\\\"\\\",\\\"hasMapping\\\":\\\"false\\\",\\\"offLineDataID\\\":\\\"\\\",\\\"id\\\":\\\"C_1\\\",\\\"DrillWhenDataChanges\\\":\\\"false\\\",\\\"LoadatStartup\\\":\\\"true\\\",\\\"Type\\\":\\\"web\\\",\\\"isLangWebservice\\\":\\\"false\\\",\\\"password\\\":\\\"\\\",\\\"url\\\":\\\""+queryLink+"\\\",\\\"queryName\\\":\\\""+queryname+"\\\",\\\"nividhQueryName\\\":\\\""+nividhQueryName+"\\\",\\\"dataSourceName\\\":\\\""+dataSourceName +"\\\",\\\"dataSourceType\\\":\\\"mysql\\\",\\\"hostName\\\":\\\""+hostName+"\\\",\\\"databaseName\\\":\\\""+databaseName+"\\\",\\\"sheet\\\":\\\"\\\",\\\"rowLimit\\\":\\\"\\\",\\\"PredictiveJsonDef\\\":\\\"\\\",\\\"parentSource\\\":\\\"\\\",\\\"childSource\\\":\\\"\\\",\\\"deriveConditions\\\":{\\\"criteria\\\":[\\\"\\\"]},\\\"availableFieldSet\\\":[{\\\"name\\\":\\\"meal_size\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true},{\\\"name\\\":\\\"order_detail_id\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true},{\\\"name\\\":\\\"space_key\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true},{\\\"name\\\":\\\"total_cost\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true},{\\\"name\\\":\\\"total_tax\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true}],\\\"allowSessionID\\\":\\\"false\\\",\\\"userID\\\":\\\"\\\",\\\"selectedDataSourceID\\\":"+datasourceidNew+",\\\"selectedServiceID\\\":"+seriveiddatasetNew+",\\\"availableConditionSet\\\":[],\\\"AssociatedDataSet\\\":[{\\\"component\\\":\\\"datagrid1\\\",\\\"id\\\":\\\"datagrid1\\\"}],\\\"AssociatedVirtualDataset\\\":[],\\\"query\\\":{\\\"filters\\\":{\\\"value\\\":\\\"\\\"}},\\\"connectionName\\\":\\\"Connection-1\\\",\\\"typeSpecifier\\\":\\\"web\\\",\\\"calculatedFieldList\\\":[],\\\"isUiActive\\\":true,\\\"isUiActiveCA\\\":false,\\\"serviceType\\\":\\\"bizviz\\\"}],\\\"queryServiceList\\\":[],\\\"selectedConnection\\\":{\\\"FieldSet\\\":[{\\\"name\\\":\\\"meal_size\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true},{\\\"name\\\":\\\"order_detail_id\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true},{\\\"name\\\":\\\"space_key\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true},{\\\"name\\\":\\\"total_cost\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true},{\\\"name\\\":\\\"total_tax\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true}],\\\"WhereClause\\\":{\\\"Con\\\":{\\\"Clause\\\":\\\"\\\",\\\"ClauseMap\\\":{}}},\\\"dataType\\\":\\\"JSON\\\",\\\"variable\\\":{\\\"Key\\\":\\\"C_1\\\",\\\"userScript\\\":{\\\"value\\\":\\\"\\\"},\\\"DefaultValues\\\":{\\\"DefaultValue\\\":[]}},\\\"refreshMinutes\\\":5,\\\"timelyRefresh\\\":\\\"false\\\",\\\"profileName\\\":\\\"\\\",\\\"hasMapping\\\":\\\"false\\\",\\\"offLineDataID\\\":\\\"\\\",\\\"id\\\":\\\"C_1\\\",\\\"DrillWhenDataChanges\\\":\\\"false\\\",\\\"LoadatStartup\\\":\\\"true\\\",\\\"Type\\\":\\\"web\\\",\\\"isLangWebservice\\\":\\\"false\\\",\\\"password\\\":\\\"\\\",\\\"url\\\":\\\""+queryLink +"\\\",\\\"queryName\\\":\\\""+queryname+"\\\",\\\"nividhQueryName\\\":\\\""+nividhQueryName+"\\\",\\\"dataSourceName\\\":\\\""+dataSourceName+"\\\",\\\"dataSourceType\\\":\\\"mysql\\\",\\\"hostName\\\":\\\""+hostName+"\\\",\\\"databaseName\\\":\\\""+databaseName+"\\\",\\\"sheet\\\":\\\"\\\",\\\"rowLimit\\\":\\\"\\\",\\\"PredictiveJsonDef\\\":\\\"\\\",\\\"parentSource\\\":\\\"\\\",\\\"childSource\\\":\\\"\\\",\\\"deriveConditions\\\":{\\\"criteria\\\":[\\\"\\\"]},\\\"availableFieldSet\\\":[{\\\"name\\\":\\\"meal_size\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true},{\\\"name\\\":\\\"order_detail_id\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true},{\\\"name\\\":\\\"space_key\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true},{\\\"name\\\":\\\"total_cost\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true},{\\\"name\\\":\\\"total_tax\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"added\\\":true}],\\\"allowSessionID\\\":\\\"false\\\",\\\"userID\\\":\\\"\\\",\\\"selectedDataSourceID\\\":"+datasourceidNew+",\\\"selectedServiceID\\\":"+seriveiddatasetNew +",\\\"availableConditionSet\\\":[],\\\"AssociatedDataSet\\\":[{\\\"component\\\":\\\"datagrid1\\\",\\\"id\\\":\\\"datagrid1\\\"}],\\\"AssociatedVirtualDataset\\\":[],\\\"query\\\":{\\\"filters\\\":{\\\"value\\\":\\\"\\\"}},\\\"connectionName\\\":\\\"Connection-1\\\",\\\"typeSpecifier\\\":\\\"web\\\",\\\"calculatedFieldList\\\":[],\\\"isUiActive\\\":true,\\\"isUiActiveCA\\\":false,\\\"serviceType\\\":\\\"bizviz\\\"}},\\\"componentGroups\\\":[],\\\"VirtualDataSet\\\":[],\\\"imports\\\":[\\\"SimpleDataGrid\\\"],\\\"importsStat\\\":1,\\\"GlobalVariable\\\":{\\\"Variable\\\":[]},\\\"OffLineData\\\":{\\\"Data\\\":[]},\\\"DatasetExpressions\\\":{\\\"DatasetExpression\\\":[]},\\\"AbsoluteLayout\\\":{\\\"gradientRotation\\\":\\\"0\\\",\\\"gradients\\\":\\\"#FFFFFF\\\",\\\"bgAlpha\\\":\\\"1\\\",\\\"borderThickness\\\":1,\\\"borderColor\\\":\\\"#08AEA8\\\",\\\"showShadow\\\":\\\"false\\\",\\\"shadowColor\\\":\\\"#000000\\\",\\\"shadowOpacity\\\":\\\"0.1\\\",\\\"resolution\\\":\\\"929x566\\\",\\\"width\\\":1540,\\\"height\\\":709,\\\"useGlobalFont\\\":\\\"false\\\",\\\"fontFamily\\\":\\\"'Raleway', sans-serif\\\",\\\"designerTheme\\\":\\\"default-theme\\\",\\\"useFontFromUrl\\\":\\\"false\\\",\\\"isAllLockedComponents\\\":\\\"false\\\",\\\"visibilityEffects\\\":\\\"false\\\",\\\"enableWatermark\\\":\\\"true\\\",\\\"fontUrl\\\":\\\"\\\",\\\"isBootstrap\\\":\\\"false\\\",\\\"scalingEnabled\\\":\\\"false\\\",\\\"scalingView\\\":\\\"fitToPage\\\",\\\"touchEnabled\\\":\\\"false\\\",\\\"Object\\\":[{\\\"componentType\\\":\\\"simple_data_grid\\\",\\\"objectName\\\":\\\"datagrid1\\\",\\\"showLocked\\\":false,\\\"subElement\\\":\\\"DataGrid\\\",\\\"globalVariableKeyAttribute\\\":\\\"Globalkey\\\",\\\"isDataSetAvailable\\\":\\\"true\\\",\\\"enableScript\\\":\\\"true\\\",\\\"referenceID\\\":\\\"datagrid1\\\",\\\"isValueFieldsAvailable\\\":\\\"false\\\",\\\"showContextMenu\\\":\\\"false\\\",\\\"shortName\\\":\\\"datagrid\\\",\\\"objectType\\\":\\\"datagrid\\\",\\\"width\\\":\\\"480\\\",\\\"unShowHidden\\\":false,\\\"groupings\\\":\\\"\\\",\\\"percentheight\\\":\\\"320\\\",\\\"initialVisibility\\\":\\\"true\\\",\\\"x\\\":64,\\\"height\\\":\\\"275\\\",\\\"y\\\":124,\\\"percentwidth\\\":\\\"450\\\",\\\"objectID\\\":\\\"BVZ713b4416-ccbf-4d21-b114-8eec9ada75bd\\\",\\\"DataGrid\\\":{\\\"CompareIndices\\\":\\\"\\\",\\\"URL\\\":\\\"\\\",\\\"pptSubHeading\\\":\\\"Sub Heading\\\",\\\"scrnShotFileName\\\":\\\"exportDashboard\\\",\\\"pptHeading\\\":\\\"Heading\\\",\\\"Globalkey\\\":\\\"pagegrid13\\\",\\\"screenShotMode\\\":\\\"ppt\\\",\\\"showExcelDownload\\\":\\\"true\\\",\\\"colorByComparison\\\":\\\"false\\\",\\\"pagerBackgroundColor\\\":\\\"#a7a9ab\\\",\\\"GaugeClickEnable\\\":\\\"false\\\",\\\"bgAlpha\\\":\\\"1\\\",\\\"bgGradientRotation\\\":\\\"0\\\",\\\"FontStyle\\\":\\\"normal\\\",\\\"labelFontFamily\\\":\\\"'Raleway', sans-serif\\\",\\\"bgGradients\\\":\\\"16777215\\\",\\\"showBorder\\\":\\\"false\\\",\\\"borderColor\\\":\\\"#BDC3C7\\\",\\\"borderThickness\\\":\\\"1\\\",\\\"showShadow\\\":\\\"false\\\",\\\"shadowColor\\\":\\\"#000000\\\",\\\"shadowOpacity\\\":\\\"0.1\\\",\\\"fitColumns\\\":\\\"true\\\",\\\"Name\\\":\\\"true\\\",\\\"Align\\\":\\\"left\\\",\\\"RowHeight\\\":\\\"30\\\",\\\"MaxRowCount\\\":\\\"20\\\",\\\"labelTextDecoration\\\":\\\"none\\\",\\\"showinfobutton\\\":\\\"false\\\",\\\"labelFontSize\\\":12,\\\"DataGridType\\\":\\\"Datagrid\\\",\\\"labelFontStyle\\\":\\\"normal\\\",\\\"AlertType\\\":\\\"bar\\\",\\\"RowCount\\\":10,\\\"xmlwithColorColumn\\\":\\\"false\\\",\\\"labelFontColor\\\":\\\"#000000\\\",\\\"AlertWithData\\\":\\\"false\\\",\\\"AlertValues\\\":\\\"30,50,70\\\",\\\"labelFontWeight\\\":\\\"normal\\\",\\\"showMaximizeButton\\\":\\\"false\\\",\\\"FontWeight\\\":\\\"normal\\\",\\\"TextDecoration\\\":\\\"none\\\",\\\"pptServiceURL\\\":\\\"http://www.bdbizviz.com/PPT/Parser\\\",\\\"FontFamily\\\":\\\"'Raleway', sans-serif\\\",\\\"AlertColors\\\":\\\"#FF0000,#FFFF00,#0000FF,#00FF00\\\",\\\"showGradient\\\":\\\"false\\\",\\\"GradientColor\\\":\\\"#F5F5F5,#F5F5F5\\\",\\\"valuesGood\\\":\\\"high\\\",\\\"id\\\":\\\"Obj.FB2D7861N44F1ND321N2D80NBF4DA5E223AA\\\",\\\"gaugeOrder\\\":\\\"1\\\",\\\"headerFontStyle\\\":\\\"normal\\\",\\\"headerFontSize\\\":14,\\\"headerFontColor\\\":\\\"#000000\\\",\\\"headerFontWeight\\\":\\\"normal\\\",\\\"headerSymbolColor\\\":\\\"#000000\\\",\\\"headerchromeColor\\\":\\\"#f7f7f7\\\",\\\"headerTextAlign\\\":\\\"left\\\",\\\"headerTextDecoration\\\":\\\"none\\\",\\\"headerFontFamily\\\":\\\"'Raleway', sans-serif\\\",\\\"FontColor\\\":\\\"#000000\\\",\\\"showTitle\\\":\\\"false\\\",\\\"FontSize\\\":\\\"13\\\",\\\"exportToExcel\\\":\\\"true\\\",\\\"exportToJPEG\\\":\\\"true\\\",\\\"exportToPNG\\\":\\\"true\\\",\\\"exportToPDF\\\":\\\"true\\\",\\\"exportToPPT\\\":\\\"true\\\",\\\"exportToPrint\\\":\\\"true\\\",\\\"showScreenShotButton\\\":\\\"true\\\",\\\"textWrap\\\":\\\"false\\\",\\\"useFieldColorAsHeader\\\":\\\"false\\\",\\\"Title\\\":{\\\"FontWeight\\\":\\\"normal\\\",\\\"Description\\\":\\\"Title\\\",\\\"FontSize\\\":\\\"12\\\",\\\"TextDecoration\\\":\\\"none\\\",\\\"Align\\\":\\\"left\\\",\\\"FontFamily\\\":\\\"'Raleway', sans-serif\\\",\\\"FontColor\\\":\\\"#808080\\\",\\\"FontStyle\\\":\\\"normal\\\",\\\"showTitle\\\":\\\"false\\\",\\\"TitleBarHeight\\\":\\\"25\\\"},\\\"SubTitle\\\":{\\\"FontColor\\\":\\\"0\\\",\\\"FontStyle\\\":\\\"normal\\\",\\\"FontFamily\\\":\\\"'Raleway', sans-serif\\\",\\\"Align\\\":\\\"center\\\",\\\"TextDecoration\\\":\\\"none\\\",\\\"showSubTitle\\\":\\\"false\\\",\\\"FontSize\\\":\\\"12\\\",\\\"Description\\\":\\\"SubTitleDescription\\\",\\\"FontWeight\\\":\\\"normal\\\"},\\\"DatagridStyles\\\":{\\\"horizontalGridLineColor\\\":\\\"#f6f6f6\\\",\\\"verticalGridLineColor\\\":\\\"#f9f9f9\\\",\\\"selectionColor\\\":\\\"#fcfcfc\\\",\\\"rollOverColor\\\":\\\"#e4fde4\\\",\\\"enableItemrenderer\\\":\\\"false\\\",\\\"alternateRowsColor\\\":\\\"#ffffff,#ffffff\\\",\\\"showhorizontalGridLines\\\":\\\"true\\\"},\\\"Column\\\":{\\\"columnwiseFill\\\":\\\"true\\\",\\\"columnColorArray\\\":\\\"#FF0000,#00CC00,#0000DD,#FFCC00\\\",\\\"columnIndeciesArray\\\":\\\"1:2:3,2:3,1:3,3\\\"},\\\"RowData\\\":{\\\"rowwiseFill\\\":\\\"false\\\",\\\"rowIndeciesArray\\\":\\\"3,5,9,11\\\",\\\"allIndeciesArray\\\":\\\"\\\"},\\\"LinkButton\\\":{\\\"Id\\\":\\\"Linkbar\\\",\\\"Description\\\":\\\"ShowAll\\\",\\\"TextRolloverColor\\\":\\\"26214\\\",\\\"TextColor\\\":\\\"0\\\",\\\"TextSelectedColor\\\":\\\"204\\\",\\\"TitRolloverColorle\\\":\\\"52479\\\",\\\"SelectedColor\\\":\\\"32425\\\"},\\\"LinkBar\\\":{\\\"SelectedColor\\\":\\\"13311\\\",\\\"LinkBarColor\\\":\\\"#020f0e\\\",\\\"TextRolloverColor\\\":\\\"16777062\\\",\\\"SeperatorColor\\\":\\\"0\\\",\\\"TextColor\\\":\\\"0\\\",\\\"TextSelectedColor\\\":\\\"13209\\\",\\\"RolloverColor\\\":\\\"13311\\\"},\\\"Alerts\\\":{},\\\"DataSet\\\":{\\\"id\\\":\\\"datagrid1\\\",\\\"dataSource\\\":\\\"C_1\\\",\\\"Fields\\\":[{\\\"secondformatter\\\":\\\"Number\\\",\\\"isfixedlabel\\\":\\\"false\\\",\\\"unitname\\\":\\\"none\\\",\\\"precision\\\":\\\"default\\\",\\\"showTooltip\\\":\\\"false\\\",\\\"Type\\\":\\\"Series\\\",\\\"displayTextStyle\\\":\\\"\\\",\\\"width\\\":\\\"150\\\",\\\"isNumeric\\\":\\\"false\\\",\\\"visible\\\":\\\"true\\\",\\\"frozencolumn\\\":\\\"false\\\",\\\"sorting\\\":\\\"true\\\",\\\"secondunitname\\\":\\\"none\\\",\\\"formatter\\\":\\\"Currency\\\",\\\"textAlign\\\":\\\"left\\\",\\\"signposition\\\":\\\"suffix\\\",\\\"fieldname\\\":\\\"meal_size\\\",\\\"displayname\\\":\\\"meal_size\\\",\\\"Name\\\":\\\"meal_size\\\",\\\"hierarchyType\\\":\\\"none\\\",\\\"parentAggregation\\\":\\\"sum\\\",\\\"Color\\\":\\\"#006684\\\",\\\"cellType\\\":\\\"none\\\",\\\"numberFormatter\\\":\\\"none\\\",\\\"rowAggregation\\\":\\\"none\\\",\\\"fieldType\\\":\\\"Field\\\",\\\"OtherField\\\":\\\"meal_size\\\",\\\"OtherFieldDisplayName\\\":\\\"meal_size\\\",\\\"ColorFieldDisplayName\\\":\\\"Color\\\",\\\"RadiusFieldDisplayName\\\":\\\"Radius\\\",\\\"iconPath\\\":\\\"./resources/images/svg/Column.svg\\\"},{\\\"secondformatter\\\":\\\"Number\\\",\\\"isfixedlabel\\\":\\\"false\\\",\\\"unitname\\\":\\\"none\\\",\\\"precision\\\":\\\"default\\\",\\\"showTooltip\\\":\\\"false\\\",\\\"Type\\\":\\\"Series\\\",\\\"displayTextStyle\\\":\\\"\\\",\\\"width\\\":\\\"150\\\",\\\"isNumeric\\\":\\\"false\\\",\\\"visible\\\":\\\"true\\\",\\\"frozencolumn\\\":\\\"false\\\",\\\"sorting\\\":\\\"true\\\",\\\"secondunitname\\\":\\\"none\\\",\\\"formatter\\\":\\\"Currency\\\",\\\"textAlign\\\":\\\"left\\\",\\\"signposition\\\":\\\"suffix\\\",\\\"fieldname\\\":\\\"order_detail_id\\\",\\\"displayname\\\":\\\"order_detail_id\\\",\\\"Name\\\":\\\"order_detail_id\\\",\\\"hierarchyType\\\":\\\"none\\\",\\\"parentAggregation\\\":\\\"sum\\\",\\\"Color\\\":\\\"#86dff9\\\",\\\"cellType\\\":\\\"none\\\",\\\"numberFormatter\\\":\\\"none\\\",\\\"rowAggregation\\\":\\\"none\\\",\\\"fieldType\\\":\\\"Field\\\",\\\"OtherField\\\":\\\"order_detail_id\\\",\\\"OtherFieldDisplayName\\\":\\\"order_detail_id\\\",\\\"ColorFieldDisplayName\\\":\\\"Color\\\",\\\"RadiusFieldDisplayName\\\":\\\"Radius\\\",\\\"iconPath\\\":\\\"./resources/images/svg/Column.svg\\\"},{\\\"secondformatter\\\":\\\"Number\\\",\\\"isfixedlabel\\\":\\\"false\\\",\\\"unitname\\\":\\\"none\\\",\\\"precision\\\":\\\"default\\\",\\\"showTooltip\\\":\\\"false\\\",\\\"Type\\\":\\\"Series\\\",\\\"displayTextStyle\\\":\\\"\\\",\\\"width\\\":\\\"150\\\",\\\"isNumeric\\\":\\\"false\\\",\\\"visible\\\":\\\"true\\\",\\\"frozencolumn\\\":\\\"false\\\",\\\"sorting\\\":\\\"true\\\",\\\"secondunitname\\\":\\\"none\\\",\\\"formatter\\\":\\\"Currency\\\",\\\"textAlign\\\":\\\"left\\\",\\\"signposition\\\":\\\"suffix\\\",\\\"fieldname\\\":\\\"space_key\\\",\\\"displayname\\\":\\\"space_key\\\",\\\"Name\\\":\\\"space_key\\\",\\\"hierarchyType\\\":\\\"none\\\",\\\"parentAggregation\\\":\\\"sum\\\",\\\"Color\\\":\\\"#f89406\\\",\\\"cellType\\\":\\\"none\\\",\\\"numberFormatter\\\":\\\"none\\\",\\\"rowAggregation\\\":\\\"none\\\",\\\"fieldType\\\":\\\"Field\\\",\\\"OtherField\\\":\\\"space_key\\\",\\\"OtherFieldDisplayName\\\":\\\"space_key\\\",\\\"ColorFieldDisplayName\\\":\\\"Color\\\",\\\"RadiusFieldDisplayName\\\":\\\"Radius\\\",\\\"iconPath\\\":\\\"./resources/images/svg/Column.svg\\\"},{\\\"secondformatter\\\":\\\"Number\\\",\\\"isfixedlabel\\\":\\\"false\\\",\\\"unitname\\\":\\\"none\\\",\\\"precision\\\":\\\"default\\\",\\\"showTooltip\\\":\\\"false\\\",\\\"Type\\\":\\\"Series\\\",\\\"displayTextStyle\\\":\\\"\\\",\\\"width\\\":\\\"150\\\",\\\"isNumeric\\\":\\\"false\\\",\\\"visible\\\":\\\"true\\\",\\\"frozencolumn\\\":\\\"false\\\",\\\"sorting\\\":\\\"true\\\",\\\"secondunitname\\\":\\\"none\\\",\\\"formatter\\\":\\\"Currency\\\",\\\"textAlign\\\":\\\"left\\\",\\\"signposition\\\":\\\"suffix\\\",\\\"fieldname\\\":\\\"total_cost\\\",\\\"displayname\\\":\\\"total_cost\\\",\\\"Name\\\":\\\"total_cost\\\",\\\"hierarchyType\\\":\\\"none\\\",\\\"parentAggregation\\\":\\\"sum\\\",\\\"Color\\\":\\\"#e0dfdf\\\",\\\"cellType\\\":\\\"none\\\",\\\"numberFormatter\\\":\\\"none\\\",\\\"rowAggregation\\\":\\\"none\\\",\\\"fieldType\\\":\\\"Field\\\",\\\"OtherField\\\":\\\"total_cost\\\",\\\"OtherFieldDisplayName\\\":\\\"total_cost\\\",\\\"ColorFieldDisplayName\\\":\\\"Color\\\",\\\"RadiusFieldDisplayName\\\":\\\"Radius\\\",\\\"iconPath\\\":\\\"./resources/images/svg/Column.svg\\\"},{\\\"secondformatter\\\":\\\"Number\\\",\\\"isfixedlabel\\\":\\\"false\\\",\\\"unitname\\\":\\\"none\\\",\\\"precision\\\":\\\"default\\\",\\\"showTooltip\\\":\\\"false\\\",\\\"Type\\\":\\\"Series\\\",\\\"displayTextStyle\\\":\\\"\\\",\\\"width\\\":\\\"150\\\",\\\"isNumeric\\\":\\\"false\\\",\\\"visible\\\":\\\"true\\\",\\\"frozencolumn\\\":\\\"false\\\",\\\"sorting\\\":\\\"true\\\",\\\"secondunitname\\\":\\\"none\\\",\\\"formatter\\\":\\\"Currency\\\",\\\"textAlign\\\":\\\"left\\\",\\\"signposition\\\":\\\"suffix\\\",\\\"fieldname\\\":\\\"total_tax\\\",\\\"displayname\\\":\\\"total_tax\\\",\\\"Name\\\":\\\"total_tax\\\",\\\"hierarchyType\\\":\\\"none\\\",\\\"parentAggregation\\\":\\\"sum\\\",\\\"Color\\\":\\\"#17becf\\\",\\\"cellType\\\":\\\"none\\\",\\\"numberFormatter\\\":\\\"none\\\",\\\"rowAggregation\\\":\\\"none\\\",\\\"fieldType\\\":\\\"Field\\\",\\\"OtherField\\\":\\\"total_tax\\\",\\\"OtherFieldDisplayName\\\":\\\"total_tax\\\",\\\"ColorFieldDisplayName\\\":\\\"Color\\\",\\\"RadiusFieldDisplayName\\\":\\\"Radius\\\",\\\"iconPath\\\":\\\"./resources/images/svg/Column.svg\\\"}]}},\\\"designData\\\":{\\\"name\\\":\\\"DataGrid\\\",\\\"type\\\":\\\"datagrid\\\",\\\"class\\\":\\\"SimpleDataGrid\\\",\\\"show\\\":true,\\\"icon\\\":\\\"./resources/images/svg/components/SimpleDataGrid.svg\\\"},\\\"variable\\\":{\\\"Key\\\":\\\"datagrid1\\\",\\\"userScript\\\":{\\\"value\\\":\\\"\\\",\\\"id\\\":\\\"BVZ713b4416-ccbf-4d21-b114-8eec9ada75bd\\\"},\\\"DefaultValues\\\":{\\\"DefaultValue\\\":[{\\\"name\\\":\\\"meal_size\\\",\\\"text\\\":\\\"\\\",\\\"displayTag\\\":\\\"datagrid1.meal_size\\\",\\\"actualTag\\\":\\\"{datagrid1.meal_size}\\\",\\\"actualTagForLabels\\\":\\\"[datagrid1.meal_size]\\\"},{\\\"name\\\":\\\"order_detail_id\\\",\\\"text\\\":\\\"\\\",\\\"displayTag\\\":\\\"datagrid1.order_detail_id\\\",\\\"actualTag\\\":\\\"{datagrid1.order_detail_id}\\\",\\\"actualTagForLabels\\\":\\\"[datagrid1.order_detail_id]\\\"},{\\\"name\\\":\\\"space_key\\\",\\\"text\\\":\\\"\\\",\\\"displayTag\\\":\\\"datagrid1.space_key\\\",\\\"actualTag\\\":\\\"{datagrid1.space_key}\\\",\\\"actualTagForLabels\\\":\\\"[datagrid1.space_key]\\\"},{\\\"name\\\":\\\"total_cost\\\",\\\"text\\\":\\\"\\\",\\\"displayTag\\\":\\\"datagrid1.total_cost\\\",\\\"actualTag\\\":\\\"{datagrid1.total_cost}\\\",\\\"actualTagForLabels\\\":\\\"[datagrid1.total_cost]\\\"},{\\\"name\\\":\\\"total_tax\\\",\\\"text\\\":\\\"\\\",\\\"displayTag\\\":\\\"datagrid1.total_tax\\\",\\\"actualTag\\\":\\\"{datagrid1.total_tax}\\\",\\\"actualTagForLabels\\\":\\\"[datagrid1.total_tax]\\\"}]}},\\\"isUiActiveCA\\\":true}]},\\\"name\\\":\\\"WebServiceDashboard\\\",\\\"variable\\\":{\\\"Key\\\":\\\"dashboard\\\",\\\"userScript\\\":{\\\"value\\\":\\\"\\\"},\\\"DefaultValues\\\":{\\\"DefaultValue\\\":[]}}},\\\"FlashVars_Param\\\":{\\\"name\\\":\\\"\\\",\\\"value\\\":\\\"\\\"},\\\"AuthProfiles_Profile\\\":{\\\"name\\\":\\\"Georjo\\\",\\\"username\\\":\\\"georjo.johan\\\",\\\"password\\\":\\\"niku3000\\\"},\\\"DataProviders_DataURL\\\":{\\\"FieldSet\\\":[],\\\"WhereClause\\\":{\\\"Con\\\":{\\\"Clause\\\":\\\"\\\",\\\"ClauseMap\\\":{}}},\\\"dataType\\\":\\\"JSON\\\",\\\"variable\\\":\\\"\\\",\\\"refreshMinutes\\\":5,\\\"timelyRefresh\\\":\\\"false\\\",\\\"profileName\\\":\\\"\\\",\\\"hasMapping\\\":\\\"false\\\",\\\"offLineDataID\\\":\\\"\\\",\\\"id\\\":\\\"\\\",\\\"DrillWhenDataChanges\\\":\\\"false\\\",\\\"LoadatStartup\\\":\\\"true\\\",\\\"Type\\\":\\\"web\\\",\\\"isLangWebservice\\\":\\\"false\\\",\\\"password\\\":\\\"\\\",\\\"url\\\":\\\"\\\",\\\"queryName\\\":\\\"\\\",\\\"nividhQueryName\\\":\\\"\\\",\\\"dataSourceName\\\":\\\"\\\",\\\"dataSourceType\\\":\\\"\\\",\\\"hostName\\\":\\\"\\\",\\\"databaseName\\\":\\\"\\\",\\\"sheet\\\":\\\"\\\",\\\"rowLimit\\\":\\\"\\\",\\\"PredictiveJsonDef\\\":\\\"\\\",\\\"parentSource\\\":\\\"\\\",\\\"childSource\\\":\\\"\\\",\\\"deriveConditions\\\":{\\\"criteria\\\":[\\\"\\\"]},\\\"availableFieldSet\\\":[],\\\"allowSessionID\\\":\\\"false\\\",\\\"userID\\\":\\\"\\\",\\\"selectedDataSourceID\\\":\\\"\\\",\\\"selectedServiceID\\\":\\\"\\\",\\\"availableConditionSet\\\":[],\\\"AssociatedDataSet\\\":[],\\\"AssociatedVirtualDataset\\\":[],\\\"query\\\":{\\\"filters\\\":{\\\"value\\\":\\\"\\\"}}},\\\"DataProviders_DataURL_FieldSet\\\":{\\\"name\\\":\\\"\\\",\\\"displayName\\\":\\\"\\\",\\\"type\\\":\\\"\\\"},\\\"DataProviders_DataURL_AssociatedDataSet\\\":{\\\"component\\\":\\\"\\\",\\\"id\\\":\\\"\\\"},\\\"DataProviders_DataURL_AssociatedVirtualDataset\\\":{\\\"component\\\":\\\"\\\",\\\"id\\\":\\\"\\\"},\\\"DatasetExpressions_DatasetExpression\\\":{\\\"name\\\":\\\"\\\",\\\"id\\\":\\\"\\\",\\\"dataSource\\\":\\\"\\\",\\\"variables\\\":{\\\"variable\\\":[]},\\\"expressionScript\\\":{\\\"cdata\\\":\\\"\\\"}},\\\"DatasetExpressions_DatasetExpression_variables_variable\\\":{\\\"name\\\":\\\"\\\",\\\"value\\\":\\\"\\\"},\\\"AbsoluteLayout_Object\\\":{\\\"objectType\\\":\\\"chart\\\",\\\"objectID\\\":\\\"\\\",\\\"width\\\":\\\"355\\\",\\\"showLocked\\\":\\\"false\\\",\\\"objectName\\\":\\\"Area_9\\\",\\\"unShowHidden\\\":\\\"false\\\",\\\"groupings\\\":\\\"\\\",\\\"x\\\":\\\"13\\\",\\\"height\\\":\\\"308\\\",\\\"y\\\":\\\"30\\\",\\\"percentheight\\\":\\\"308\\\",\\\"initialVisibility\\\":\\\"true\\\",\\\"percentwidth\\\":\\\"355\\\"},\\\"AbsoluteLayout_Object_Chart_DataSet\\\":{\\\"id\\\":\\\"\\\",\\\"dataSource\\\":\\\"\\\",\\\"Fields\\\":[]},\\\"AbsoluteLayout_Object_DataGrid_DataSet\\\":{\\\"id\\\":\\\"\\\",\\\"dataSource\\\":\\\"\\\",\\\"Fields\\\":[]},\\\"AbsoluteLayout_Object_Scorecard_DataSet\\\":{\\\"id\\\":\\\"\\\",\\\"dataSource\\\":\\\"\\\",\\\"Fields\\\":[]},\\\"AbsoluteLayout_Object_Filter_DataSet\\\":{\\\"id\\\":\\\"\\\",\\\"dataSource\\\":\\\"\\\",\\\"Fields\\\":[]},\\\"AbsoluteLayout_Object_Funnel_DataSet\\\":{\\\"id\\\":\\\"\\\",\\\"dataSource\\\":\\\"\\\",\\\"Fields\\\":[]},\\\"AbsoluteLayout_Object_Chart_DataSet_Fields\\\":{\\\"DisplayName\\\":\\\"\\\",\\\"Type\\\":\\\"Series\\\",\\\"Name\\\":\\\"\\\",\\\"Color\\\":\\\"#006488\\\",\\\"ChartType\\\":\\\"column\\\",\\\"axis\\\":\\\"left\\\",\\\"visible\\\":\\\"true\\\",\\\"Precision\\\":\\\"default\\\",\\\"PlotType\\\":\\\"point\\\",\\\"LineWidth\\\":\\\"2\\\",\\\"LineType\\\":\\\"straight\\\",\\\"PlotRadius\\\":\\\"3\\\",\\\"RadiusField\\\":\\\"\\\",\\\"ColorField\\\":\\\"\\\",\\\"OtherField\\\":\\\"\\\",\\\"OtherFieldDisplayName\\\":\\\"\\\",\\\"RadiusFieldDisplayName\\\":\\\"\\\",\\\"ColorFieldDisplayName\\\":\\\"\\\",\\\"ToolTip\\\":\\\"\\\",\\\"PlotTransparency\\\":\\\"1\\\",\\\"DataSeperator\\\":\\\"~\\\",\\\"hierarchyType\\\":\\\"none\\\",\\\"cellType\\\":\\\"none\\\",\\\"isfixedlabel\\\":\\\"false\\\",\\\"formatter\\\":\\\"Currency\\\",\\\"unitname\\\":\\\"none\\\",\\\"signposition\\\":\\\"prefix\\\",\\\"secondformatter\\\":\\\"Number\\\",\\\"secondunitname\\\":\\\"none\\\",\\\"width\\\":\\\"200\\\",\\\"SecondaryUnit\\\":\\\"auto\\\",\\\"Unit\\\":\\\"none\\\",\\\"FieldChartType\\\":\\\"clustered\\\",\\\"Aggregation\\\":\\\"sum\\\",\\\"IndicatorType\\\":\\\"sparkline\\\",\\\"DataLabelCustomProperties\\\":{\\\"showDataLabel\\\":\\\"false\\\",\\\"useFieldColor\\\":\\\"false\\\",\\\"dataLabelTextAlign\\\":\\\"center\\\",\\\"dataLabelFontColor\\\":\\\"#808080\\\",\\\"dataLabelRotation\\\":\\\"0\\\",\\\"dataLabelFontSize\\\":\\\"12\\\",\\\"datalabelFontStyle\\\":\\\"normal\\\",\\\"datalabelFontWeight\\\":\\\"normal\\\",\\\"datalabelFontFamily\\\":\\\"'Raleway', sans-serif\\\",\\\"datalabelField\\\":\\\"\\\",\\\"datalabelPosition\\\":\\\"Top\\\",\\\"dataLabelUseComponentFormater\\\":true,\\\"datalabelFormaterUnit\\\":\\\"none\\\",\\\"datalabelFormaterPrecision\\\":\\\"default\\\",\\\"datalabelFormaterCurrency\\\":\\\"none\\\",\\\"datalabelFormaterPosition\\\":\\\"suffix\\\"}},\\\"AbsoluteLayout_Object_DynamicDataGrid_DataSet_Fields\\\":{\\\"parentAggregation\\\":\\\"sum\\\"},\\\"AbsoluteLayout_Object_DataGrid_DataSet_Fields\\\":{\\\"expressionID\\\":\\\"\\\",\\\"secondformatter\\\":\\\"Number\\\",\\\"isfixedlabel\\\":\\\"false\\\",\\\"unitname\\\":\\\"none\\\",\\\"precision\\\":\\\"default\\\",\\\"showTooltip\\\":\\\"false\\\",\\\"Type\\\":\\\"Series\\\",\\\"displayTextStyle\\\":\\\"\\\",\\\"width\\\":\\\"150\\\",\\\"isNumeric\\\":\\\"false\\\",\\\"visible\\\":\\\"true\\\",\\\"frozencolumn\\\":\\\"false\\\",\\\"sorting\\\":\\\"true\\\",\\\"secondunitname\\\":\\\"none\\\",\\\"formatter\\\":\\\"Currency\\\",\\\"textAlign\\\":\\\"left\\\",\\\"signposition\\\":\\\"suffix\\\",\\\"fieldname\\\":\\\"\\\",\\\"displayname\\\":\\\"\\\",\\\"Name\\\":\\\"\\\",\\\"hierarchyType\\\":\\\"none\\\",\\\"parentAggregation\\\":\\\"sum\\\",\\\"Color\\\":\\\"#006488\\\",\\\"cellType\\\":\\\"none\\\",\\\"numberFormatter\\\":\\\"none\\\",\\\"rowAggregation\\\":\\\"none\\\"},\\\"AbsoluteLayout_Object_DataGrid_Alerts\\\":{\\\"AlertColumn\\\":[]},\\\"AbsoluteLayout_Object_DataGrid_Alerts_AlertColumn\\\":{\\\"showAlert\\\":\\\"false\\\",\\\"name\\\":\\\"\\\",\\\"colors\\\":\\\"#F22613,#F7CA18,#2ECC71\\\",\\\"alertType\\\":\\\"colorfill\\\",\\\"texts\\\":\\\"\\\",\\\"fixedValueCompare\\\":\\\"true\\\",\\\"fixedValue\\\":\\\"0\\\",\\\"mode\\\":\\\"Comparison\\\",\\\"compareColumn\\\":\\\"\\\",\\\"ranges\\\":\\\"0~100,101~200,201~500\\\",\\\"staticRange\\\":\\\"0,1,2\\\",\\\"isAlertText\\\":\\\"false\\\",\\\"showData\\\":\\\"true\\\",\\\"operatorName\\\":\\\"<=,==,>=\\\",\\\"alertPosition\\\":\\\"left\\\",\\\"showDynamicRange\\\":\\\"false\\\",\\\"minColor\\\":\\\"#f89406\\\",\\\"maxColor\\\":\\\"#00b16a\\\"},\\\"AbsoluteLayout_Object_Scorecard_DataSet_Fields\\\":{\\\"expressionID\\\":\\\"\\\",\\\"secondformatter\\\":\\\"Number\\\",\\\"isfixedlabel\\\":\\\"false\\\",\\\"unitname\\\":\\\"none\\\",\\\"hierarchyType\\\":\\\"none\\\",\\\"cellType\\\":\\\"none\\\",\\\"numberFormatter\\\":\\\"none\\\",\\\"precision\\\":\\\"default\\\",\\\"showTooltip\\\":\\\"false\\\",\\\"Type\\\":\\\"Series\\\",\\\"displayTextStyle\\\":\\\"\\\",\\\"width\\\":\\\"150\\\",\\\"isNumeric\\\":\\\"false\\\",\\\"visible\\\":\\\"true\\\",\\\"sorting\\\":\\\"true\\\",\\\"secondunitname\\\":\\\"none\\\",\\\"formatter\\\":\\\"Currency\\\",\\\"textAlign\\\":\\\"left\\\",\\\"signposition\\\":\\\"suffix\\\",\\\"Name\\\":\\\"\\\",\\\"DisplayName\\\":\\\"\\\",\\\"parentAggregation\\\":\\\"none\\\"},\\\"AbsoluteLayout_Object_Scorecard_Alerts\\\":{\\\"AlertColumn\\\":[]},\\\"AbsoluteLayout_Object_Scorecard_Alerts_AlertColumn\\\":{\\\"showAlert\\\":\\\"false\\\",\\\"name\\\":\\\"\\\",\\\"colors\\\":\\\"#F22613,#F7CA18,#2ECC71\\\",\\\"alertType\\\":\\\"colorfill\\\",\\\"texts\\\":\\\"\\\",\\\"fixedValueCompare\\\":\\\"true\\\",\\\"fixedValue\\\":\\\"0\\\",\\\"mode\\\":\\\"Comparison\\\",\\\"compareColumn\\\":\\\"\\\",\\\"ranges\\\":\\\"0~100,101~200,201~500\\\",\\\"isAlertText\\\":\\\"false\\\",\\\"showData\\\":\\\"true\\\",\\\"alertPosition\\\":\\\"left\\\",\\\"showDynamicRange\\\":\\\"false\\\",\\\"minColor\\\":\\\"#f89406\\\",\\\"maxColor\\\":\\\"#00b16a\\\"},\\\"AbsoluteLayout_Object_Funnel_DataSet_Fields\\\":{\\\"Type\\\":\\\"Series\\\",\\\"expressionID\\\":\\\"\\\",\\\"DisplayName\\\":\\\"\\\",\\\"visible\\\":\\\"true\\\",\\\"PlotTransparency\\\":\\\"1\\\",\\\"color\\\":\\\"#006488\\\",\\\"Name\\\":\\\"\\\"},\\\"AbsoluteLayout_Object_Filter_DataSet_Fields\\\":{\\\"Name\\\":\\\"\\\",\\\"DisplayName\\\":\\\"\\\",\\\"Type\\\":\\\"\\\",\\\"defaultChild\\\":\\\"\\\",\\\"hierarchyType\\\":\\\"parent\\\",\\\"parentAggregation\\\":\\\"none\\\"},\\\"AbsoluteLayout_Object_Chart_CategoryColors\\\":{\\\"categoryDefaultColor\\\":\\\"\\\",\\\"categoryDefaultColorSet\\\":\\\"\\\",\\\"showColorsFromCategoryName\\\":\\\"\\\",\\\"CategoryColor\\\":[]},\\\"AbsoluteLayout_Object_Chart_CategoryColors_CategoryColor\\\":{\\\"categoryName\\\":\\\"\\\",\\\"color\\\":\\\"\\\"},\\\"AbsoluteLayout_Object_Chart_SubCategoryColors\\\":{\\\"subCategoryDefaultColor\\\":\\\"\\\",\\\"subCategoryDefaultColorSet\\\":\\\"\\\",\\\"showColorsFromSubCategoryName\\\":\\\"\\\",\\\"subCategoryColor\\\":[]},\\\"AbsoluteLayout_Object_Chart_SubCategoryColors_subCategoryColor\\\":{\\\"subCategoryName\\\":\\\"\\\",\\\"color\\\":\\\"\\\"},\\\"AbsoluteLayout_Object_Chart_ConditionalColors\\\":{\\\"ConditionalColor\\\":[]},\\\"AbsoluteLayout_Object_Chart_ConditionalColors_ConditionalColor\\\":{\\\"seriesName\\\":\\\"\\\",\\\"operator\\\":\\\"\\\",\\\"compareTo\\\":\\\"\\\",\\\"color\\\":\\\"\\\"},\\\"AbsoluteLayout_Object_URLButton_Params\\\":{\\\"name\\\":\\\"\\\",\\\"value\\\":\\\"\\\"},\\\"VirtualDataSet\\\":{\\\"virtualDataID\\\":\\\"\\\",\\\"DataSet\\\":{\\\"id\\\":\\\"\\\",\\\"dataSource\\\":\\\"\\\",\\\"Fields\\\":[]},\\\"VisibilityTriggerMap\\\":{\\\"Object\\\":[]}},\\\"VirtualDataSet_DataSet_Fields\\\":{\\\"name\\\":\\\"Year\\\"},\\\"VirtualDataSet_VisibilityTriggerMap_Object\\\":{\\\"id\\\":\\\"\\\"},\\\"GlobalVariable_Variable\\\":{\\\"Key\\\":\\\"\\\",\\\"userScript\\\":{\\\"value\\\":\\\"\\\"},\\\"DefaultValues\\\":{\\\"DefaultValue\\\":[]}},\\\"GlobalVariable_Variable_DefaultValues_DefaultValue\\\":{\\\"name\\\":\\\"\\\",\\\"text\\\":\\\"\\\",\\\"displayTag\\\":\\\"\\\",\\\"actualTag\\\":\\\"\\\"},\\\"OffLineData_Data\\\":{\\\"id\\\":\\\"\\\",\\\"specifications\\\":{\\\"sheetNumber\\\":\\\"0\\\",\\\"dateHeaders\\\":\\\"\\\",\\\"headerAsFirstRow\\\":\\\"true\\\",\\\"dateFormat\\\":\\\"\\\",\\\"textQualifier\\\":\\\"\\\",\\\"delimiter\\\":\\\",\\\"},\\\"Records\\\":{\\\"Record\\\":[]}},\\\"changeStatus\\\":0}\"}";
                Response response1 =
                        given()
                                .header("spaceKey", spaceKey)
                                .header("userid", uid)
                                .header("authToken", authToken)
                                .param("dashboardParameters", dashboardParameters2)
                                .param("token", authToken)
                                .param("spacekey", spaceKey)
                                .when()
                                .post(urlsaveDB)
                                .then()
                                .statusCode(statusCode)
                                .extract().response();
                System.out.println("responsesavedashboard=" + response1.asString());
                HashMap<String, Object> s1 = from(response1.asString()).get("");
                /*******parsing the json object******/
                HashMap<String, Object> designerresp = (HashMap) s1.get("DesignerResp");
                Object obj1 = designerresp.get("params");
                System.out.println(obj1);
                JSONParser parser1 = new JSONParser();
                JSONObject object1 = (JSONObject) parser1.parse(obj1.toString());
                dashboardId = (String) object1.get("dashboardId");
                System.out.println("dashboardIdCreateSave is=====:" + dashboardId);

                //Assertions
                Assert.assertEquals(designerresp.get("success"), true);
                Assert.assertNotNull(dashboardId, "dashboardId is null");
            }
            LOGGER.info("successful execution");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //Open Dashboard
    public  void openDashboard(String dashboardParameters,String uid,String spaceKey,String authToken,int statusCode) {
        try {

           // String dashboardParameters = "{\"dashboardId\":\""+dashboardId+"\"}";
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", uid)
                            .header("authtoken", authToken)
                            //params
                            .param("dashboardParameters", dashboardParameters )
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlopenDB)
                            .then().assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> openDashboard_resp = from(response.asString()).get("");
                HashMap<String, Object> DesignerResp = (HashMap) openDashboard_resp.get("DesignerResp");
                //parsing Json
                Object obj_Params = DesignerResp.get("params");
                JSONParser parser = new JSONParser();
                JSONObject object = (JSONObject) parser.parse(obj_Params.toString());
                JSONObject dashboardJson = (JSONObject) object.get("dashboardJson");
                JSONObject dashboard = (JSONObject) dashboardJson.get("Dashboard");
                String dashId = (String) dashboard.get("backendId");
                String workSpaceId = (String) dashboard.get("workspaceId");
                LOGGER.info("responseopendashboard=" + response.asString());
                System.out.println(obj_Params);
                LOGGER.info("DashboardId is=" + dashId);
                LOGGER.info("WorkspaceId is=" + workSpaceId);

                //Assertions
                Assert.assertNotNull(dashId, "id is null");
                Assert.assertNotNull(workSpaceId, "id is null");
                Assert.assertEquals(response.path("DesignerResp.success"), true);
            }

            LOGGER.info("successful execution");
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //Document Info
    public  void getDocumentInfoByID(String uid,String spaceKey,String authToken,int statusCode) {
        try {
            String docId = "0";
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", uid)
                            .header("authtoken", authToken)
                            .param("docId",docId  )
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdocumentinfobyid)
                            .then().assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> response_DocumentInfoById = from(response.asString()).get("trees");

                LOGGER.info("DocumentInfoById ==:" + response_DocumentInfoById);

                //Assertions
                Assert.assertEquals(response_DocumentInfoById.get("success"), true);
            }
            LOGGER.info("successful execution");
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //save Data ie  publishing dashboard
    public static  void publishDashboard(String uid,String spaceKey,String authToken,int statusCode) {
        try {
            int id = 0;
            int width = 1362;
            int height = 596;
            String dependencyDetails = "[{\"queryServiceID\":"+seriveiddatasetNew+"}]";
            String description = "Published from dashboard designer";
            Date dt = new Date();
            String didtime = "dashboard" + dt.getTime();
            Long epoch  = System.currentTimeMillis();
            String file = "{\"Niv\":{\"Dashboard\":{\"id\":\""+didtime+"\",\"backendId\":\""+dashboardId +"\",\"workspaceId\":\""+workspaceId+"\",\"DashboardOptions\":{\"publishWSDLServer\":\"\",\"expiryDate\":\"\",\"hasExpiry\":\"\"},\"versionDetails\":{\"author\":\"BizViz Technologies Pvt. Ltd.\",\"edittedBy\":\"\",\"lastUpdate\":\""+dt+"\",\"dashboardVersion\":\"3.2.1\",\"publishDocId\":\"\",\"lastPublishedVersion\":\"\",\"createdDesignerVersion\":\"\",\"lastUpdatedDesignerVersion\":\"3.x-F1002\",\"lastUpdatedDesignerDate\":\""+epoch+"\"},\"FlashVars\":{\"Param\":[{\"name\":\"token\",\"value\":\""+authToken+"\"}]},\"AuthProfiles\":{\"Profile\":[]},\"DataProviders\":{\"DataURL\":[{\"FieldSet\":[{\"name\":\"meal_size\",\"displayName\":\"\",\"type\":\"\",\"added\":true},{\"name\":\"order_detail_id\",\"displayName\":\"\",\"type\":\"\",\"added\":true},{\"name\":\"space_key\",\"displayName\":\"\",\"type\":\"\",\"added\":true},{\"name\":\"total_cost\",\"displayName\":\"\",\"type\":\"\",\"added\":true},{\"name\":\"total_tax\",\"displayName\":\"\",\"type\":\"\",\"added\":true}],\"WhereClause\":{\"Con\":{\"Clause\":\"\",\"ClauseMap\":{}}},\"dataType\":\"JSON\",\"variable\":{\"Key\":\"C_1\",\"userScript\":{\"value\":\"\"},\"DefaultValues\":{\"DefaultValue\":[]}},\"refreshMinutes\":5,\"timelyRefresh\":\"false\",\"profileName\":\"\",\"hasMapping\":\"false\",\"offLineDataID\":\"\",\"id\":\"C_1\",\"DrillWhenDataChanges\":\"false\",\"LoadatStartup\":\"true\",\"Type\":\"web\",\"isLangWebservice\":\"false\",\"password\":\"\",\"url\":\""+queryLink+"\",\"queryName\":\""+queryname+"\",\"nividhQueryName\":\""+nividhQueryName+"\",\"dataSourceName\":\""+dataSourceName+"\",\"dataSourceType\":\"mysql\",\"hostName\":\""+hostName+"\",\"databaseName\":\""+databaseName+"\",\"sheet\":\"\",\"rowLimit\":\"\",\"PredictiveJsonDef\":\"\",\"parentSource\":\"\",\"childSource\":\"\",\"deriveConditions\":{\"criteria\":[\"\"]},\"availableFieldSet\":[{\"name\":\"meal_size\",\"displayName\":\"\",\"type\":\"\",\"added\":true},{\"name\":\"order_detail_id\",\"displayName\":\"\",\"type\":\"\",\"added\":true},{\"name\":\"space_key\",\"displayName\":\"\",\"type\":\"\",\"added\":true},{\"name\":\"total_cost\",\"displayName\":\"\",\"type\":\"\",\"added\":true},{\"name\":\"total_tax\",\"displayName\":\"\",\"type\":\"\",\"added\":true}],\"allowSessionID\":\"false\",\"userID\":\"\",\"selectedDataSourceID\":"+datasourceidNew+",\"selectedServiceID\":"+seriveiddatasetNew+",\"availableConditionSet\":[],\"AssociatedDataSet\":[{\"component\":\"datagrid1\",\"id\":\"datagrid1\"}],\"AssociatedVirtualDataset\":[],\"query\":{\"filters\":{\"value\":\"\"}},\"connectionName\":\"Connection-1\",\"typeSpecifier\":\"web\",\"calculatedFieldList\":[],\"isUiActive\":true,\"isUiActiveCA\":false,\"serviceType\":\"bizviz\"}],\"queryServiceList\":[],\"selectedConnection\":{\"FieldSet\":[{\"name\":\"meal_size\",\"displayName\":\"\",\"type\":\"\",\"added\":true},{\"name\":\"order_detail_id\",\"displayName\":\"\",\"type\":\"\",\"added\":true},{\"name\":\"space_key\",\"displayName\":\"\",\"type\":\"\",\"added\":true},{\"name\":\"total_cost\",\"displayName\":\"\",\"type\":\"\",\"added\":true},{\"name\":\"total_tax\",\"displayName\":\"\",\"type\":\"\",\"added\":true}],\"WhereClause\":{\"Con\":{\"Clause\":\"\",\"ClauseMap\":{}}},\"dataType\":\"JSON\",\"variable\":{\"Key\":\"C_1\",\"userScript\":{\"value\":\"\"},\"DefaultValues\":{\"DefaultValue\":[]}},\"refreshMinutes\":5,\"timelyRefresh\":\"false\",\"profileName\":\"\",\"hasMapping\":\"false\",\"offLineDataID\":\"\",\"id\":\"C_1\",\"DrillWhenDataChanges\":\"false\",\"LoadatStartup\":\"true\",\"Type\":\"web\",\"isLangWebservice\":\"false\",\"password\":\"\",\"url\":\""+queryLink+"\",\"queryName\":\""+queryname+"\",\"nividhQueryName\":\""+nividhQueryName+"\",\"dataSourceName\":\""+dataSourceName+"\",\"dataSourceType\":\"mysql\",\"hostName\":\""+hostName+"\",\"databaseName\":\""+databaseName+"\",\"sheet\":\"\",\"rowLimit\":\"\",\"PredictiveJsonDef\":\"\",\"parentSource\":\"\",\"childSource\":\"\",\"deriveConditions\":{\"criteria\":[\"\"]},\"availableFieldSet\":[{\"name\":\"meal_size\",\"displayName\":\"\",\"type\":\"\",\"added\":true},{\"name\":\"order_detail_id\",\"displayName\":\"\",\"type\":\"\",\"added\":true},{\"name\":\"space_key\",\"displayName\":\"\",\"type\":\"\",\"added\":true},{\"name\":\"total_cost\",\"displayName\":\"\",\"type\":\"\",\"added\":true},{\"name\":\"total_tax\",\"displayName\":\"\",\"type\":\"\",\"added\":true}],\"allowSessionID\":\"false\",\"userID\":\"\",\"selectedDataSourceID\":"+datasourceidNew+",\"selectedServiceID\":"+seriveiddatasetNew+",\"availableConditionSet\":[],\"AssociatedDataSet\":[{\"component\":\"datagrid1\",\"id\":\"datagrid1\"}],\"AssociatedVirtualDataset\":[],\"query\":{\"filters\":{\"value\":\"\"}},\"connectionName\":\"Connection-1\",\"typeSpecifier\":\"web\",\"calculatedFieldList\":[],\"isUiActive\":true,\"isUiActiveCA\":false,\"serviceType\":\"bizviz\"}},\"componentGroups\":[],\"VirtualDataSet\":[],\"imports\":[\"SimpleDataGrid\"],\"importsStat\":1,\"GlobalVariable\":{\"Variable\":[]},\"OffLineData\":{\"Data\":[]},\"DatasetExpressions\":{\"DatasetExpression\":[]},\"AbsoluteLayout\":{\"gradientRotation\":\"0\",\"gradients\":\"#FFFFFF\",\"bgAlpha\":\"1\",\"borderThickness\":1,\"borderColor\":\"#08AEA8\",\"showShadow\":\"false\",\"shadowColor\":\"#000000\",\"shadowOpacity\":\"0.1\",\"resolution\":\"929x566\",\"width\":1540,\"height\":709,\"useGlobalFont\":\"false\",\"fontFamily\":\"'Raleway', sans-serif\",\"designerTheme\":\"default-theme\",\"useFontFromUrl\":\"false\",\"isAllLockedComponents\":\"false\",\"visibilityEffects\":\"false\",\"enableWatermark\":\"true\",\"fontUrl\":\"\",\"isBootstrap\":\"false\",\"scalingEnabled\":\"false\",\"scalingView\":\"fitToPage\",\"touchEnabled\":\"false\",\"Object\":[{\"componentType\":\"simple_data_grid\",\"objectName\":\"datagrid1\",\"showLocked\":false,\"subElement\":\"DataGrid\",\"globalVariableKeyAttribute\":\"Globalkey\",\"isDataSetAvailable\":\"true\",\"enableScript\":\"true\",\"referenceID\":\"datagrid1\",\"isValueFieldsAvailable\":\"false\",\"showContextMenu\":\"false\",\"shortName\":\"datagrid\",\"objectType\":\"datagrid\",\"width\":\"480\",\"unShowHidden\":false,\"groupings\":\"\",\"percentheight\":\"320\",\"initialVisibility\":\"true\",\"x\":64,\"height\":\"275\",\"y\":124,\"percentwidth\":\"450\",\"objectID\":\"BVZ713b4416-ccbf-4d21-b114-8eec9ada75bd\",\"DataGrid\":{\"CompareIndices\":\"\",\"URL\":\"\",\"pptSubHeading\":\"Sub Heading\",\"scrnShotFileName\":\"exportDashboard\",\"pptHeading\":\"Heading\",\"Globalkey\":\"pagegrid13\",\"screenShotMode\":\"ppt\",\"showExcelDownload\":\"true\",\"colorByComparison\":\"false\",\"pagerBackgroundColor\":\"#a7a9ab\",\"GaugeClickEnable\":\"false\",\"bgAlpha\":\"1\",\"bgGradientRotation\":\"0\",\"FontStyle\":\"normal\",\"labelFontFamily\":\"'Raleway', sans-serif\",\"bgGradients\":\"16777215\",\"showBorder\":\"false\",\"borderColor\":\"#BDC3C7\",\"borderThickness\":\"1\",\"showShadow\":\"false\",\"shadowColor\":\"#000000\",\"shadowOpacity\":\"0.1\",\"fitColumns\":\"true\",\"Name\":\"true\",\"Align\":\"left\",\"RowHeight\":\"30\",\"MaxRowCount\":\"20\",\"labelTextDecoration\":\"none\",\"showinfobutton\":\"false\",\"labelFontSize\":12,\"DataGridType\":\"Datagrid\",\"labelFontStyle\":\"normal\",\"AlertType\":\"bar\",\"RowCount\":10,\"xmlwithColorColumn\":\"false\",\"labelFontColor\":\"#000000\",\"AlertWithData\":\"false\",\"AlertValues\":\"30,50,70\",\"labelFontWeight\":\"normal\",\"showMaximizeButton\":\"false\",\"FontWeight\":\"normal\",\"TextDecoration\":\"none\",\"pptServiceURL\":\"http://www.bdbizviz.com/PPT/Parser\",\"FontFamily\":\"'Raleway', sans-serif\",\"AlertColors\":\"#FF0000,#FFFF00,#0000FF,#00FF00\",\"showGradient\":\"false\",\"GradientColor\":\"#F5F5F5,#F5F5F5\",\"valuesGood\":\"high\",\"id\":\"Obj.FB2D7861N44F1ND321N2D80NBF4DA5E223AA\",\"gaugeOrder\":\"1\",\"headerFontStyle\":\"normal\",\"headerFontSize\":14,\"headerFontColor\":\"#000000\",\"headerFontWeight\":\"normal\",\"headerSymbolColor\":\"#000000\",\"headerchromeColor\":\"#f7f7f7\",\"headerTextAlign\":\"left\",\"headerTextDecoration\":\"none\",\"headerFontFamily\":\"'Raleway', sans-serif\",\"FontColor\":\"#000000\",\"showTitle\":\"false\",\"FontSize\":\"13\",\"exportToExcel\":\"true\",\"exportToJPEG\":\"true\",\"exportToPNG\":\"true\",\"exportToPDF\":\"true\",\"exportToPPT\":\"true\",\"exportToPrint\":\"true\",\"showScreenShotButton\":\"true\",\"textWrap\":\"false\",\"useFieldColorAsHeader\":\"false\",\"Title\":{\"FontWeight\":\"normal\",\"Description\":\"Title\",\"FontSize\":\"12\",\"TextDecoration\":\"none\",\"Align\":\"left\",\"FontFamily\":\"'Raleway', sans-serif\",\"FontColor\":\"#808080\",\"FontStyle\":\"normal\",\"showTitle\":\"false\",\"TitleBarHeight\":\"25\"},\"SubTitle\":{\"FontColor\":\"0\",\"FontStyle\":\"normal\",\"FontFamily\":\"'Raleway', sans-serif\",\"Align\":\"center\",\"TextDecoration\":\"none\",\"showSubTitle\":\"false\",\"FontSize\":\"12\",\"Description\":\"SubTitleDescription\",\"FontWeight\":\"normal\"},\"DatagridStyles\":{\"horizontalGridLineColor\":\"#f6f6f6\",\"verticalGridLineColor\":\"#f9f9f9\",\"selectionColor\":\"#fcfcfc\",\"rollOverColor\":\"#e4fde4\",\"enableItemrenderer\":\"false\",\"alternateRowsColor\":\"#ffffff,#ffffff\",\"showhorizontalGridLines\":\"true\"},\"Column\":{\"columnwiseFill\":\"true\",\"columnColorArray\":\"#FF0000,#00CC00,#0000DD,#FFCC00\",\"columnIndeciesArray\":\"1:2:3,2:3,1:3,3\"},\"RowData\":{\"rowwiseFill\":\"false\",\"rowIndeciesArray\":\"3,5,9,11\",\"allIndeciesArray\":\"\"},\"LinkButton\":{\"Id\":\"Linkbar\",\"Description\":\"ShowAll\",\"TextRolloverColor\":\"26214\",\"TextColor\":\"0\",\"TextSelectedColor\":\"204\",\"TitRolloverColorle\":\"52479\",\"SelectedColor\":\"32425\"},\"LinkBar\":{\"SelectedColor\":\"13311\",\"LinkBarColor\":\"#020f0e\",\"TextRolloverColor\":\"16777062\",\"SeperatorColor\":\"0\",\"TextColor\":\"0\",\"TextSelectedColor\":\"13209\",\"RolloverColor\":\"13311\"},\"Alerts\":{},\"DataSet\":{\"id\":\"datagrid1\",\"dataSource\":\"C_1\",\"Fields\":[{\"secondformatter\":\"Number\",\"isfixedlabel\":\"false\",\"unitname\":\"none\",\"precision\":\"default\",\"showTooltip\":\"false\",\"Type\":\"Series\",\"displayTextStyle\":\"\",\"width\":\"150\",\"isNumeric\":\"false\",\"visible\":\"true\",\"frozencolumn\":\"false\",\"sorting\":\"true\",\"secondunitname\":\"none\",\"formatter\":\"Currency\",\"textAlign\":\"left\",\"signposition\":\"suffix\",\"fieldname\":\"meal_size\",\"displayname\":\"meal_size\",\"Name\":\"meal_size\",\"hierarchyType\":\"none\",\"parentAggregation\":\"sum\",\"Color\":\"#006684\",\"cellType\":\"none\",\"numberFormatter\":\"none\",\"rowAggregation\":\"none\",\"fieldType\":\"Field\",\"OtherField\":\"meal_size\",\"OtherFieldDisplayName\":\"meal_size\",\"ColorFieldDisplayName\":\"Color\",\"RadiusFieldDisplayName\":\"Radius\",\"iconPath\":\"./resources/images/svg/Column.svg\"},{\"secondformatter\":\"Number\",\"isfixedlabel\":\"false\",\"unitname\":\"none\",\"precision\":\"default\",\"showTooltip\":\"false\",\"Type\":\"Series\",\"displayTextStyle\":\"\",\"width\":\"150\",\"isNumeric\":\"false\",\"visible\":\"true\",\"frozencolumn\":\"false\",\"sorting\":\"true\",\"secondunitname\":\"none\",\"formatter\":\"Currency\",\"textAlign\":\"left\",\"signposition\":\"suffix\",\"fieldname\":\"order_detail_id\",\"displayname\":\"order_detail_id\",\"Name\":\"order_detail_id\",\"hierarchyType\":\"none\",\"parentAggregation\":\"sum\",\"Color\":\"#86dff9\",\"cellType\":\"none\",\"numberFormatter\":\"none\",\"rowAggregation\":\"none\",\"fieldType\":\"Field\",\"OtherField\":\"order_detail_id\",\"OtherFieldDisplayName\":\"order_detail_id\",\"ColorFieldDisplayName\":\"Color\",\"RadiusFieldDisplayName\":\"Radius\",\"iconPath\":\"./resources/images/svg/Column.svg\"},{\"secondformatter\":\"Number\",\"isfixedlabel\":\"false\",\"unitname\":\"none\",\"precision\":\"default\",\"showTooltip\":\"false\",\"Type\":\"Series\",\"displayTextStyle\":\"\",\"width\":\"150\",\"isNumeric\":\"false\",\"visible\":\"true\",\"frozencolumn\":\"false\",\"sorting\":\"true\",\"secondunitname\":\"none\",\"formatter\":\"Currency\",\"textAlign\":\"left\",\"signposition\":\"suffix\",\"fieldname\":\"space_key\",\"displayname\":\"space_key\",\"Name\":\"space_key\",\"hierarchyType\":\"none\",\"parentAggregation\":\"sum\",\"Color\":\"#f89406\",\"cellType\":\"none\",\"numberFormatter\":\"none\",\"rowAggregation\":\"none\",\"fieldType\":\"Field\",\"OtherField\":\"space_key\",\"OtherFieldDisplayName\":\"space_key\",\"ColorFieldDisplayName\":\"Color\",\"RadiusFieldDisplayName\":\"Radius\",\"iconPath\":\"./resources/images/svg/Column.svg\"},{\"secondformatter\":\"Number\",\"isfixedlabel\":\"false\",\"unitname\":\"none\",\"precision\":\"default\",\"showTooltip\":\"false\",\"Type\":\"Series\",\"displayTextStyle\":\"\",\"width\":\"150\",\"isNumeric\":\"false\",\"visible\":\"true\",\"frozencolumn\":\"false\",\"sorting\":\"true\",\"secondunitname\":\"none\",\"formatter\":\"Currency\",\"textAlign\":\"left\",\"signposition\":\"suffix\",\"fieldname\":\"total_cost\",\"displayname\":\"total_cost\",\"Name\":\"total_cost\",\"hierarchyType\":\"none\",\"parentAggregation\":\"sum\",\"Color\":\"#e0dfdf\",\"cellType\":\"none\",\"numberFormatter\":\"none\",\"rowAggregation\":\"none\",\"fieldType\":\"Field\",\"OtherField\":\"total_cost\",\"OtherFieldDisplayName\":\"total_cost\",\"ColorFieldDisplayName\":\"Color\",\"RadiusFieldDisplayName\":\"Radius\",\"iconPath\":\"./resources/images/svg/Column.svg\"},{\"secondformatter\":\"Number\",\"isfixedlabel\":\"false\",\"unitname\":\"none\",\"precision\":\"default\",\"showTooltip\":\"false\",\"Type\":\"Series\",\"displayTextStyle\":\"\",\"width\":\"150\",\"isNumeric\":\"false\",\"visible\":\"true\",\"frozencolumn\":\"false\",\"sorting\":\"true\",\"secondunitname\":\"none\",\"formatter\":\"Currency\",\"textAlign\":\"left\",\"signposition\":\"suffix\",\"fieldname\":\"total_tax\",\"displayname\":\"total_tax\",\"Name\":\"total_tax\",\"hierarchyType\":\"none\",\"parentAggregation\":\"sum\",\"Color\":\"#17becf\",\"cellType\":\"none\",\"numberFormatter\":\"none\",\"rowAggregation\":\"none\",\"fieldType\":\"Field\",\"OtherField\":\"total_tax\",\"OtherFieldDisplayName\":\"total_tax\",\"ColorFieldDisplayName\":\"Color\",\"RadiusFieldDisplayName\":\"Radius\",\"iconPath\":\"./resources/images/svg/Column.svg\"}]}},\"designData\":{\"name\":\"DataGrid\",\"type\":\"datagrid\",\"class\":\"SimpleDataGrid\",\"show\":true,\"icon\":\"./resources/images/svg/components/SimpleDataGrid.svg\"},\"variable\":{\"Key\":\"datagrid1\",\"userScript\":{\"value\":\"\",\"id\":\"BVZ713b4416-ccbf-4d21-b114-8eec9ada75bd\"},\"DefaultValues\":{\"DefaultValue\":[{\"name\":\"meal_size\",\"text\":\"\",\"displayTag\":\"datagrid1.meal_size\",\"actualTag\":\"{datagrid1.meal_size}\",\"actualTagForLabels\":\"[datagrid1.meal_size]\"},{\"name\":\"order_detail_id\",\"text\":\"\",\"displayTag\":\"datagrid1.order_detail_id\",\"actualTag\":\"{datagrid1.order_detail_id}\",\"actualTagForLabels\":\"[datagrid1.order_detail_id]\"},{\"name\":\"space_key\",\"text\":\"\",\"displayTag\":\"datagrid1.space_key\",\"actualTag\":\"{datagrid1.space_key}\",\"actualTagForLabels\":\"[datagrid1.space_key]\"},{\"name\":\"total_cost\",\"text\":\"\",\"displayTag\":\"datagrid1.total_cost\",\"actualTag\":\"{datagrid1.total_cost}\",\"actualTagForLabels\":\"[datagrid1.total_cost]\"},{\"name\":\"total_tax\",\"text\":\"\",\"displayTag\":\"datagrid1.total_tax\",\"actualTag\":\"{datagrid1.total_tax}\",\"actualTagForLabels\":\"[datagrid1.total_tax]\"}]}},\"isUiActiveCA\":true}]},\"name\":\"WebServiceDashboard\",\"variable\":{\"Key\":\"dashboard\",\"userScript\":{\"value\":\"\"},\"DefaultValues\":{\"DefaultValue\":[]}}}}}";
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", uid)
                            .header("authtoken", authToken)
                            //params
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .param("parentid", myDocumentId )
                            .param("position",position)
                            .param("type", typefile)
                            .param("dashboardtype", dashboardtype)
                            .param("id", id)
                            .param("mobileViewVal", 0)
                            .param("imagename", imagename)
                            .param("description", description)
                            .param("width", width)
                            .param("height", height)
                            .param("title", dashboardName)
                            .param("dependencyDetails", dependencyDetails)
                            .param("file", file)
                            .param("originalfilename", originalfilename)
                            .when()
                            .post(urluploadDB)
                            .then().assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                System.out.println("responsepublishdashboard=" + response.asString());
                HashMap<String, Object> s = from(response.asString()).get("");//response of publish dashboard
                HashMap<String, Object> trees = (HashMap) s.get("trees");
                HashMap<String, Object> tree = (HashMap<String, Object>) trees.get("tree");
                publishDashboardId = tree.get("id").toString();
                LOGGER.info("publishDashboardId is===" + publishDashboardId);
            }
            LOGGER.info("successful execution");
            Assert.assertNotNull(publishDashboardId);
        }catch (Exception e){
            e.printStackTrace();
        }

    }


    public  void getDataDashboard(String id, String uid,String spaceKey,String authToken,int statusCode){
        try {
            Response resp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userid", uid)
                            .header("authtoken", authToken)
                            //Param
                            .param("id", "id")
                            .param("documentType", 2)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetDataDashboard)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            String getData_Response = from(resp.asString()).get("");
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void getEndpointUrl(String data, String uid,String spaceKey,String authToken,int statusCode){
        try {
            Response resp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userid", uid)
                            .header("authtoken", authToken)
                            //Param
                            .param("data", data)
                            .param("userid", uid)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetEndpointUrl)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            ArrayList<HashMap<String, Object>> response_Actual = from(resp.asString()).get("");
            HashMap<String, Object> obj = response_Actual.get(0);
            LOGGER.info("Response" + response_Actual);
            LOGGER.info("type: " + obj.get("type"));
            endPointUrl = obj.get("url").toString();
            LOGGER.info("url: " + obj.get("url"));

            String expectedResponse = "[{\"type\":\"mysql\",\"url\":\"http://localhost:8185/cxf/queryServiceHttpSoapEndpoint/\"}]";
            for (HashMap response_ActualObj : response_Actual) {

                JSONObject jsonObject = new JSONObject();
                jsonObject.putAll(response_ActualObj);

                // Assert.assertEquals(response_ActualObj.toString(),expectedResponse.toString() );
            }

        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    public  void getRecords(String uid,String spaceKey,String authToken,int statusCode){
        try {
            String queryServiceHttpSoapEndpoint = Utils.getproperty("queryServiceHttpSoapEndpoint");
            Long epoch  = System.currentTimeMillis();
            String wsdl = "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\"><Body><executeQuery xmlns=\"http://webservice.required.bdbizviz.com\"><filter xmlns=\"\"/><AuthToken xmlns=\"\">"+authToken+"</AuthToken><key xmlns=\"\"><serviceName>"+nividhQueryName+"</serviceName><dataType>JSON</dataType><Limit></Limit></key></executeQuery></Body></Envelope>";

            Response resp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userid", uid)
                            .header("authtoken", authToken)
                            //Param
                            .param("url", queryServiceHttpSoapEndpoint)
                            .param("wsdl", wsdl)
                            .when()
                            .post(urlgetRecords)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            String getRecords_Response = resp.asString().toString();
            System.out.println("getRecords_Response:"+ getRecords_Response);
            org.json.JSONObject js = org.json.XML.toJSONObject(getRecords_Response);
            System.out.println("js:"+ js);
            org.json.JSONObject envlopeObj = js.getJSONObject("soap:Envelope");
            org.json.JSONObject soapBodyObj = envlopeObj.getJSONObject("soap:Body");
            org.json.JSONObject executeQueryResponseObj = soapBodyObj.getJSONObject("ns2:executeQueryResponse");
            org.json.JSONObject returnObj = executeQueryResponseObj.getJSONObject("return");
            org.json.JSONObject recordsObj = returnObj.getJSONObject("records");
            String contentObj = recordsObj.getString("content");

            org.json.JSONArray actualgetRecordsData=new org.json.JSONArray(contentObj);
            System.out.println("content:" + actualgetRecordsData );

            //JDBC Connection for validation for DashboardName
            String jdbcdashId = "Select * from dashboard where SPACE_KEY='"+spaceKey+"' and title='"+designerDashName+"'";
            String jdbcresult = Jdbc_connection.jdbcResult(jdbcdashId, "title", JDBC_IP_PORT, JDBC_DBNAME, JDBC_USERNAME, JDBC_Password);
            System.out.println(jdbcresult);
            Assert.assertEquals(jdbcresult, designerDashName);

            //JDBC Connection for validation for Dashboarddata
            String query = "select ORDER_DETAIL_ID,MEAL_SIZE,SPACE_KEY,TOTAL_COST,TOTAL_TAX from order_detail where ORDER_TYPE='RUSH_ORDER' union select ORDER_DETAILS_SPLIT_ID,MENU_ITEM_SIZE,SPACE_KEY,PRICE,TAX from order_details_split where IS_ACTIVE='1' and FUNDRAISER_ITEM!='NULL' limit 100";

            String DB_URL = "jdbc:mysql://"+JDBC_dbip+"/"+JDBC_dbname+"";
            List<HashMap<String,String>> datasList =  Jdbc_connection.getResultsList(DB_URL,query, JDBC_dbuser,JDBC_dbpass);
            org.json.JSONArray jdbcgetRecordsData = new org.json.JSONArray(datasList);

            System.out.println(jdbcgetRecordsData);
            jdbcgetRecordsData.getJSONObject(0).keySet();


            for(int i = 0; i< jdbcgetRecordsData.length();i++){
                Set<String> jdbcKyst = jdbcgetRecordsData.getJSONObject(i).keySet();

                for(String key:jdbcKyst){
                    if(actualgetRecordsData.getJSONObject(i).get(key).equals(jdbcgetRecordsData.getJSONObject(i).get(key))){
                        Assert.assertEquals(actualgetRecordsData.getJSONObject(i).get(key), jdbcgetRecordsData.getJSONObject(i).get(key));
                        System.out.println("Assertion done!...");
                        continue;
                    }else{
                        System.out.println("Assertion failed!..");
                        break;
                    }
                }
            }

        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void getDataStoreDetails(String consumerName, String serviceName, String authToken, String spaceKey, String userId, int statusCode) {
        try {
            urlpluginService = Utils.getUrl("pluginservice");
            String dataStr =  "{\"id\":0,\"datasourcetype\":\"all\"}";

            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authToken", authToken)
                            // req data
                            .param("userid", userId)
                            .param("from", 0)
                            .param("rows", Utils.getproperty("rows"))
                            .param("isSecure", "true")
                            .param("consumerName", consumerName)
                            .param("serviceName", serviceName)
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpluginService)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> resp = from(response.asString()).get("");
            LOGGER.info(("resp:" +resp.toString()));
            String success= resp.get("success").toString();
            // testps
            List< HashMap<String, Object> >  bizvizCubes = (List<HashMap<String, Object>>) resp.get("bizvizCubes");

            if(bizvizCubes!=null && !bizvizCubes.isEmpty()){
                for (HashMap<String, Object> bizvizCube: bizvizCubes) {
                    if(bizvizCube.containsKey("name") && bizvizCube.get("name").toString().equals("RestAutomationDataStore")){
                        bizvizCubeId = (Integer) bizvizCube.get("id");
                    }
                }
            }

            System.out.println("bizvizCubeId:" + bizvizCubeId);
            //****Asserting for create document****//
            Assert.assertEquals(success,"true" );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void getCubeInfo(String consumerName, String serviceName, String authToken, String spaceKey, String userId,  int statusCode) {

        try {

            JSONObject data = new JSONObject();
            Integer id = bizvizCubeId;
            data.put("id",id);
            String dataStr =  data.toString();
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authToken", authToken)
                            // req data
                            .param("userid", userId)
                            .param("from", 0)
                            .param("rows", Utils.getproperty("rows"))
                            .param("isSecure", "true")
                            .param("consumerName", consumerName)
                            .param("serviceName", serviceName)
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpluginService)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String, Object> resp = from(response.asString()).get("");
            HashMap<String, Object>  bizvizCube= (HashMap<String, Object> ) resp.get("bizvizCube");
           /* String name  = (String) bizvizCube.get("name");
            LOGGER.info(("resp:" +resp.toString()));*/

            //****Asserting for create document****//
            //  Assert.assertEquals(name, "RestAutomationDataStore");

        } catch (Exception e) {
            e.printStackTrace();
            // LOGGER.info("context", e);
        }


    }


    //******Different  db's dashboard functional Flow services******//

    //create workspace and getting workspace id
    public  void createWorkspace(String uid, String spaceKey, String authToken, String workspaceName, String workspaceJSON, int statusCode) {
        try {
            Response response =
                    given()
                            .header("userid", uid)
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            .param("workspaceName", workspaceName)
                            .param("workspaceJSON", workspaceJSON)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlCrtWS)
                            .then()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> responseMap = from(response.asString()).get("");
                HashMap<String, Object> DesignerResp = (HashMap) responseMap.get("DesignerResp");
                String success = DesignerResp.get("success").toString();
                Object params = DesignerResp.get("params");
                JSONParser parser = new JSONParser();
                JSONObject object = (JSONObject) parser.parse(params.toString());
                wrkSpaceId = object.get("id").toString();
                System.out.println("params:" + params);
                System.out.println("workspaceId is" + wrkSpaceId);

                //Assertions
                Assert.assertNotNull(wrkSpaceId);
                Assert.assertEquals(success, "true");
            }
            LOGGER.info("successful execution");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public  void createDashboard(String dashboardParameters, String uid, String spaceKey, String authToken,int statusCode) {
        try {
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userid", uid)
                            .header("authtoken", authToken)
                            //Param
                            .param("dashboardParameters", dashboardParameters)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlCrtDB)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if (statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> responseMap = from(response.asString()).get("");
                HashMap<String, Object> DesignerResp = (HashMap) responseMap.get("DesignerResp");

                Object obj = DesignerResp.get("params");
                System.out.println(obj);

                JSONParser parser = new JSONParser();
                JSONObject object = (JSONObject) parser.parse(obj.toString());
                dashId = object.get("dashboardId").toString();
                System.out.println("dashboardIdCreate is=====:" + dashId);

                //Assertion
                Assert.assertEquals(DesignerResp.get("success"), true);
                Assert.assertNotNull(dashId);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public  void saveDashboard(String saveDashboardParameters, String uid, String spaceKey, String authToken,int statusCode) {
        try{
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", uid)
                            .header("authToken", authToken)
                            .param("dashboardParameters", saveDashboardParameters)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveDB)
                            .then()
                            .statusCode(statusCode)
                            .extract().response();
            if (statusCode == HttpStatus.SC_OK) {
                System.out.println("responsesavedashboard=" + response.asString());
                HashMap<String, Object> s1 = from(response.asString()).get("");

                /*******parsing the json object******/
                HashMap<String, Object> designerresp = (HashMap) s1.get("DesignerResp");
                Object obj1 = designerresp.get("params");
                System.out.println(obj1);
                JSONParser parser1 = new JSONParser();
                JSONObject object1 = (JSONObject) parser1.parse(obj1.toString());
                dashId = (String) object1.get("dashboardId");
                System.out.println("dashboardIdCreateSave is=====:" + dashId);

                //Assertions
                Assert.assertEquals(designerresp.get("success"), true);
                Assert.assertNotNull(dashId, "dashboardId is null");

            }
            LOGGER.info("successful execution");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //save Data ie  publishing dashboard
    public  void publishDashboardDB(String originalfilename,String dashboardName,String dependencyDetails,String description,String file,String uid,String spaceKey,String authToken,int statusCode) {
        try {
            int id = 0;
            int width = 1362;
            int height = 596;
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", uid)
                            .header("authtoken", authToken)
                            //params
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .param("parentid", myDocumentId )
                            .param("position",position)
                            .param("type", typefile)
                            .param("dashboardtype", dashboardtype)
                            .param("id", id)
                            .param("mobileViewVal", 0)
                            .param("imagename", imagename)
                            .param("description", description)
                            .param("width", width)
                            .param("height", height)
                            .param("title", dashboardName)
                            .param("dependencyDetails", dependencyDetails)
                            .param("file", file)
                            .param("originalfilename", originalfilename)
                            .when()
                            .post(urluploadDB)
                            .then().assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                System.out.println("responsepublishdashboard=" + response.asString());
                HashMap<String, Object> s = from(response.asString()).get("");//response of publish dashboard
                HashMap<String, Object> trees = (HashMap) s.get("trees");
                HashMap<String, Object> tree = (HashMap<String, Object>) trees.get("tree");
                publishDashId = tree.get("id").toString();
                LOGGER.info("publishDashboardId is===" + publishDashId);
            }
            LOGGER.info("successful execution");

            Assert.assertNotNull(publishDashId);
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public JSONArray getRecordsDB( String queryServiceHttpSoapEndpoint,String wsdl,String uid,String spaceKey,String authToken,int statusCode){
        try {
           // String queryServiceHttpSoapEndpoint = Utils.getproperty("queryServiceHttpSoapEndpoint");
            /*String wsdl = "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\"><Body><executeQuery xmlns=\"http://webservice.required.bdbizviz.com\"><filter xmlns=\"\"/><AuthToken xmlns=\"\">"+authToken+"</AuthToken><key xmlns=\"\"><serviceName>"+nividhQueryName+"</serviceName><dataType>JSON</dataType><Limit></Limit></key></executeQuery></Body></Envelope>";*/

            Response resp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userid", uid)
                            .header("authtoken", authToken)
                            //Param
                            .param("url", queryServiceHttpSoapEndpoint)
                            .param("wsdl", wsdl)
                            .when()
                            .post(urlgetRecords)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            String getRecords_Response = resp.asString().toString();
            System.out.println("getRecords_Response:"+ getRecords_Response);
            org.json.JSONObject js = org.json.XML.toJSONObject(getRecords_Response);
            System.out.println("js:"+ js);

            org.json.JSONObject envlopeObj = js.getJSONObject("soap:Envelope");
            org.json.JSONObject soapBodyObj = envlopeObj.getJSONObject("soap:Body");
            org.json.JSONObject executeQueryResponseObj = soapBodyObj.getJSONObject("ns2:executeQueryResponse");
            org.json.JSONObject returnObj = executeQueryResponseObj.getJSONObject("return");
            Thread.sleep(1000);
            org.json.JSONObject recordsObj = returnObj.getJSONObject("records");
            String contentObj = recordsObj.getString("content");

            actualgetRecordsData = new org.json.JSONArray(contentObj);
            System.out.println("content:" + actualgetRecordsData );
            Thread.sleep(1000);

        }catch (Exception e) {
            e.printStackTrace();
        }
        return actualgetRecordsData;
    }

    //saveorupdateUserDesignerpreference
    public  void saveorupdateuserdesignerpreferences(String preferences, String uid,String spaceKey,String authToken,int statusCode) {
        try {
            String preferenceID = "12345";
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //params
                            .param("preferences", preferences)
                            .param("preferenceID", preferenceID)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveorupdateuserdesignerpreferences)
                            .then().assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if (statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> DesignerResp = from(response.asString()).get("");
                LOGGER.info("response_designerPreference ==:" + DesignerResp);

              //  Assert.assertEquals(DesignerResp.get("success").toString(), "true");
            } else {
                LOGGER.info("successful execution");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }





}