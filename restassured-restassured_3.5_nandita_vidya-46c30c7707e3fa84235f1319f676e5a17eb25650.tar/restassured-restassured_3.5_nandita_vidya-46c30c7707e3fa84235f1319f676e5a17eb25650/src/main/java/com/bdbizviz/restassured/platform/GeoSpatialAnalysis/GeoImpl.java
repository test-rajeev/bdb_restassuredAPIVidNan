package com.bdbizviz.restassured.platform.GeoSpatialAnalysis;

import com.bdbizviz.restassured.platform.Designer.DesignerImpl;
import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.Utils;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.logging.Logger;

import static com.bdbizviz.restassured.platform.UserManagement.UserManagementHelper.*;

public class GeoImpl extends GeoHelper {
    private static final Logger LOGGER = Logger.getLogger(GeoImpl.class.getName());



    @BeforeClass
    public  void setupGeoImpl() {

        urlsaveOrUpdateGeoSpatialSettings = Utils.getUrl("saveOrUpdateGeoSpatialSettings");
        urlgetAllGeoSpatialSettings = Utils.getUrl("getAllGeoSpatialSettings");
        urlgetAllGeoShapeDatas = Utils.getUrl("getAllGeoShapeDatas");
        urluploadGeoShapeData = Utils.getUrl("uploadGeoShapeData");
        urluploadGeoSpatialRule = Utils.getUrl("uploadGeoSpatialRule");
        urlsaveGeoData = Utils.getUrl("saveGeoData");

        titleGoogle = Utils.getproperty("titleGoogle");
        titleleaflet = Utils.getproperty("titleleaflet");
        mapTypeGoogle = Utils.getproperty("mapTypeGoogle");
        mapTypeleaflet = Utils.getproperty("mapTypeleaflet");
        mapKeyGoogle = Utils.getproperty("mapKeyGoogle");
        mapKeyleaflet = Utils.getproperty("mapKeyleaflet");
        titlePolygon = Utils.getproperty("titlePolygon");

        user = Helper.getCustomerKey(emailidcreate,space_admin);
        userauth = Helper.getAuthToken(emailidcreate,pass_admin,space_admin);
        spaceKey = user.getSpacekey();
        uid = user.getId();
        authToken = userauth.getAuthToken();

        String commit = "";
        String new_Commit = "";
    }


    @Test(description = "getAllGeoShapeDatas")
    public void getAllGeoShapeDatas() {

        try {
            String geometryType = "Polygon";
            getAllGeoShapeDatas(geometryType,uid,authToken, spaceKey, HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }


 @Test(description = "getAllGeoShapeDatas")
    public void saveOrUpdateGeoSpatialSettings() {
        try {
            //get the google and leafletId
            getAllGeoSpatialSettingsAdmin(uid,authToken, spaceKey, HttpStatus.SC_OK);
            if(google_id == null) {
                saveOrUpdateGeoSpatialSettings(titleGoogle, mapTypeGoogle, mapKeyGoogle, mapDataGoogle, uid, authToken, spaceKey, HttpStatus.SC_OK);
                Thread.sleep(2000);
            }
            if(leaflet_id == null) {
                mapDataleaflet = "&copy; <a href=\"http://osm.org/copyright\">OpenStreetMap</a> contributors";
                saveOrUpdateGeoSpatialSettings(titleleaflet, mapTypeleaflet, mapKeyleaflet, mapDataleaflet, uid, authToken, spaceKey, HttpStatus.SC_OK);
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createGeoPolygonDocumentFlow")
    public void createGeoPolygonDocumentFlow() {

        try {
            String geometryType = "Polygon";

            uploadGeoShapeData("Country",geometryType,uid,authToken, spaceKey, HttpStatus.SC_OK);

            getAllGeoShapeDatas(geometryType,uid, authToken,spaceKey, HttpStatus.SC_OK);

            String geoJsonDataPolygon = "{\"type\":\"FeatureCollection\",\"features\": {\"AFG\":{\"Location\":\"AFG\",\"Revenue\":\"100000\"},\"AGO\":{\"Location\":\"AGO\",\"Revenue\":\"345677\"},\"ALB\":{\"Location\":\"ALB\",\"Revenue\":\"887655\"},\"ARE\":{\"Location\":\"ARE\",\"Revenue\":\"223354\"},\"ARG\":{\"Location\":\"ARG\",\"Revenue\":\"887655\"},\"ARM\":{\"Location\":\"ARM\",\"Revenue\":\"887655\"},\"ATA\":{\"Location\":\"ATA\",\"Revenue\":\"345666\"},\"ATF\":{\"Location\":\"ATF\",\"Revenue\":\"100000\"},\"AUS\":{\"Location\":\"AUS\",\"Revenue\":\"787333\"},\"AUT\":{\"Location\":\"AUT\",\"Revenue\":\"1111\"},\"AZE\":{\"Location\":\"AZE\",\"Revenue\":\"887655\"},\"BDI\":{\"Location\":\"BDI\",\"Revenue\":\"887655\"},\"BEL\":{\"Location\":\"BEL\",\"Revenue\":\"413322\"},\"BEN\":{\"Location\":\"BEN\",\"Revenue\":\"612233\"},\"BFA\":{\"Location\":\"BFA\",\"Revenue\":\"712233\"},\"BGD\":{\"Location\":\"BGD\",\"Revenue\":\"332211\"},\"BGR\":{\"Location\":\"BGR\",\"Revenue\":\"992233\"},\"BHS\":{\"Location\":\"BHS\",\"Revenue\":\"345677\"},\"BIH\":{\"Location\":\"BIH\",\"Revenue\":\"111111\"},\"BLR\":{\"Location\":\"BLR\",\"Revenue\":\"887655\"},\"BLZ\":{\"Location\":\"BLZ\",\"Revenue\":\"235456\"},\"BMU\":{\"Location\":\"BMU\",\"Revenue\":\"112233\"},\"BOL\":{\"Location\":\"BOL\",\"Revenue\":\"345565\"},\"BRA\":{\"Location\":\"BRA\",\"Revenue\":\"112233\"},\"BRN\":{\"Location\":\"BRN\",\"Revenue\":\"345677\"},\"BTN\":{\"Location\":\"BTN\",\"Revenue\":\"233454\"},\"BWA\":{\"Location\":\"BWA\",\"Revenue\":\"100000\"},\"CAF\":{\"Location\":\"CAF\",\"Revenue\":\"987654\"},\"CAN\":{\"Location\":\"CAN\",\"Revenue\":\"334422\"},\"CHE\":{\"Location\":\"CHE\",\"Revenue\":\"112233\"},\"CHL\":{\"Location\":\"CHL\",\"Revenue\":\"345677\"},\"CHN\":{\"Location\":\"CHN\",\"Revenue\":\"893344\"},\"CIV\":{\"Location\":\"CIV\",\"Revenue\":\"112233\"},\"CMR\":{\"Location\":\"CMR\",\"Revenue\":\"100000\"},\"COD\":{\"Location\":\"COD\",\"Revenue\":\"778833\"},\"COG\":{\"Location\":\"COG\",\"Revenue\":\"334422\"},\"COL\":{\"Location\":\"COL\",\"Revenue\":\"345677\"},\"CRI\":{\"Location\":\"CRI\",\"Revenue\":\"345677\"},\"CUB\":{\"Location\":\"CUB\",\"Revenue\":\"777733\"},\"IND\":{\"Location\":\"IND\",\"Revenue\":\"992233\"},\"MAR\":{\"Location\":\"MAR\",\"Revenue\":\"887655\"},\"USA\":{\"Location\":\"USA\",\"Revenue\":\"112233\"},\"UKR\":{\"Location\":\"UKR\",\"Revenue\":\"345677\"},\"ZAF\":{\"Location\":\"ZAF\",\"Revenue\":\"112233\"}},\"keyList\":[\"Location\"]}";

            String geoSpatialRuleString = "{\"Rules\":[{\"object\":\"Location\",\"operator\":\"=\",\"operand\":\"IND\",\"color\":\"#4a25db\",\"strokeColor\":\"#4a25db\"}],\"shapeFileId\":\""+geoShapeId+"\", \"defaultColor\":\"#ffffff\",\"descPopUpList\": [\"Location\"],\"dispList\": [\"Location\",\"Revenue\"]}";
            uploadGeoSpatialRule(geoJsonDataPolygon,geoSpatialRuleString,geometryType,uid,authToken, spaceKey, HttpStatus.SC_OK);

            getUserInfoByToken(authToken);

            saveGeoData(titlePolygon,ruleId,uid,authToken, spaceKey, HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }



}
