package com.bdbizviz.restassured.platform.SecurityCheck;

import com.bdbizviz.restassured.platform.Designer.DesignerHelper;
import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.User;
import com.bdbizviz.restassured.platform.Util.Utils;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.logging.Logger;

public class DesignerSecurityCheck extends DesignerHelper {

    private static final Logger LOGGER = Logger.getLogger(DesignerSecurityCheck.class.getName());
    public static User usernan;
    public static User usernanauth;
    public static String authTokennan;
    public static String uidnan;
    public static String spaceKeynan;

    String commit = "";

    @BeforeClass
    public void setupHomeUI(){
        prop = Utils.getProps();

        //Craete a new user
        createnewuserFunctional(spaceKeyadmin,uidadmin,authTokenadmin,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authTokenadmin,spaceKey, HttpStatus.SC_OK);

        //User which is not assigned to any group for security check
        usernan=Helper.getCustomerKey(emailidcreatefun,space_admin);
        usernanauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
        spaceKeynan = useradmin.getSpacekey();
        authTokennan=usernanauth.getAuthToken();
        uidnan=usernan.getId();
    }

    @Test(description = "getuserdesignerpreferences")
    public void getuserdesignerpreferencesNeg() {

        try {
            getuserdesignerpreferences(uidnan, spaceKeynan,authTokennan, HttpStatus.SC_USE_PROXY);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getAllWorkspaceAndDashboard")
    public void getAllWorkspaceAndDashboardNeg() {

        try {
            getAllWorkspaceAndDashboard(uidnan, spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "gettrashitems")
    public void gettrashitemsNeg() {

        try {
            gettrashitems(uidnan, spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "CreateWorkspace")
    public void createWorkspaceNeg() {

        try {
            fetchWorkspace(uidnan, spaceKeynan,authTokennan,workspaceName_Advanced,workspaceJSON,HttpStatus.SC_USE_PROXY);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "CreateDashboard")
    public void createDashboardNeg() {

        try {
            String dashboardParameters = "{\"workspaceId\":\"" + workspaceId + "\",\"dashboardName\":\"" + dashboardName + "\",\"dashboardJSON\":\"{}\"}";
            fetchDashboardWebservice(dashboardParameters,uidnan, spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "openDashboard")
    public void openDashboardNeg() {
        try {
            String dashboardParameters_Open = "{\"dashboardId\":\""+dashboardId+"\"}";
            openDashboard(dashboardParameters_Open,uidnan, spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "RestoreWorkspace")
    public void restoreWorkspaceNeg() {

        try {
            String dashboardParameters_restore = "{\"dashboardId\":\""+workspaceId+"\",\"workspaceId\":\""+workspaceId+"\"}";
            restoredashboardfromtrash(dashboardParameters_restore,uidnan, spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getdocumentInfo")
    public void getdocumentinfobyidNeg() {

        try {
            getDocumentInfoByID(uidnan, spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "publishDashboard")
    public void publishDashboardNeg() {

        try {
            publishDashboard(uidnan, spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    //flow1
    @Test(description = "CreateWorkSpaceToDeleteWorkSpace")
    public void createWorkSpaceToDeleteWorkSpaceNeg() {

        try {
            //Create Worksapce
            fetchWorkspace(uidnan, spaceKey,authTokennan,workspaceName_Advanced,workspaceJSON,HttpStatus.SC_USE_PROXY);

            //Rename Workspace
            String dashboardParameters = "{\"dashboardId\":\""+workspaceId+"\",\"dashboardName\":\"RestWorkspaceNew\"}";
            renameOrmoveWorkspace(dashboardParameters,uidnan,spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);

            //Trash Workspace
            String dashboardParameters_del = "{\"dashboardId\":\""+dashboardId+"\",\"workspaceId\":\""+workspaceId+"\"}";
            trashWorkspace(dashboardParameters_del,uidnan,spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);

            //Get all trash items
            gettrashitems(uidnan, spaceKey,authTokennan,HttpStatus.SC_USE_PROXY);

            //restore Workspace
            String dashboardParameters_restore = "{\"dashboardId\":\""+workspaceId+"\",\"workspaceId\":\""+workspaceId+"\"}";
            restoredashboardfromtrash(dashboardParameters_restore,uidnan, spaceKey,authTokennan,HttpStatus.SC_USE_PROXY);

            //Trash Workspace
            trashWorkspace(dashboardParameters_del,uidnan,spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);

            //Delete workspace permantely
            String dashboardParameters_permanant = "{\"dashboardId\":\"["+dashboardId+"]\",\"workspaceId\":\"["+dashboardId+"]\"}";
            deleteDashboardPermanently(dashboardParameters_permanant,uidnan,spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);


        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //flow2
    @Test(description = "movedashboard from one workspace to other")
    public void moveDashboardNeg() {
        try {
            //Create Worksapce
            //  fetchWorkspace(uidnan, spaceKey,authTokennan,workspaceName_Advanced,workspaceJSON);
            fetchWorkspace(uidnan, spaceKeynan,authTokennan,moveRestWorkSpace,workspaceJSON,HttpStatus.SC_USE_PROXY);

            //Create Dashboard
            String dashboardParameters = "{\"workspaceId\":\"" + workspaceId + "\",\"dashboardName\":\"" + dashboardName + "\",\"dashboardJSON\":\"{}\"}";
            fetchDashboardWebservice(dashboardParameters,uidnan, spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);

            //Create Worksapce
            fetchWorkspace(uidnan, spaceKeynan,authTokennan,workspaceName_New,workspaceJSON,HttpStatus.SC_USE_PROXY);

            //Move Workspace
            String dashboardParameters_move = "{\"dashboardId\":\""+dashboardId+"\",\"workspaceId\":\""+workspaceId+"\"}";
            renameOrmoveWorkspace(dashboardParameters_move,uidnan,spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);



        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //flow3
    @Test(description = "CreateDashboardToDeleteDashboard")
    public void createDashboardToDeleteDashboardNeg() {

        try {
            //Create Worksapce
            fetchWorkspace(uidnan, spaceKeynan,authTokennan,workspaceName_Advanced,workspaceJSON,HttpStatus.SC_USE_PROXY);

            //Rename Workspace
            String dashboardParameters = "{\"dashboardId\":\""+workspaceId+"\",\"dashboardName\":\"RestFlowWorkspace\"}";
            renameOrmoveWorkspace(dashboardParameters,uidnan,spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);

            //create Dashboard
            String dashboardParameters_createDash = "{\"workspaceId\":\"" + workspaceId + "\",\"dashboardName\":\"" + dashboardName + "\",\"dashboardJSON\":\"{}\"}";
            fetchDashboardWebservice(dashboardParameters_createDash,uidnan, spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);

            //Open Dashboard
            String dashboardParameters_Open = "{\"dashboardId\":\""+dashboardId+"\"}";
            openDashboard(dashboardParameters_Open,uidnan, spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);

            //Rename dashboard
            String dashboardParameters_rename = "{\"dashboardId\":\""+dashboardId+"\",\"dashboardName\":\"RenamedWebServiceDashboard\"}";
            renameOrmoveWorkspace(dashboardParameters_rename,uidnan,spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);

            //getAllDashboards And worksapces
            getAllWorkspaceAndDashboard(uidnan, spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);

            //Move Dashboard from one workspace to other
            String dashboardParameters_move = "{\"dashboardId\":\""+dashboardId+"\",\"workspaceId\":\""+getWorkSpaceId+"\"}";
            renameOrmoveWorkspace(dashboardParameters_move,uidnan,spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);

            //Trash Workspace
            String dashboardParameters_del = "{\"dashboardId\":\""+workspaceId+"\",\"workspaceId\":\""+workspaceId+"\"}";
            trashWorkspace(dashboardParameters_del,uidnan,spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);

            //Get all trash items
            gettrashitems(uidnan, spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);

            //Delete workspace permantely
            String dashboardParameters_permanant = "{\"dashboardId\":\"["+dashboardId+"]\",\"workspaceId\":\"["+dashboardId+"]\"}";
            deleteDashboardPermanently(dashboardParameters_permanant,uidnan,spaceKeynan,authTokennan,HttpStatus.SC_USE_PROXY);



        } catch (Exception e) {

            e.printStackTrace();
        }
    }




}