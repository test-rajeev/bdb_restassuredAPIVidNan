
package com.bdbizviz.restassured.platform.HomeUI;

import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.User;
import com.bdbizviz.restassured.platform.Util.Utils;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.bdbizviz.restassured.platform.Designer.DesignerHelper.*;
import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;

public class HomeUI_Impl extends  HomeUiHelper {
    private static final Logger LOGGER = Logger.getLogger(HomeUI_Impl.class.getName());

    @BeforeClass
    public static void setupHomeUi(){
        prop = Utils.getProps();//Fetch all Permission data of properties Permission file and store in prop
        position = Long.valueOf(Utils.getproperty("position"));
        rows = Long.valueOf(Utils.getproperty("rows"));
        folderType= Utils.getproperty("folderType");
        dashboardTypeFolder= Utils.getproperty("dashboardTypeFolder");
        imagenameFile= Utils.getproperty("imagenamefile");
        folTitle= Utils.getproperty("folTitle");
        folTitleRename=Utils.getproperty("folTitleRename");
        doctype=Utils.getproperty("doctype");
        doctypefile=Utils.getproperty("doctypefile");
        docTitleRename=Utils.getproperty("docTitleRename");
        copyTitle=Utils.getproperty("copyTitle");
        copyDocTitle=Utils.getproperty("copyDocTitle");
        bIStoryname=Utils.getproperty("bIStoryname");
        wrksapceName=Utils.getproperty("wrksapceName");
        dashName = Utils.getproperty("dashName");
        dashboardNameNew = Utils.getproperty("dashboardNameNew");

        urlgetUserInfoByToken = Utils.getUrl( "getUserInfoByToken");
        urlgetAllDocuments = Utils.getUrl("getalldocuments");
        urlsaveFolData = Utils.getUrl("saveFolderData");
        urlrenameNode = Utils.getUrl("renameNode");
        urlgetFavouriteDocuments = Utils.getUrl("getfavouritedocuments");
        urlcopyPaste = Utils.getUrl("copyPaste");
        urlgetListView = Utils.getUrl("getlistview");
        urlassignAllPrivilege = Utils.getUrl("assignAllPrivilege");
        urlgetDocumentList = Utils.getUrl("getDocumentList");
        urlgetUsersfromGroups = Utils.getUrl("getUsersfromGroups");
        urlcutPaste = Utils.getUrl("cutPasteFolder");
        urlpluginService = Utils.getUrl("pluginservice");
        urlgetWikiByDocId = Utils.getUrl("getWikiByDocId");
        urlgetCubeData = Utils.getUrl("getDsData");
        urlcreateOrUpdateWiki = Utils.getUrl("createOrUpdateWiki");
        urlloadPrivilege = Utils.getUrl("loadPrivilege");
        urldmAssignExcludePrivilege = Utils.getUrl("dmAssignExcludePrivilege");


        //Non-Admin user
        user = Helper.getCustomerKey(emailidcreate,space_admin);
        userauth = Helper.getAuthToken(emailidcreate,pass_admin,space_admin);
        spaceKey = user.getSpacekey();
        uid = user.getId();
        authToken = userauth.getAuthToken();

        String commit = "";

    }

    @Test(description = "getUserInfoByToken")
    public void getUserInfoByToken() {

        try {
            getUserInfoByToken(authToken);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getFavouriteDocuments")
    public void getFavouriteDocuments() {
        try {
            getFavouriteDocuments(uid,spaceKey,authToken, HttpStatus.SC_OK);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "getalldocuments")
    public void getListview() {
        try {
            getlistview(uid,spaceKey,authToken,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createDocumentOnHomeUI")
    public void createDocMyDocHomeUi() {

        try {
            createDocMyDocHomeUi(uid,spaceKey,authToken, HttpStatus.SC_OK);

            //Remove Folder
            removeNodeDocument(uidadmin, docId_HomeUi, authTokenadmin, spaceKey, HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createFolderAndDocument")
    public void createFolderInMyDocs() {

        try {
            createFolderInMyDocs(uid,HomeUiHelper.myDocumentId,position,authToken,spaceKey,HttpStatus.SC_OK);

             //Remove Folder
            removeNodeDocument(uidadmin, folderid, authTokenadmin, spaceKey, HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createFolderInPublicFolder")
    public void createFolderInPublicDoc() {
        try {
            createFolderInPublicDoc(uid,HomeUiHelper.publicDocumentId,position,authToken,spaceKey,HttpStatus.SC_OK);

            //Deleting the created Folder
            removeNode(uid,createFol_pubId, authToken, spaceKey,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createDocumentInFolderPublicFolder")
    public void createDocInFolderPublicDoc() {
        try {
            createDocInFolderPublicDoc(uid,HomeUiHelper.createFol_pubId,position,authToken,spaceKey,HttpStatus.SC_OK);

            //Deleting the created document
            removeNode(uid,create_pubDocId, authToken, spaceKey,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //======A unquie function to perform mul service calls by using folder id====//
    @Test(description ="creating the folder and renaming it, add folder to fav and delete")
    public static void createFolToDelFlow(){
        try{
            //Creating Folder
            createFolderInHomeUi(uid, myDocumentId, position,authToken,spaceKey,HttpStatus.SC_OK);
            LOGGER.info(("folderid:" +folderid_Home));

            renameNode(folderid_Home,folTitleRename,doctype,uid,spaceKey,authToken, HttpStatus.SC_OK);

            //add fol to favourites
            addFolToFav(uid,folderid_Home, authToken, spaceKey,HttpStatus.SC_OK);

            //remove fol
            removeNode(uid,folderid_Home, authToken, spaceKey,HttpStatus.SC_OK);
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    //flow2
    //====A unquie function to perform mul service calls by using document id====//
    @Test(description="crearting the Document and renaming it,add document to fav and delete")
    public static void createDocInFolToDelDocumentFlow(){
        try{
            //CreateFolAnd Document inside Folder
            createFolderInMyDocs(uid, myDocumentId,position,authToken,spaceKey,HttpStatus.SC_OK);

            renameNode(docId,docTitleRename,doctypefile,uid,spaceKey,authToken, HttpStatus.SC_OK);

            // Adding Document to Favourites
            addDocToFav(uid,folderid,authToken,spaceKey,HttpStatus.SC_OK);

            // moveDocument();
            removeNodeDocument(uid,folderid,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //flow3
    @Test(description ="creating the Folder and deleting it")
    public static void copyFolder(){
        try{
            //getUserInfoToken
            getUserInfoByToken(authToken);

            //CreateFolder
            createFolderInHomeUi(uid, HomeUiHelper.myDocumentId, position,authToken,spaceKey,HttpStatus.SC_OK);
            String dashboardType = Utils.getproperty("dashboardType");

            copyPaste(folderid_Home,copyTitle,myDocumentId,Integer.valueOf(dashboardType),uid,spaceKey,authToken, HttpStatus.SC_OK);

            //Deleting the created folder
            removeNode(uid,folderid_Home, authToken, spaceKey,HttpStatus.SC_OK);

            //getListView to get copyid
            getlistview(uid,spaceKey,authToken,HttpStatus.SC_OK);

            //Deleting the copied folder
            removeNode(uid,copyId, authToken, spaceKey,HttpStatus.SC_OK);
        }
        catch(Exception e){
            e.printStackTrace();
        }

    }

    //flow4
    @Test(description ="creating the Document inside folder and copy pasting in my documents")
    public static void copyDocument(){
        try{
            int x = 0;
            Long postion = new Long(x);

            int dashDocType = 0;
            Long dashDoc = new Long(dashDocType);

            createDocInMyDoc(uid, doctypefile,dashDoc ,myDocumentId,postion,authToken,spaceKey, HttpStatus.SC_OK);
            String dashboardType = Utils.getproperty("dashboardType");

           //CopyPasteDocument
            copyPaste(docId,copyDocTitle,myDocumentId,Integer.valueOf(dashboardType),uid,spaceKey,authToken, HttpStatus.SC_OK);

            //Deleting the created Document
            removeNode(uid,docId, authToken, spaceKey,HttpStatus.SC_OK);

            //getListView to get copyid
            getlistview(uid,spaceKey,authToken,HttpStatus.SC_OK);

            //Deleting the created Document
            removeNode(uid,copyIdDoc, authToken, spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //flow5
    @Test(description = "creating the folder and moving the same")
    public static void moveFolder(){
        try{
            createFolderInHomeUi(uid, myDocumentId, position,authToken,spaceKey,HttpStatus.SC_OK);

            //CutPasteFolder
            cutPaste(folderid_Home,Utils.getproperty("moveto"),folTitleRename,myDocumentId,uid,spaceKey,authToken, HttpStatus.SC_OK);

            //Deleting the created Folder
            removeNode(uid,folderid_Home, authToken, spaceKey,HttpStatus.SC_OK);
        }
        catch(Exception e){
            e.printStackTrace();
        }

    }

    //flow6
    @Test(description = "creating the document and moving the same")
    public static void moveDocument(){
        try{
            //create Document
            createDocMyDocHomeUi(uid, spaceKey,authToken, HttpStatus.SC_OK);

            //moveToList
            moveToList(docId_HomeUi,uid, folderid_Home, authToken, spaceKey,HttpStatus.SC_OK );

            //CutPasteDocument
            cutPaste(docId_HomeUi,Utils.getproperty("moveto"),Utils.getproperty("documentTitle"),myDocumentId,uid,spaceKey,authToken, HttpStatus.SC_OK);

            //Deleting the created Folder
            removeNode(uid,docId_HomeUi, authToken, spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //flow7
    @Test(description ="Create User, share Document to User and delete document,delete user")
    public static void getDocumentList(){

        try {
            //Create Folder and document inside
            createFolderInMyDocs(uid, myDocumentId,position,authToken,spaceKey,HttpStatus.SC_OK);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("NEWCREATEGRPID==" + newgroupid);

            //ShareDocumentToUser
            shareDocUser(docId,uid,authToken,spaceKey, HttpStatus.SC_OK);
            System.out.println("emailId ======"+emailidcreatefun);
            System.out.println("createUserId ======"+newuseridfunuser);

            //Login with new user passing valid password
            User usernew = Helper.getCustomerKey(emailidcreatefun,space_admin);
            User userobjauthnew = Helper.getAuthToken(emailidcreatefun,pass_admin, space_admin);
            String authnew =  null;
            authnew = userobjauthnew.getAuthToken();
            String idnew = null;
            idnew = usernew.getId();

            //***calling documentListView by logging from the Selected user credentials***//
            Response response_DocumentList =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userid", Integer.valueOf(idnew))
                            .header("authtoken", authnew)
                            //params
                            .param("userId", idnew)
                            .param("nodeId", folderid)
                            .param("token",authnew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetDocumentList)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> resp = from(response_DocumentList.asString()).get("");
            HashMap<String,Object> trees = (HashMap)resp.get("trees");
            List<HashMap<String,Object>> treesList = (ArrayList<HashMap<String, Object>>)trees.get("treesList");

            for (HashMap<String, Object> treeListObj : treesList) {
                if (treeListObj.containsKey("id") &&   treeListObj.get("id").toString().equals(docId)) {
                    sharedDocid =  treeListObj.get("id").toString();
                }
            }

            LOGGER.info(("trees_DocumentList:" +trees.toString()));
            LOGGER.info(("sharedDocid:" +sharedDocid));

            //****Assert to check whether document is shared for user ***//
            Assert.assertEquals(sharedDocid, docId);

            //Deleting the created Document
            removeNode(uid,sharedDocid, authToken, spaceKey,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //flow8
    @Test(description =" Create User, group, crate DocumentShare the document to assigned usergroup and exclude the selected user")
    public static void excludeDocUserGroup(){
        try{
            //Create Folder and document inside
            createFolderInMyDocs(uid, myDocumentId,position,authToken,spaceKey,HttpStatus.SC_OK);
            System.out.println("selDocId:"+docId);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("selUserGrpId==" + newgroupid);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+ Helper.generateRandomString(),usrname,fullname+ Helper.generateRandomString(),pass_admin,newgroupid,authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);

            //getting User from groups
            getusersfromgroups(uid,newgroupid, authToken, spaceKey,HttpStatus.SC_OK );

            //Sharing Document to Usergroup
            shareDocUserGroup(docId,newgroupid, selUserId, uid, authToken,spaceKey,HttpStatus.SC_OK);

            //Login with new user passing  valid password
            User usernew = Helper.getCustomerKey(selUsers_MailId,space_admin);
            User userobjauthnew = Helper.getAuthToken(selUsers_MailId,pass_admin, space_admin);
            String authnew =  null;
            authnew = userobjauthnew.getAuthToken();
            String idnew = null;
            idnew = usernew.getId();

            //****DocumentList service to check whether the particular user has excluded to get the documents***//
            Response response1 =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userid", Integer.valueOf(idnew))
                            .header("authtoken", authnew)
                            //params
                            .param("userId", idnew)
                            .param("nodeId", myDocumentId)
                            .param("token",authnew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetDocumentList)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> resp = from(response1.asString()).get("");
            HashMap<String,Object> trees = (HashMap)resp.get("trees");
            List< HashMap<String, Object> > treesList = (ArrayList<HashMap<String, Object>>) trees.get("treesList");

            for(HashMap<String, Object> tree:treesList){
                if(tree.containsKey("id") && tree.get("id").equals(docId)){
                    sharedDocid =  tree.get("id").toString();
                }
            }
            LOGGER.info(("trees:" +trees.toString()));
            LOGGER.info(("sharedDocid:" +sharedDocid));

            //****Assert to check whether document is shared for the same user and document is shared excluding the user ***//
            Assert.assertEquals(selUserId, Integer.valueOf(idnew));

            //Deleting the created Folder
            removeNode(uid,folderid, authToken, spaceKey,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    //Flow 9
    //when we click on any document and click on properties//
    @Test(description ="get the document info(when we modify the document")
    public  void getDocumentInfoById(){
        try{
            //*****Calling order by date service******//
            String orderTypeDate = Utils.getproperty("orderTypeDate");
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            .param("nodeid", myDocumentId)
                            .param("orderType", orderTypeDate)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> responseMap = from(response.asString()).get("trees");
            LOGGER.info(("trees:" +responseMap.toString()));

            //****Assert to check success message***//
            Assert.assertEquals(responseMap.get("success").toString(),"true" );

            //calling createDoc function to fetch the docid
            int x = 0;
            Long postion = new Long(x);

            int dashDocType = 0;
            Long dashDoc = new Long(dashDocType);

            createDocInMyDoc(uid, doctypefile,dashDoc ,myDocumentId,postion,authToken,spaceKey, HttpStatus.SC_OK);

            //adding getThumbnailByTreeID in a flow
            getThumbnailByTreeID(docId,uid,authToken,spaceKey, HttpStatus.SC_OK);

            //getDocumentInfoById
            getdocumentinfobyid(docId, uid,spaceKey,authToken,HttpStatus.SC_OK);

            //Delete document
            removeNodeDocument(uid,docId,authToken,spaceKey,HttpStatus.SC_OK);

        }catch(Exception e){
            e.printStackTrace();
        }


    }

    //BI-Story Creation
    @Test(description = "creating and saving the Story in My documents")
    public static void createStoryFlow(){

        try {
            createStoryInFolderMyDoc(Utils.getproperty("consumerNameCreateStory"),Utils.getproperty("serviceNameCreateStory"),spaceKey,authToken,uid, HttpStatus.SC_OK);

            saveStoryData(storyId,authToken,spaceKey,uid,HttpStatus.SC_OK);

            getData(savedStoryId,authToken,spaceKey,uid,HttpStatus.SC_OK);

            getWikiByDocId(savedStoryId, authToken,spaceKey,uid,HttpStatus.SC_OK);

            getStoryById(Utils.getproperty("consumerNameCreateStory"),Utils.getproperty("serviceNameStory"),authToken,spaceKey,uid,HttpStatus.SC_OK);

            getDeliveryResultByOwnerId(Utils.getproperty("consumerNamegetDeliveryResultByOwnerId"), Utils.getproperty("serviceNamegetDeliveryResultByOwnerId"),authToken,spaceKey,uid,HttpStatus.SC_OK);

            getDataStoreDetails(Utils.getproperty("consumerNamegetCubeDetails"), Utils.getproperty("serviceNamegetDatastoreDetails"),authToken,spaceKey,uid,HttpStatus.SC_OK);

            getCubeInfo(Utils.getproperty("consumerNamegetCubeById"), Utils.getproperty("serviceNamegetCubeInfo"),authToken,spaceKey,uid, HttpStatus.SC_OK);

            serviceNamegetCubeData = bizvizCubeId + spaceKey;
            String cubeDataDimen = "{\"title\":\"Untitled\",\"desc\":\"By Location_Id\",\"defaultChartClass\":\"MixedChart\",\"chartProperties\":{\"Object.Chart.xAxis.LabelFontSize\":\"12\",\"Object.Chart.yAxis.LabelFontSize\":\"12\",\"Object.Chart.Precision\":\"0\",\"Object.Chart.secondaryAxisShow\":false,\"Object.Chart.SecondaryAxisPrecision\":\"0\",\"Object.Chart.SecondaryAxisSecondaryFormatter\":\"Number\",\"Object.Chart.SecondaryAxisSecondaryUnit\":\"auto\",\"Object.Chart.SecondaryFormater\":\"Number\",\"Object.Chart.Unit\":\"None\",\"Object.Chart.SecondaryUnit\":\"auto\",\"Object.Chart.showSlider\":false,\"Object.Chart.baseZero\":false},\"filter\":{},\"filterList\":\"None\",\"mergedCubes\":[],\"currentCube\":null,\"isMergeEnabled\":false,\"mergedCubeDetails\":{},\"aggregation\":{\"op\":\"sum\",\"sfx\":\"\",\"pfx\":\"\",\"measure\":\"\"},\"category\":[{\"dimension\":\"Location_Id\",\"interval\":\"\",\"sourceID\":"+bizvizCubeId+"}],\"series\":[],\"transDim\":\"\",\"customField\":[],\"rules\":[],\"properties\":{\"legend\":{\"enable\":false,\"orientation\":1,\"style\":1},\"excludeView\":{\"enable\":false},\"showDataLabel\":true,\"cardFilter\":{\"enabled\":false,\"field\":\"None\"},\"dataRestriction\":{}},\"querytype\":\"simple\",\"mergedDataStore\":{},\"masterDataStore\":\""+bizvizCubeId+"\"}";
            getCubeData(cubeDataDimen,Utils.getproperty("consumerNamegetCubeData"), serviceNamegetCubeData,authToken,spaceKey,uid,HttpStatus.SC_OK);

            String cubeDataMeasure = "{\"title\":\"Sum( Order_Amount )\",\"desc\":\"By Location_Id\",\"defaultChartClass\":\"MixedChart\",\"chartProperties\":{\"Object.Chart.xAxis.LabelFontSize\":\"12\",\"Object.Chart.yAxis.LabelFontSize\":\"12\",\"Object.Chart.Precision\":\"0\",\"Object.Chart.secondaryAxisShow\":false,\"Object.Chart.SecondaryAxisPrecision\":\"0\",\"Object.Chart.SecondaryAxisSecondaryFormatter\":\"Number\",\"Object.Chart.SecondaryAxisSecondaryUnit\":\"auto\",\"Object.Chart.SecondaryFormater\":\"Number\",\"Object.Chart.Unit\":\"None\",\"Object.Chart.SecondaryUnit\":\"auto\",\"Object.Chart.showSlider\":false,\"Object.Chart.baseZero\":false,\"Object.Chart.showLegends\":false},\"filter\":{},\"filterList\":\"None\",\"mergedCubes\":[],\"currentCube\":null,\"isMergeEnabled\":false,\"mergedCubeDetails\":{},\"aggregation\":{\"op\":\"sum\",\"sfx\":\"\",\"pfx\":\"\",\"measure\":\"\"},\"category\":[{\"dimension\":\"Location_Id\",\"interval\":\"\",\"sourceID\":"+bizvizCubeId+"}],\"series\":[{\"measure\":\"Order_Amount\",\"op\":\"sum\",\"sourceID\":"+bizvizCubeId+"}],\"transDim\":\"\",\"customField\":[],\"rules\":[],\"properties\":{\"legend\":{\"enable\":false,\"orientation\":1,\"style\":1},\"excludeView\":{\"enable\":false},\"showDataLabel\":true,\"cardFilter\":{\"enabled\":false,\"field\":\"None\"},\"dataRestriction\":{}},\"querytype\":\"simple\",\"mergedDataStore\":{},\"masterDataStore\":\""+bizvizCubeId+"\"}";
            getCubedataDimen2(cubeDataMeasure,Utils.getproperty("consumerNamegetCubedataDimen2"), serviceNamegetCubeData,authToken,spaceKey,uid,HttpStatus.SC_OK);

            String cubeDataMeasureTwo = "{\"title\":\"Sum( Order_Amount )\",\"desc\":\"By Location_Id\",\"defaultChartClass\":\"MixedChart\",\"chartProperties\":{\"Object.Chart.xAxis.LabelFontSize\":\"12\",\"Object.Chart.yAxis.LabelFontSize\":\"12\",\"Object.Chart.Precision\":\"0\",\"Object.Chart.secondaryAxisShow\":false,\"Object.Chart.SecondaryAxisPrecision\":\"0\",\"Object.Chart.SecondaryAxisSecondaryFormatter\":\"Number\",\"Object.Chart.SecondaryAxisSecondaryUnit\":\"auto\",\"Object.Chart.SecondaryFormater\":\"Number\",\"Object.Chart.Unit\":\"None\",\"Object.Chart.SecondaryUnit\":\"auto\",\"Object.Chart.showSlider\":false,\"Object.Chart.baseZero\":false,\"Object.Chart.showLegends\":false},\"filter\":{},\"filterList\":\"None\",\"mergedCubes\":[],\"currentCube\":null,\"isMergeEnabled\":false,\"mergedCubeDetails\":{},\"aggregation\":{\"op\":\"sum\",\"sfx\":\"\",\"pfx\":\"\",\"measure\":\"\"},\"category\":[{\"dimension\":\"Location_Id\",\"interval\":\"\",\"sourceID\":"+bizvizCubeId+"}],\"series\":[{\"measure\":\"Order_Amount\",\"op\":\"sum\",\"sourceID\":"+bizvizCubeId+"},{\"measure\":\"Commission\",\"op\":\"sum\",\"sourceID\":"+bizvizCubeId+"}],\"transDim\":\"\",\"customField\":[],\"rules\":[],\"properties\":{\"legend\":{\"enable\":false,\"orientation\":1,\"style\":1},\"excludeView\":{\"enable\":false},\"showDataLabel\":true,\"cardFilter\":{\"enabled\":false,\"field\":\"None\"},\"dataRestriction\":{}},\"querytype\":\"simple\",\"mergedDataStore\":{},\"masterDataStore\":\""+bizvizCubeId+"\"}";
            getCubedataDimen2(cubeDataMeasureTwo,Utils.getproperty("consumerNamegetCubedataDimen2"), serviceNamegetCubeData,authToken,spaceKey,uid,HttpStatus.SC_OK);

            String filterdata = "{\"filter\":{},\"dimForFilter\":[\"Location_Id\"],\"dimension\":[{\"name\":\"Location_Id\",\"interval\":\"\"}],\"measure\":[],\"facts\":{},\"elasticSearch\":{\"isEnabled\":true},\"limit\":[\"0\"]}";
            getDistinctDimName(filterdata,Utils.getproperty("consumerNamegetCubedataDimen2"), serviceNamegetCubeData,authToken,spaceKey,uid,HttpStatus.SC_OK);

            String filterCubeData = "{\"title\":\"Sum( Order_Amount )\",\"desc\":\"By Location_Id\",\"defaultChartClass\":\"MixedChart\",\"chartProperties\":{\"Object.Chart.xAxis.LabelFontSize\":\"12\",\"Object.Chart.yAxis.LabelFontSize\":\"12\",\"Object.Chart.Precision\":\"0\",\"Object.Chart.secondaryAxisShow\":false,\"Object.Chart.SecondaryAxisPrecision\":\"0\",\"Object.Chart.SecondaryAxisSecondaryFormatter\":\"Number\",\"Object.Chart.SecondaryAxisSecondaryUnit\":\"auto\",\"Object.Chart.SecondaryFormater\":\"Number\",\"Object.Chart.Unit\":\"None\",\"Object.Chart.SecondaryUnit\":\"auto\",\"Object.Chart.showSlider\":false,\"Object.Chart.baseZero\":false,\"Object.Chart.showLegends\":false},\"filter\":{\"Location_Id\":[\"301161\",\"301721\",\"301781\",\"301451\",\"301306\",\"301252\",\"301509\",\"301564\",\"301326\"]},\"filterList\":\"None\",\"mergedCubes\":[],\"currentCube\":null,\"isMergeEnabled\":false,\"mergedCubeDetails\":{},\"aggregation\":{\"op\":\"sum\",\"sfx\":\"\",\"pfx\":\"\",\"measure\":\"\"},\"category\":[{\"dimension\":\"Location_Id\",\"interval\":\"\",\"sourceID\":"+bizvizCubeId+"}],\"series\":[{\"measure\":\"Order_Amount\",\"op\":\"sum\",\"sourceID\":"+bizvizCubeId+"},{\"measure\":\"Commission\",\"op\":\"sum\",\"sourceID\":"+bizvizCubeId+"}],\"transDim\":\"\",\"customField\":[],\"rules\":[],\"properties\":{\"legend\":{\"enable\":false,\"orientation\":1,\"style\":1},\"excludeView\":{\"enable\":false},\"showDataLabel\":true,\"cardFilter\":{\"enabled\":false,\"field\":\"None\"},\"dataRestriction\":{}},\"querytype\":\"simple\",\"mergedDataStore\":{},\"masterDataStore\":\""+bizvizCubeId+"\"}";
            getCubedataDimen2(filterCubeData,Utils.getproperty("consumerNamegetCubedataDimen2"), serviceNamegetCubeData,authToken,spaceKey,uid,HttpStatus.SC_OK);

            saveCubeView(Utils.getproperty("consumerNamesaveCubeView"),Utils.getproperty("serviceNamesaveCubeView"),authToken,spaceKey,uid,HttpStatus.SC_OK);

            CreateViewLog(Utils.getproperty("consumerNameCreateViewLog"),Utils.getproperty("serviceNameCreateViewLog"),authToken, spaceKey,uid,HttpStatus.SC_OK);

            String dataStr = "{\"spaceKey\":\""+spaceKey+"\",\"storyDefenition\":\"{\\\"theme\\\":\\\"none\\\",\\\"version\\\":\\\"3.2.0\\\",\\\"story\\\":[{\\\"cube\\\":"+bizvizCubeId+",\\\"cubeview\\\":[{\\\"ref\\\":\\\"c19176e5-e638-4047-a535-884612fbb1d0\\\",\\\"id\\\":"+cubeViewId+",\\\"data\\\":\\\"{\\\\\\\"measure\\\\\\\":[{\\\\\\\"name\\\\\\\":\\\\\\\"Order_Amount\\\\\\\",\\\\\\\"op\\\\\\\":\\\\\\\"sum\\\\\\\"},{\\\\\\\"name\\\\\\\":\\\\\\\"Commission\\\\\\\",\\\\\\\"op\\\\\\\":\\\\\\\"sum\\\\\\\"}],\\\\\\\"dimension\\\\\\\":[{\\\\\\\"name\\\\\\\":\\\\\\\"Location_Id\\\\\\\",\\\\\\\"interval\\\\\\\":\\\\\\\"\\\\\\\"}],\\\\\\\"facts\\\\\\\":{\\\\\\\"Location_Id\\\\\\\":[\\\\\\\"301161\\\\\\\",\\\\\\\"301721\\\\\\\",\\\\\\\"301781\\\\\\\",\\\\\\\"301451\\\\\\\",\\\\\\\"301306\\\\\\\",\\\\\\\"301252\\\\\\\",\\\\\\\"301509\\\\\\\",\\\\\\\"301564\\\\\\\",\\\\\\\"301326\\\\\\\"]},\\\\\\\"transDim\\\\\\\":\\\\\\\"\\\\\\\",\\\\\\\"elasticSearch\\\\\\\":{\\\\\\\"isEnabled\\\\\\\":true},\\\\\\\"limit\\\\\\\":[\\\\\\\"0\\\\\\\"]}\\\"}]}],\\\"storyProperties\\\":{\\\"viewOrder\\\":[\\\"c19176e5-e638-4047-a535-884612fbb1d0\\\"],\\\"viewCfg\\\":{\\\"c19176e5-e638-4047-a535-884612fbb1d0\\\":{\\\"chartProperties\\\":{},\\\"size\\\":{\\\"w\\\":4,\\\"h\\\":5},\\\"sizeRestriction\\\":{}}},\\\"theme\\\":0},\\\"action\\\":{}}\",\"name\":\""+bIStoryname+"\",\"id\":"+storyId+",\"isActive\":0,\"createdDate\":null,\"lastUpdatedDate\":null}";
            String consumerNamesaveStory = Utils.getproperty("consumerNamesaveStory");
            String serviceNamesaveStory = Utils.getproperty("serviceNamesaveStory");
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", "true")
                            .param("consumerName", consumerNamesaveStory)
                            .param("serviceName", serviceNamesaveStory)
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpluginService)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees = from(response.asString()).get("");
            String name= trees.get("name").toString();
            LOGGER.info(("trees:" +trees.toString()));

            //****Asserting for create document****//
            Assert.assertEquals(name, bIStoryname);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Comments Workflow
    @Test(description = "commentsFlow")
    public  void commentsFlow(){
        try {
            getListViewStory(authToken,spaceKey,uid,HttpStatus.SC_OK);
            int statusCode = HttpStatus.SC_OK;

            //getWikiById
            WikiByDocId(selDocId_GetList,uid,spaceKey,authToken,HttpStatus.SC_OK );

            //Adding comments
            Date dt = new Date();
            Long epoch  = System.currentTimeMillis();
            String name = "RestAutomation" + epoch;
            String data="{\""+name+"\":{\"owner\":\"RestAutomation\",\"comment\":\"AddedComment\",\"status\":\"true\",\"time\":\""+dt+"\",\"deletedby\":\"none\"}}";
            Response response_Comments =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            .param("data", data)
                            .param("blogStatus", "true")
                            .param("docId", selDocId_GetList)
                            /* .param("id", wikiId)*/
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlcreateOrUpdateWiki)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String, Object> resp_comment = from(response_Comments.asString()).get("wikiResp");
            HashMap<String, Object> wiki_comment = (HashMap) resp_comment.get("wiki");
            HashMap<String, Object> docId_resp = (HashMap) wiki_comment.get("docId");

            LOGGER.info("comment"+resp_comment);

            //Asserts
            Assert.assertNotNull(docId_resp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //OpenDoc Story Flow
    @Test(description = "StoryOpenDocFlow")
    public  void openDocStoryFlow(){
        try{
            //getListView to get Story Id
            getListViewStory(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //Get the storyId from create story service, fetgch it from story service-Incomplete
            loadPrivilege(selDocId_GetList, authToken,spaceKey,uid,HttpStatus.SC_OK);

            urlgetdocumentinfobyid = Utils.getUrl( "getdocumentinfobyid");
            Response response1 =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            .param("docId", selDocId_GetList)
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdocumentinfobyid)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> resp = from(response1.asString()).get("");
            HashMap<String,Object> trees = (HashMap)resp.get("trees");
            HashMap<String, Object> tree = (HashMap)trees.get("tree");
            LOGGER.info(("trees:" +trees.toString()));

            //getDocumentInfoById
            getdocumentinfobyid(selDocId_GetList, uid,spaceKey,authToken,HttpStatus.SC_OK);

            //adding getThumbnailByTreeID in a flow
            getThumbnailByTreeID(selDocId_GetList,uid,authToken,spaceKey, HttpStatus.SC_OK);

            //Creating ApiToken
            createApiToken(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //getData of Story
            savedStoryId = Integer.valueOf(selDocId_GetList);
            getData(savedStoryId,authToken,spaceKey,uid,HttpStatus.SC_OK);

            //Cubedata service call after click on open doc Url
            String filterCubeData = "{\"measure\":[{\"name\":\"Order_Amount\",\"op\":\"sum\"},{\"name\":\"Commission\",\"op\":\"sum\"}],\"dimension\":[{\"name\":\"Location_Id\",\"interval\":\"\"}],\"facts\":{\"Location_Id\":[\"301161\",\"301721\",\"301781\",\"301451\",\"301306\",\"301252\",\"301509\",\"301564\",\"301326\"]},\"transDim\":\"\",\"elasticSearch\":{\"isEnabled\":true},\"limit\":[\"0\"]}";
            System.out.println(filterCubeData);

            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authToken", authToken)
                            // req data
                            .param("consumerName", Utils.getproperty("consumerNamegetCubedataDimen2"))
                            .param("serviceName", serviceNamegetCubeData)
                            .param("data", filterCubeData)
                            .param("isSecure", "true")
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetCubeData)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            //  List<HashMap<String, Object>>respCubedata = from(response.asString()).get("");
            LOGGER.info(("resp:" +response.toString()));

            String expectedCubeDataJson = "[{\"Location_Id\":\"301161\",\"sum_Order_Amount\":\"250521.260000004782341420650482177734375\",\"sum_Commission\":\"45039\"},{\"Location_Id\":\"301721\",\"sum_Order_Amount\":\"124236.07000000003608874976634979248046875\",\"sum_Commission\":\"4372.75\"},{\"Location_Id\":\"301781\",\"sum_Order_Amount\":\"59482.1099999992802622728049755096435546875\",\"sum_Commission\":\"2854.1099999999669307726435363292694091796875\"},{\"Location_Id\":\"301451\",\"sum_Order_Amount\":\"70954.519999999436549842357635498046875\",\"sum_Commission\":\"2966\"},{\"Location_Id\":\"301306\",\"sum_Order_Amount\":\"74518.25\",\"sum_Commission\":\"5723\"},{\"Location_Id\":\"301252\",\"sum_Order_Amount\":\"53867.8499999999985448084771633148193359375\",\"sum_Commission\":\"4363\"},{\"Location_Id\":\"301509\",\"sum_Order_Amount\":\"60356.8399999998291605152189731597900390625\",\"sum_Commission\":\"7014.5199999999385909177362918853759765625\"},{\"Location_Id\":\"301564\",\"sum_Order_Amount\":\"38165.220000000859727151691913604736328125\",\"sum_Commission\":\"1308.74000000002479282557033002376556396484375\"},{\"Location_Id\":\"301326\",\"sum_Order_Amount\":\"41540.749999999417923390865325927734375\",\"sum_Commission\":\"3231.79999999996243786881677806377410888671875\"}]";

            /*for (HashMap<String,Object> respCubedataObj: respCubedata) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.putAll(respCubedataObj);

                 Assert.assertEquals(jsonObject.toString(),expectedCubeDataJson );
            }*/


        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //OpenDoc Dashboard flow
    @Test(description = "DashboardOpenDocFlow")
    public  void openDocDashboardFlow(){
        try{
            //getListView to get Story Id
            getListViewStory(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //Get the dashboardId from getListView
            loadPrivilege(selDashboardId_GetList, authToken,spaceKey,uid,HttpStatus.SC_OK);

            //getDocumentInfoById
            getdocumentinfobyid(selDashboardId_GetList, uid,spaceKey,authToken,HttpStatus.SC_OK);

            //adding getThumbnailByTreeID in a flow
            getThumbnailByTreeID(selDashboardId_GetList,uid,authToken,spaceKey, HttpStatus.SC_OK);

            //Creating ApiToken
            createApiToken(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //getData of Dashboard
            savedDashId = Integer.valueOf(selDashboardId_GetList);
            getData(savedDashId,authToken,spaceKey,uid,HttpStatus.SC_OK);

            String data = "{\"dcType\":[{\"type\":\"mysql\"}]}";
            getEndpointUrl(data, uid, spaceKey,authToken,HttpStatus.SC_OK);

            //Delete Storydocument
            //   removeNodeDocument(uid,selDocId_GetList,authToken,spaceKey,HttpStatus.SC_OK);


        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //---------------story sharetoUser and sharetoUserGroup and shareAsCopy api's----------//

    //ShareStoryToUser
    @Test(description ="Create User add to group, share dashboard to User,Login with user details, get the id, exclude document and delete user")
    public static void shareStoryToUser(){

        try {
            //getListView to get Story Id
            getListViewStory(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("NEWCREATEGRPID==" + newgroupid);

            //ShareDashboardToUser
            shareDocUser(selDocId_GetList,uid,authToken,spaceKey, HttpStatus.SC_OK);
            System.out.println("emailId ======"+emailidcreatefun);
            System.out.println("createUserId ======"+newuseridfunuser);

            userLogin(emailidcreatefun, pass_admin,space_admin);

            getListViewShared(shareDocumentId,authnew, spaceKey, idnew, HttpStatus.SC_OK);

            //****Assert to check whether document is shared for user ***//
            Assert.assertEquals(newuseridfunuser,idnew);
            Assert.assertEquals(sharedStoryId, selDocId_GetList);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //ShareStoryTOUserGroup and exclude story to one user
    @Test(description =" Create User, group, crate DashboardShare the dashboard to assigned usergroup and exclude the selected user")
    public static void excludeStoryToUserGroup(){
        try{
            //Creating story
            createStoryFlow();

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);
            LOGGER.info("Firstuser==" + newuseridfunuser);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("selUserGrpId==" + newgroupid);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+ Helper.generateRandomString(),usrname,fullname+ Helper.generateRandomString(),pass_admin,newgroupid,authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);
            LOGGER.info("2nduser==" + newuseridfunuser);

            //getting User from groups
            getusersfromgroups(uid,newgroupid, authToken, spaceKey,HttpStatus.SC_OK );

            //Sharing Document to Usergroup
            String storyId = savedStoryId.toString();
            shareDocUserGroup(storyId,newgroupid, selUserId, uid, authToken,spaceKey,HttpStatus.SC_OK);

            userLogin(selUsers_MailId, pass_admin,space_admin);

            getListViewShared(shareDocumentId,authnew, spaceKey, idnew, HttpStatus.SC_OK);

            //****Assert to check whether document is shared for the same user and document is shared excluding the user ***//
            Assert.assertEquals(selUserId.toString(), idnew);
            Assert.assertNull(sharedStoryId);

            //Delete Story
            removeNode(uid,storyId,authToken, spaceKey,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    //ShareStoryTOUserGroup and exclude story to one user
    @Test(description =" Create User, group, crate DashboardShare the dashboard to assigned usergroup and exclude the selected user")
    public static void excludeStoryToUserGroupShareAndUnshare(){
        try{
            //Creating story
            createStoryFlow();

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);
            LOGGER.info("Firstuser==" + newuseridfunuser);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("selUserGrpId==" + newgroupid);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+ Helper.generateRandomString(),usrname,fullname+ Helper.generateRandomString(),pass_admin,newgroupid,authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);
            LOGGER.info("2nduser==" + newuseridfunuser);

            //getting User from groups
            getusersfromgroups(uid,newgroupid, authToken, spaceKey,HttpStatus.SC_OK );

            //Sharing Document to Usergroup
            String storyId = savedStoryId.toString();
            shareDocUserGroupShare(storyId,newgroupid, selUserId, uid, authToken,spaceKey,HttpStatus.SC_OK);

            shareDocUserGroupCheck(storyId,newgroupid, selUserId, uid, authToken,spaceKey,HttpStatus.SC_OK);

            userLogin(selUsers_MailId, pass_admin,space_admin);

            getListViewShared(shareDocumentId,authnew, spaceKey, idnew, HttpStatus.SC_OK);


            //****Assert to check whether document is shared for the same user and document is shared excluding the user ***//
            Assert.assertEquals(selUserId.toString(), idnew);
            if(sharedStoryId != null) {
                Assert.assertNotNull(sharedStoryId);
            }

            //Delete Story
            removeNode(uid,storyId,authToken, spaceKey,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    //ShareAsCopy
    @Test(description = "ShareAsCopy")
    public static void storyShareCopy(){
        try {
            //getListView to get Story Id
            getListViewStory(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("selUserGrpId==" + newgroupid);

            String data="{\"id\":0,\"datasourcetype\":\"\"}";
            getAllDataStore(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //shareAsCopy method calling
            shareAsCopy(selDocId_GetList, newuseridfunuser,authToken, spaceKey,uid, HttpStatus.SC_OK);

            //Login with new user passing  valid password
            userLogin(emailidcreatefun, pass_admin,space_admin);

            getListViewShared(shareDocumentId,authnew, spaceKey, idnew, HttpStatus.SC_OK);

            //Comparing the datastoreid of admin and after copying story
            getAllSharedDataStore(spaceKey,uid,authToken,data,HttpStatus.SC_OK);
            Assert.assertEquals(dataStoreId, shareddataStoreId);

            //***asserting that the document has copied to user***//
            Assert.assertEquals(newuseridfunuser,idnew);
            Assert.assertNotNull(sharedStoryId);

            //Delete Story
            removeNode(uid,sharedStoryId,authToken, spaceKey,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch (Exception e){
            e.printStackTrace();
        }

    }


    //--------Dashboard sharetoUser and sharetoUserGroup api's--------------//

    @Test(description ="Create User add to group, share dashboard to User,Login with user details, get the id, exclude document and delete user")
    public static void shareDashboardToUser(){

        try {
            //getListView to get Story Id
            getListViewStory(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("NEWCREATEGRPID==" + newgroupid);

            //ShareDashboardToUser
            shareDocUser(selDashboardId_GetList,uid,authToken,spaceKey, HttpStatus.SC_OK);
            System.out.println("emailId ======"+emailidcreatefun);
            System.out.println("createUserId ======"+newuseridfunuser);

            userLogin(emailidcreatefun, pass_admin,space_admin);

            getListViewShared(shareDocumentId,authnew, spaceKey, idnew, HttpStatus.SC_OK);

            //****Assert to check whether document is shared for user ***//
            Assert.assertEquals(newuseridfunuser,idnew);
            Assert.assertEquals(sharedDashboardId, selDashboardId_GetList);

            //Exclude document to shared user
            dmAssignExcludePrivilege(sharedDashboardId,newuseridfunuser,authnew,spaceKey,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch (Exception e){
            e.printStackTrace();
        }
    }


    @Test(description =" Create User, group, crate DashboardShare the dashboard to assigned usergroup and exclude the selected user")
    public static void excludeDashboardToUserGroup(){
        try{

            fetchWorkspace(uid, spaceKey,authToken,workspaceName_Advanced,workspaceJSON,HttpStatus.SC_OK);

            String dashboardParameters = "{\"workspaceId\":\"" + workspaceId + "\",\"dashboardName\":\"" + dashboardName + "\",\"dashboardJSON\":\"{}\"}";
            fetchDashboardWebservice(dashboardParameters,uid, spaceKey,authToken,HttpStatus.SC_OK);

            publishDashboard(uid, spaceKey,authToken,HttpStatus.SC_OK);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("selUserGrpId==" + newgroupid);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+ Helper.generateRandomString(),usrname,fullname+ Helper.generateRandomString(),pass_admin,newgroupid,authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);

            //getting User from groups
            getusersfromgroups(uid,newgroupid, authToken, spaceKey,HttpStatus.SC_OK );

            //Sharing Document to Usergroup
            shareDocUserGroup(publishDashboardId,newgroupid, selUserId, uid, authToken,spaceKey,HttpStatus.SC_OK);

            userLogin(selUsers_MailId, pass_admin,space_admin);

            getListViewShared(shareDocumentId,authnew, spaceKey, idnew, HttpStatus.SC_OK);

            //****Assert to check whether document is shared for the same user and document is shared excluding the user ***//
            Assert.assertEquals(selUserId, Integer.valueOf(idnew));
            Assert.assertNull(sharedDashboardId);

            removeNode(uid,publishDashboardId, authToken, spaceKey,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Test(description =" Create User, group, crate DashboardShare the dashboard to assigned usergroup and exclude the selected user")
    public static void excludeDashboardToUserGroupShareAndUnshare(){
        try{

            fetchWorkspace(uid, spaceKey,authToken,workspaceName_Advanced,workspaceJSON,HttpStatus.SC_OK);

            String dashboardParameters = "{\"workspaceId\":\"" + workspaceId + "\",\"dashboardName\":\"" + dashboardName + "\",\"dashboardJSON\":\"{}\"}";
            fetchDashboardWebservice(dashboardParameters,uid, spaceKey,authToken,HttpStatus.SC_OK);

            publishDashboard(uid, spaceKey,authToken,HttpStatus.SC_OK);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("selUserGrpId==" + newgroupid);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+ Helper.generateRandomString(),usrname,fullname+ Helper.generateRandomString(),pass_admin,newgroupid,authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);

            //Sharing Document to Usergroup
            shareDocUserGroupShare(publishDashboardId,newgroupid, selUserId, uid, authToken,spaceKey,HttpStatus.SC_OK);

            shareDocUserGroupCheck(publishDashboardId,newgroupid, selUserId, uid, authToken,spaceKey,HttpStatus.SC_OK);

            userLogin(selUsers_MailId, pass_admin,space_admin);

            Thread.sleep(2000);
            getListViewShared(shareDocumentId,authnew, spaceKey, idnew, HttpStatus.SC_OK);

            //****Assert to check whether document is shared for the same user and document is shared excluding the user ***//
            Assert.assertEquals(selUserId.toString(), idnew);
            if(sharedDashboardId != null) {
                Assert.assertNotNull(sharedDashboardId);
            }

            removeNode(uid,publishDashboardId, authToken, spaceKey,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch(Exception e){
            e.printStackTrace();
        }
    }


    //---------------LinkUrl and modify document flow-------------//

    @Test(description ="Linkurl flow")
    public static void linkUrlFlow(){
        try{
            //Link url
            String linkurlName  = "QALinkUrl";
            saveWebLinkData(linkurlName,Utils.getproperty("treeRelLinkUrl"),spaceKey,uid, authToken, HttpStatus.SC_OK);

            //dashboardparameters
            saveDashBoardParameters(linkUrlId, spaceKey, uid, authToken,HttpStatus.SC_OK);

            urlgetListView = Utils.getUrl("getlistview");
            Response response_GetlistView =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            //params
                            .param("nodeid", myDocumentId)
                            .param("orderType", "")
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees_getListView = from(response_GetlistView.asString()).get("trees");
            List< HashMap<String, Object> > treesList = (ArrayList<HashMap<String, Object>>) trees_getListView.get("treesList");

            for (HashMap treesObj:treesList) {
                if (treesObj.containsKey("title") && treesObj.get("title").toString().equals("QALinkUrl") ){
                    linkUrlId = treesObj.get("id").toString();
                }
            }
            LOGGER.info(("sharedDoclistId:" +linkUrlId));
            LOGGER.info(("resp_getListViewShared:" +trees_getListView));



        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Test(description ="modifyDocumentFlow")
    public static void linkUrlDashboardFlow(){
        try{
            //getListView to get dashboard Id
            getListViewStory(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //Link url
            String linkurlName  = "dashboardLinkUrl";
            String treeRelIdNew = "https://qa.bdbizviz.com/opendocument.html?docid="+selDashboardId_GetList+"";
            System.out.println("treeRelId ===" + treeRelIdNew);
            saveWebLinkData(linkurlName,treeRelIdNew,spaceKey,uid, authToken, HttpStatus.SC_OK);

            //dashboardparameters
            saveDashBoardParametersmodifyDoc(linkUrlId, spaceKey, uid, authToken,HttpStatus.SC_OK);

            urlgetListView = Utils.getUrl("getlistview");
            Response response_GetlistView =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            //params
                            .param("nodeid", myDocumentId)
                            .param("orderType", "")
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees_getListView = from(response_GetlistView.asString()).get("trees");
            List< HashMap<String, Object> > treesList = (ArrayList<HashMap<String, Object>>) trees_getListView.get("treesList");

            for (HashMap treesObj:treesList) {
                if (treesObj.containsKey("title") && treesObj.get("title").toString().equals("dashboardLinkUrl") ){
                    linkUrlIdnew = treesObj.get("id").toString();
                }
            }
            LOGGER.info(("linkUrlIdnew:" +linkUrlId));
            LOGGER.info(("resp_getListViewShared:" +trees_getListView));

            Assert.assertNotNull(linkUrlIdnew);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Test(description ="modifyDocumentFlow")
    public static void linkUrlStoryFlow(){
        try{
            //getListView to get dashboard Id
            getListViewStory(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //Link url
            String linkurlName  = "storyLinkUrl";
            String treeRelIdNew = "https://qa.bdbizviz.com/opendocument.html?docid="+selDocId_GetList+"";
            System.out.println("treeRelId ===" + treeRelIdNew);
            saveWebLinkData(linkurlName,treeRelIdNew,spaceKey,uid, authToken, HttpStatus.SC_OK);

            //dashboardparameters
            saveDashBoardParametersmodifyDoc(linkUrlId, spaceKey, uid, authToken,HttpStatus.SC_OK);

            urlgetListView = Utils.getUrl("getlistview");
            Response response_GetlistView =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            //params
                            .param("nodeid", myDocumentId)
                            .param("orderType", "")
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees_getListView = from(response_GetlistView.asString()).get("trees");
            List< HashMap<String, Object> > treesList = (ArrayList<HashMap<String, Object>>) trees_getListView.get("treesList");

            for (HashMap treesObj:treesList) {
                if (treesObj.containsKey("title") && treesObj.get("title").toString().equals("storyLinkUrl") ){
                    linkUrlIdnew = treesObj.get("id").toString();
                }
            }
            LOGGER.info(("linkUrlIdnew:" +linkUrlId));
            LOGGER.info(("resp_getListViewShared:" +trees_getListView));

            Assert.assertNotNull(linkUrlIdnew);

        }catch(Exception e){
            e.printStackTrace();
        }
    }


}