package com.bdbizviz.restassured.platform.BS;

import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.Jdbc_connection;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.bdbizviz.restassured.platform.Util.Utils;

import static com.bdbizviz.restassured.platform.DataCenter.DataCenterHelper.cubeid;
import static com.bdbizviz.restassured.platform.UserManagement.UserManagementHelper.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.json.simple.JSONObject;


public class BusinessStory extends BusinessStoryHelper {
	static BusinessStoryHelper bsh = new BusinessStoryHelper();
	public static JSONObject prop=null;
	public static String dbip=null;
	public static String dbname=null;
	public static String dbuser=null;
	public static String dbpass=null;

	@BeforeClass
	public static void setupBS() {

		//Non-Admin user
		user = Helper.getCustomerKey(emailidcreate,space_admin);
		userauth = Helper.getAuthToken(emailidcreate,pass_admin,space_admin);
		spaceKey = user.getSpacekey();
		uid = user.getId();
		authToken = userauth.getAuthToken();
		dbip=Utils.getproperty("dbip");
		dbname= Utils.getproperty("dbname");
		dbuser=Utils.getproperty("dbuser");
		dbpass=Utils.getproperty("dbpass");
		bsh.getCubeID();

	}

	@Test(description = "createStoryInFolderMyDocTest")
	public static void createStoryInFolderMyDocTest() {
		String dataStr ="{\"spaceKey\":\""+spaceKey+"\",\"storyDefenition\":\"{\\\"story\\\":[]}\",\"name\":\""+storyname+"\",\"id\":null,\"isActive\":0,\"createdDate\":null,\"lastUpdatedDate\":null}";
		BusinessStoryHelper.createStoryInFolderMyDoc(dataStr);
	}

	@Test(description = "createStoryInFolderMyDocTest2")
	public static void createStoryInFolderMyDocTest2() {
		String dataStr ="{\"spaceKey\":\""+spaceKey+"\",\"storyDefenition\":\"{\\\"theme\\\":\\\"none\\\",\\\"version\\\":\\\""+Utils.getproperty("docVersion")+"\\\",\\\"story\\\":[{\\\"cube\\\":"+cubeid+",\\\"cubeview\\\":[{\\\"ref\\\":\\\"d2ee3caf-e854-4290-9da9-55733ae3f63a\\\",\\\"id\\\":"+viewId+",\\\"data\\\":\\\"{\\\\\\\"measure\\\\\\\":[{\\\\\\\"name\\\\\\\":\\\\\\\"Order_Amount\\\\\\\",\\\\\\\"op\\\\\\\":\\\\\\\"sum\\\\\\\"}],\\\\\\\"dimension\\\\\\\":[{\\\\\\\"name\\\\\\\":\\\\\\\"Location_Id\\\\\\\",\\\\\\\"interval\\\\\\\":\\\\\\\"\\\\\\\"}],\\\\\\\"facts\\\\\\\":{},\\\\\\\"transDim\\\\\\\":\\\\\\\"\\\\\\\",\\\\\\\"elasticSearch\\\\\\\":{\\\\\\\"isEnabled\\\\\\\":true},\\\\\\\"limit\\\\\\\":[\\\\\\\"0\\\\\\\"]}\\\"}]}],\\\"storyProperties\\\":{\\\"viewOrder\\\":[\\\"d2ee3caf-e854-4290-9da9-55733ae3f63a\\\"],\\\"viewCfg\\\":{\\\"d2ee3caf-e854-4290-9da9-55733ae3f63a\\\":{\\\"chartProperties\\\":{},\\\"size\\\":{\\\"w\\\":4,\\\"h\\\":5},\\\"sizeRestriction\\\":{}}},\\\"theme\\\":0},\\\"action\\\":{}}\",\"name\":\""+storyname+"\",\"id\":"+storyId+",\"isActive\":0,\"createdDate\":null,\"lastUpdatedDate\":null}";
		BusinessStoryHelper.createStoryInFolderMyDoc(dataStr);
	}

	@Test(description = "saveStoryDataTest")
	public static void saveStoryDataTest() {

		BusinessStoryHelper.saveStoryData();
	}

	@Test(description = "saveStoryInFolderMyDocTest")
	public static void saveStoryInFolderMyDocTest() {

		BusinessStoryHelper.saveStoryInFolderMyDoc();
	}

	@Test(description = "getDataStoreDetailsTest")
	public static void getDataStoreDetailsTest() {

		BusinessStoryHelper.getDataStoreDetails();
	}

	@Test(description = "getdeliveryresultbyowneridTest")
	public static void getdeliveryresultbyowneridTest() {

		BusinessStoryHelper.getdeliveryresultbyownerid();
	}

	@Test(description = "getDSDataTest")
	public static void getDSDataTest() {
		String dataa_dim="{\"title\":\"Untitled\",\"desc\":\"By Location_Id\",\"defaultChartClass\":\"DataGrid\",\"chartProperties\":{},\"filter\":{},\"filterList\":\"None\",\"mergedCubes\":[],\"currentCube\":null,\"isMergeEnabled\":false,\"mergedCubeDetails\":{},\"aggregation\":{\"op\":\"sum\",\"sfx\":\"\",\"pfx\":\"\",\"measure\":\"\"},\"category\":[{\"dimension\":\"Location_Id\",\"interval\":\"\",\"sourceID\":"+cbid+"}],\"series\":[],\"transDim\":\"\",\"customField\":[],\"rules\":[],\"properties\":{\"measure.Description\":\"Measure\",\"summary.Description\":\"Total\",\"tableHead\":{\"alignment\":\"center\",\"textColor\":\"black\",\"bgColor\":\"#FFFFFF\",\"isBold\":false,\"isItalics\":false,\"isUnderline\":false,\"fontSize\":\"small\",\"isScroll\":true},\"excludeView\":{\"enable\":false},\"cardFilter\":{\"enabled\":false,\"field\":\"None\"},\"dataRestriction\":{}},\"querytype\":\"simple\",\"mergedDataStore\":{},\"masterDataStore\":\""+cbid+"\"}";
		String dataa_mes="{\"title\":\"Sum( Order_Amount )\",\"desc\":\"By Location_Id\",\"defaultChartClass\":\"DataGrid\",\"chartProperties\":{},\"filter\":{},\"filterList\":\"None\",\"mergedCubes\":[],\"currentCube\":null,\"isMergeEnabled\":false,\"mergedCubeDetails\":{},\"aggregation\":{\"op\":\"sum\",\"sfx\":\"\",\"pfx\":\"\",\"measure\":\"\"},\"category\":[{\"dimension\":\"Location_Id\",\"interval\":\"\",\"sourceID\":151060628}],\"series\":[{\"format\":{\"format\":\"Auto\",\"precision\":\"2\",\"sfx\":\"Auto\",\"pfx\":\"\"},\"tableColumn\":{\"alignment\":\"center\"},\"alertDetails\":{\"showAlert\":false,\"showDynamicColor\":true,\"gridRange\":\"\",\"gridDynamicRange\":\"\",\"totalgridRange\":20,\"minColor\":\"#f89406\",\"maxColor\":\"#00b16a\",\"col_font_clr\":\"#000000\"},\"measure\":\"Order_Amount\",\"op\":\"sum\",\"sourceID\":"+cbid+"}],\"transDim\":\"\",\"customField\":[],\"rules\":[],\"properties\":{\"measure.Description\":\"Measure\",\"summary.Description\":\"Total\",\"tableHead\":{\"alignment\":\"center\",\"textColor\":\"black\",\"bgColor\":\"#FFFFFF\",\"isBold\":false,\"isItalics\":false,\"isUnderline\":false,\"fontSize\":\"small\",\"isScroll\":true},\"excludeView\":{\"enable\":false},\"cardFilter\":{\"enabled\":false,\"field\":\"None\"},\"dataRestriction\":{}},\"querytype\":\"simple\",\"mergedDataStore\":{},\"masterDataStore\":\""+cbid+"\"}";
		List<String> Location_Ids =  new ArrayList<String>();
		List<HashMap<String, Object>> resp1  = BusinessStoryHelper.getDSData(dataa_dim);
		if(resp1!=null && !resp1.isEmpty()){
			for(HashMap<String,Object>  hm:resp1){
				Location_Ids.add(hm.get("Location_Id").toString());
			}
		}
		
		String sql1 = "select LOCATION_ID from orders where total_amount>0 and TOTAL_COMMISSION>0 and LOCATION_ID="+Location_Ids.get(0);	
		Assert.assertEquals(Location_Ids.get(0), Jdbc_connection.jdbcResult(sql1,"LOCATION_ID",dbip,dbname,dbuser,dbpass));
		
		List<String> sum_Order_Amounts =  new ArrayList<String>();
		List<HashMap<String, Object>> resp2  = BusinessStoryHelper.getDSData(dataa_mes);
		if(resp2!=null && !resp2.isEmpty()){
			for(HashMap<String,Object> hm:resp2){
				if(hm.get("Location_Id").toString().equals(Location_Ids.get(0))){
				sum_Order_Amounts.add(hm.get("sum_Order_Amount").toString());
				}
			}
		}
		String sql2 = "Select sum(TOTAL_AMOUNT) from orders where total_amount>0 and TOTAL_COMMISSION>0 and LOCATION_ID="+Location_Ids.get(0);
		String act=sum_Order_Amounts.get(0).substring(0, sum_Order_Amounts.get(0).length() - 6);
		String exp=Jdbc_connection.jdbcResult(sql2,"sum(TOTAL_AMOUNT)",dbip,dbname,dbuser,dbpass).substring(0, Jdbc_connection.jdbcResult(sql2,"sum(TOTAL_AMOUNT)",dbip,dbname,dbuser,dbpass).length()-8);
		Assert.assertEquals(act,exp);
	}

	@Test(description = "getStoryByIdTest")
	public static void getStoryByIdTest() {

		BusinessStoryHelper.getStoryById();
	}

	@Test(description = "getStoryByIdTest")
	public static void getCubeInfoTest() {

		BusinessStoryHelper.getCubeInfo();
	}

	@Test(description = "CreateViewLogTest")
	public static void CreateViewLogTest()
	{
		BusinessStoryHelper.CreateViewLog();
	}

	@Test(description = "DeleteViewLogTest")
	public static void DeleteViewLogTest() {
		//BusinessStoryHelper.DeleteViewLog();
	}

	@Test(description = "getDistinctDimNameTest")
	public static void getDistinctDimNameTest() {

		BusinessStoryHelper.getDistinctDimName();
	}

	@Test(description = "saveCubeViewTest")
	public static void saveCubeViewTest() {
		String dataa="{\"cube\":"+cubeid+",\"serviceid\":\""+cubeid+"\",\"name\":\""+storyname+"\",\"defenition\":\"{\\\"dataDef\\\":{\\\"filetype\\\":\\\"mysql\\\",\\\"databasename\\\":\\\"BizViz_Automation_WT\\\",\\\"query\\\":\\\"Select order_id,location_id as Location_Id,ACCOUNT_HOLDER_ID,LOCATION_DROP_OFF_ID,space_key as Franchise_IOId,total_amount as Order_Amount,FROM_UNIXTIME((transaction_date)/1000,'%Y-%m-%d') as Transaction_Date,total_commission as Commission from orders where total_amount>0 and TOTAL_COMMISSION>0\\\"},\\\"columnNames\\\":{\\\"order_id\\\":\\\"long\\\",\\\"Location_Id\\\":\\\"long\\\",\\\"ACCOUNT_HOLDER_ID\\\":\\\"long\\\",\\\"LOCATION_DROP_OFF_ID\\\":\\\"long\\\",\\\"Franchise_IOId\\\":\\\"string\\\",\\\"Order_Amount\\\":\\\"double\\\",\\\"Transaction_Date\\\":\\\"string\\\",\\\"Commission\\\":\\\"double\\\"},\\\"adhocResults\\\":[\\\"{\\\\\\\"measures\\\\\\\":{\\\\\\\"order_id\\\\\\\":327793246263,\\\\\\\"Location_Id\\\\\\\":301747,\\\\\\\"ACCOUNT_HOLDER_ID\\\\\\\":152527,\\\\\\\"LOCATION_DROP_OFF_ID\\\\\\\":321118,\\\\\\\"Order_Amount\\\\\\\":42.0,\\\\\\\"Commission\\\\\\\":2.0},\\\\\\\"facts\\\\\\\":{\\\\\\\"Franchise_IOId\\\\\\\":\\\\\\\"7385\\\\\\\",\\\\\\\"Transaction_Date\\\\\\\":\\\\\\\"2016-01-24\\\\\\\"}}\\\"],\\\"fieldDef\\\":{\\\"facts\\\":[\\\"Franchise_IOId\\\",\\\"order_id\\\",\\\"Location_Id\\\",\\\"ACCOUNT_HOLDER_ID\\\",\\\"LOCATION_DROP_OFF_ID\\\"],\\\"measures\\\":[\\\"Order_Amount\\\",\\\"Commission\\\"],\\\"time\\\":[\\\"Transaction_Date\\\"]},\\\"elasticSearch\\\":{\\\"isEnabled\\\":true,\\\"properties\\\":{\\\"Franchise_IOId\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"order_id\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"Location_Id\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"ACCOUNT_HOLDER_ID\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"LOCATION_DROP_OFF_ID\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"Order_Amount\\\":{\\\"type\\\":\\\"double\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"Commission\\\":{\\\"type\\\":\\\"double\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"Transaction_Date\\\":{\\\"type\\\":\\\"date\\\",\\\"index\\\":\\\"not_analyzed\\\"}}},\\\"drillDef\\\":[{\\\"title\\\":\\\"Drill Def\\\",\\\"drillOrder\\\":[\\\"Franchise_IOId\\\",\\\"Location_Id\\\",\\\"LOCATION_DROP_OFF_ID\\\",\\\"ACCOUNT_HOLDER_ID\\\"]}],\\\"batchProcess\\\":{\\\"fieldName\\\":\\\"\\\",\\\"distinctQuery\\\":\\\"\\\",\\\"batchquery\\\":\\\"\\\"},\\\"dataRestriction\\\":{},\\\"scheduleInfo\\\":\\\"0 0 12 1 1/1 ? *\\\",\\\"scheduleDef\\\":{\\\"interval\\\":\\\"monthly\\\",\\\"option\\\":\\\"every\\\",\\\"optionArgs\\\":{\\\"choiceDay\\\":\\\"1\\\",\\\"choiceMonth\\\":\\\"1\\\"},\\\"time\\\":{\\\"hour\\\":12,\\\"min\\\":0}},\\\"notification\\\":{\\\"status\\\":false,\\\"mailid\\\":\\\"\\\"},\\\"enableNLP\\\":true,\\\"formulaJSON\\\":{},\\\"deltaProcess\\\":{\\\"isDeltaProcess\\\":false,\\\"deltaQuery\\\":\\\"\\\",\\\"delta\\\":\\\"\\\"}}\",\"cubeview\":[{\"lastRunDate\":null,\"createdBy\":{\"id\":"+uidadmin+"},\"updatedBy\":{\"id\":"+uidadmin+"},\"spaceKey\":\""+spaceKey+"\",\"name\":\"\",\"type\":1,\"id\":null,\"status\":1,\"createdDate\":null,\"lastUpdatedDate\":null,\"isActive\":0,\"privacyType\":true,\"defenition\":\"{\\\"title\\\":\\\"Sum( Order_Amount )\\\",\\\"desc\\\":\\\"By Location_Id\\\",\\\"defaultChartClass\\\":\\\"DataGrid\\\",\\\"chartProperties\\\":{},\\\"filter\\\":{},\\\"filterList\\\":\\\"\\\",\\\"mergedCubes\\\":[],\\\"currentCube\\\":null,\\\"isMergeEnabled\\\":false,\\\"mergedCubeDetails\\\":{},\\\"aggregation\\\":{\\\"op\\\":\\\"sum\\\",\\\"sfx\\\":\\\"\\\",\\\"pfx\\\":\\\"\\\",\\\"measure\\\":\\\"\\\"},\\\"category\\\":[{\\\"dimension\\\":\\\"Location_Id\\\",\\\"interval\\\":\\\"\\\",\\\"sourceID\\\":"+cbid+",\\\"$$hashKey\\\":\\\"object:6173\\\"}],\\\"series\\\":[{\\\"format\\\":{\\\"format\\\":\\\"Auto\\\",\\\"precision\\\":\\\"2\\\",\\\"sfx\\\":\\\"Auto\\\",\\\"pfx\\\":\\\"\\\"},\\\"tableColumn\\\":{\\\"alignment\\\":\\\"center\\\"},\\\"alertDetails\\\":{\\\"showAlert\\\":false,\\\"showDynamicColor\\\":true,\\\"gridRange\\\":\\\"\\\",\\\"gridDynamicRange\\\":\\\"\\\",\\\"totalgridRange\\\":20,\\\"minColor\\\":\\\"#f89406\\\",\\\"maxColor\\\":\\\"#00b16a\\\",\\\"col_font_clr\\\":\\\"#000000\\\"},\\\"measure\\\":\\\"Order_Amount\\\",\\\"op\\\":\\\"sum\\\",\\\"sourceID\\\":"+cbid+",\\\"$$hashKey\\\":\\\"object:6179\\\"}],\\\"transDim\\\":\\\"\\\",\\\"customField\\\":{\\\"list\\\":[],\\\"condition\\\":[]},\\\"properties\\\":{\\\"measure.Description\\\":\\\"Measure\\\",\\\"summary.Description\\\":\\\"Total\\\",\\\"tableHead\\\":{\\\"alignment\\\":\\\"center\\\",\\\"textColor\\\":\\\"black\\\",\\\"bgColor\\\":\\\"#FFFFFF\\\",\\\"isBold\\\":false,\\\"isItalics\\\":false,\\\"isUnderline\\\":false,\\\"fontSize\\\":\\\"small\\\",\\\"isScroll\\\":true,\\\"excludeView\\\":{\\\"enable\\\":false}},\\\"dataRestriction\\\":{}},\\\"querytype\\\":\\\"simple\\\",\\\"mergedDataStore\\\":{},\\\"masterDataStore\\\":"+cubeid+"}\"}]}";
		BusinessStoryHelper.saveCubeView(dataa);
	}

	@Test(description = "ExecuteBSRScriptTest")
	public static void ExecuteBSRScriptTest() {
		//BusinessStoryHelper.ExecuteBSRScript();
	}

	@Test(description = "savecubealartTest")
	public static void savecubealartTest() {
		//BusinessStoryHelper.savecubealart();
	}

	@Test(description = "deletecubealertTest")
	public static void deletecubealertTest() {
		//BusinessStoryHelper.deletecubealert();
	}

	@Test(description = "getNLPTest")
	public static void getNLPTest() {
		String q1="order_amount of 2423";
		String q2="Order_Amount of 2423 for Transaction_Date 2017";
		BusinessStoryHelper.getNLP(q1);
		BusinessStoryHelper.getNLP(q2);
	}

	@Test(description="editgetcubeinfoTest")
	public static void editgetcubeinfoTest() {

		BusinessStoryHelper.getCubeInfo();
	}

	@Test(description = "editgetDSDataTest")
	public static void editgetDSDataTest() {
		String dataa="{\"title\":\"Sum( Order_Amount )\",\"desc\":\"By Location_Id\",\"defaultChartClass\":\"DataGrid\",\"chartProperties\":{},\"filter\":{\"Location_Id\":[\"301161\"]},\"filterList\":\"\",\"mergedCubes\":[],\"currentCube\":null,\"isMergeEnabled\":false,\"mergedCubeDetails\":{},\"aggregation\":{\"op\":\"sum\",\"sfx\":\"\",\"pfx\":\"\",\"measure\":\"\"},\"category\":[{\"dimension\":\"Location_Id\",\"interval\":\"\",\"sourceID\":"+cbid+"}],\"series\":[{\"format\":{\"format\":\"Auto\",\"precision\":\"2\",\"sfx\":\"Auto\",\"pfx\":\"\"},\"tableColumn\":{\"alignment\":\"center\"},\"alertDetails\":{\"showAlert\":false,\"showDynamicColor\":true,\"gridRange\":\"\",\"gridDynamicRange\":\"\",\"totalgridRange\":20,\"minColor\":\"#f89406\",\"maxColor\":\"#00b16a\",\"col_font_clr\":\"#000000\"},\"measure\":\"Order_Amount\",\"op\":\"sum\",\"sourceID\":"+cbid+"}],\"transDim\":\"\",\"customField\":{\"list\":[],\"condition\":[]},\"properties\":{\"measure.Description\":\"Measure\",\"summary.Description\":\"Total\",\"tableHead\":{\"alignment\":\"center\",\"textColor\":\"black\",\"bgColor\":\"#FFFFFF\",\"isBold\":false,\"isItalics\":false,\"isUnderline\":false,\"fontSize\":\"small\",\"isScroll\":true,\"excludeView\":{\"enable\":false}},\"dataRestriction\":{}},\"querytype\":\"simple\",\"mergedDataStore\":{},\"masterDataStore\":"+cbid+"}";
		BusinessStoryHelper.getDSData(dataa);
	}

	@Test(description = "saveappliedfilterViewTest")
	public static void saveappliedfilterViewTest() {
		String dataa="{\"cube\":"+cubeid+",\"serviceid\":\""+cubeid+"\",\"name\":\""+storyname+"\",\"defenition\":\"{\\\"dataDef\\\":{\\\"filetype\\\":\\\"mysql\\\",\\\"databasename\\\":\\\"BizViz_Automation_WT\\\",\\\"query\\\":\\\"\\\\nSelect order_id,location_id as Location_Id,ACCOUNT_HOLDER_ID,LOCATION_DROP_OFF_ID,space_key as Franchise_IOId,total_amount as Order_Amount,FROM_UNIXTIME((transaction_date)/1000,'%Y-%m-%d') as Transaction_Date,total_commission as Commission from orders\\\\nwhere total_amount>0 and TOTAL_COMMISSION>0\\\"},\\\"columnNames\\\":{\\\"order_id\\\":\\\"long\\\",\\\"Location_Id\\\":\\\"long\\\",\\\"ACCOUNT_HOLDER_ID\\\":\\\"long\\\",\\\"LOCATION_DROP_OFF_ID\\\":\\\"long\\\",\\\"Franchise_IOId\\\":\\\"string\\\",\\\"Order_Amount\\\":\\\"double\\\",\\\"Transaction_Date\\\":\\\"string\\\",\\\"Commission\\\":\\\"double\\\"},\\\"adhocResults\\\":[\\\"{\\\\\\\"measures\\\\\\\":{\\\\\\\"order_id\\\\\\\":327793246263,\\\\\\\"Location_Id\\\\\\\":301747,\\\\\\\"ACCOUNT_HOLDER_ID\\\\\\\":152527,\\\\\\\"LOCATION_DROP_OFF_ID\\\\\\\":321118,\\\\\\\"Order_Amount\\\\\\\":42.0,\\\\\\\"Commission\\\\\\\":2.0},\\\\\\\"facts\\\\\\\":{\\\\\\\"Franchise_IOId\\\\\\\":\\\\\\\"7385\\\\\\\",\\\\\\\"Transaction_Date\\\\\\\":\\\\\\\"2016-01-24\\\\\\\"}}\\\"],\\\"fieldDef\\\":{\\\"facts\\\":[\\\"Franchise_IOId\\\",\\\"order_id\\\",\\\"Location_Id\\\",\\\"ACCOUNT_HOLDER_ID\\\",\\\"LOCATION_DROP_OFF_ID\\\"],\\\"measures\\\":[\\\"Order_Amount\\\",\\\"Commission\\\"],\\\"time\\\":[\\\"Transaction_Date\\\"]},\\\"elasticSearch\\\":{\\\"isEnabled\\\":true,\\\"properties\\\":{\\\"Franchise_IOId\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"order_id\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"Location_Id\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"ACCOUNT_HOLDER_ID\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"LOCATION_DROP_OFF_ID\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"Order_Amount\\\":{\\\"type\\\":\\\"double\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"Commission\\\":{\\\"type\\\":\\\"double\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"Transaction_Date\\\":{\\\"type\\\":\\\"date\\\",\\\"index\\\":\\\"not_analyzed\\\"}}},\\\"drillDef\\\":[{\\\"title\\\":\\\"Drill Def\\\",\\\"drillOrder\\\":[\\\"Franchise_IOId\\\",\\\"Location_Id\\\"]}],\\\"batchProcess\\\":{\\\"fieldName\\\":\\\"\\\",\\\"distinctQuery\\\":\\\"\\\",\\\"batchquery\\\":\\\"\\\"},\\\"dataRestriction\\\":{\\\"Franchise_IOId\\\":\\\"spacekey\\\",\\\"order_id\\\":\\\"orderid\\\"},\\\"scheduleInfo\\\":\\\"0 0 12 1 1/1 ? *\\\",\\\"scheduleDef\\\":{\\\"interval\\\":\\\"monthly\\\",\\\"option\\\":\\\"every\\\",\\\"optionArgs\\\":{\\\"choiceDay\\\":\\\"1\\\",\\\"choiceMonth\\\":\\\"1\\\"},\\\"time\\\":{\\\"hour\\\":12,\\\"min\\\":0}},\\\"notification\\\":{\\\"status\\\":true,\\\"mailid\\\":\\\"\\\"},\\\"enableNLP\\\":true,\\\"formulaJSON\\\":{},\\\"deltaProcess\\\":{\\\"isDeltaProcess\\\":false,\\\"deltaQuery\\\":\\\"\\\",\\\"delta\\\":\\\"\\\"}}\",\"cubeview\":[{\"lastRunDate\":null,\"createdBy\":{\"id\":"+uid+"},\"updatedBy\":{\"id\":"+uid+"},\"spaceKey\":\""+spaceKey+"\",\"name\":\"\",\"type\":1,\"id\":"+viewId+",\"status\":1,\"createdDate\":null,\"lastUpdatedDate\":null,\"isActive\":0,\"privacyType\":true,\"defenition\":\"{\\\"title\\\":\\\"Sum( Order_Amount )\\\",\\\"desc\\\":\\\"By Location_Id\\\",\\\"defaultChartClass\\\":\\\"DataGrid\\\",\\\"chartProperties\\\":{},\\\"filter\\\":{\\\"Location_Id\\\":[\\\"301161\\\"]},\\\"filterList\\\":\\\"\\\",\\\"mergedCubes\\\":[],\\\"currentCube\\\":null,\\\"isMergeEnabled\\\":false,\\\"mergedCubeDetails\\\":{},\\\"aggregation\\\":{\\\"op\\\":\\\"sum\\\",\\\"sfx\\\":\\\"\\\",\\\"pfx\\\":\\\"\\\",\\\"measure\\\":\\\"\\\"},\\\"category\\\":[{\\\"dimension\\\":\\\"Location_Id\\\",\\\"interval\\\":\\\"\\\",\\\"sourceID\\\":"+cbid+",\\\"$$hashKey\\\":\\\"object:6173\\\"}],\\\"series\\\":[{\\\"format\\\":{\\\"format\\\":\\\"Auto\\\",\\\"precision\\\":\\\"2\\\",\\\"sfx\\\":\\\"Auto\\\",\\\"pfx\\\":\\\"\\\"},\\\"tableColumn\\\":{\\\"alignment\\\":\\\"center\\\"},\\\"alertDetails\\\":{\\\"showAlert\\\":false,\\\"showDynamicColor\\\":true,\\\"gridRange\\\":\\\"\\\",\\\"gridDynamicRange\\\":\\\"\\\",\\\"totalgridRange\\\":20,\\\"minColor\\\":\\\"#f89406\\\",\\\"maxColor\\\":\\\"#00b16a\\\",\\\"col_font_clr\\\":\\\"#000000\\\"},\\\"measure\\\":\\\"Order_Amount\\\",\\\"op\\\":\\\"sum\\\",\\\"sourceID\\\":"+cbid+",\\\"$$hashKey\\\":\\\"object:6179\\\"}],\\\"transDim\\\":\\\"\\\",\\\"customField\\\":{\\\"list\\\":[],\\\"condition\\\":[]},\\\"properties\\\":{\\\"measure.Description\\\":\\\"Measure\\\",\\\"summary.Description\\\":\\\"Total\\\",\\\"tableHead\\\":{\\\"alignment\\\":\\\"center\\\",\\\"textColor\\\":\\\"black\\\",\\\"bgColor\\\":\\\"#FFFFFF\\\",\\\"isBold\\\":false,\\\"isItalics\\\":false,\\\"isUnderline\\\":false,\\\"fontSize\\\":\\\"small\\\",\\\"isScroll\\\":true,\\\"excludeView\\\":{\\\"enable\\\":false}},\\\"dataRestriction\\\":{}},\\\"querytype\\\":\\\"simple\\\",\\\"mergedDataStore\\\":{},\\\"masterDataStore\\\":"+cubeid+"}\"}]}";
		BusinessStoryHelper.saveCubeView(dataa);
	}

	@Test(description = "saveFormulaOperationTest")
	public static void saveFormulaOperationTest() {

		BusinessStoryHelper.saveFormulaOperation();
	}

	@Test(description = "listAllFormulaTest")
	public static void listAllFormulaTest() {

		BusinessStoryHelper.listAllFormula();
	}
}