package com.bdbizviz.restassured.platform.Util;

public class UserUtils {

    private  String customerKey;
    private  String spaceKey;
    private  String authToken;
    private  String userID;

    public String getCustomerKey() {

        return customerKey;
    }

    public void setCustomerKey(String customerKey) {

        this.customerKey = customerKey;
    }

    public String getUserID() {

        return userID;
    }

    public void setUserID(String userID) {

        this.userID = userID;
    }

    public String getAuthToken() {

        return authToken;
    }

    public void setAuthToken(String authToken)
    {

        this.authToken = authToken;
    }

    public String getSpaceKey() {

        return spaceKey;
    }

    public void setSpaceKey(String spaceKey) {

        this.spaceKey = spaceKey;
    }
}
