/**
 *
 */
package com.bdbizviz.restassured.platform.Util;

import java.sql.*;
import java.util.*;

import org.json.simple.JSONObject;

public class Jdbc_connection {
	public static HashMap<String,String> hm=new HashMap<String,String>();
	public static JSONObject prop=null;
	public static String dbip=null;
	public static String dbname=null;
	public static String dbuser=null;
	public static String dbpass=null;
	String newCommit = null;


	public static ArrayList<String> columnData=new ArrayList<String>();


	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		/*String sql1="SELECT A.ORDER_DETAIL_ID,A.MASTER_MENU_ID,A.SPACE_KEY ,A.MEAL_SIZE,A.AMOUNT_REFUND,A.TAX_ONE,A.TAX_TWO,if(A.TAX_THREE>5,'YES', 'NO') as ta,A.TOTAL_COST,A.TOTAL_TAX,B.PRICE,B.TAX,B.COMBOITEM,A.ORDER_TYPE,A.DISTRIBUTION_METHOD,A.SIDE_METHOD,A.CANCEL_REASON FROM order_detail as A join order_details_split as B on A.ORDER_DETAIL_ID=B.ORDER_DETAIL_ID WHERE A.AMOUNT_REFUND<7.2 and A.TOTAL_COST>1 or B.PRICE<=5 or A.TOTAL_TAX>=1 limit 100" ";
		
		createConnection(sql1);
		
		System.out.println(hm.get("subject_area"));*/
		String sql1="select ORDER_ID,ACCOUNT_HOLDER_ID,space_key,location_id,location_drop_off_id,total_amount,TOTAL_COMMISSION from orders where TOTAL_AMOUNT>0 and TOTAL_COMMISSION>0 and ACCOUNT_HOLDER_ID=152527 limit 1000";

		prop = Utils.getProps();
		dbip=Utils.getproperty("dbip");
		dbname= Utils.getproperty("dbname");
		dbuser=Utils.getproperty("dbuser");
		dbpass=Utils.getproperty("dbpass");
		//String DB_URL = "jdbc:mysql://"+JDBC_dbip+"/"+JDBC_dbname+"";

		createConnection(sql1,dbip,dbname,dbuser,dbpass);
		System.out.println(hm.get("ORDER_ID"));
	}

	public static String jdbcResult(String sql2,String colname,String ip,String dbname,String user,String pass){
		createConnection(sql2,ip,dbname,user,pass);
		return hm.get(colname);
	}


	public static void createConnection(String sql,String dbip,String dbname,String dbuser,String dbpass){
		String JDBC_DRIVER = "com.mysql.jdbc.Driver";
		String DB_URL = "jdbc:mysql://"+dbip+"/"+dbname+"";

			// Database credentials
		String USER = dbuser;
		String PASS = dbpass;
		Connection conn=null;
		Statement stmt=null;

		try{
			//STEP 3: Open a connection
			conn = DriverManager.getConnection(DB_URL, USER, PASS);

			//STEP 4: Execute a query
			stmt = conn.createStatement();
			getResultSet(stmt.executeQuery(sql));
			System.out.println("Query executed successfully...");
		}

		catch(SQLException se){
			//Handle errors for JDBC
			se.printStackTrace();
		}

		catch(Exception e){
			//Handle errors for Class.forName
			e.printStackTrace();
		}

		finally{
			//finally block used to close resources
			try{
				if(stmt!=null)
					stmt.close();}catch(SQLException se2){
			}
			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
	}

	private static void getResultSet(ResultSet rs) throws SQLException {
		ResultSetMetaData columns = rs.getMetaData();
		ArrayList<String> columnNames=new ArrayList<String>();
		while(rs.next()){
			//Retrieve by column name
			for(int i=1;i<=columns.getColumnCount();i++){
				columnNames.add(columns.getColumnName(i));
				}

			Iterator itr=columnNames.iterator();
			while(itr.hasNext()){
				String s=itr.next().toString();
				hm.put(s, rs.getString(s));
			}
			break;
		}
		rs.close();
	}

    //Dashboard data validation
	public static List<HashMap<String,String>> getResultsList(String DB_URL,String query,String JDBC_dbuser,String JDBC_dbpass) throws SQLException {
		String JDBC_DRIVER = "com.mysql.jdbc.Driver";
		//String DB_URL = "jdbc:mysql://"+JDBC_dbip+"/"+JDBC_dbname+"";
		String USER = JDBC_dbuser;
		String PASS = JDBC_dbpass;
		Connection conn=null;
		Statement stmt=null;
		ResultSet rs = null;
		List<HashMap<String,String>> hmList=new ArrayList<HashMap<String,String>>();

		try {
			// Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			HashMap<String,String> obj = null;
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			ArrayList<String> columnNames=new ArrayList<String>();
			if(rs!=null){
				ResultSetMetaData md = rs.getMetaData();
				for(int i=1;i<=md.getColumnCount();i++){
					columnNames.add(md.getColumnName(i));
				}
			}

			while (rs.next()) {
				obj = new HashMap<String, String>();
				for(String col:columnNames){
					obj.put(col.toLowerCase(),rs.getObject(col).toString());
				}
				hmList.add(obj);
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			if(rs !=null){
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return hmList;
	}

	private static void getMultiResultSet(ResultSet rs,String colname) throws SQLException {

		ResultSetMetaData columns = rs.getMetaData();
		ArrayList<String> columnNames=new ArrayList<String>();
		while(rs.next()){
			//Retrieve by column name
			for(int i=1;i<=columns.getColumnCount();i++){
				columnNames.add(columns.getColumnName(i));
			}
			Iterator itr=columnNames.iterator();
			while(itr.hasNext()){
				String s=itr.next().toString();
				hm.put(s, rs.getString(s));
				columnData.add(hm.get(colname));
			}
		}
		rs.close();
	}

	public static void createMulConnection(String sql,String dbip,String dbname,String dbuser,String dbpass,String colname){
		String JDBC_DRIVER = "com.mysql.jdbc.Driver";
		String DB_URL = "jdbc:mysql://"+dbip+"/"+dbname+"";
		// Database credentials
		String USER = dbuser;
		String PASS = dbpass;
		Connection conn=null;
		Statement stmt=null;

		try{
			//STEP 3: Open a connection
			conn = DriverManager.getConnection(DB_URL, USER, PASS);

			//STEP 4: Execute a query
			stmt = conn.createStatement();
			getMultiResultSet(stmt.executeQuery(sql),colname);
			System.out.println("Query executed successfully...");
		}

		catch(SQLException se){
			//Handle errors for JDBC
			se.printStackTrace();
		}

		catch(Exception e){
			//Handle errors for Class.forName
			e.printStackTrace();
		}

		finally{
			//finally block used to close resources
			try{
				if(stmt!=null)
					stmt.close();}catch(SQLException se2){
			}

			// nothing we can do
			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
	}
}
