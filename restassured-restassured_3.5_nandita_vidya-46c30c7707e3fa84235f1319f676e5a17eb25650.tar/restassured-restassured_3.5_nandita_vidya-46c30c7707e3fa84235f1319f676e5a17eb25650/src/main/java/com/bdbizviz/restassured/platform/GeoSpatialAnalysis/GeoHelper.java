package com.bdbizviz.restassured.platform.GeoSpatialAnalysis;

import com.bdbizviz.restassured.platform.Admininstration.AdminHelper;
import com.bdbizviz.restassured.platform.HomeUI.HomeUI_Impl;
import com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper;
import com.bdbizviz.restassured.platform.Util.Utils;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.Assert;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.bdbizviz.restassured.platform.Admininstration.AdminHelper.urlgetAllGeoSpatialSettings;
import static com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper.*;
import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;

public class GeoHelper {
    public static final Logger LOGGER = Logger.getLogger(GeoHelper.class.getName());
    public static Integer google_id;
    public static Integer leaflet_id;
    public static String geoShapeId;
    public static Integer treeRelIdPoint;
    public static Integer treeRelIdPolygon;
    public static Integer treeRelIdLine;
    public static String urlgetAllGeoSpatialRules;
    public static String ruleId;
    public static String geoDocumentId_Polygon;
    public static String urluploadGeoShapeData;
    public static String urlgetAllGeoShapeDatas;
    public static String urlsaveGeoData;
    public static String urlgetAllGeoSpatialSettings;
    public static String urlsaveOrUpdateGeoSpatialSettings;
    public static String urluploadGeoSpatialRule;
    public static String titleGoogle;
    public static String titleleaflet;
    public  String mapTypeGoogle;
    public  String mapTypeleaflet;
    public  String mapKeyGoogle;
    public  String mapKeyleaflet;
    public  String mapDataGoogle = "";
    public  String mapDataleaflet ;
    public String titlePolygon;

    String commit = "";



    public static void getUserInfoByToken(String authToken ) {
        try {
            Response response = given()
                    .param("token", authToken)
                    .when()
                    .post(Utils.getUrl( "getUserInfoByToken"))
                    .then()
                    .statusCode(HttpStatus.SC_OK)
                    .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            List<HashMap<String, Object>> treesList = (ArrayList<HashMap<String, Object>>) users.get("trees");
            for (HashMap treesList_Obj :treesList) {
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("My Documents")){
                    myDocumentId = treesList_Obj.get("id").toString();
                }
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Public Documents")) {
                    publicDocumentId = treesList_Obj.get("id").toString();
                }
                else if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Shared Documents")) {
                    shareDocumentId = treesList_Obj.get("id").toString();
                }
            }


            LOGGER.info(("ShareDocumentId is==" +shareDocumentId));
            LOGGER.info(("MyDocumentId is==" +myDocumentId));
            LOGGER.info(("PublicDocumentId is==" +publicDocumentId));

            //****To assert checking id's are not null***//
            List<Integer> ids = from(response.asString()).get("users.trees.id");
            for (Integer id : ids) {
                Assert.assertNotNull(id);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void saveOrUpdateGeoSpatialSettings(String title, String mapType, String mapKey,String mapData,String userId, String authToken, String spaceKey,int statusCode) {
        try{
            Response response_Geo =
                    given()  //headers
                            .header("userID", Integer.valueOf(userId))
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //req params
                            .param("title",title)
                            .param("mapType",mapType)
                            .param("mapKey",mapKey)
                            .param("mapData",mapData)
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveOrUpdateGeoSpatialSettings)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String,Object> resp = from(response_Geo.asString()).get("");
            HashMap<String,Object> geoSpatialResp = (HashMap)resp.get("geoSpatialResp");

            System.out.println("saveOrUpdateGeoSpatialSettings:" + resp);
            String msg = geoSpatialResp.get("success").toString();
            Assert.assertEquals(msg,"true" );

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //get all geo shape datas
    public static void getAllGeoShapeDatas(String geometryType,String userId, String authToken, String spaceKey,int statusCode){
        try{
            Response response_Geo =
                    given()  //headers
                            .header("userID", Integer.valueOf(userId))
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //req params
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .param("geometryType", geometryType)
                            .when()
                            .post(urlgetAllGeoShapeDatas)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String,Object> resp = from(response_Geo.asString()).get("");
            HashMap<String,Object> geoSpatialResp = (HashMap)resp.get("geoSpatialResp");
            List<HashMap<String,Object>> geoShapeDataList = (ArrayList<HashMap<String,Object>>)geoSpatialResp.get("geoShapeDataList");
            LOGGER.info(("resp:" +resp.toString()));

            for(HashMap<String, Object> geoShapeDataListObj:geoShapeDataList){
                if(geoShapeDataListObj.containsKey("name") && geoShapeDataListObj.get("name").equals("PolygonShape")){
                    geoShapeId =  geoShapeDataListObj.get("id").toString();
                }
            }

            String msg = geoSpatialResp.get("success").toString();
            Assert.assertEquals(msg,"true" );
            if(geoShapeId!= null){
                Assert.assertNotNull(geoShapeId);
            }
        }catch(Exception e){
            e.printStackTrace();
        }

    }

    //Upload Geo Shape Data's
    public static void uploadGeoShapeData(String areaType, String geometryType,String userId, String authToken, String spaceKey,int statusCode){
        try{
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(new FileReader("E:/work/bizvizAutomationGitWSNew/restassured/src/main/resources/countries.geo.json"));

            JSONObject jsonObjectShapeData = (JSONObject) obj;
            System.out.println(jsonObjectShapeData);

            String geoShapeDataCountries = jsonObjectShapeData.toString();


            String shapeName = "PolygonShape";
            Response response_Geo =
                    given()  //headers
                            .header("userID", Integer.valueOf(userId))
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //req params
                            .param("shapeData", geoShapeDataCountries)
                            .param("shapeName", shapeName)
                            .param("geometryType", geometryType)
                            .param("areaType", areaType)
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urluploadGeoShapeData)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String,Object> resp = from(response_Geo.asString()).get("");
            HashMap<String,Object> geoSpatialResp = (HashMap)resp.get("geoSpatialResp");
            HashMap<String,Object> geoShapeData = (HashMap)geoSpatialResp.get("geoShapeData");
            Integer geoShapeId = (Integer)geoShapeData.get("id");


            //***Assert message to check  folder added to favouites***//
            String message = geoSpatialResp.get("success").toString();
            Assert.assertEquals(message,"true" );
            Assert.assertNotNull(geoShapeId);

        }catch(Exception e){
            e.printStackTrace();
        }

    }

    //get all geospatial settings
    public static void getAllGeoSpatialSettingsAdmin(String userId, String authToken, String spaceKey, int statusCode){
        try{
            urlgetAllGeoSpatialSettings = Utils.getUrl("getAllGeoSpatialSettings");
            Response response_Geo =
                    given()  //headers
                            .header("userID", Integer.valueOf(userId))
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //req params
                            .param("geometryType","")
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllGeoSpatialSettings"))
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String,Object> resp = from(response_Geo.asString()).get("");
            HashMap<String,Object> geoSpatialResp = (HashMap)resp.get("geoSpatialResp");
            List<HashMap<String,Object>> geoSpatialSettingsList = (ArrayList<HashMap<String,Object>>)geoSpatialResp.get("geoSpatialSettingsList");

            for(HashMap<String, Object> geoSpatialSettingsListObj:geoSpatialSettingsList){
                if(geoSpatialSettingsListObj.containsKey("title") && geoSpatialSettingsListObj.get("title").equals("google")){
                    google_id =  (Integer) geoSpatialSettingsListObj.get("id");
                }
            }
            for(HashMap<String, Object> geoSpatialSettingsListObj:geoSpatialSettingsList){
                if(geoSpatialSettingsListObj.containsKey("title") && geoSpatialSettingsListObj.get("title").equals("leaflet")){
                    leaflet_id =  (Integer) geoSpatialSettingsListObj.get("id");
                }
            }
            LOGGER.info(("resp:" +resp.toString()));
            LOGGER.info(("google_id:" +google_id));
            LOGGER.info(("leaflet_id:" +leaflet_id));


            String msg = geoSpatialResp.get("success").toString();
            Assert.assertEquals(msg, "true");
            Assert.assertNotNull(google_id);
            Assert.assertNotNull(leaflet_id);

        }catch(Exception e){
            e.printStackTrace();
        }

    }

    //get all geospatial settings
    public static void uploadGeoSpatialRule(String geoJsonData, String geoSpatialRuleString,String geometryType,String userId, String authToken, String spaceKey, int statusCode){
        try{
            Response response_Geo =
                    given()  //headers
                            .header("userID", Integer.valueOf(userId))
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //req params
                            .param("ruleName","GeoSpatialAnalysisPolygon")
                            .param("geometryType",geometryType)
                            .param("geoSpatialRuleString",geoSpatialRuleString)
                            .param("mapSettingsId",google_id)
                            .param("sourceType","CSV File")
                            .param("dataSourceUrl","mapdataPolygon.csv")
                            .param("geoJsonData",geoJsonData)
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urluploadGeoSpatialRule)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String,Object> resp = from(response_Geo.asString()).get("");
            HashMap<String,Object> geoSpatialResp = (HashMap)resp.get("geoSpatialResp");
            HashMap<String,Object> geoSpatialRule = (HashMap)geoSpatialResp.get("geoSpatialRule");
            ruleId = geoSpatialRule.get("ruleId").toString();

          /*  String msg = resp.get("success").toString();
            Assert.assertEquals(msg, "true");*/
            System.out.println("ruleId :" + ruleId);
            Assert.assertNotNull(ruleId);

        }catch(Exception e){
            e.printStackTrace();
        }

    }


    public static void getAllGeoSpatialRules(String userId, String authToken, String spaceKey, int statusCode){
        try{
            Response response_getAllGeoSpatialRules =
                    given()  //headers
                            .header("userID", Integer.valueOf(userId))
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //req params
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getproperty("getAllGeoSpatialRules"))
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String,Object> resp = from(response_getAllGeoSpatialRules.asString()).get("");
            HashMap<String,Object> geoSpatialResp = (HashMap)resp.get("geoSpatialResp");
            List<HashMap<String,Object>> geoSpatialRuleList = (ArrayList<HashMap<String,Object>>)geoSpatialResp.get("geoSpatialRuleList");
            LOGGER.info(("resp:" +resp.toString()));

            for (HashMap<String, Object> geoSpatialRuleListObj:geoSpatialRuleList) {

                if(geoSpatialRuleListObj.containsKey("ruleName")&& geoSpatialRuleListObj.get("ruleName").toString().equals("GeoSpatialAnalysisPolygon")){
                    treeRelIdPolygon = (Integer) geoSpatialRuleListObj.get("ruleId");

                }
            }
            System.out.println(("treeRelIdPolygon:" +treeRelIdPolygon));
            String msg = geoSpatialResp.get("success").toString();
            Assert.assertEquals("true", msg);
            Assert.assertNotNull(treeRelIdPolygon);

        }catch(Exception e){
            e.printStackTrace();
        }

    }

    public static void saveGeoData(String title, String ruleId, String userId, String authToken, String spaceKey, int statusCode){
        try{
           String description = "";
           int position = 0;
           int dashboardtype = 6;
           String imagename = "form.png";
           String type = "file";
            Response response_getAllGeoSpatialRules =
                    given()  //headers
                            .header("userID", Integer.valueOf(userId))
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //req params
                            .param("position", position)
                            .param("dashboardtype",dashboardtype)
                            .param("parentid",myDocumentId)
                            .param("type",type)
                            .param("id",position)
                            .param("imagename", imagename)
                            .param("title",title)
                            .param("description",description)
                            .param("treeRel",ruleId)
                            .param("file",description)
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveGeoData)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String,Object> resp = from(response_getAllGeoSpatialRules.asString()).get("");
            HashMap<String,Object> trees = (HashMap)resp.get("trees");
            HashMap<String,Object> tree = (HashMap)trees.get("tree");
            System.out.println(("resp:" +resp.toString()));
            geoDocumentId_Polygon = tree.get("id").toString();

            String message = trees.get("message").toString();
            System.out.println("geoDocumentId_Polygon:" + geoDocumentId_Polygon);

            //***Assert message to check  folder added to favouites***//
            Assert.assertEquals(message, "Successfully save the dashboard");
            Assert.assertEquals(trees.get("success"), true);


        }catch(Exception e){
            e.printStackTrace();
        }

    }


}
