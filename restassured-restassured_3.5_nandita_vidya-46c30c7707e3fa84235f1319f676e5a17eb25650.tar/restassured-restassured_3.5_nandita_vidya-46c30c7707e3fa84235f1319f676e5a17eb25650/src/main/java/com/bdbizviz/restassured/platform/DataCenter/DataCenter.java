package com.bdbizviz.restassured.platform.DataCenter;

import com.bdbizviz.restassured.platform.UserManagement.UserManagement;
import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.Jdbc_connection;
import com.bdbizviz.restassured.platform.Util.User;
import com.bdbizviz.restassured.platform.Util.Utils;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import sun.rmi.runtime.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;

import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;

public class DataCenter extends DataCenterHelper {
    public static final Logger LOGGER = Logger.getLogger(DataCenter.class.getName());



    @BeforeClass
    public static void setupDataCenter() throws Exception {
        prop = Utils.getProps();//Fetch all Permission data of properties Permission file and store in prop
        pass_admin= Utils.getproperty("passadmin");
        space_admin=Utils.getproperty("spaceQAadmin");
        Groupnameuser = Utils.getproperty("Groupnameuser");
        isExistsMetadta = Utils.getproperty("isExistsMetadta");
        consumerName = Utils.getproperty("consumerName");
        serviceName = Utils.getproperty("serviceName");
        serviceNameCreation = Utils.getproperty("serviceNameCreation");

        isExistsMetadta=Utils.getproperty("isExistsMetadta");
        consumerName=Utils.getproperty("consumerName");
        serviceName=Utils.getproperty("serviceName");
        serviceNameCreation=Utils.getproperty("serviceNameCreation");

        //Fetching All Urls
        urlgetdatsourcelist = Utils.getUrl("getdatasourcelist");
        urlcreatedatasource = Utils.getUrl("createdatasource");
        urllistquerryservices = Utils.getUrl("listquerryservices");
        urltestquerryservice = Utils.getUrl("testquerryservice");
        urltestquerrycassendra=Utils.getUrl("testquerrycassendra");
        urlcreatequerryservice = Utils.getUrl("createquerryservice");
        urlviewdatasourcedetails = Utils.getUrl("viewdatasourcedetails");
        urlgetdatasourceinfobytype = Utils.getUrl("getdatasourceinfobytype");
        urlcheckdatasource = Utils.getUrl("checkdatasource");
        urlcheckconnection=Utils.getUrl("checkconnection");
        urlupdatedatasourcedetails = Utils.getUrl("updatedatasourcedetails");
        urlreconnect = Utils.getUrl("reconnect");
        urldeleteddatasource = Utils.getUrl("deleteddatasource");
        urlgetprivilegedetails = Utils.getUrl("getprivilegedetails");
        urlloadprivileges = Utils.getUrl("loadprivileges");
        urlsharedatasource = Utils.getUrl("sharedatasource");
        urlgetusersfromgroups = Utils.getUrl("getusersfromgroups");
        urlupdatequeryservice = Utils.getUrl("updatequeryservice");
        urldeletequeryservice = Utils.getUrl("deletequeryservice");
        urlgetDataStoreInfo=Utils.getUrl("getDataStoreInfo");
        urlpluginservice=Utils.getUrl("pluginservice");

        //Fetching Permission data from properties Permission file
        dataStoreName=Utils.getproperty("dataStoreName");
        dataSourceName=Utils.getproperty("dataSourceName");
        dataSourceNameMysql=Utils.getproperty("dataSourceNameMysql");
        updatedatasrcname=Utils.getproperty("updatedatasrcname");
        queryname=Utils.getproperty("queryname");
        querynameMysql=Utils.getproperty("querynameMysql");
        querynameMSsql=Utils.getproperty("querynameMSsql");
        querynameOracle=Utils.getproperty("querynameOracle");
        querynameHive=Utils.getproperty("querynameHive");
        querynameSparkSql=Utils.getproperty("querynameSparkSql");
        querynameCassendra=Utils.getproperty("querynameCassendra");
        querynameOdata=Utils.getproperty("querynameOdata");
        dbUserName=Utils.getproperty("dbUserName");
        dbPassword=Utils.getproperty("dbPassword");
        dbPortNumber=Utils.getproperty("dbPortNumber");
        dbHostName=Utils.getproperty("dbHostName");
        dbName=Utils.getproperty("dbName");
        dbType=Utils.getproperty("dbType");
        dsQuery=Utils.getproperty("dsQuery");
        GroupnameGeneral=Utils.getproperty("GroupnameGeneral");

        dbUserNameMSsql=Utils.getproperty("dbUserNameMSsql");
        dataSourceNameMSsql=Utils.getproperty("dataSourceNameMSsql");
        dbPasswordMSsql=Utils.getproperty("dbPasswordMSsql");
        dbPortNumberMSsql=Utils.getproperty("dbPortNumberMSsql");
        dbHostNameMSsql=Utils.getproperty("dbHostNameMSsql");
        dbNameMSsql=Utils.getproperty("dbNameMSsql");
        dbTypeMSsql=Utils.getproperty("dbTypeMSsql");
        dsQueryMSsql1=Utils.getproperty("dsQueryMSsql1");
        dsQueryMSsql2=Utils.getproperty("dsQueryMSsql2");
        dsQueryMSsql3=Utils.getproperty("dsQueryMSsql3");
        dsQueryMSsql4=Utils.getproperty("dsQueryMSsql4");
        dsQueryMSsql5=Utils.getproperty("dsQueryMSsql5");
        dsQueryMSsql6=Utils.getproperty("dsQueryMSsql6");
        dsQueryMSsql7=Utils.getproperty("dsQueryMSsql7");

        dbUserNameOracle=Utils.getproperty("dbUserNameOracle");
        dataSourceNameOracle=Utils.getproperty("dataSourceNameOracle");
        dbPasswordOracle=Utils.getproperty("dbPasswordOracle");
        dbPortNumberOracle=Utils.getproperty("dbPortNumberOracle");
        dbHostNameOracle=Utils.getproperty("dbHostNameOracle");
        dbServiceNameOracle=Utils.getproperty("dbServiceNameOracle");
        dbTypeOracle=Utils.getproperty("dbTypeOracle");
        dsQueryOracle=Utils.getproperty("dsQueryOracle");

        dbUserNameHive=Utils.getproperty("dbUserNameHive");
        dataSourceNameHive=Utils.getproperty("dataSourceNameHive");
        dbPasswordHive=Utils.getproperty("dbPasswordHive");
        dbPortNumberHive=Utils.getproperty("dbPortNumberHive");
        dbHostNameHive=Utils.getproperty("dbHostNameHive");
        dbTypeHive=Utils.getproperty("dbTypeHive");
        dsQueryHive=Utils.getproperty("dsQueryHive");

        dbPortNumberSparkSql=Utils.getproperty("dbPortNumberSparkSql");
        dataSourceNameSparkSql=Utils.getproperty("dataSourceNameSparkSql");
        dbTypeSparkSql=Utils.getproperty("dbTypeSparkSql");

        dbUserNameCassendra=Utils.getproperty("dbUserNameCassendra");
        dataSourceNameCassendra=Utils.getproperty("dataSourceNameCassendra");
        dbPasswordCassendra=Utils.getproperty("dbPasswordCassendra");
        dbPortNumberCassendra=Utils.getproperty("dbPortNumberCassendra");
        dbHostNameCassendra=Utils.getproperty("dbHostNameCassendra");
        dbTypeCassendra=Utils.getproperty("dbTypeCassendra");
        dsQueryCassendra=Utils.getproperty("dsQueryCassendra");
        consistencylevelCassendra=Utils.getproperty("consistencylevelCassendra");
        consistencylevelCassendratwo=Utils.getproperty("consistencylevelCassendratwo");

        dbUserNameOData=Utils.getproperty("dbUserNameOData");
        dataSourceNameOdata=Utils.getproperty("dataSourceNameOdata");
        dbPasswordOData=Utils.getproperty("dbPasswordOData");
        dbHostNameOData=Utils.getproperty("dbHostNameOData");
        dbTypeOData=Utils.getproperty("dbTypeOData");
        dsQueryOData=Utils.getproperty("dsQueryOData");

        serviceNameIndex=Utils.getproperty("serviceNameIndex");
        serviceNameDelCube=Utils.getproperty("serviceNameDelCube");

        updatequerynameMysql = Utils.getproperty("updatequerynameMysql");
        updatequerynameMssql = Utils.getproperty("updatequerynameMssql");
        updatequerynameOracle = Utils.getproperty("updatequerynameOracle");
        updatequerynameHive = Utils.getproperty("updatequerynameHive");
        updatequerynameSparkSql = Utils.getproperty("updatequerynameSparkSql");
        updatequerynameCassandra = Utils.getproperty("updatequerynameCassandra");
        updatequerynameOData = Utils.getproperty("updatequerynameOData");

        querynameFilter = Utils.getproperty("querynameFilter");
        dataSourceNameFilter = Utils.getproperty("dataSourceNameFilter");
        dsQueryFilter = Utils.getproperty("dsQueryFilter");


        //NonAdmin user
        user = Helper.getCustomerKey(emailidcreate,space_admin);
        userauth = Helper.getAuthToken(emailidcreate,pass_admin,space_admin);
        spaceKey = user.getSpacekey();
        uid = user.getId();
        authToken = userauth.getAuthToken();


        //-------------------------------------Converts a Permission data to string for Cassendra createdataconnector-----//
        JSONObject obj=new JSONObject();
        JSONObject innerobj=new JSONObject();
        innerobj.put("consistencylevel",consistencylevelCassendra);
        innerobjdata=innerobj.toString();

        obj.put("dataSourceName",dataSourceName);
        obj.put("userName",dbUserNameCassendra);
        obj.put("password",dbPasswordCassendra);
        obj.put("portNumber",dbPortNumberCassendra);
        obj.put("hostName",dbHostNameCassendra);
        obj.put("databaseName","");
        obj.put("dataSourceType",dbTypeCassendra);
        obj.put("description","");
        obj.put("advanced",innerobj);
        objdata=obj.toString();

        JSONObject objupdate=new JSONObject();
        JSONObject innerobjupdate=new JSONObject();
        innerobjupdate.put("consistencylevel",consistencylevelCassendratwo);
        innerobjdataupdate=innerobjupdate.toString();

        objupdate.put("dataSourceName",updatedatasrcname);
        objupdate.put("userName",dbUserNameCassendra);
        objupdate.put("password",dbPasswordCassendra);
        objupdate.put("portNumber",dbPortNumberCassendra);
        objupdate.put("hostName",dbHostNameCassendra);
        objupdate.put("databaseName","");
        objupdate.put("dataSourceType",dbTypeCassendra);
        objupdate.put("description","");
        objupdate.put("advanced",innerobjupdate);
        objdataupdate=objupdate.toString();


    String commit = "";
    }

    @BeforeClass
    public static void setupnew() throws InterruptedException {
        Thread.sleep(2000);
        createnewGroupDataShare(spaceKey,uid,authToken,GroupnameGeneral+Helper.generateRandomString());

        Thread.sleep(1000);
        //create a new user which is assigned to usergroup
        createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,newgroupidtest,authToken,spaceKey,HttpStatus.SC_OK);

    }

//***********************************BAT TestCases******************************************//

    @Test(description = "checkDataSource")
    public static void checkDataSource() {
        try {
            checkDataSource(spaceKey,uid,authToken,dataSourceName,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createDataConnector")
    public  void createDataConnector() {
        try {

            createDataConnector(spaceKey,uid,authToken,dataSourceName,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,"null",HttpStatus.SC_OK);


        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "previewDataSet")
    public  void previewDataSet() {
        try {

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQuery+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbType+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createDataSet")
    public  void createDataSet() {
        try {

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,dbName, dsQuery, datasourceid,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "publishDataSet")
    public  void publishDataSet() {
        try {

            //publish  Queryservice
            publishDataSet(spaceKey,uid,authToken ,seriveiddataset,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getAllDataSet")
    public  void getAllDataSet() {
        try {

            //publish  Queryservice
            getAllDataSet(spaceKey,uid,authToken ,"0",HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test
    public  void getQueryInfo() {

        String data="{\"id\":\""+datasourceid+"\",\"query\":\"\\n"+Utils.getproperty("dsQueryDataStore")+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbType+"\"}";

        getQueryInfo(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

    }

    @Test
    public  void getAllDataStore() {

        String data="{\"id\":0,\"datasourcetype\":\"\"}";
        getAllDataStore(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

    }

    @Test
    public  void getDataSourceList() {

        getDataSourceList(spaceKey,uid,authToken,HttpStatus.SC_OK);

    }

    @Test
    public  void getDataSourceInfoByType() {

        getDataSourceInfoByType(spaceKey,uid,authToken,"",HttpStatus.SC_OK);

    }


    //DataStore Creation
    @Test(description = "pluginSaveCubee,Data Store Creation")
    public  void pluginSaveCubee() {
        try {

            pluginSaveCubee(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //DataStore Scheduling
    @Test(description = "pluginExecuteSheduler,Data Store Scheduler")
    public  void pluginExecuteScheduler() {
        try {

            pluginExecuteSheduler(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //DataStore RefreshNow
    @Test(description = "pluginInitialCubeCreation,Data Store Refresh")
    public  void pluginInitialCubeCreation() {
        try {
            pluginInitialCubeCreation(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //DataStore Info
    @Test(description = "plugingetLatestSchedulerHistory,Data Store Refresh Info")
    public  void plugingetLatestSchedulerHistory() {
        try {
            plugingetLatestSchedulerHistory(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getDataSourceInfoByTypeDelete,Validation Level:Status code,Id not null,Success is true and Message")
    public void getDataSourceInfoByTypeDelete() {

        try {
            UserManagement.login();
            getDataSourceInfoByTypeDelete(spaceKeyadmin,uidadmin,authTokenadmin,"",HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getDataSourceInfoByTypeDelete,Validation Level:Status code,Id not null,Success is true and Message")
    public void getAllDataStoreDelete() {

        try {
            UserManagement.login();
            String data="{\"id\":0,\"datasourcetype\":\"\"}";
            getAllDataStoreDelete(spaceKeyadmin,uidadmin,authTokenadmin,data,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }



//************************************Functional TestCases*************************************//

    //---------------------------------------MYSQL-------------------------------------//

    @Test(description = "dataConnFlowMYSQLPositive")
    public  void dataConnFlowMYSQLPositive(){
        try{
            String datasourceidafterdel=null;

            checkDataSource(spaceKey,uid,authToken,dataSourceNameMysql,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameMysql,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytypsrc =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbType)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypsrc = from(responsegetdatasrcbytypsrc.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypsrc = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypsrc.get("dataSourcesList");

            Thread.sleep(3000);
            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypsrc) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationMysqlTest")) {
                    namebytype=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceid==="+datasourceid);
            log.info("namebytype===="+namebytype);

            Assert.assertEquals( dataSourcesgetdatasrcbytypsrc.get("success").toString(),"true");

            //Validating that new query is created with name restdbautomation
            Assert.assertEquals(namebytype,"restdbautomationMysqlTest");

            //Fetches the detail of newly created data connector for update
            viewDataSourceDetails(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Validation of id
            Assert.assertEquals(idviewdatasrc.toString(),datasourceid.toString());

            //Before updating check the datconnector
            checkDataSourceEdit(spaceKey,uid,authToken,dbUserName,null,dbPortNumber,dbHostName,dbName,datasourceid,dbType,null,HttpStatus.SC_OK);

            //Update the newly created data connector
            updateDataSourceDetails(spaceKey,uid,authToken,dbUserName,null,dbPortNumber,dbHostName,dbName,datasourceid,dbType,null,HttpStatus.SC_OK);

            //Reconnect the same data connector
            reconnect(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Finally delete that same data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            log.info("ggggg===="+datasourceid);

            //Fetches the id and name of newly created data connector
            Response responseget =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbType)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesget = from(responseget.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListget = (ArrayList<HashMap<String, Object>>) dataSourcesget.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListget) {
                if (iddb.containsKey("dataSourceID") &&   iddb.get("dataSourceID").toString().equals(datasourceid)) {
                    datasourceidafterdel = iddb.get("dataSourceID").toString();
                }
            }

            //Validating that created new connector id is deleted and it is null
            Assert.assertNull(datasourceidafterdel);

           /* //Storing the actual Permission from creationToDeletionWorkflowUser.Permission in outputjson
            JSONObject actualjson = Utils.getJson("./src/main/resources/dataConnFlowDataMYSQL.json");
            log.info("actualjson=====" + actualjson);

            //Conversion of Hashmap to Permission form
            JSONObject expectedjson = new JSONObject();
            expectedjson.putAll(dataSourcesget);
            log.info("expectedjson=====================" + expectedjson);
*/
            //Json validation
            // Assert.assertEquals(actualjson.toString(),expectedjson.toString());
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //create a new connector,fetch that connector id,share it to aumategrp user,check in autmategrp
    //user space whether this connector is presetnt or not and validate and delete that connector
    //at end do Permission validation of getdatasourceinfobytype of autmategrp user
    @Test(description = "shareUserDataSourceFlowMYSQLPositive")
    public  void shareUserDataSourceFlowMYSQLPositive() {
        try {
            String datasourceidafterdel=null;

            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameMysql,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,HttpStatus.SC_OK);

            //create datasource
            createDataConnector(spaceKey,uid,authToken,dataSourceNameMysql,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,"null",HttpStatus.SC_OK);

            //getdatasourceinforbytype which fetches the data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbType)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationMysqlTest")) {
                    namebytype = iddb.get("dataSourceName").toString();
                }
            }

            log.info("datasourceidBeforeSharing===" + datasourceid);
            log.info("namebytypeBeforeSharing==" + namebytype);

            Assert.assertEquals(dataSourcesgetdatasrcbytyp.get("success").toString(),"true");

            Assert.assertEquals(namebytype,"restdbautomationMysqlTest");

            Thread.sleep(1000);
            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,newgroupidtest,authToken,spaceKey,HttpStatus.SC_OK);

            //Sharedatasource to share the data connector to user(AutmateGrouAugust)
            shareUserDataSource(spaceKey,uid,authToken,datasourceid, newuseridfunuser,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            Thread.sleep(1000);
            //Login with AutmateGrouAugust user to check whether shared connector is present in AutmateGrouAugust or not
            Response responsegetdatasrcbytypnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbType)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew = from(responsegetdatasrcbytypnew.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypnew = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypnew.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypnew) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").equals("restdbautomationMysqlTest")) {
                    datasourceidnewusr = iddb.get("dataSourceID").toString();
                    namebytypenewusr=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidAfterSharing=="+datasourceidnewusr);
            log.info("namebytypeAfterSharing=="+namebytypenewusr);

            Assert.assertEquals(dataSourcesgetdatasrcbytypnew.get("success").toString(),"true");

            Thread.sleep(1000);
            Assert.assertEquals(datasourceidnewusr,datasourceid);

            //Delete newly created data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //After delete again fetching the list of data connector for AutmateGrouAugust grp for Permission validation
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbType)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSources = from(response.asString()).get("");

            List<HashMap<String, Object>> dataSourcesListget = (ArrayList<HashMap<String, Object>>) dataSources.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListget) {
                if (iddb.containsKey("dataSourceID") &&   iddb.get("dataSourceID").toString().equals(datasourceid)) {
                    datasourceidafterdel = iddb.get("dataSourceID").toString();
                }
            }

            //Validating that data connector is deleted
            Assert.assertNull(datasourceidafterdel);

            String jsondata="{\"tables\":[],\"success\":true,\"databaseUtils\":[],\"dataSourcesList\":[]}";

            //Conversion of Hashmap to Permission form
            JSONObject expectedjson = new JSONObject();
            expectedjson.putAll(dataSources);
            log.info("expectedjson=====================" + expectedjson);

            //Json validation
            Assert.assertEquals(expectedjson.toString(),jsondata);

            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);


        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataSourceToExcludeMYSQLPositive")
    public  void shareGroupDataSourceToExcludeMYSQLPositive() {
        try {
            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameMysql,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,HttpStatus.SC_OK);

            //create data source
            createDataConnector(spaceKey,uid,authToken,dataSourceNameMysql,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,"null",HttpStatus.SC_OK);

            //getdatasourceinforbytype which fetches the data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbType)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationMysqlTest")) {
                    namebytype=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidBeforeSharingGrp==="+datasourceid);
            log.info("namebytypeBeforeSharingGrp==="+namebytype);

            Thread.sleep(1000);

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            Thread.sleep(2000);
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(), newuseridfunuser,HttpStatus.SC_OK);

            getUsersFromGroups(newgroupid,HttpStatus.SC_OK);

            //Sharegroupdatasource
            shareGroupDataSource(spaceKey,uid,authToken,datasourceid,newgroupid,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with autmategrp user to check whether shared connector is present in autmategrp or not
            Response responsegetdatasrcbytypnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbType)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew = from(responsegetdatasrcbytypnew.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypnew = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypnew.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypnew) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationMysqlTest")) {
                    datasourceidnew = iddb.get("dataSourceID").toString();
                    namebytypenew=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidAfterSharingGrp==="+datasourceidnew);
            log.info("namebytypeAfterSharingGrp==="+namebytypenew);

            Assert.assertEquals(dataSourcesgetdatasrcbytypnew.get("success").toString(),"true");
            Assert.assertEquals(datasourceidnew.toString(),datasourceid.toString());

            //Exclude user from group
            excludeShareDataSource(spaceKey,uid,authToken,datasourceid,newgroupid, newuseridfunuser,datasourceid,HttpStatus.SC_OK);

            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Again fetching the list of data connectors for autmategrp user for Permission validation
            Response responsegetdatasrcbytypnew1 =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbType)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew1 = from(responsegetdatasrcbytypnew1.asString()).get("");

            Assert.assertNull(dataSourcesgetdatasrcbytypnew1.get("dataSourceID"));

            String actualjson="{\"tables\":[],\"success\":true,\"databaseUtils\":[],\"dataSourcesList\":[]}";

            //Storing the actual Permission from shareConnector.Permission in outputjson
            log.info("actualjsonAfterexclude==========" + actualjson);

            //Conversion of Hashmap to Permission form
            JSONObject expectedjson = new JSONObject();
            expectedjson.putAll(dataSourcesgetdatasrcbytypnew1);
            log.info("excludejsonAfterexclude===========" + expectedjson);

            //Json validation
            Assert.assertEquals(expectedjson.toString(),actualjson.toString());

            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "queryServiceFlowMYSQLPositive")
    public void queryServiceFlowMYSQLPositive(){
        try{
            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameMysql,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,HttpStatus.SC_OK);

            //create data source
            createDataConnector(spaceKey,uid,authToken,dataSourceNameMysql,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,"null",HttpStatus.SC_OK);

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQuery+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbType+"\",\"filter\":\"{}\"}";
            Thread.sleep(2000);
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);
            Thread.sleep(2000);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,querynameMysql,dbName, dsQuery, datasourceid,HttpStatus.SC_OK);

            //Fetching the list of query service in a data connector
            getAllDataSet(spaceKey,uid,authToken,"0",HttpStatus.SC_OK);
            downloadDataSet("./src/main/resources/mysqlDownload1.txt",authToken,nividhQueryName);

            //Fetches the detail of newly created query service for update
            viewEditQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);
            Assert.assertEquals(viewquryid.toString(),seriveiddataset.toString());

            //Test query service before creation
            String dataedit=null;
            dataedit="{\"query\":\""+Utils.getproperty("dsQueryupdate1")+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbType+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,dataedit,HttpStatus.SC_OK);
            log.info("id"+seriveiddataset.toString());

            //Update the newly created query service
            updateQueryService(updatequerynameMysql,spaceKey,uid,authToken,dbName,Utils.getproperty("dsQueryupdate1"),datasourceid,seriveiddataset.toString(),HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/mysqlDownload2.txt",authToken,nividhQueryName);

            //Test query service before creation
            String dataedit1=null;
            dataedit1="{\"query\":\""+Utils.getproperty("dsQueryupdate3")+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbType+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,dataedit1,HttpStatus.SC_OK);
            log.info("id"+seriveiddataset.toString());

            //Update the newly created query service
            updateQueryService(updatequerynameMysql,spaceKey,uid,authToken,dbName,Utils.getproperty("dsQueryupdate3"),datasourceid,seriveiddataset.toString(),HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/mysqlDownload3.txt",authToken,nividhQueryName);

            //Test query service before creation
            String dataedit2=null;
            dataedit2="{\"query\":\""+Utils.getproperty("dsQueryupdate5")+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbType+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,dataedit2,HttpStatus.SC_OK);
            log.info("id"+seriveiddataset.toString());

            //Update the newly created query service
            updateQueryService(updatequerynameMysql,spaceKey,uid,authToken,dbName,Utils.getproperty("dsQueryupdate5"),datasourceid,seriveiddataset.toString(),HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/mysqlDownload4.txt",authToken,nividhQueryName);

           /* //Using number of Different Queries using all functions,operators,dates etc
            JSONObject actualjson = Utils.getJson("./src/main/resources/mysqlQuery.Permission");
            JSONArray userArray = (JSONArray) actualjson.get("queries");
            for (Object number : userArray) {
                JSONObject jsonNumber = (JSONObject) number;
                String query = (String) jsonNumber.get("query");

                //Test query service before creation
                String dataupdatemysql=null;
                dataupdatemysql="{\"query\":\""+query+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbType+"\",\"filter\":\"{}\"}";

                runDataService(spaceKey,uid,authToken,dataupdatemysql,HttpStatus.SC_OK);

                updateQueryService(updatequerynameMysql,spaceKey,uid,authToken,dbName,query,datasourceid,seriveiddataset.toString(),HttpStatus.SC_OK);

                Thread.sleep(3000);
                downloadDataSetLoop(authToken,nividhQueryName);
                Thread.sleep(5000);

                String header[]= responsedownload.split("\n");
                log.info("dw"+header);

                String a=header[0];
                log.info(a);
                String arr[]=a.split(",");
                log.info("arr"+arr);

                org.json.JSONArray jdbcgetRecordsData=null;
                List<HashMap<String,String>> datasList=null;

                Thread.sleep(3000);
                datasList =  Jdbc_connection.getResultsList(query,"192.168.1.10:3306", "BizViz_Automation_WT", "automation_user", "Auto%987");
                jdbcgetRecordsData = new org.json.JSONArray(datasList);

                String oput = "";
                oput=a;
                for(int i=0 ;i<jdbcgetRecordsData.length();i++) {
                    List v=new ArrayList();
                    String inline = "";
                    org.json.JSONObject ko= jdbcgetRecordsData.getJSONObject(i);

                    for (int j = 0; j< arr.length; j++) {
                        String key = arr[j];
                        String value = ko.get(key.toLowerCase()).toString();
                        inline = inline+value;
                        if(j!=arr.length-1){
                            inline+=",";
                        }
                                          }
                    oput =oput+"\n"+inline;
                }
                oput+="\n";

                System.out.println("["+oput+"]");
                System.out.println(datasList);
                Assert.assertEquals(oput.toString(),responsedownload.toString());
                            }
*/

            //Publish the Dataset
            publishDataSet(spaceKey,uid,authToken,seriveiddataset,HttpStatus.SC_OK);
            //Call this function to check published data set is avaialble in dashboard designer

            listQueryServices(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Validate that published Data set is available for Dashboard creation.
            Assert.assertEquals(quryserviceidMysql.toString(),seriveiddataset.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataServiceFlowMYSQLPositive")
    public  void shareUserDataServiceFlowMYSQLPositive() {
        try {
            String namebytypeshare=null;

            checkDataSource(spaceKey,uid,authToken,dataSourceNameMysql,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameMysql,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbType)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationMysqlTest")) {
                    namebytypeshare=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidshare==="+datasourceid);
            log.info("namebytypeshare===="+namebytypeshare);

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQuery+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbType+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,dbName, dsQuery, datasourceid,HttpStatus.SC_OK);

            Thread.sleep(2000);
            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,newgroupidtest,authToken,spaceKey,HttpStatus.SC_OK);

            //Sharedatasource to share the queryservice to user(AutmateGrouAugust)
            shareUserDataService(spaceKey,uid,authToken,seriveiddataset, newuseridfunuser,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with rest user to check whether shared queryservice is present in rest or not
            Response responseaut =
                    given()                       //Header
                            .header("spacekey", spaceKey)
                            .header("userID",uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            // HashMap<String, Object> queryServicesaut = from(responseaut.asString()).get("");
            List<HashMap<String, Object>> queryServicesaut = from(responseaut.asString()).get("");

            //List<HashMap<String, Object>> queryServiceslistaut = (ArrayList<HashMap<String, Object>>) queryServicesaut.get("queryServicesList");

            for (HashMap<String, Object> iddbnew : queryServicesaut) {
                if (iddbnew.containsKey("serviceId") && iddbnew.get("serviceId").toString().equals(seriveiddataset)) {
                    idnew = iddbnew.get("serviceId").toString();
                }
            }
            log.info("idnew=="+idnew);
            Assert.assertEquals(idnew.toString(),seriveiddataset);

            //delete newly created query service
            deleteQueryService(spaceKey,uid,authToken,seriveiddataset,HttpStatus.SC_OK);

            //delete newly created data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            Response responseusr =
                    given()                       //Header
                            .header("spacekey", spaceKey)
                            .header("userID",uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            // HashMap<String, Object> queryServicesaut = from(responseaut.asString()).get("");
            List<HashMap<String, Object>> queryServicesusr = from(responseusr.asString()).get("");

            //Json validation
            Assert.assertEquals(queryServicesusr.toString(),"[]");

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataServiceToExcludeMYSQLPositive")
    public  void shareGroupDataServiceToExcludeMYSQLPositive() {
        try{

            String namebytypeshare=null;

            checkDataSource(spaceKey,uid,authToken,dataSourceNameMysql,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameMysql,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbType)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationMysqlTest")) {
                    namebytypeshare=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidshare==="+datasourceid);
            log.info("namebytypeshare===="+namebytypeshare);


            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQuery+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbType+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,dbName, dsQuery, datasourceid,HttpStatus.SC_OK);

            //Fetching the list of query service
            getAllDataSet(spaceKey,uid,authToken,"0",HttpStatus.SC_OK);

            Thread.sleep(1000);
            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            Thread.sleep(1000);
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(), newuseridfunuser,HttpStatus.SC_OK);

            //SharegroupDataService
            shareGroupDataService(spaceKey,uid,authToken,seriveiddataset.toString(),newgroupid,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            // HashMap<String, Object> dataSources = from(response.asString()).get("dataSources");
            List<HashMap<String, Object>> getdata = from(response.asString()).get("");

            for (HashMap<String, Object> iddata : getdata) {
                if (iddata.containsKey("serviceId") &&   iddata.get("serviceId").toString().equals(seriveiddataset)) {
                    idnew = iddata.get("serviceId").toString();
                }
            }

            Assert.assertEquals(idnew.toString(),seriveiddataset.toString());

            //Exclude user from group
            excludeShareDataService(spaceKey,uid,authToken,seriveiddataset.toString(),newgroupid, newuseridfunuser,HttpStatus.SC_OK);

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with autmategrp user to check whether shared queryservice is present in autmategrp or not
            Response responseautnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesautnew = from(responseautnew.asString()).get("");

            Assert.assertNotEquals(queryServicesautnew,seriveiddataset.toString());

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //fetches the query list of autmategrp usr for Permission validation
            Response responseusr =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesusr = from(responseautnew.asString()).get("");

            //Json validation
            Assert.assertEquals(queryServicesusr.toString(),"[]");

            deleteQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);

            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }


//--------------------------------------MSSQL-------------------------------------//

    @Test(description = "dataConnFlowMSSQLPositive")
    public  void dataConnFlowMSSQLPositive(){
        try{
            String datasourceidafterdel=null;

            checkDataSource(spaceKey,uid,authToken,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytypsrc =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeMSsql)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypsrc = from(responsegetdatasrcbytypsrc.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypsrc = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypsrc.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypsrc) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationMSsql")) {
                    namebytype=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceid==="+datasourceid);
            log.info("namebytype===="+namebytype);

            Assert.assertEquals(dataSourcesgetdatasrcbytypsrc.get("success").toString(),"true");

            //Validating that new query is created with name restdbautomation
            Assert.assertEquals(namebytype,"restdbautomationMSsql");

            //Fetches the detail of newly created data connector for update
            viewDataSourceDetails(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Validation of id
            Assert.assertEquals(idviewdatasrc.toString(),datasourceid.toString());

            //Before updating check the datconnector
            checkDataSourceEdit(spaceKey,uid,authToken,dbUserNameMSsql,null,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,datasourceid,dbTypeMSsql,null,HttpStatus.SC_OK);

            //Update the newly created data connector
            updateDataSourceDetails(spaceKey,uid,authToken,dbUserNameMSsql,null,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,datasourceid,dbTypeMSsql,null,HttpStatus.SC_OK);

            //Reconnect the same data connector
            reconnect(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Finally delete that same data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //getDataSourceInfoByType which fetches the list of data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeMSsql)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");

            List<HashMap<String, Object>> dataSourcesListget = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListget) {
                if (iddb.containsKey("dataSourceID") &&   iddb.get("dataSourceID").toString().equals(datasourceid)) {
                    datasourceidafterdel = iddb.get("dataSourceID").toString();
                }
            }

            //Validating that data connector is deleted
            Assert.assertNull(datasourceidafterdel);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataSourceFlowMSSQLPositive")
    public  void shareUserDataSourceFlowMSSQLPositive() {
        try {
            String datasourceidafterdel=null;

            checkDataSource(spaceKey,uid,authToken,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,"null",HttpStatus.SC_OK);

            //getdatasourceinforbytype which fetches the data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeMSsql)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationMSsql")) {
                    namebytype = iddb.get("dataSourceName").toString();
                }
            }

            log.info("datasourceidBeforeSharing===" + datasourceid);
            log.info("namebytypeBeforeSharing==" + namebytype);

            Assert.assertEquals(dataSourcesgetdatasrcbytyp.get("success").toString(),"true");

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,newgroupidtest,authToken,spaceKey,HttpStatus.SC_OK);

            //Sharedatasource to share the data connector to user(AutmateGrouAugust)
            shareUserDataSource(spaceKey,uid,authToken,datasourceid, newuseridfunuser,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with AutmateGrouAugust user to check whether shared connector is present in AutmateGrouAugust or not
            Response responsegetdatasrcbytypnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeMSsql)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew = from(responsegetdatasrcbytypnew.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypnew = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypnew.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypnew) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").equals("restdbautomationMSsql")) {
                    datasourceidnewusr = iddb.get("dataSourceID").toString();
                    namebytypenewusr=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidAfterSharing=="+datasourceidnewusr);
            log.info("namebytypeAfterSharing=="+namebytypenewusr);

            Assert.assertEquals(dataSourcesgetdatasrcbytypnew.get("success").toString(),"true");

            Assert.assertEquals(datasourceidnewusr.toString(),datasourceid.toString());

            //Delete newly created data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //After delete again fetching the list of data connector for AutmateGrouAugust grp for Permission validation
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeMSsql)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSources = from(response.asString()).get("");

            List<HashMap<String, Object>> dataSourcesListget = (ArrayList<HashMap<String, Object>>) dataSources.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListget) {
                if (iddb.containsKey("dataSourceID") &&   iddb.get("dataSourceID").toString().equals(datasourceid)) {
                    datasourceidafterdel = iddb.get("dataSourceID").toString();
                }
            }

            //Validating that data connector is deleted
            Assert.assertNull(datasourceidafterdel);

            String jsondata="{\"tables\":[],\"success\":true,\"databaseUtils\":[],\"dataSourcesList\":[]}";

            //Conversion of Hashmap to Permission form
            JSONObject expectedjson = new JSONObject();
            expectedjson.putAll(dataSources);
            log.info("expectedjson=====================" + expectedjson);

            //Json validation
            Assert.assertEquals(expectedjson.toString(),jsondata);

            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataSourceToExcludeMSSQLPositive")
    public  void shareGroupDataSourceToExcludeMSSQLPositive() {
        try {

            checkDataSource(spaceKey,uid,authToken,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,"null",HttpStatus.SC_OK);

            //getdatasourceinforbytype which fetches the data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeMSsql)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationMSsql")) {
                    // datasourceid = iddb.get("dataSourceID").toString();
                    namebytype=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidBeforeSharingGrp==="+datasourceid);
            log.info("namebytypeBeforeSharingGrp==="+namebytype);

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            Thread.sleep(1000);
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(), newuseridfunuser,HttpStatus.SC_OK);

            getUsersFromGroups(newgroupid,HttpStatus.SC_OK);

            //Sharegroupdatasource
            shareGroupDataSource(spaceKey,uid,authToken,datasourceid,newgroupid,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with autmategrp user to check whether shared connector is present in autmategrp or not
            Response responsegetdatasrcbytypnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeMSsql)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew = from(responsegetdatasrcbytypnew.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypnew = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypnew.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypnew) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationMSsql")) {
                    datasourceidnew = iddb.get("dataSourceID").toString();
                    namebytypenew=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidAfterSharingGrp==="+datasourceidnew);
            log.info("namebytypeAfterSharingGrp==="+namebytypenew);

            Assert.assertEquals(dataSourcesgetdatasrcbytypnew.get("success").toString(),"true");
            //  Assert.assertEquals(datasourceidnew.toString(),datasourceid.toString());

            //Exclude user from group
            excludeShareDataSource(spaceKey,uid,authToken,datasourceid,newgroupid, newuseridfunuser,datasourceid,HttpStatus.SC_OK);

            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Again fetching the list of data connectors for autmategrp user for Permission validation
            Response responsegetdatasrcbytypnew1 =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeMSsql)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew1 = from(responsegetdatasrcbytypnew1.asString()).get("");

            Assert.assertNull(dataSourcesgetdatasrcbytypnew1.get("dataSourceID"));

            String actualjson="{\"tables\":[],\"success\":true,\"databaseUtils\":[],\"dataSourcesList\":[]}";

            //Storing the actual Permission from shareConnector.Permission in outputjson
            log.info("actualjsonAfterexclude==========" + actualjson);

            //Conversion of Hashmap to Permission form
            JSONObject expectedjson = new JSONObject();
            expectedjson.putAll(dataSourcesgetdatasrcbytypnew1);
            log.info("excludejsonAfterexclude===========" + expectedjson);

            //Json validation
            Assert.assertEquals(expectedjson.toString(),actualjson.toString());

            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "queryServiceFlowMSSQLPositive")
    public  void queryServiceFlowMSSQLPositive(){
        try{

            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,HttpStatus.SC_OK);

            //create data source
            createDataConnector(spaceKey,uid,authToken,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,"null",HttpStatus.SC_OK);

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryMSsql1+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbTypeMSsql+"\",\"type\":\""+dbTypeMSsql+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            Thread.sleep(2000);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,querynameMSsql,dbNameMSsql, dsQueryMSsql1, datasourceid,HttpStatus.SC_OK);

            //Fetching the list of query service in a data connector
            getAllDataSet(spaceKey,uid,authToken,"0",HttpStatus.SC_OK);

            downloadDataSet("./src/main/resources/mssqlDownload1.txt",authToken,nividhQueryName);

            //Fetches the detail of newly created query service for update
            viewEditQueryService(spaceKey,uid,authToken,seriveiddataset,HttpStatus.SC_OK);

            Assert.assertEquals(viewquryid.toString(),seriveiddataset);

            //Edit1
            //Test query service before creation
            String dataedit=null;
            dataedit="{\"query\":\""+dsQueryMSsql2+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbNameMSsql+"\",\"type\":\""+dbTypeMSsql+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,dataedit,HttpStatus.SC_OK);

            //Update the newly created query service
            updateQueryService(updatequerynameMssql,spaceKey,uid,authToken,dbNameMSsql,dsQueryMSsql2,datasourceid,seriveiddataset,HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/mssqlDownload2.txt",authToken,nividhQueryName);

            //Edit2
            //Test query service before creation
            String dataedit1=null;
            dataedit1="{\"query\":\""+dsQueryMSsql3+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbNameMSsql+"\",\"type\":\""+dbTypeMSsql+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,dataedit1,HttpStatus.SC_OK);

            //Update the newly created query service
            updateQueryService(updatequerynameMssql,spaceKey,uid,authToken,dbNameMSsql,dsQueryMSsql3,datasourceid,seriveiddataset,HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/mssqlDownload3.txt",authToken,nividhQueryName);

            //Edit3
            //Test query service before creation
            String dataedit2=null;
            dataedit2="{\"query\":\""+dsQueryMSsql4+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbNameMSsql+"\",\"type\":\""+dbTypeMSsql+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,dataedit2,HttpStatus.SC_OK);

            //Update the newly created query service
            updateQueryService(updatequerynameMssql,spaceKey,uid,authToken,dbNameMSsql,dsQueryMSsql4,datasourceid,seriveiddataset.toString(),HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/mssqlDownload4.txt",authToken,nividhQueryName);

            //Edit4
            //Test query service before creation
            String dataedit3=null;
            dataedit3="{\"query\":\""+dsQueryMSsql5+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbNameMSsql+"\",\"type\":\""+dbTypeMSsql+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,dataedit3,HttpStatus.SC_OK);

            //Update the newly created query service
            updateQueryService(updatequerynameMssql,spaceKey,uid,authToken,dbNameMSsql,dsQueryMSsql5,datasourceid,seriveiddataset.toString(),HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/mssqlDownload5.txt",authToken,nividhQueryName);

            //Edit5
            //Test query service before creation
            String dataedit4=null;
            dataedit4="{\"query\":\""+dsQueryMSsql6+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbNameMSsql+"\",\"type\":\""+dbTypeMSsql+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,dataedit4,HttpStatus.SC_OK);

            //Update the newly created query service
            updateQueryService(updatequerynameMssql,spaceKey,uid,authToken,dbNameMSsql,dsQueryMSsql6,datasourceid,seriveiddataset.toString(),HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/mssqlDownload6.txt",authToken,nividhQueryName);

            //Edit6
            //Test query service before creation
            String dataedit5=null;
            dataedit5="{\"query\":\""+dsQueryMSsql7+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbNameMSsql+"\",\"type\":\""+dbTypeMSsql+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,dataedit5,HttpStatus.SC_OK);

            log.info("id"+seriveiddataset.toString());

            //Update the newly created query service
            updateQueryService(updatequerynameMssql,spaceKey,uid,authToken,dbNameMSsql,dsQueryMSsql7,datasourceid,seriveiddataset.toString(),HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/mssqlDownload7.txt",authToken,nividhQueryName);

           /* //Using number of Different Queries using all functions,operators,dates etc
            JSONObject actualjson = Utils.getJson("./src/main/resources/oracleQuery.Permission");
            JSONArray userArray = (JSONArray) actualjson.get("queries");
            for (Object number : userArray) {
                JSONObject jsonNumber = (JSONObject) number;
                String query = (String) jsonNumber.get("query");

                updateQueryService(updatequerynameMysql,spaceKey,uid,authToken,dbName,query,datasourceid,seriveiddataset.toString(),HttpStatus.SC_OK);
            }
*/

            //Publish the Dataset
            publishDataSet(spaceKey,uid,authToken,seriveiddataset,HttpStatus.SC_OK);

            //Call this function to check published data set is avaialble in dashboard designer
            listQueryServices(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Validate that published Data set is available for Dashboard creation.
            Assert.assertEquals(quryserviceidMssql.toString(),seriveiddataset);


        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataServiceFlowMSSQLPositive")
    public  void shareUserDataServiceFlowMSSQLPositive() {
        try {
            String namebytypeshare=null;

            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,HttpStatus.SC_OK);

            //create data source
            createDataConnector(spaceKey,uid,authToken,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeMSsql)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationMSsql")) {
                    namebytypeshare=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidshare==="+datasourceid);
            log.info("namebytypeshare===="+namebytypeshare);

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryMSsql1+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbTypeMSsql+"\",\"type\":\""+dbTypeMSsql+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,dbNameMSsql, dsQueryMSsql1, datasourceid,HttpStatus.SC_OK);

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,newgroupidtest,authToken,spaceKey,HttpStatus.SC_OK);

            //Sharedatasource to share the queryservice to user(AutmateGrouAugust)
            shareUserDataService(spaceKey,uid,authToken,seriveiddataset, newuseridfunuser,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with rest user to check whether shared queryservice is present in rest or not
            Response responseaut =
                    given()                       //Header
                            .header("spacekey", spaceKey)
                            .header("userID",uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            // HashMap<String, Object> queryServicesaut = from(responseaut.asString()).get("");
            List<HashMap<String, Object>> queryServicesaut = from(responseaut.asString()).get("");

            //List<HashMap<String, Object>> queryServiceslistaut = (ArrayList<HashMap<String, Object>>) queryServicesaut.get("queryServicesList");

            for (HashMap<String, Object> iddbnew : queryServicesaut) {
                if (iddbnew.containsKey("serviceId") && iddbnew.get("serviceId").toString().equals(seriveiddataset)) {
                    idnew = iddbnew.get("serviceId").toString();
                }
            }
            log.info("idnew=="+idnew);
            Assert.assertEquals(idnew.toString(),seriveiddataset);

            //delete newly created query service
            deleteQueryService(spaceKey,uid,authToken,seriveiddataset,HttpStatus.SC_OK);

            //delete newly created data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            Response responseusr =
                    given()                       //Header
                            .header("spacekey", spaceKey)
                            .header("userID",uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            // HashMap<String, Object> queryServicesaut = from(responseaut.asString()).get("");
            List<HashMap<String, Object>> queryServicesusr = from(responseusr.asString()).get("");

            //Json validation
            Assert.assertEquals(queryServicesusr.toString(),"[]");

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataServiceToExcludeMSSQLPositive")
    public  void shareGroupDataServiceToExcludeMSSQLPositive() {
        try{
            String namebytypeshare=null;

            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,HttpStatus.SC_OK);

            //create data source
            createDataConnector(spaceKey,uid,authToken,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeMSsql)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationMysql")) {
                    namebytypeshare=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidshare==="+datasourceid);
            log.info("namebytypeshare===="+namebytypeshare);

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryMSsql1+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbTypeMSsql+"\",\"type\":\""+dbTypeMSsql+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,dbNameMSsql, dsQueryMSsql1, datasourceid,HttpStatus.SC_OK);

            //Fetching the list of query service
            getAllDataSet(spaceKey,uid,authToken,"0",HttpStatus.SC_OK);

            Thread.sleep(1000);
            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            Thread.sleep(1000);
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(), newuseridfunuser,HttpStatus.SC_OK);

            //SharegroupDataService
            shareGroupDataService(spaceKey,uid,authToken,seriveiddataset.toString(),newgroupid,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            // HashMap<String, Object> dataSources = from(response.asString()).get("dataSources");
            List<HashMap<String, Object>> getdata = from(response.asString()).get("");

            for (HashMap<String, Object> iddata : getdata) {
                if (iddata.containsKey("serviceId") &&   iddata.get("serviceId").toString().equals(seriveiddataset)) {
                    idnew = iddata.get("serviceId").toString();
                }
            }

            Assert.assertEquals(idnew.toString(),seriveiddataset.toString());

            //Exclude user from group
            excludeShareDataService(spaceKey,uid,authToken,seriveiddataset.toString(),newgroupid, newuseridfunuser,HttpStatus.SC_OK);

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with autmategrp user to check whether shared queryservice is present in autmategrp or not
            Response responseautnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesautnew = from(responseautnew.asString()).get("");

            Assert.assertNotEquals(queryServicesautnew,seriveiddataset.toString());

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //fetches the query list of autmategrp usr for Permission validation
            Response responseusr =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesusr = from(responseautnew.asString()).get("");

            //Json validation
            Assert.assertEquals(queryServicesusr.toString(),"[]");

            deleteQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);

            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

//--------------------------------------Oracle--------------------------------------//

    @Test(description = "dataConnFlowOraclePositive")
    public  void dataConnFlowOraclePositive(){
        try{
            String datasourceidafterdel=null;

            checkDataSource(spaceKey,uid,authToken,dataSourceNameOracle,dbUserNameOracle, dbPasswordOracle, dbPortNumberOracle, dbHostNameOracle, dbServiceNameOracle, dbTypeOracle,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameOracle,dbUserNameOracle, dbPasswordOracle, dbPortNumberOracle, dbHostNameOracle, dbServiceNameOracle, dbTypeOracle,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytypsrc =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeOracle)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypsrc = from(responsegetdatasrcbytypsrc.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypsrc = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypsrc.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypsrc) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationOracle")) {
                    namebytype=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceid==="+datasourceid);
            log.info("namebytype===="+namebytype);

            Assert.assertEquals(dataSourcesgetdatasrcbytypsrc.get("success").toString(),"true");

            //Validating that new query is created with name restdbautomation
            Assert.assertEquals(namebytype,"restdbautomationOracle");

            //Fetches the detail of newly created data connector for update
            viewDataSourceDetails(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Validation of id
            Assert.assertEquals(idviewdatasrc.toString(),datasourceid.toString());

            //Before updating check the datconnector
            checkDataSourceEdit(spaceKey,uid,authToken,dbUserNameOracle,null,dbPortNumberOracle,dbHostNameOracle,dbServiceNameOracle,datasourceid,dbTypeOracle,null,HttpStatus.SC_OK);

            //Update the newly created data connector
            updateDataSourceDetails(spaceKey,uid,authToken,dbUserNameOracle,null,dbPortNumberOracle,dbHostNameOracle,dbServiceNameOracle,datasourceid,dbTypeOracle,null,HttpStatus.SC_OK);

            //Reconnect the same data connector
            reconnect(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Finally delete that same data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //getDataSourceInfoByType which fetches the list of data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeOracle)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListget = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListget) {
                if (iddb.containsKey("dataSourceID") &&   iddb.get("dataSourceID").toString().equals(datasourceid)) {
                    datasourceidafterdel = iddb.get("dataSourceID").toString();
                }
            }

            //Validating that data connector is deleted
            Assert.assertNull(datasourceidafterdel);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataSourceFlowOraclePositive")
    public  void shareUserDataSourceFlowOraclePositive() {
        try {
            String datasourceidafterdel=null;

            Thread.sleep(1000);

            checkDataSource(spaceKey,uid,authToken,dataSourceNameOracle,dbUserNameOracle, dbPasswordOracle, dbPortNumberOracle, dbHostNameOracle, dbServiceNameOracle, dbTypeOracle,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameOracle,dbUserNameOracle, dbPasswordOracle, dbPortNumberOracle, dbHostNameOracle, dbServiceNameOracle, dbTypeOracle,"null",HttpStatus.SC_OK);

            //getdatasourceinforbytype which fetches the data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeOracle)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationOracle")) {
                    namebytype = iddb.get("dataSourceName").toString();
                }
            }

            log.info("datasourceidBeforeSharing===" + datasourceid);
            log.info("namebytypeBeforeSharing==" + namebytype);

            Assert.assertEquals(dataSourcesgetdatasrcbytyp.get("success").toString(),"true");

            Thread.sleep(2000);
            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,newgroupidtest,authToken,spaceKey,HttpStatus.SC_OK);

            //Sharedatasource to share the data connector to user(AutmateGrouAugust)
            shareUserDataSource(spaceKey,uid,authToken,datasourceid, newuseridfunuser,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with AutmateGrouAugust user to check whether shared connector is present in AutmateGrouAugust or not
            Response responsegetdatasrcbytypnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeOracle)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew = from(responsegetdatasrcbytypnew.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypnew = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypnew.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypnew) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").equals("restdbautomationOracle")) {
                    datasourceidnewusr = iddb.get("dataSourceID").toString();
                    namebytypenewusr=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidAfterSharing=="+datasourceidnewusr);
            log.info("namebytypeAfterSharing=="+namebytypenewusr);

            Assert.assertEquals(dataSourcesgetdatasrcbytypnew.get("success").toString(),"true");

            Assert.assertEquals(datasourceidnewusr.toString(),datasourceid.toString());

            //Delete newly created data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //After delete again fetching the list of data connector for AutmateGrouAugust grp for Permission validation
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeOracle)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSources = from(response.asString()).get("");

            List<HashMap<String, Object>> dataSourcesListget = (ArrayList<HashMap<String, Object>>) dataSources.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListget) {
                if (iddb.containsKey("dataSourceID") &&   iddb.get("dataSourceID").toString().equals(datasourceid)) {
                    datasourceidafterdel = iddb.get("dataSourceID").toString();
                }
            }

            //Validating that data connector is deleted
            Assert.assertNull(datasourceidafterdel);

            String jsondata="{\"tables\":[],\"success\":true,\"databaseUtils\":[],\"dataSourcesList\":[]}";

            //Conversion of Hashmap to Permission form
            JSONObject expectedjson = new JSONObject();
            expectedjson.putAll(dataSources);
            log.info("expectedjson=====================" + expectedjson);

            //Json validation
            Assert.assertEquals(expectedjson.toString(),jsondata);

            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataSourceToExcludeOraclePositive")
    public  void shareGroupDataSourceToExcludeOraclePositive() {
        try {

            Thread.sleep(1000);

            checkDataSource(spaceKey,uid,authToken,dataSourceNameOracle,dbUserNameOracle, dbPasswordOracle, dbPortNumberOracle, dbHostNameOracle, dbServiceNameOracle, dbTypeOracle,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameOracle,dbUserNameOracle, dbPasswordOracle, dbPortNumberOracle, dbHostNameOracle, dbServiceNameOracle, dbTypeOracle,"null",HttpStatus.SC_OK);

            //getdatasourceinforbytype which fetches the data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeOracle)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationOracle")) {
                    namebytype=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidBeforeSharingGrp==="+datasourceid);
            log.info("namebytypeBeforeSharingGrp==="+namebytype);

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(), newuseridfunuser,HttpStatus.SC_OK);

            getUsersFromGroups(newgroupid,HttpStatus.SC_OK);

            //Sharegroupdatasource
            shareGroupDataSource(spaceKey,uid,authToken,datasourceid,newgroupid,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with autmategrp user to check whether shared connector is present in autmategrp or not
            Response responsegetdatasrcbytypnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeOracle)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew = from(responsegetdatasrcbytypnew.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypnew = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypnew.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypnew) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationOracle")) {
                    datasourceidnew = iddb.get("dataSourceID").toString();
                    namebytypenew=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidAfterSharingGrp==="+datasourceidnew);
            log.info("namebytypeAfterSharingGrp==="+namebytypenew);

            Assert.assertEquals(dataSourcesgetdatasrcbytypnew.get("success").toString(),"true");
            Assert.assertEquals(datasourceidnew.toString(),datasourceid.toString());

            //Exclude user from group
            excludeShareDataSource(spaceKey,uid,authToken,datasourceid,newgroupid, newuseridfunuser,datasourceid,HttpStatus.SC_OK);

            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Again fetching the list of data connectors for autmategrp user for Permission validation
            Response responsegetdatasrcbytypnew1 =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeOracle)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew1 = from(responsegetdatasrcbytypnew1.asString()).get("");

            Assert.assertNull(dataSourcesgetdatasrcbytypnew1.get("dataSourceID"));

            String actualjson="{\"tables\":[],\"success\":true,\"databaseUtils\":[],\"dataSourcesList\":[]}";

            //Storing the actual Permission from shareConnector.Permission in outputjson
            log.info("actualjsonAfterexclude==========" + actualjson);

            //Conversion of Hashmap to Permission form
            JSONObject expectedjson = new JSONObject();
            expectedjson.putAll(dataSourcesgetdatasrcbytypnew1);
            log.info("excludejsonAfterexclude===========" + expectedjson);

            //Json validation
            Assert.assertEquals(expectedjson.toString(),actualjson.toString());

            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "queryServiceFlowOraclePositive")
    public  void queryServiceFlowOraclePositive(){
        try {

            Thread.sleep(1000);
            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameOracle,dbUserNameOracle, dbPasswordOracle, dbPortNumberOracle, dbHostNameOracle, dbServiceNameOracle, dbTypeOracle,HttpStatus.SC_OK);

            //create data source
            createDataConnector(spaceKey,uid,authToken,dataSourceNameOracle,dbUserNameOracle, dbPasswordOracle, dbPortNumberOracle, dbHostNameOracle, dbServiceNameOracle, dbTypeOracle,"null",HttpStatus.SC_OK);

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryOracle+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbServiceNameOracle+"\",\"type\":\""+dbTypeOracle+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            Thread.sleep(2000);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,dbServiceNameOracle, dsQueryOracle, datasourceid,HttpStatus.SC_OK);

            //Fetching the list of query service in a data connector
            getAllDataSet(spaceKey,uid,authToken,"0",HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/oracleDownload.txt",authToken,nividhQueryName);

            //Fetches the detail of newly created query service for update
            viewEditQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);

            Assert.assertEquals(viewquryid.toString(),seriveiddataset.toString());

            //Test query service before creation
            String dataedit=null;
            dataedit="{\"query\":\""+Utils.getproperty("dsQueryOracle")+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbTypeOracle+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,dataedit,HttpStatus.SC_OK);

            //Update the newly created query service
            updateQueryService(updatequerynameOracle,spaceKey,uid,authToken,dbServiceNameOracle,dsQueryOracle,datasourceid,seriveiddataset.toString(),HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/oracleDownload.txt",authToken,nividhQueryName);

            //Using number of Different Queries using all functions,operators,dates etc
            JSONObject actualjsonoracle = Utils.getJson("./src/main/resources/oracleQuery.Permission");
            JSONArray userArrayoracle = (JSONArray) actualjsonoracle.get("queries");
            for (Object numberoracle : userArrayoracle) {
                JSONObject jsonNumberoracle = (JSONObject) numberoracle;
                String queryoracle = (String) jsonNumberoracle.get("query");

                //Test query service before creation
                String dataupdateoracle=null;
                dataupdateoracle="{\"query\":\""+queryoracle+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbTypeOracle+"\",\"filter\":\"{}\"}";

                runDataService(spaceKey,uid,authToken,dataupdateoracle,HttpStatus.SC_OK);

                updateQueryService(updatequerynameOracle,spaceKey,uid,authToken,dbServiceNameOracle,queryoracle,datasourceid,seriveiddataset.toString(),HttpStatus.SC_OK);
            }

            Assert.assertNotNull(actualjsonoracle);

            //Publish the Dataset
            publishDataSet(spaceKey,uid,authToken,seriveiddataset,HttpStatus.SC_OK);

            //Call this function to check published data set is avaialble in dashboard designer
            listQueryServices(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Validate that published Data set is available for Dashboard creation.
            Assert.assertEquals(restqueryupdateOracle.toString(),seriveiddataset.toString());

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataServiceFlowOraclePositive")
    public  void shareUserDataServiceFlowOraclePositive() {
        try {
            String namebytypeshare=null;

            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameOracle,dbUserNameOracle, dbPasswordOracle, dbPortNumberOracle, dbHostNameOracle, dbServiceNameOracle, dbTypeOracle,HttpStatus.SC_OK);

            //create data source
            createDataConnector(spaceKey,uid,authToken,dataSourceNameOracle,dbUserNameOracle, dbPasswordOracle, dbPortNumberOracle, dbHostNameOracle, dbServiceNameOracle, dbTypeOracle,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeOracle)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationOracle")) {
                    namebytypeshare=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidshare==="+datasourceid);
            log.info("namebytypeshare===="+namebytypeshare);

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryOracle+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbServiceNameOracle+"\",\"type\":\""+dbTypeOracle+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,dbServiceNameOracle, dsQueryOracle, datasourceid,HttpStatus.SC_OK);

            Thread.sleep(1000);
            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,newgroupidtest,authToken,spaceKey,HttpStatus.SC_OK);

            //Sharedatasource to share the queryservice to user(AutmateGrouAugust)
            shareUserDataService(spaceKey,uid,authToken,seriveiddataset, newuseridfunuser,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with rest user to check whether shared queryservice is present in rest or not
            Response responseaut =
                    given()                       //Header
                            .header("spacekey", spaceKey)
                            .header("userID",uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesaut = from(responseaut.asString()).get("");

            for (HashMap<String, Object> iddbnew : queryServicesaut) {
                if (iddbnew.containsKey("serviceId") && iddbnew.get("serviceId").toString().equals(seriveiddataset)) {
                    idnew = iddbnew.get("serviceId").toString();
                }
            }
            log.info("idnew=="+idnew);
            Assert.assertEquals(idnew.toString(),seriveiddataset);

            //delete newly created query service
            deleteQueryService(spaceKey,uid,authToken,seriveiddataset,HttpStatus.SC_OK);

            //delete newly created data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            Response responseusr =
                    given()                       //Header
                            .header("spacekey", spaceKey)
                            .header("userID",uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesusr = from(responseusr.asString()).get("");

            //Json validation
            Assert.assertEquals(queryServicesusr.toString(),"[]");

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataServiceToExcludeOraclePositive")
    public  void shareGroupDataServiceToExcludeOraclePositive() {
        try{
            String namebytypeshare=null;

            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameOracle,dbUserNameOracle, dbPasswordOracle, dbPortNumberOracle, dbHostNameOracle, dbServiceNameOracle, dbTypeOracle,HttpStatus.SC_OK);

            //create data source
            createDataConnector(spaceKey,uid,authToken,dataSourceNameOracle,dbUserNameOracle, dbPasswordOracle, dbPortNumberOracle, dbHostNameOracle, dbServiceNameOracle, dbTypeOracle,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeOracle)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationOracle")) {
                    namebytypeshare=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidshare==="+datasourceid);
            log.info("namebytypeshare===="+namebytypeshare);

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryOracle+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbServiceNameOracle+"\",\"type\":\""+dbTypeOracle+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,dbServiceNameOracle, dsQueryOracle, datasourceid,HttpStatus.SC_OK);

            Thread.sleep(1000);
            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            Thread.sleep(1000);
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(), newuseridfunuser,HttpStatus.SC_OK);

            //SharegroupDataService
            shareGroupDataService(spaceKey,uid,authToken,seriveiddataset.toString(),newgroupid,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Exclude user from group
            excludeShareDataService(spaceKey,uid,authToken,seriveiddataset.toString(),newgroupid, newuseridfunuser,HttpStatus.SC_OK);

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with autmategrp user to check whether shared queryservice is present in autmategrp or not
            Response responseautnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesautnew = from(responseautnew.asString()).get("");

            Assert.assertNotEquals(queryServicesautnew,seriveiddataset.toString());

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //fetches the query list of autmategrp usr for Permission validation
            Response responseusr =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesusr = from(responseautnew.asString()).get("");

            //Json validation
            Assert.assertEquals(queryServicesusr.toString(),"[]");

            deleteQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);

            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    //-------------------------------------HIVE------------------------------------------------//
    @Test(description = "dataConnFlowHivePositive")
    public  void dataConnFlowHivePositive(){
        try{
            String datasourceidafterdel=null;

            checkDataSource(spaceKey,uid,authToken,dataSourceNameHive,dbUserNameHive, dbPasswordHive, dbPortNumberHive, dbHostNameHive, "null", dbTypeHive,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameHive,dbUserNameHive, dbPasswordHive, dbPortNumberHive, dbHostNameHive, "null", dbTypeHive,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytypsrc =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeHive)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypsrc = from(responsegetdatasrcbytypsrc.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypsrc = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypsrc.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypsrc) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationHive")) {
                    namebytype=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceid==="+datasourceid);
            log.info("namebytype===="+namebytype);

            Assert.assertEquals(dataSourcesgetdatasrcbytypsrc.get("success").toString(),"true");

            //Validating that new query is created with name restdbautomation
            Assert.assertEquals(namebytype,"restdbautomationHive");

            //Fetches the detail of newly created data connector for update
            viewDataSourceDetails(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Validation of id
            Assert.assertEquals(idviewdatasrc.toString(),datasourceid.toString());

            //Before updating check the datconnector
            checkDataSourceEdit(spaceKey,uid,authToken,dbUserNameHive,null,dbPortNumberHive,dbHostNameHive,"null",datasourceid,dbTypeHive,null,HttpStatus.SC_OK);

            //Update the newly created data connector
            updateDataSourceDetails(spaceKey,uid,authToken,dbUserNameHive,null,dbPortNumberHive,dbHostNameHive,"null",datasourceid,dbTypeHive,null,HttpStatus.SC_OK);

            //Reconnect the same data connector
            reconnect(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Finally delete that same data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //getDataSourceInfoByType which fetches the list of data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeHive)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListget = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListget) {
                if (iddb.containsKey("dataSourceID") &&   iddb.get("dataSourceID").toString().equals(datasourceid)) {
                    datasourceidafterdel = iddb.get("dataSourceID").toString();
                }
            }

            //Validating that data connector is deleted
            Assert.assertNull(datasourceidafterdel);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataSourceFlowHivePositive")
    public  void shareUserDataSourceFlowHivePositive() {
        try {
            String datasourceidafterdel=null;

            checkDataSource(spaceKey,uid,authToken,dataSourceNameHive,dbUserNameHive, dbPasswordHive, dbPortNumberHive, dbHostNameHive, "null", dbTypeHive,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameHive,dbUserNameHive, dbPasswordHive, dbPortNumberHive, dbHostNameHive, "null", dbTypeHive,"null",HttpStatus.SC_OK);

            //getdatasourceinforbytype which fetches the data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeHive)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationHive")) {
                    namebytype = iddb.get("dataSourceName").toString();
                }
            }

            log.info("datasourceidBeforeSharing===" + datasourceid);
            log.info("namebytypeBeforeSharing==" + namebytype);

            Assert.assertEquals(dataSourcesgetdatasrcbytyp.get("success").toString(),"true");

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,newgroupidtest,authToken,spaceKey,HttpStatus.SC_OK);

            //Sharedatasource to share the data connector to user(AutmateGrouAugust)
            shareUserDataSource(spaceKey,uid,authToken,datasourceid, newuseridfunuser,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with AutmateGrouAugust user to check whether shared connector is present in AutmateGrouAugust or not
            Response responsegetdatasrcbytypnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeHive)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew = from(responsegetdatasrcbytypnew.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypnew = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypnew.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypnew) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").equals("restdbautomationHive")) {
                    datasourceidnewusr = iddb.get("dataSourceID").toString();
                    namebytypenewusr=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidAfterSharing=="+datasourceidnewusr);
            log.info("namebytypeAfterSharing=="+namebytypenewusr);

            Assert.assertEquals(dataSourcesgetdatasrcbytypnew.get("success").toString(),"true");

            Assert.assertEquals(datasourceidnewusr.toString(),datasourceid.toString());

            //Delete newly created data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //After delete again fetching the list of data connector for AutmateGrouAugust grp for Permission validation
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeHive)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSources = from(response.asString()).get("");

            List<HashMap<String, Object>> dataSourcesListget = (ArrayList<HashMap<String, Object>>) dataSources.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListget) {
                if (iddb.containsKey("dataSourceID") &&   iddb.get("dataSourceID").toString().equals(datasourceid)) {
                    datasourceidafterdel = iddb.get("dataSourceID").toString();
                }
            }

            //Validating that data connector is deleted
            Assert.assertNull(datasourceidafterdel);

            String jsondata="{\"tables\":[],\"listFormDataUtil\":null,\"fetchSize\":null,\"success\":true,\"databaseUtils\":[],\"errorMessage\":null,\"errorCode\":null,\"stackTrace\":null,\"message\":null,\"dataSource\":null,\"dataSourcesList\":[]}";

            //Conversion of Hashmap to Permission form
            JSONObject expectedjson = new JSONObject();
            expectedjson.putAll(dataSources);
            log.info("expectedjson=====================" + expectedjson);

            //Json validation
            Assert.assertEquals(expectedjson.toString(),jsondata);

            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataSourceToExcludeHivePositive")
    public  void shareGroupDataSourceToExcludeHivePositive() {
        try {

            checkDataSource(spaceKey,uid,authToken,dataSourceNameHive,dbUserNameHive, dbPasswordHive, dbPortNumberHive, dbHostNameHive, "null", dbTypeHive,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameHive,dbUserNameHive, dbPasswordHive, dbPortNumberHive, dbHostNameHive, "null", dbTypeHive,"null",HttpStatus.SC_OK);

            //getdatasourceinforbytype which fetches the data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeHive)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationHive")) {
                    namebytype=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidBeforeSharingGrp==="+datasourceid);
            log.info("namebytypeBeforeSharingGrp==="+namebytype);

            Thread.sleep(2000);
            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(), newuseridfunuser,HttpStatus.SC_OK);

            getUsersFromGroups(newgroupid,HttpStatus.SC_OK);

            //Sharegroupdatasource
            shareGroupDataSource(spaceKey,uid,authToken,datasourceid,newgroupid,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with autmategrp user to check whether shared connector is present in autmategrp or not
            Response responsegetdatasrcbytypnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeHive)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew = from(responsegetdatasrcbytypnew.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypnew = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypnew.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypnew) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationHive")) {
                    datasourceidnew = iddb.get("dataSourceID").toString();
                    namebytypenew=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidAfterSharingGrp==="+datasourceidnew);
            log.info("namebytypeAfterSharingGrp==="+namebytypenew);

            Assert.assertEquals(dataSourcesgetdatasrcbytypnew.get("success").toString(),"true");
            Assert.assertEquals(datasourceidnew.toString(),datasourceid.toString());

            //Exclude user from group
            excludeShareDataSource(spaceKey,uid,authToken,datasourceid,newgroupid, newuseridfunuser,datasourceid,HttpStatus.SC_OK);

            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Again fetching the list of data connectors for autmategrp user for Permission validation
            Response responsegetdatasrcbytypnew1 =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeHive)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew1 = from(responsegetdatasrcbytypnew1.asString()).get("");

            Assert.assertNull(dataSourcesgetdatasrcbytypnew1.get("dataSourceID"));

            String actualjson="{\"tables\":[],\"listFormDataUtil\":null,\"fetchSize\":null,\"success\":true,\"databaseUtils\":[],\"errorMessage\":null,\"errorCode\":null,\"stackTrace\":null,\"message\":null,\"dataSource\":null,\"dataSourcesList\":[]}";

            //Storing the actual Permission from shareConnector.Permission in outputjson
            log.info("actualjsonAfterexclude==========" + actualjson);

            //Conversion of Hashmap to Permission form
            JSONObject expectedjson = new JSONObject();
            expectedjson.putAll(dataSourcesgetdatasrcbytypnew1);
            log.info("excludejsonAfterexclude===========" + expectedjson);

            //Json validation
            Assert.assertEquals(expectedjson.toString(),actualjson.toString());

            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "queryServiceFlowHivePositive")
    public  void queryServiceFlowHivePositive(){
        try{
            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameHive,dbUserNameHive, dbPasswordHive, dbPortNumberHive, dbHostNameHive, "null", dbTypeHive,HttpStatus.SC_OK);

            //create data source
            createDataConnector(spaceKey,uid,authToken,dataSourceNameHive,dbUserNameHive, dbPasswordHive, dbPortNumberHive, dbHostNameHive, "null", dbTypeHive,"null",HttpStatus.SC_OK);

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryHive+"\",\"id\":\""+datasourceid+"\",\"dbname\":\"\",\"type\":\""+dbTypeHive+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            Thread.sleep(2000);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,"null", dsQueryHive, datasourceid,HttpStatus.SC_OK);

            //Fetching the list of query service in a data connector
            getAllDataSet(spaceKey,uid,authToken,"0",HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/hiveDownload.txt",authToken,nividhQueryName);

            //Validating that query is created
            // Assert.assertEquals(nametype,"restqueryautomationHive");

            //Fetches the detail of newly created query service for update
            viewEditQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);

            Assert.assertEquals(viewquryid.toString(),seriveiddataset.toString());

            //Test query service before creation
            String dataedit=null;
            dataedit="{\"query\":\""+dsQueryHive+"\",\"id\":\""+datasourceid+"\",\"dbname\":\"\",\"type\":\""+dbTypeHive+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,dataedit,HttpStatus.SC_OK);

            //Update the newly created query service
            updateQueryService(updatequerynameHive,spaceKey,uid,authToken,"null",dsQueryHive,datasourceid,seriveiddataset.toString(),HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/hiveDownload.txt",authToken,nividhQueryName);

            //Publish the Dataset
            publishDataSet(spaceKey,uid,authToken,seriveiddataset,HttpStatus.SC_OK);

            //Call this function to check published data set is avaialble in dashboard designer
            listQueryServices(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Validate that published Data set is available for Dashboard creation.
            Assert.assertEquals(restqueryupdateHive.toString(),seriveiddataset.toString());

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataServiceFlowHivePositive")
    public  void shareUserDataServiceFlowHivePositive() {
        try {
            String namebytypeshare=null;

            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameHive,dbUserNameHive, dbPasswordHive, dbPortNumberHive, dbHostNameHive, "null", dbTypeHive,HttpStatus.SC_OK);

            //create data source
            createDataConnector(spaceKey,uid,authToken,dataSourceNameHive,dbUserNameHive, dbPasswordHive, dbPortNumberHive, dbHostNameHive, "null", dbTypeHive,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeHive)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationHive")) {
                    namebytypeshare=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidshare==="+datasourceid);
            log.info("namebytypeshare===="+namebytypeshare);

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryHive+"\",\"id\":\""+datasourceid+"\",\"dbname\":\"\",\"type\":\""+dbTypeHive+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,"null", dsQueryHive, datasourceid,HttpStatus.SC_OK);

            Thread.sleep(2000);
            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,newgroupidtest,authToken,spaceKey,HttpStatus.SC_OK);

            //Sharedatasource to share the queryservice to user(AutmateGrouAugust)
            shareUserDataService(spaceKey,uid,authToken,seriveiddataset, newuseridfunuser,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with rest user to check whether shared queryservice is present in rest or not
            Response responseaut =
                    given()                       //Header
                            .header("spacekey", spaceKey)
                            .header("userID",uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesaut = from(responseaut.asString()).get("");

            for (HashMap<String, Object> iddbnew : queryServicesaut) {
                if (iddbnew.containsKey("serviceId") && iddbnew.get("serviceId").toString().equals(seriveiddataset)) {
                    idnew = iddbnew.get("serviceId").toString();
                }
            }
            log.info("idnew=="+idnew);
            Assert.assertEquals(idnew.toString(),seriveiddataset);

            //delete newly created query service
            deleteQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);

            //delete newly created data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            Response responseusr =
                    given()                       //Header
                            .header("spacekey", spaceKey)
                            .header("userID",uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesusr = from(responseusr.asString()).get("");

            //Json validation
            Assert.assertEquals(queryServicesusr.toString(),"[]");

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataServiceToExcludeHivePositive")
    public  void shareGroupDataServiceToExcludeHivePositive() {
        try{
            String namebytypeshare=null;

            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameHive,dbUserNameHive, dbPasswordHive, dbPortNumberHive, dbHostNameHive, "null", dbTypeHive,HttpStatus.SC_OK);

            //create data source
            createDataConnector(spaceKey,uid,authToken,dataSourceNameHive,dbUserNameHive, dbPasswordHive, dbPortNumberHive, dbHostNameHive, "null", dbTypeHive,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeHive)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationHive")) {
                    namebytypeshare=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidshare==="+datasourceid);
            log.info("namebytypeshare===="+namebytypeshare);


            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryHive+"\",\"id\":\""+datasourceid+"\",\"dbname\":\"\",\"type\":\""+dbTypeHive+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,"null", dsQueryHive, datasourceid,HttpStatus.SC_OK);

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(), newuseridfunuser,HttpStatus.SC_OK);

            //SharegroupDataService
            shareGroupDataService(spaceKey,uid,authToken,seriveiddataset.toString(),newgroupid,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> getdata = from(response.asString()).get("");

            for (HashMap<String, Object> iddata : getdata) {
                if (iddata.containsKey("queryName") &&   iddata.get("queryName").toString().equals("restqueryautomationHive")) {
                    idnew = iddata.get("serviceId").toString();
                }
            }

            Assert.assertEquals(idnew.toString(),seriveiddataset.toString());

            //Exclude user from group
            excludeShareDataService(spaceKey,uid,authToken,seriveiddataset.toString(),newgroupid, newuseridfunuser,HttpStatus.SC_OK);

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with autmategrp user to check whether shared queryservice is present in autmategrp or not
            Response responseautnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesautnew = from(responseautnew.asString()).get("");

            Assert.assertNotEquals(queryServicesautnew,seriveiddataset.toString());

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //fetches the query list of autmategrp usr for Permission validation
            Response responseusr =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesusr = from(responseautnew.asString()).get("");

            //Json validation
            Assert.assertEquals(queryServicesusr.toString(),"[]");

            deleteQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);

            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

//-----------------------------------SPARKSQL-------------------------------------------------------//

    @Test(description = "dataConnFlowSparkSqlPositive")
    public  void dataConnFlowSparkSqlPositive(){
        try{
            String datasourceidafterdel=null;

            checkDataSource(spaceKey,uid,authToken,dataSourceNameSparkSql,dbUserNameHive, dbPasswordHive, dbPortNumberSparkSql, dbHostNameHive, "null", dbTypeSparkSql,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameSparkSql,dbUserNameHive, dbPasswordHive, dbPortNumberSparkSql, dbHostNameHive, "null", dbTypeSparkSql,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytypsrc =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeSparkSql)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypsrc = from(responsegetdatasrcbytypsrc.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypsrc = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypsrc.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypsrc) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationSparkSql")) {
                    namebytype=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceid==="+datasourceid);
            log.info("namebytype===="+namebytype);

            Assert.assertEquals(dataSourcesgetdatasrcbytypsrc.get("success").toString(),"true");

            //Validating that new query is created with name restdbautomation
            Assert.assertEquals(namebytype,"restdbautomationSparkSql");

            //Fetches the detail of newly created data connector for update
            viewDataSourceDetails(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Validation of id
            Assert.assertEquals(idviewdatasrc.toString(),datasourceid.toString());

            //Before updating check the datconnector
            checkDataSourceEdit(spaceKey,uid,authToken,dbUserNameHive,null,dbPortNumberSparkSql,dbHostNameHive,"null",datasourceid,dbTypeSparkSql,null,HttpStatus.SC_OK);

            //Update the newly created data connector
            updateDataSourceDetails(spaceKey,uid,authToken,dbUserNameHive,null,dbPortNumberSparkSql,dbHostNameHive,"null",datasourceid,dbTypeSparkSql,null,HttpStatus.SC_OK);

            //Reconnect the same data connector
            reconnect(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Finally delete that same data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //getDataSourceInfoByType which fetches the list of data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeSparkSql)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListget = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListget) {
                if (iddb.containsKey("dataSourceID") &&   iddb.get("dataSourceID").toString().equals(datasourceid)) {
                    datasourceidafterdel = iddb.get("dataSourceID").toString();
                }
            }

            //Validating that data connector is deleted
            Assert.assertNull(datasourceidafterdel);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataSourceFlowSparkSqlPositive")
    public  void shareUserDataSourceFlowSparkSqlPositive() {
        try {
            String datasourceidafterdel=null;

            checkDataSource(spaceKey,uid,authToken,dataSourceNameSparkSql,dbUserNameHive, dbPasswordHive, dbPortNumberSparkSql, dbHostNameHive, "null", dbTypeSparkSql,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameSparkSql,dbUserNameHive, dbPasswordHive, dbPortNumberSparkSql, dbHostNameHive, "null", dbTypeSparkSql,"null",HttpStatus.SC_OK);

            //getdatasourceinforbytype which fetches the data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeSparkSql)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationSparkSql")) {
                    namebytype = iddb.get("dataSourceName").toString();
                }
            }

            log.info("datasourceidBeforeSharing===" + datasourceid);
            log.info("namebytypeBeforeSharing==" + namebytype);

            Assert.assertEquals(dataSourcesgetdatasrcbytyp.get("success").toString(),"true");

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,newgroupidtest,authToken,spaceKey,HttpStatus.SC_OK);

            //Sharedatasource to share the data connector to user(AutmateGrouAugust)
            shareUserDataSource(spaceKey,uid,authToken,datasourceid, newuseridfunuser,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with AutmateGrouAugust user to check whether shared connector is present in AutmateGrouAugust or not
            Response responsegetdatasrcbytypnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeSparkSql)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew = from(responsegetdatasrcbytypnew.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypnew = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypnew.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypnew) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").equals("restdbautomationSparkSql")) {
                    datasourceidnewusr = iddb.get("dataSourceID").toString();
                    namebytypenewusr=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidAfterSharing=="+datasourceidnewusr);
            log.info("namebytypeAfterSharing=="+namebytypenewusr);

            Assert.assertEquals(dataSourcesgetdatasrcbytypnew.get("success").toString(),"true");

            Assert.assertEquals(datasourceidnewusr.toString(),datasourceid.toString());

            //Delete newly created data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //After delete again fetching the list of data connector for AutmateGrouAugust grp for Permission validation
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeSparkSql)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSources = from(response.asString()).get("");

            List<HashMap<String, Object>> dataSourcesListget = (ArrayList<HashMap<String, Object>>) dataSources.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListget) {
                if (iddb.containsKey("dataSourceID") &&   iddb.get("dataSourceID").toString().equals(datasourceid)) {
                    datasourceidafterdel = iddb.get("dataSourceID").toString();
                }
            }

            //Validating that data connector is deleted
            Assert.assertNull(datasourceidafterdel);

            String jsondata="{\"tables\":[],\"success\":true,\"databaseUtils\":[],\"dataSourcesList\":[]}";

            //Conversion of Hashmap to Permission form
            JSONObject expectedjson = new JSONObject();
            expectedjson.putAll(dataSources);
            log.info("expectedjson=====================" + expectedjson);

            //Json validation
            Assert.assertEquals(expectedjson.toString(),jsondata);

            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataSourceToExcludeSparkSqlPositive")
    public  void shareGroupDataSourceToExcludeSparkSqlPositive() {
        try {
            checkDataSource(spaceKey,uid,authToken,dataSourceNameSparkSql,dbUserNameHive, dbPasswordHive, dbPortNumberSparkSql, dbHostNameHive, "null", dbTypeSparkSql,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameSparkSql,dbUserNameHive, dbPasswordHive, dbPortNumberSparkSql, dbHostNameHive, "null", dbTypeSparkSql,"null",HttpStatus.SC_OK);

            //getdatasourceinforbytype which fetches the data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeSparkSql)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationSparkSql")) {
                    namebytype=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidBeforeSharingGrp==="+datasourceid);
            log.info("namebytypeBeforeSharingGrp==="+namebytype);

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(), newuseridfunuser,HttpStatus.SC_OK);

            getUsersFromGroups(newgroupid,HttpStatus.SC_OK);

            //Sharegroupdatasource
            shareGroupDataSource(spaceKey,uid,authToken,datasourceid,newgroupid,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with autmategrp user to check whether shared connector is present in autmategrp or not
            Response responsegetdatasrcbytypnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeSparkSql)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew = from(responsegetdatasrcbytypnew.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypnew = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypnew.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypnew) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationSparkSql")) {
                    datasourceidnew = iddb.get("dataSourceID").toString();
                    namebytypenew=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidAfterSharingGrp==="+datasourceidnew);
            log.info("namebytypeAfterSharingGrp==="+namebytypenew);

            Assert.assertEquals(dataSourcesgetdatasrcbytypnew.get("success").toString(),"true");
            Assert.assertEquals(datasourceidnew.toString(),datasourceid.toString());

            //Exclude user from group
            excludeShareDataSource(spaceKey,uid,authToken,datasourceid,newgroupid, newuseridfunuser,datasourceid,HttpStatus.SC_OK);

            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Again fetching the list of data connectors for autmategrp user for Permission validation
            Response responsegetdatasrcbytypnew1 =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeSparkSql)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew1 = from(responsegetdatasrcbytypnew1.asString()).get("");

            Assert.assertNull(dataSourcesgetdatasrcbytypnew1.get("dataSourceID"));

            String actualjson="{\"tables\":[],\"success\":true,\"databaseUtils\":[],\"dataSourcesList\":[]}";

            //Storing the actual Permission from shareConnector.Permission in outputjson
            log.info("actualjsonAfterexclude==========" + actualjson);

            //Conversion of Hashmap to Permission form
            JSONObject expectedjson = new JSONObject();
            expectedjson.putAll(dataSourcesgetdatasrcbytypnew1);
            log.info("excludejsonAfterexclude===========" + expectedjson);

            //Json validation
            Assert.assertEquals(expectedjson.toString(),actualjson.toString());

            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "queryServiceFlowSparkSqlPositive")
    public  void queryServiceFlowSparkSqlPositive(){
        try{

            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameSparkSql,dbUserNameHive, dbPasswordHive, dbPortNumberSparkSql, dbHostNameHive, "null", dbTypeSparkSql,HttpStatus.SC_OK);

            //create datasource
            createDataConnector(spaceKey,uid,authToken,dataSourceNameSparkSql,dbUserNameHive, dbPasswordHive, dbPortNumberSparkSql, dbHostNameHive, "null", dbTypeSparkSql,"null",HttpStatus.SC_OK);

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryHive+"\",\"id\":\""+datasourceid+"\",\"dbname\":\"\",\"type\":\""+dbTypeSparkSql+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            Thread.sleep(2000);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,"null", dsQueryHive, datasourceid,HttpStatus.SC_OK);

            //Fetching the list of query service in a data connector
            getAllDataSet(spaceKey,uid,authToken,"0",HttpStatus.SC_OK);

            Thread.sleep(2000);
            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/sparksqlDownload.txt",authToken,nividhQueryName);

            //Fetches the detail of newly created query service for update
            viewEditQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);

            Assert.assertEquals(viewquryid.toString(),seriveiddataset.toString());

            //Test query service before creation
            String dataedit=null;
            dataedit="{\"query\":\""+dsQueryHive+"\",\"id\":\""+datasourceid+"\",\"dbname\":\"\",\"type\":\""+dbTypeSparkSql+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,dataedit,HttpStatus.SC_OK);

            //Update the newly created query service
            updateQueryService(updatequerynameSparkSql,spaceKey,uid,authToken,"null",dsQueryHive,datasourceid,seriveiddataset.toString(),HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/sparksqlDownload.txt",authToken,nividhQueryName);

            //Publish the Dataset
            publishDataSet(spaceKey,uid,authToken,seriveiddataset,HttpStatus.SC_OK);

            //Call this function to check published data set is avaialble in dashboard designer
            listQueryServices(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Validate that published Data set is available for Dashboard creation.
            Assert.assertEquals(restqueryupdateSparkSql.toString(),seriveiddataset.toString());

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataServiceFlowSparkSqlPositive")
    public  void shareUserDataServiceFlowSparkSqlPositive() {
        try {
            String namebytypeshare=null;

            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameSparkSql,dbUserNameHive, dbPasswordHive, dbPortNumberSparkSql, dbHostNameHive, "null", dbTypeSparkSql,HttpStatus.SC_OK);

            //create datasource
            createDataConnector(spaceKey,uid,authToken,dataSourceNameSparkSql,dbUserNameHive, dbPasswordHive, dbPortNumberSparkSql, dbHostNameHive, "null", dbTypeSparkSql,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeSparkSql)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationSparkSql")) {
                    namebytypeshare=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidshare==="+datasourceid);
            log.info("namebytypeshare===="+namebytypeshare);

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryHive+"\",\"id\":\""+datasourceid+"\",\"dbname\":\"\",\"type\":\""+dbTypeSparkSql+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);
            Thread.sleep(1000);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,"null", dsQueryHive, datasourceid,HttpStatus.SC_OK);

            Thread.sleep(2000);
            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,newgroupidtest,authToken,spaceKey,HttpStatus.SC_OK);

            //Sharedatasource to share the queryservice to user(AutmateGrouAugust)
            shareUserDataService(spaceKey,uid,authToken,seriveiddataset.toString(), newuseridfunuser,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with rest user to check whether shared queryservice is present in rest or not
            Response responseaut =
                    given()                       //Header
                            .header("spacekey", spaceKey)
                            .header("userID",uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesaut = from(responseaut.asString()).get("");

            for (HashMap<String, Object> iddbnew : queryServicesaut) {
                if (iddbnew.containsKey("serviceId") && iddbnew.get("serviceId").toString().equals(seriveiddataset)) {
                    idnew = iddbnew.get("serviceId").toString();
                }
            }
            log.info("idnew=="+idnew);
            Assert.assertEquals(idnew.toString(),seriveiddataset.toString());

            //delete newly created query service
            deleteQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);

            //delete newly created data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            Response responseusr =
                    given()                       //Header
                            .header("spacekey", spaceKey)
                            .header("userID",uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            // HashMap<String, Object> queryServicesaut = from(responseaut.asString()).get("");
            List<HashMap<String, Object>> queryServicesusr = from(responseusr.asString()).get("");

            //Json validation
            Assert.assertEquals(queryServicesusr.toString(),"[]");

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataServiceToExcludeSparkSqlPositive")
    public  void shareGroupDataServiceToExcludeSparkSqlPositive() {
        try{
            String namebytypeshare=null;

            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameSparkSql,dbUserNameHive, dbPasswordHive, dbPortNumberSparkSql, dbHostNameHive, "null", dbTypeSparkSql,HttpStatus.SC_OK);

            //create datasource
            createDataConnector(spaceKey,uid,authToken,dataSourceNameSparkSql,dbUserNameHive, dbPasswordHive, dbPortNumberSparkSql, dbHostNameHive, "null", dbTypeSparkSql,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeSparkSql)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationSparkSql")) {
                    namebytypeshare=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidshare==="+datasourceid);
            log.info("namebytypeshare===="+namebytypeshare);


            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryHive+"\",\"id\":\""+datasourceid+"\",\"dbname\":\"\",\"type\":\""+dbTypeSparkSql+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,"null", dsQueryHive, datasourceid,HttpStatus.SC_OK);

            Thread.sleep(1000);
            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            Thread.sleep(1000);

            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(), newuseridfunuser,HttpStatus.SC_OK);

            //SharegroupDataService
            shareGroupDataService(spaceKey,uid,authToken,seriveiddataset.toString(),newgroupid,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            // HashMap<String, Object> dataSources = from(response.asString()).get("dataSources");
            List<HashMap<String, Object>> getdata = from(response.asString()).get("");

            for (HashMap<String, Object> iddata : getdata) {
                if (iddata.containsKey("serviceId") &&   iddata.get("serviceId").toString().equals(seriveiddataset)) {
                    idnew = iddata.get("serviceId").toString();
                }
            }

            Assert.assertEquals(idnew.toString(),seriveiddataset.toString());

            //Exclude user from group
            excludeShareDataService(spaceKey,uid,authToken,seriveiddataset.toString(),newgroupid, newuseridfunuser,HttpStatus.SC_OK);

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with autmategrp user to check whether shared queryservice is present in autmategrp or not
            Response responseautnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesautnew = from(responseautnew.asString()).get("");

            Assert.assertNotEquals(queryServicesautnew,seriveiddataset.toString());

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //fetches the query list of autmategrp usr for Permission validation
            Response responseusr =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesusr = from(responseautnew.asString()).get("");

            //Json validation
            Assert.assertEquals(queryServicesusr.toString(),"[]");

            deleteQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);

            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    //-----------------------------------CASSENDRA---------------------------------------------------------//
    @Test(description = "dataConnFlowCassendraPositive")
    public  void dataConnFlowCassendraPositive() {
        try{
            String datasourceidafterdel=null;

            //Checkconnection service before creation
            checkConnectionCassendra(spaceKey,uid,authToken,HttpStatus.SC_OK);

            //Create a new connector
            createDataConnector(spaceKey,uid,authToken,dataSourceNameCassendra,dbUserNameCassendra, dbPasswordCassendra, dbPortNumberCassendra, dbHostNameCassendra,"null", dbTypeCassendra,innerobjdata,HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytypsrc =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeCassendra)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypsrc = from(responsegetdatasrcbytypsrc.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypsrc = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypsrc.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypsrc) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationCassendra")) {
                    namebytype=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceid==="+datasourceid);
            log.info("namebytype===="+namebytype);

            Assert.assertEquals(dataSourcesgetdatasrcbytypsrc.get("success").toString(),"true");

            //Validating that new query is created with name restdbautomation
            Assert.assertEquals(namebytype,"restdbautomationCassendra");

            //Fetches the detail of newly created data connector for update
            viewDataSourceDetails(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Validation of id
            Assert.assertEquals(idviewdatasrc.toString(),datasourceid.toString());

            //Checkconnection service before creation
            checkConnectionCassendraUpdate(spaceKey,uid,authToken,HttpStatus.SC_OK);

            //Update the newly created data connector
            updateDataSourceDetails(spaceKey,uid,authToken,dbUserNameCassendra,null,dbPortNumberCassendra,dbHostNameCassendra,"null",datasourceid,dbTypeCassendra,innerobjdataupdate,HttpStatus.SC_OK);

            //Reconnect the same data connector
            reconnect(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Finally delete that same data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //getDataSourceInfoByType which fetches the list of data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeCassendra)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListget = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListget) {
                if (iddb.containsKey("dataSourceID") &&   iddb.get("dataSourceID").toString().equals(datasourceid)) {
                    datasourceidafterdel = iddb.get("dataSourceID").toString();
                }
            }

            //Validating that data connector is deleted
            Assert.assertNull(datasourceidafterdel);

        } catch (Exception e) {

            e.printStackTrace();
        }

    }

    @Test(description = "shareUserDataSourceFlowCassendraPositive")
    public  void shareUserDataSourceFlowCassendraPositive() {
        try {
            String datasourceidafterdel=null;

            //Checkconnection service before creation
            checkConnectionCassendra(spaceKey, uid, authToken,HttpStatus.SC_OK);

            //Create a new connector
            createDataConnector(spaceKey,uid,authToken,dataSourceNameCassendra,dbUserNameCassendra, dbPasswordCassendra, dbPortNumberCassendra, dbHostNameCassendra,"null", dbTypeCassendra,innerobjdata,HttpStatus.SC_OK);

            //getdatasourceinforbytype which fetches the data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeCassendra)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationCassendra")) {
                    namebytype = iddb.get("dataSourceName").toString();
                }
            }

            log.info("datasourceidBeforeSharing===" + datasourceid);
            log.info("namebytypeBeforeSharing==" + namebytype);

            Assert.assertEquals(dataSourcesgetdatasrcbytyp.get("success").toString(),"true");

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,newgroupidtest,authToken,spaceKey,HttpStatus.SC_OK);

            //Sharedatasource to share the data connector to user(AutmateGrouAugust)
            shareUserDataSource(spaceKey,uid,authToken,datasourceid, newuseridfunuser,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with AutmateGrouAugust user to check whether shared connector is present in AutmateGrouAugust or not
            Response responsegetdatasrcbytypnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeCassendra)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew = from(responsegetdatasrcbytypnew.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypnew = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypnew.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypnew) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").equals("restdbautomationCassendra")) {
                    datasourceidnewusr = iddb.get("dataSourceID").toString();
                    namebytypenewusr=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidAfterSharing=="+datasourceidnewusr);
            log.info("namebytypeAfterSharing=="+namebytypenewusr);

            Assert.assertEquals(dataSourcesgetdatasrcbytypnew.get("success").toString(),"true");

            Assert.assertEquals(datasourceidnewusr.toString(),datasourceid.toString());

            //Delete newly created data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //After delete again fetching the list of data connector for AutmateGrouAugust grp for Permission validation
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeCassendra)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSources = from(response.asString()).get("");

            List<HashMap<String, Object>> dataSourcesListget = (ArrayList<HashMap<String, Object>>) dataSources.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListget) {
                if (iddb.containsKey("dataSourceID") &&   iddb.get("dataSourceID").toString().equals(datasourceid)) {
                    datasourceidafterdel = iddb.get("dataSourceID").toString();
                }
            }

            //Validating that data connector is deleted
            Assert.assertNull(datasourceidafterdel);

            String jsondata="{\"tables\":[],\"success\":true,\"databaseUtils\":[],\"dataSourcesList\":[]}";

            //Conversion of Hashmap to Permission form
            JSONObject expectedjson = new JSONObject();
            expectedjson.putAll(dataSources);
            log.info("expectedjson=====================" + expectedjson);

            //Json validation
            Assert.assertEquals(expectedjson.toString(),jsondata);

            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataSourceToExcludeCassendraPositive")
    public  void shareGroupDataSourceToExcludeCassendraPositive() {
        try {

            //Checkconnection service before creation
            checkConnectionCassendra(spaceKey, uid, authToken,HttpStatus.SC_OK);

            //Create a new connector
            createDataConnector(spaceKey,uid,authToken,dataSourceNameCassendra,dbUserNameCassendra, dbPasswordCassendra, dbPortNumberCassendra, dbHostNameCassendra,"null", dbTypeCassendra,innerobjdata,HttpStatus.SC_OK);

            //getdatasourceinforbytype which fetches the data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeCassendra)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationCassendra")) {
                    namebytype=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidBeforeSharingGrp==="+datasourceid);
            log.info("namebytypeBeforeSharingGrp==="+namebytype);

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(), newuseridfunuser,HttpStatus.SC_OK);

            getUsersFromGroups(newgroupid,HttpStatus.SC_OK);

            //Sharegroupdatasource
            shareGroupDataSource(spaceKey,uid,authToken,datasourceid,newgroupid,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with autmategrp user to check whether shared connector is present in autmategrp or not
            Response responsegetdatasrcbytypnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeCassendra)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew = from(responsegetdatasrcbytypnew.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypnew = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypnew.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypnew) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationCassendra")) {
                    datasourceidnew = iddb.get("dataSourceID").toString();
                    namebytypenew=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidAfterSharingGrp==="+datasourceidnew);
            log.info("namebytypeAfterSharingGrp==="+namebytypenew);

            Assert.assertEquals(dataSourcesgetdatasrcbytypnew.get("success").toString(),"true");
            Assert.assertEquals(datasourceidnew.toString(),datasourceid.toString());

            //Exclude user from group
            excludeShareDataSource(spaceKey,uid,authToken,datasourceid,newgroupid, newuseridfunuser,datasourceid,HttpStatus.SC_OK);

            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Again fetching the list of data connectors for autmategrp user for Permission validation
            Response responsegetdatasrcbytypnew1 =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeCassendra)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew1 = from(responsegetdatasrcbytypnew1.asString()).get("");

            Assert.assertNull(dataSourcesgetdatasrcbytypnew1.get("dataSourceID"));

            String actualjson="{\"tables\":[],\"success\":true,\"databaseUtils\":[],\"dataSourcesList\":[]}";

            //Storing the actual Permission from shareConnector.Permission in outputjson
            log.info("actualjsonAfterexclude==========" + actualjson);

            //Conversion of Hashmap to Permission form
            JSONObject expectedjson = new JSONObject();
            expectedjson.putAll(dataSourcesgetdatasrcbytypnew1);
            log.info("excludejsonAfterexclude===========" + expectedjson);

            //Json validation
            Assert.assertEquals(expectedjson.toString(),actualjson.toString());

            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "queryServiceFlowCassendraPositive")
    public  void queryServiceFlowCassendraPositive(){
        try{

            //Checkconnection service before creation
            checkConnectionCassendra(spaceKey, uid, authToken,HttpStatus.SC_OK);

            //Create a new connector
            createDataConnector(spaceKey,uid,authToken,dataSourceNameCassendra,dbUserNameCassendra, dbPasswordCassendra, dbPortNumberCassendra, dbHostNameCassendra,"null", dbTypeCassendra,innerobjdata,HttpStatus.SC_OK);

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryCassendra+"\",\"id\":\""+datasourceid+"\",\"dbname\":\"\",\"type\":\""+dbTypeCassendra+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            Thread.sleep(2000);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,"null", dsQueryCassendra, datasourceid,HttpStatus.SC_OK);

            //Fetching the list of query service in a data connector
            getAllDataSet(spaceKey,uid,authToken,"0",HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/cassendraDownload.txt",authToken,nividhQueryName);

            //Fetches the detail of newly created query service for update
            viewEditQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);

            Assert.assertEquals(viewquryid.toString(),seriveiddataset.toString());

            //Test query service before creation
            String dataedit=null;
            dataedit="{\"query\":\""+dsQueryCassendra+"\",\"id\":\""+datasourceid+"\",\"dbname\":\"\",\"type\":\""+dbTypeCassendra+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,dataedit,HttpStatus.SC_OK);

            //Update the newly created query service
            updateQueryService(updatequerynameCassandra,spaceKey,uid,authToken,"null",dsQueryCassendra,datasourceid,seriveiddataset.toString(),HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/cassendraDownload.txt",authToken,nividhQueryName);

            //Publish the Dataset
            publishDataSet(spaceKey,uid,authToken,seriveiddataset,HttpStatus.SC_OK);

            //Call this function to check published data set is avaialble in dashboard designer
            listQueryServices(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Validate that published Data set is available for Dashboard creation.
            Assert.assertEquals(restqueryupdateCassandra.toString(),seriveiddataset.toString());

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataServiceFlowCassendraPositive")
    public  void shareUserDataServiceFlowCassendraPositive() {
        try {
            String namebytypeshare=null;

            //Checkconnection service before creation
            checkConnectionCassendra(spaceKey, uid, authToken,HttpStatus.SC_OK);

            //Create a new connector
            createDataConnector(spaceKey,uid,authToken,dataSourceNameCassendra,dbUserNameCassendra, dbPasswordCassendra, dbPortNumberCassendra, dbHostNameCassendra,"null", dbTypeCassendra,innerobjdata,HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeCassendra)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationCassendra")) {
                    namebytypeshare=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidshare==="+datasourceid);
            log.info("namebytypeshare===="+namebytypeshare);

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryCassendra+"\",\"id\":\""+datasourceid+"\",\"dbname\":\"\",\"type\":\""+dbTypeCassendra+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,"null", dsQueryCassendra, datasourceid,HttpStatus.SC_OK);

            Thread.sleep(1000);

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,newgroupidtest,authToken,spaceKey,HttpStatus.SC_OK);

            //Sharedatasource to share the queryservice to user(AutmateGrouAugust)
            shareUserDataService(spaceKey,uid,authToken,seriveiddataset.toString(), newuseridfunuser,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with rest user to check whether shared queryservice is present in rest or not
            Response responseaut =
                    given()                       //Header
                            .header("spacekey", spaceKey)
                            .header("userID",uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesaut = from(responseaut.asString()).get("");

            for (HashMap<String, Object> iddbnew : queryServicesaut) {
                if (iddbnew.containsKey("serviceId") && iddbnew.get("serviceId").toString().equals(seriveiddataset)) {
                    idnew = iddbnew.get("serviceId").toString();
                }
            }
            log.info("idnew=="+idnew);
            Assert.assertEquals(idnew.toString(),seriveiddataset.toString());

            //delete newly created query service
            deleteQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);

            //delete newly created data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            Response responseusr =
                    given()                       //Header
                            .header("spacekey", spaceKey)
                            .header("userID",uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            // HashMap<String, Object> queryServicesaut = from(responseaut.asString()).get("");
            List<HashMap<String, Object>> queryServicesusr = from(responseusr.asString()).get("");

            //Json validation
            Assert.assertEquals(queryServicesusr.toString(),"[]");

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataServiceToExcludeCassendraPositive")
    public  void shareGroupDataServiceToExcludeCassendraPositive() {
        try{
            String namebytypeshare=null;

            //Checkconnection service before creation
            checkConnectionCassendra(spaceKey, uid, authToken,HttpStatus.SC_OK);

            //Create a new connector
            createDataConnector(spaceKey,uid,authToken,dataSourceNameCassendra,dbUserNameCassendra, dbPasswordCassendra, dbPortNumberCassendra, dbHostNameCassendra,"null", dbTypeCassendra,innerobjdata,HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeCassendra)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationCassendra")) {
                    namebytypeshare=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidshare==="+datasourceid);
            log.info("namebytypeshare===="+namebytypeshare);


            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryCassendra+"\",\"id\":\""+datasourceid+"\",\"dbname\":\"\",\"type\":\""+dbTypeCassendra+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,"null", dsQueryCassendra, datasourceid,HttpStatus.SC_OK);

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(), newuseridfunuser,HttpStatus.SC_OK);

            //SharegroupDataService
            shareGroupDataService(spaceKey,uid,authToken,seriveiddataset.toString(),newgroupid,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            // HashMap<String, Object> dataSources = from(response.asString()).get("dataSources");
            List<HashMap<String, Object>> getdata = from(response.asString()).get("");

            for (HashMap<String, Object> iddata : getdata) {
                if (iddata.containsKey("serviceId") &&   iddata.get("serviceId").toString().equals(seriveiddataset)) {
                    idnew = iddata.get("serviceId").toString();
                }
            }

            Assert.assertEquals(idnew.toString(),seriveiddataset.toString());

            //Exclude user from group
            excludeShareDataService(spaceKey,uid,authToken,seriveiddataset.toString(),newgroupid, newuseridfunuser,HttpStatus.SC_OK);

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with autmategrp user to check whether shared queryservice is present in autmategrp or not
            Response responseautnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesautnew = from(responseautnew.asString()).get("");

            Assert.assertNotEquals(queryServicesautnew,seriveiddataset.toString());

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //fetches the query list of autmategrp usr for Permission validation
            Response responseusr =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesusr = from(responseautnew.asString()).get("");

            //Json validation
            Assert.assertEquals(queryServicesusr.toString(),"[]");

            deleteQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);

            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

//-------------------------------------O-DATA-----------------------------------------------------------//

    @Test(description = "dataConnFlowODataPositive")
    public  void dataConnFlowODataPositive(){
        try{
            String datasourceidafterdel=null;

            checkDataSource(spaceKey,uid,authToken,dataSourceNameOdata,dbUserNameOData, dbPasswordOData, "null", dbHostNameOData, "null", dbTypeOData,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameOdata,dbUserNameOData, dbPasswordOData, "null", dbHostNameOData, "null", dbTypeOData,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytypsrc =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeOData)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypsrc = from(responsegetdatasrcbytypsrc.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypsrc = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypsrc.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypsrc) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationOdata")) {
                    namebytype=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceid==="+datasourceid);
            log.info("namebytype===="+namebytype);

            Assert.assertEquals(dataSourcesgetdatasrcbytypsrc.get("success").toString(),"true");

            //Validating that new query is created with name restdbautomation
            Assert.assertEquals(namebytype,"restdbautomationOdata");

            //Fetches the detail of newly created data connector for update
            viewDataSourceDetails(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Validation of id
            Assert.assertEquals(idviewdatasrc.toString(),datasourceid.toString());

            //Before updating check the datconnector
            checkDataSourceEdit(spaceKey,uid,authToken,dbUserNameOData,null,"null",dbHostNameOData,"null",datasourceid,dbTypeOData,null,HttpStatus.SC_OK);

            //Update the newly created data connector
            updateDataSourceDetails(spaceKey,uid,authToken,dbUserNameOData,null,"null",dbHostNameOData,"null",datasourceid,dbTypeOData,null,HttpStatus.SC_OK);

            //Reconnect the same data connector
            reconnect(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Finally delete that same data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //getDataSourceInfoByType which fetches the list of data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeOData)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListget = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListget) {
                if (iddb.containsKey("dataSourceID") &&   iddb.get("dataSourceID").toString().equals(datasourceid)) {
                    datasourceidafterdel = iddb.get("dataSourceID").toString();
                }
            }

            //Validating that data connector is deleted
            Assert.assertNull(datasourceidafterdel);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataSourceFlowODataPositive")
    public  void shareUserDataSourceFlowODataPositive() {
        try {
            String datasourceidafterdel=null;

            checkDataSource(spaceKey,uid,authToken,dataSourceNameOdata,dbUserNameOData, dbPasswordOData, "null", dbHostNameOData, "null", dbTypeOData,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameOdata,dbUserNameOData, dbPasswordOData, "null", dbHostNameOData, "null", dbTypeOData,"null",HttpStatus.SC_OK);

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,newgroupidtest,authToken,spaceKey,HttpStatus.SC_OK);

            //Sharedatasource to share the data connector to user(AutmateGrouAugust)
            shareUserDataSource(spaceKey,uid,authToken,datasourceid, newuseridfunuser,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with AutmateGrouAugust user to check whether shared connector is present in AutmateGrouAugust or not
            Response responsegetdatasrcbytypnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeCassendra)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew = from(responsegetdatasrcbytypnew.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypnew = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypnew.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypnew) {
                if (iddb.containsKey("dataSourceID") && iddb.get("dataSourceID").equals(datasourceid)) {
                    datasourceidnewusr = iddb.get("dataSourceID").toString();
                    namebytypenewusr=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidAfterSharing=="+datasourceidnewusr);
            log.info("namebytypeAfterSharing=="+namebytypenewusr);

            Assert.assertEquals(dataSourcesgetdatasrcbytypnew.get("success").toString(),"true");

            //    Assert.assertEquals(datasourceidnewusr.toString(),datasourceid.toString());

            //Delete newly created data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //After delete again fetching the list of data connector for AutmateGrouAugust grp for Permission validation
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeCassendra)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSources = from(response.asString()).get("");

            List<HashMap<String, Object>> dataSourcesListget = (ArrayList<HashMap<String, Object>>) dataSources.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListget) {
                if (iddb.containsKey("dataSourceID") &&   iddb.get("dataSourceID").toString().equals(datasourceid)) {
                    datasourceidafterdel = iddb.get("dataSourceID").toString();
                }
            }

            //Validating that data connector is deleted
            Assert.assertNull(datasourceidafterdel);

            String jsondata="{\"tables\":[],\"success\":true,\"databaseUtils\":[],\"dataSourcesList\":[]}";

            //Conversion of Hashmap to Permission form
            JSONObject expectedjson = new JSONObject();
            expectedjson.putAll(dataSources);
            log.info("expectedjson=====================" + expectedjson);

            //Json validation
            Assert.assertEquals(expectedjson.toString(),jsondata);

            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataSourceToExcludeODataPositive")
    public  void shareGroupDataSourceToExcludeODataPositive() {
        try {

            checkDataSource(spaceKey,uid,authToken,dataSourceNameOdata,dbUserNameOData, dbPasswordOData, "null", dbHostNameOData, "null", dbTypeOData,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameOdata,dbUserNameOData, dbPasswordOData, "null", dbHostNameOData, "null", dbTypeOData,"null",HttpStatus.SC_OK);

            log.info("datasourceidBeforeSharingGrp==="+datasourceid);
            log.info("namebytypeBeforeSharingGrp==="+namebytype);

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(), newuseridfunuser,HttpStatus.SC_OK);

            getUsersFromGroups(newgroupid,HttpStatus.SC_OK);

            //Sharegroupdatasource
            shareGroupDataSource(spaceKey,uid,authToken,datasourceid,newgroupid,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with autmategrp user to check whether shared connector is present in autmategrp or not
            Response responsegetdatasrcbytypnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeOData)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew = from(responsegetdatasrcbytypnew.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytypnew = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytypnew.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytypnew) {
                if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restdbautomationOdata")) {
                    datasourceidnew = iddb.get("dataSourceID").toString();
                    namebytypenew=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidAfterSharingGrp==="+datasourceidnew);
            log.info("namebytypeAfterSharingGrp==="+namebytypenew);

            Assert.assertEquals(dataSourcesgetdatasrcbytypnew.get("success").toString(),"true");
            Assert.assertEquals(datasourceidnew.toString(),datasourceid.toString());

            //Exclude user from group
            excludeShareDataSource(spaceKey,uid,authToken,datasourceid,newgroupid, newuseridfunuser,datasourceid,HttpStatus.SC_OK);

            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Again fetching the list of data connectors for autmategrp user for Permission validation
            Response responsegetdatasrcbytypnew1 =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("datasourcetype", dbTypeOData)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytypnew1 = from(responsegetdatasrcbytypnew1.asString()).get("");

            Assert.assertNull(dataSourcesgetdatasrcbytypnew1.get("dataSourceID"));

            String actualjson="{\"tables\":[],\"success\":true,\"databaseUtils\":[],\"dataSourcesList\":[]}";

            //Storing the actual Permission from shareConnector.Permission in outputjson
            log.info("actualjsonAfterexclude==========" + actualjson);

            //Conversion of Hashmap to Permission form
            JSONObject expectedjson = new JSONObject();
            expectedjson.putAll(dataSourcesgetdatasrcbytypnew1);
            log.info("excludejsonAfterexclude===========" + expectedjson);

            //Json validation
            Assert.assertEquals(expectedjson.toString(),actualjson.toString());

            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "queryServiceFlowODataPositive")
    public  void queryServiceFlowODataPositive(){
        try{

            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameOdata,dbUserNameOData, dbPasswordOData, "null", dbHostNameOData, "null", dbTypeOData,HttpStatus.SC_OK);

            //create datasource
            createDataConnector(spaceKey,uid,authToken,dataSourceNameOdata,dbUserNameOData, dbPasswordOData, "null", dbHostNameOData, "null", dbTypeOData,"null",HttpStatus.SC_OK);

            log.info("datasourceid==="+datasourceid);
            log.info("namebytype===="+namebytype);


            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryOData+"\",\"id\":\""+datasourceid+"\",\"dbname\":\"\",\"type\":\""+dbTypeOData+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,"null", dsQueryOData, datasourceid,HttpStatus.SC_OK);

            //Fetching the list of query service in a data connector
            getAllDataSet(spaceKey,uid,authToken,"0",HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/odataDownload.txt",authToken,nividhQueryName);

            //Fetches the detail of newly created query service for update
            viewEditQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);

            Assert.assertEquals(viewquryid.toString(),seriveiddataset.toString());

            //Test query service before creation
            String dataedit=null;
            dataedit="{\"query\":\""+dsQueryOData+"\",\"id\":\""+datasourceid+"\",\"dbname\":\"\",\"type\":\""+dbTypeOData+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,dataedit,HttpStatus.SC_OK);

            //Update the newly created query service
            updateQueryService(updatequerynameOData,spaceKey,uid,authToken,"null",dsQueryOData,datasourceid,seriveiddataset.toString(),HttpStatus.SC_OK);

            //Downloading Data and doing Text file validation
            downloadDataSet("./src/main/resources/odataDownload.txt",authToken,nividhQueryName);

            //Publish the Dataset
            publishDataSet(spaceKey,uid,authToken,seriveiddataset,HttpStatus.SC_OK);

            //Call this function to check published data set is avaialble in dashboard designer
            listQueryServices(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Validate that published Data set is available for Dashboard creation.
            Assert.assertEquals(restqueryupdateOdata.toString(),seriveiddataset.toString());

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataServiceFlowODataPositive")
    public  void shareUserDataServiceFlowODataPositive() {
        try {
            String namebytypeshare=null;

            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameOdata,dbUserNameOData, dbPasswordOData, "null", dbHostNameOData, "null", dbTypeOData,HttpStatus.SC_OK);

            //create datasource
            createDataConnector(spaceKey,uid,authToken,dataSourceNameOdata,dbUserNameOData, dbPasswordOData, "null", dbHostNameOData, "null", dbTypeOData,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeOData)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationOdata")) {
                    namebytypeshare=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidshare==="+datasourceid);
            log.info("namebytypeshare===="+namebytypeshare);

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryOData+"\",\"id\":\""+datasourceid+"\",\"dbname\":\"\",\"type\":\""+dbTypeOData+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,"null", dsQueryOData, datasourceid,HttpStatus.SC_OK);

            Thread.sleep(2000);
            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,newgroupidtest,authToken,spaceKey,HttpStatus.SC_OK);

            //Sharedatasource to share the queryservice to user(AutmateGrouAugust)
            shareUserDataService(spaceKey,uid,authToken,seriveiddataset.toString(), newuseridfunuser,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with rest user to check whether shared queryservice is present in rest or not
            Response responseaut =
                    given()    //Header
                            .header("spacekey", spaceKey)
                            .header("userID",uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesaut = from(responseaut.asString()).get("");

            for (HashMap<String, Object> iddbnew : queryServicesaut) {
                if (iddbnew.containsKey("serviceId") && iddbnew.get("serviceId").toString().equals(seriveiddataset)) {
                    idnew = iddbnew.get("serviceId").toString();
                }
            }
            log.info("idnew=="+idnew);
            Assert.assertEquals(idnew.toString(),seriveiddataset.toString());

            //delete newly created query service
            deleteQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);

            //delete newly created data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            Response responseusr =
                    given()                       //Header
                            .header("spacekey", spaceKey)
                            .header("userID",uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            // HashMap<String, Object> queryServicesaut = from(responseaut.asString()).get("");
            List<HashMap<String, Object>> queryServicesusr = from(responseusr.asString()).get("");

            //Json validation
            Assert.assertEquals(queryServicesusr.toString(),"[]");

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataServiceToExcludeODataPositive")
    public  void shareGroupDataServiceToExcludeODataPositive() {
        try{
            String namebytypeshare=null;

            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameOdata,dbUserNameOData, dbPasswordOData, "null", dbHostNameOData, "null", dbTypeOData,HttpStatus.SC_OK);

            //create datasource
            createDataConnector(spaceKey,uid,authToken,dataSourceNameOdata,dbUserNameOData, dbPasswordOData, "null", dbHostNameOData, "null", dbTypeOData,"null",HttpStatus.SC_OK);

            //Fetches the id and name of newly created data connector
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", dbTypeOData)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
            List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

            for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                if (iddb.containsKey("dataSourceName") &&   iddb.get("dataSourceName").toString().equals("restdbautomationOdata")) {
                    namebytypeshare=iddb.get("dataSourceName").toString();
                }
            }
            log.info("datasourceidshare==="+datasourceid);
            log.info("namebytypeshare===="+namebytypeshare);


            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQueryOData+"\",\"id\":\""+datasourceid+"\",\"dbname\":\"\",\"type\":\""+dbTypeOData+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,queryname,"null", dsQueryOData, datasourceid,HttpStatus.SC_OK);

            Thread.sleep(2000);
            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            Thread.sleep(2000);
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(), newuseridfunuser,HttpStatus.SC_OK);

            //SharegroupDataService
            shareGroupDataService(spaceKey,uid,authToken,seriveiddataset.toString(),newgroupid,HttpStatus.SC_OK);

            User userautmate=null;
            User userautmateauth=null;
            String authtokenautmate=null;
            String uidautmate=null;

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            // HashMap<String, Object> dataSources = from(response.asString()).get("dataSources");
            List<HashMap<String, Object>> getdata = from(response.asString()).get("");

            for (HashMap<String, Object> iddata : getdata) {
                if (iddata.containsKey("serviceId") &&   iddata.get("serviceId").toString().equals(seriveiddataset)) {
                    idnew = iddata.get("serviceId").toString();
                }
            }

            Assert.assertEquals(idnew.toString(),seriveiddataset.toString());

            //Exclude user from group
            excludeShareDataService(spaceKey,uid,authToken,seriveiddataset.toString(),newgroupid, newuseridfunuser,HttpStatus.SC_OK);

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //Login with autmategrp user to check whether shared queryservice is present in autmategrp or not
            Response responseautnew =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesautnew = from(responseautnew.asString()).get("");

            Assert.assertNotEquals(queryServicesautnew,seriveiddataset.toString());

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //fetches the query list of autmategrp usr for Permission validation
            Response responseusr =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uidautmate)
                            .header("authtoken", authtokenautmate)
                            //Body
                            .param("isPublished",0)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> queryServicesusr = from(responseautnew.asString()).get("");

            //Json validation
            Assert.assertEquals(queryServicesusr.toString(),"[]");

            deleteQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),HttpStatus.SC_OK);

            deletedDataSource(spaceKey,uid,authToken,datasourceid,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //--------------------------------------META-DATA-----------------------------------------------------//
    //Fetches the list of Data Connector by database type
    @Test
    public static void getDataStoreInfoPositive() {
        try {
            Response responsegetdatastoreinfo =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("index","" )
                            .param("isExists",isExistsMetadta)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetDataStoreInfo)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> dataSourcesListgetdatastoreinfo = from(responsegetdatastoreinfo.asString()).get("");

            log.info("getDataStoreInfo====="+responsegetdatastoreinfo.asString());

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test
    public static void pluginServicesFlowMetaData() {
        try {

            String datacreation="{\"defenition\":\"{\\\"fieldDef\\\":{\\\"time\\\":[],\\\"facts\\\":[\\\"COMP_NAME\\\"],\\\"measures\\\":[\\\"COMP_ID\\\"]},\\\"drillDef\\\":[],\\\"dataRestriction\\\":{\\\"COMP_NAME\\\":\\\"BATA\\\"},\\\"columnNames\\\":{\\\"COMP_NAME\\\":\\\"string\\\",\\\"COMP_ID\\\":\\\"double\\\"},\\\"esIndex\\\":{\\\"index\\\":\\\"\\\"},\\\"elasticSearch\\\":{\\\"isEnabled\\\":true,\\\"isChanged\\\":false,\\\"properties\\\":{\\\"COMP_NAME\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"COMP_ID\\\":{\\\"type\\\":\\\"double\\\",\\\"index\\\":\\\"not_analyzed\\\"}}}}\",\"createdBy\":{\"id\":450265088},\"updatedBy\":{\"id\":450265088},\"cubeOptions\":\"{\\\"cubeName\\\":\\\"restt\\\",\\\"columnNmae\\\":{\\\"facts\\\":[\\\"COMP_NAME\\\"],\\\"measures\\\":[\\\"COMP_ID\\\"],\\\"time\\\":[]}}\",\"name\":\""+Utils.getproperty("plugincraetionname")+"\",\"id\":null,\"type\":1,\"status\":1,\"createdDate\":null,\"lastUpdatedDate\":null,\"isActive\":0,\"spaceKey\":3829}";

            //Meta-Data creation
            pluginServices(isExistsMetadta,consumerName,serviceNameCreation,datacreation);

            //Fetches all meta data along with its detail
            pluginserviceGetAllMetadata();

            //Meta-Data updation
            String dataupdate="{\"defenition\":\"{\\\"fieldDef\\\":{\\\"time\\\":[],\\\"facts\\\":[\\\"COMP_NAME\\\"],\\\"measures\\\":[\\\"COMP_ID\\\"]},\\\"drillDef\\\":[],\\\"dataRestriction\\\":{\\\"COMP_NAME\\\":\\\"BATA\\\"},\\\"columnNames\\\":{\\\"COMP_NAME\\\":\\\"string\\\",\\\"COMP_ID\\\":\\\"double\\\"},\\\"esIndex\\\":{\\\"index\\\":\\\"\\\"},\\\"elasticSearch\\\":{\\\"isEnabled\\\":true,\\\"isChanged\\\":false,\\\"properties\\\":{\\\"COMP_NAME\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"COMP_ID\\\":{\\\"type\\\":\\\"double\\\",\\\"index\\\":\\\"not_analyzed\\\"}}}}\",\"createdBy\":{\"id\":450265088},\"updatedBy\":{\"id\":450265088},\"cubeOptions\":\"{\\\"cubeName\\\":\\\"resttupdate\\\",\\\"columnNmae\\\":{\\\"facts\\\":[\\\"COMP_NAME\\\"],\\\"measures\\\":[\\\"COMP_ID\\\"],\\\"time\\\":[]}}\",\"name\":\""+Utils.getproperty("pluginupdatename")+"\",\"id\":"+pluginid+",\"type\":1,\"status\":1,\"createdDate\":null,\"lastUpdatedDate\":null,\"isActive\":0,\"spaceKey\":3829}";
            pluginServices(isExistsMetadta,consumerName,serviceNameCreation,dataupdate);

            //Fetches the particular meta data and its index detail
            pluginserviceGetIndex();



        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public void dataCenterGroupPermissions( String uid,String authToken,Integer http){
        try{
            //check data source before creation
            checkDataSource(spaceKey,uid,authToken,dataSourceNameMysql,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,http);

            //create data source
            createDataConnector(spaceKey,uid,authToken,dataSourceNameMysql,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,"null",http);

            //Fetches the detail of newly created data connector for update
            viewDataSourceDetails(spaceKey,uid,authToken,datasourceid,http);

            //Before updating check the datconnector
            checkDataSourceEdit(spaceKey,uid,authToken,dbUserName,null,dbPortNumber,dbHostName,dbName,datasourceid,dbType,null,http);

            //Update the newly created data connector
            updateDataSourceDetails(spaceKey,uid,authToken,dbUserName,null,dbPortNumber,dbHostName,dbName,datasourceid,dbType,null,http);

            //Reconnect the same data connector
            reconnect(spaceKey,uid,authToken,datasourceid,http);

            //Sharedatasource to share the data connector to user(AutmateGrouAugust)
            shareUserDataSource(spaceKey,uid,authToken,datasourceid, newuseridfunuser,http);

            //Sharegroupdatasource
            shareGroupDataSource(spaceKey,uid,authToken,datasourceid,newgroupid,http);

            //Exclude user from group
            excludeShareDataSource(spaceKey,uid,authToken,datasourceid,newgroupid, newuseridfunuser,datasourceid,http);

            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQuery+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbType+"\",\"filter\":\"{}\"}";
            runDataService(spaceKey,uid,authToken,data,http);
            Thread.sleep(2000);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,querynameMysql,dbName, dsQuery, datasourceid,http);

            //Fetching the list of query service in a data connector
            getAllDataSet(spaceKey,uid,authToken,"0",http);

            //Fetches the detail of newly created query service for update
            viewEditQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),http);

            //Test query service before creation
            String dataedit=null;
            dataedit="{\"query\":\""+Utils.getproperty("dsQueryupdate1")+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbType+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,dataedit,http);
            log.info("id"+seriveiddataset.toString());

            //Update the newly created query service
            updateQueryService(updatequerynameMysql,spaceKey,uid,authToken,dbName,Utils.getproperty("dsQueryupdate1"),datasourceid,seriveiddataset.toString(),http);

            //Publish the Dataset
            publishDataSet(spaceKey,uid,authToken,seriveiddataset,http);
            //Call this function to check published data set is avaialble in dashboard designer

            listQueryServices(spaceKey,uid,authToken,datasourceid,http);

            //Sharedatasource to share the queryservice to user(AutmateGrouAugust)
            shareUserDataService(spaceKey,uid,authToken,seriveiddataset, newuseridfunuser,http);

            //SharegroupDataService
            shareGroupDataService(spaceKey,uid,authToken,seriveiddataset.toString(),newgroupid,http);

            //Exclude user from group
            excludeShareDataService(spaceKey,uid,authToken,seriveiddataset.toString(),newgroupid, newuseridfunuser,http);

            //Finally delete that same query service
            deleteQueryService(spaceKey,uid,authToken,seriveiddataset.toString(),http);
            //Delete newly created data connector
            deletedDataSource(spaceKey,uid,authToken,datasourceid,http);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //---------------------------Dashboard-Filter dataservices----------------------------------------------//

    public void dashboardFilter() {
        try {
            checkDataSource(spaceKey,uid,authToken,dataSourceNameFilter,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,HttpStatus.SC_OK);

            createDataConnector(spaceKey,uid,authToken,dataSourceNameFilter,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,"null",HttpStatus.SC_OK);

            String data=null;
            data="{\"query\":\""+dsQueryFilter+"\",\"id\":\""+datasourceid+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbType+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,querynameFilter,dbName, dsQueryFilter, datasourceid,HttpStatus.SC_OK);

            publishDataSet(spaceKey,uid,authToken ,seriveiddataset,HttpStatus.SC_OK);


        } catch (Exception e) {

            e.printStackTrace();
        }
    }



}