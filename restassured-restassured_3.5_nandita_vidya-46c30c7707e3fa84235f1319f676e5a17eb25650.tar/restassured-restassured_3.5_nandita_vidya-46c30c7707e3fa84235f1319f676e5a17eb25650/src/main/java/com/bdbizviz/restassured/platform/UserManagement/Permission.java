package com.bdbizviz.restassured.platform.UserManagement;

import com.bdbizviz.restassured.platform.Admininstration.Admin;
import com.bdbizviz.restassured.platform.DataCenter.DataCenter;
import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.Jdbc_connection;
import com.bdbizviz.restassured.platform.Util.User;
import com.bdbizviz.restassured.platform.Util.Utils;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Created by bizviz on 7/5/18.
 */
public class Permission extends UserManagement {
    User userautmate = null;
    User userautmateauth = null;
    String authtokenautmate = null;
    String uidautmate=null;

    @BeforeClass
    public static void setupUserMang() {
        prop = Utils.getProps();//Fetch all Permission data of properties Permission file and store in prop
        UserManagement.setupUserMang();

    }

    @Test(description = "userGroupPermission")
    public void userGroupPermission() {
        try {
            Thread.sleep(3000);

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey, uid, authToken, uniqueid + Helper.generateRandomString(), usrname, fulnme, pass_admin, "", authToken, spaceKey, HttpStatus.SC_OK);

            if (newuseridfunuser==null){
                createnewuserFunctional(spaceKey, uid, authToken, uniqueid + Helper.generateRandomString(), usrname, fulnme, pass_admin, "", authToken, spaceKey, HttpStatus.SC_OK);

            }
            //******************Createnewusergroup**********************//
            createnewGroupPerm(spaceKey, uid, authToken, Groupnameuser, newuseridfunuser, HttpStatus.SC_OK);
            LOGGER.info("NEWCREATEGRPID==" + newuseridfunuser);

            permission();

            //--------------------------------Play Module Permission---------------------------//
            Thread.sleep(5000);

            updateusergroupPlay(spaceKey, uid, authToken,Utils.getproperty("GroupnameUpdate"),Create_Folder,Modify_Document_File,newgroupid, authToken, spaceKey, newuseridfunuser, HttpStatus.SC_OK);
            Thread.sleep(3000);

            permission();

            //--------------------------------Survey Module Permission---------------------------//
            Thread.sleep(3000);

            updateusergroupSurvey(spaceKey, uid, authToken,Utils.getproperty("GroupnameUpdate"),Create_Folder,Modify_Document_File,newgroupid, authToken, spaceKey, newuseridfunuser, HttpStatus.SC_OK);
            Thread.sleep(3000);

            permission();

            //--------------------------------SMB Module Permission---------------------------//
            Thread.sleep(3000);

            updateusergroupSMB(spaceKey, uid, authToken,Utils.getproperty("GroupnameUpdate"),Create_Folder,Modify_Document_File,newgroupid, authToken, spaceKey, newuseridfunuser, HttpStatus.SC_OK);
            Thread.sleep(3000);

            permission();

            //--------------------------------Sentiment Module Permission---------------------------//
            Thread.sleep(3000);

            updateusergroupSentiment(spaceKey, uid, authToken,Utils.getproperty("GroupnameUpdate"),Create_Folder,Modify_Document_File,newgroupid, authToken, spaceKey, newuseridfunuser, HttpStatus.SC_OK);
            Thread.sleep(3000);

            permission();

            //--------------------------------Designer Module Permission---------------------------//
            Thread.sleep(3000);

            updateusergroupDesigner(spaceKey, uid, authToken,Utils.getproperty("GroupnameUpdate"),Create_Folder,Modify_Document_File,newgroupid, authToken, spaceKey, newuseridfunuser, HttpStatus.SC_OK);
            Thread.sleep(3000);

            permission();

            //--------------------------------ETL Module Permission---------------------------//
            updateusergroupETL(spaceKey, uid, authToken,Utils.getproperty("GroupnameUpdate"),Create_Folder,Modify_Document_File,newgroupid, authToken, spaceKey, newuseridfunuser, HttpStatus.SC_OK);
            Thread.sleep(3000);

            permission();

            //--------------------------------ETL Module Permission---------------------------//
            Thread.sleep(3000);

            updateusergroupGeo(spaceKey, uid, authToken,Utils.getproperty("GroupnameUpdate"),Create_Folder,Modify_Document_File,newgroupid, authToken, spaceKey, newuseridfunuser, HttpStatus.SC_OK);
            Thread.sleep(3000);

            permission();

            //--------------------------------Data Center Module Permission---------------------------//
            Thread.sleep(3000);

            updateusergroupDataCenter(spaceKey, uid, authToken,Utils.getproperty("GroupnameUpdate"),Create_Folder,Modify_Document_File,newgroupid, authToken, spaceKey, newuseridfunuser, HttpStatus.SC_OK);
            Thread.sleep(3000);
            //Login with new user to check able to login with new user or not.
            userautmate = Helper.getCustomerKey(emailidcreatefun, space_admin);
            userautmateauth = Helper.getAuthToken(emailidcreatefun, pass_admin, space_admin);
            authtokenautmate = userautmateauth.getAuthToken();
            uidautmate = userautmate.getId();

            DataCenter dc=new DataCenter();
            DataCenter.setupDataCenter();
            dc.dataCenterGroupPermissions(uidautmate,authtokenautmate,HttpStatus.SC_OK);

            permission();

            //--------------------------------Administration Module Permission---------------------------//
            Thread.sleep(3000);
            updateusergroupAdmin(spaceKey, uid, authToken,Utils.getproperty("GroupnameUpdate"),Create_Folder,Modify_Document_File,newgroupid, authToken, spaceKey, newuseridfunuser, HttpStatus.SC_OK);
            Thread.sleep(3000);

            //Login with new user to check able to login with new user or not.
            userautmate = Helper.getCustomerKey(emailidcreatefun, space_admin);
            userautmateauth = Helper.getAuthToken(emailidcreatefun, pass_admin, space_admin);
            authtokenautmate = userautmateauth.getAuthToken();
            uidautmate = userautmate.getId();

            com.bdbizviz.restassured.platform.Admininstration.Admin ad=new Admin();
            Thread.sleep(3000);
            com.bdbizviz.restassured.platform.Admininstration.Admin.setupAdmin();
            ad.adminGroupPermission(uidautmate,authtokenautmate,HttpStatus.SC_OK);

            permission();

            //--------------------------------User Management Module Permission---------------------------//
            Thread.sleep(3000);
            updateusergroupUser(spaceKey, uid, authToken,Utils.getproperty("GroupnameUpdate"),Create_Folder,Modify_Document_File,newgroupid, authToken, spaceKey, newuseridfunuser, HttpStatus.SC_OK);
            Thread.sleep(3000);

            //Login with new user to check able to login with new user or not.
            userautmate = Helper.getCustomerKey(emailidcreatefun, space_admin);
            userautmateauth = Helper.getAuthToken(emailidcreatefun, pass_admin, space_admin);
            authtokenautmate = userautmateauth.getAuthToken();
            uidautmate = userautmate.getId();

            createToDeleteFlowUserPerm(uidautmate,authtokenautmate,HttpStatus.SC_OK);

            permission();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void permission(){

        try{
            //Login with new user to check able to login with new user or not.
            userautmate = Helper.getCustomerKey(emailidcreatefun, space_admin);
            userautmateauth = Helper.getAuthToken(emailidcreatefun, pass_admin, space_admin);
            authtokenautmate = userautmateauth.getAuthToken();
            uidautmate = userautmate.getId();

            String dash=null;
            org.json.JSONArray grouppermdb_dash=null;
            //JDBC Connection for permission validation
            String sqldash = "select PERMISSION_IN_JSON from addedPermissionToUser where SPACE_KEY=" + spaceKey + " and USER_ID=" + uidautmate + "";
            dash = Jdbc_connection.jdbcResult(sqldash, "PERMISSION_IN_JSON", JDBC_IP_PORT, JDBC_DBNAME, JDBC_USERNAME, JDBC_Password);
            System.out.println(dash);

            grouppermdb_dash=new org.json.JSONArray(dash);

            for(int i =0;i<grouppermdb_dash.length();i++){
                grouppermdb_dash.getJSONObject(i).remove("createdDate");
            }

            //Fetches all Assigned Group permission
            getAllChildPermission(spaceKey,uidautmate,authtokenautmate,HttpStatus.SC_OK);

            //Json validation of getAllChildPermission service to check permissions assigend to it
            Assert.assertEquals(allpermission.toString(), grouppermdb_dash.toString());

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    }


