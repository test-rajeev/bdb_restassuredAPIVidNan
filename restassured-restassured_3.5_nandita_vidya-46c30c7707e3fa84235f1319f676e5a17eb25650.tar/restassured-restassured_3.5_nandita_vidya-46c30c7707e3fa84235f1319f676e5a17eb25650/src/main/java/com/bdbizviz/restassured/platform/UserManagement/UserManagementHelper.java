package com.bdbizviz.restassured.platform.UserManagement;

import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.User;
import com.bdbizviz.restassured.platform.Util.Utils;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.json.simple.JSONObject;
import org.testng.Assert;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;
import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;


public class UserManagementHelper {
    private static final Logger LOGGER = Logger.getLogger(UserManagementHelper.class.getName());
    public static JSONObject prop = null;

    public static String newuseriduser = null;
    public static String message = null;
    public static User user = null;
    public static String usrname = null;
    public static String uid=null;
    public static String updateuserprofilename=null;
    public static String projectpath=null;
    public static User userauth=null;
    public static String spaceKey=null;
    public static String authToken=null;
    public static String emailid_admin=null;
    public static String pass_admin=null;
    public static String passworduser_admin=null;
    public static String space_admin=null;
    public static String urlcreatenewgrp=null;
    public static String newgroupid=null;
    public static String success=null;
    public static String emailidcreate=null;
    public static String newuseridfunuser=null;
    public static String emailidcreatefun=null;
    public static String usrid=null;
    public static String status=null;
    public static String nme=null;
    public static String emailID=null;
    public static String grpid=null;
    public static String statusdetialgroup=null;
    public static String namedetailgroup=null;
    public static User useradmin=null;
    public static User userauthadmin=null;
    public static String spaceKeyadmin=null;
    public static String uidadmin=null;
    public static String authTokenadmin=null;
    public static Object Modify_Document_File;
    public static Object Rename_File;
    public static Object Delete_File;
    public static Object Copy_File;
    public static Object Add_To_Favorite_File;
    public static Object Remove_From_Favorite_File;
    public static Object Properties_File;
    public static Object Share_With_File;
    public static Object Exclude_Users_File;
    public static Object Copy_To_File;
    public static Object Move_To_File;
    public static Object Create_Folder;
    public static Object Link_a_URL_Folder;
    public static Object Rename_Folder;
    public static Object Delete_Folder;
    public static Object Copy_Folder;
    public static Object Paste_Folder;
    public static Object Add_To_Favorite_Folder;
    public static Object Remove_From_Favorite_Folder;
    public static Object Create_Geospatial_Folder;
    public static Object Properties_Folder;
    public static Object Create_Story_Folder;
    public static Object Move_To_Folder;
    public static String uniqueid=null;
    public static String fulnme=null;
    public static String passnew=null;
    public static String updateusrname=null;
    public static String uniqueidupdate=null;
    public static String optypblock=null;
    public static String optypactivate=null;
    public static String optypdel=null;
    public static String optypreset=null;
    public static String activefilter=null;
    public static String blockfilter=null;
    public static String deletefilter=null;
    public static String urlgetlist=null;
    protected static String urlpermit = null;
    public static String urlgrpblock_activate;
    public static String urlgrpstatuslist;
    public static String urlusergroupdetails;
    public static String urlupdateusergroup;
    public static String optypgrpblock;
    public static String optypgrpactivate;
    public static String saveOrUpdateEmailConfSettings;

    public static String Groupnameuser=null;
    public static Object tokenval=null;
    public static Object apitoken=null;
    public static String successmenu=null;
    public static String successplugin=null;
    public static String activegrpid=null;
    public static String fullname=null;
    public static String passchanged=null;
    public static Object theme=null;
    public static String usergroupname=null;
    public   Object assignuserid=null;
    public  User userpasschange=null;
    public  User userauthpasschange=null;
    public  String spaceKeypasschange=null;
    public  String uidpasschange=null;
    public  String authTokenpasschange=null;
    public static String getuserid=null;
    public String allpermission=null;
    public static String JDBC_IP_PORT;
    public static String JDBC_DBNAME;
    public static String JDBC_USERNAME;
    public static String JDBC_Password;
    public static String ShareDataStore;
    public static String ViewDataStoreDetails;
    public static String RemoveDataStore;
    public static String EditDataStore;
    public static String CreateCAPPMWSDL;
    public static String CreateDataConnector;
    public static String CreateDataService;
    public static String ViewDataConnectorDetails;
    public static String EditDataConnector;
    public static String ShareDataService;
    public static String ViewDataServiceDetails;
    public static String RemoveDataService;
    public static String EditDataService;
    public static String CreateDataStore;
    public static String RemoveDataConnector;
    public static String ShareDataConnector;
    public static String EditCAPPMService;
    public static String RemoveCAPPMService;
    public static String ShareCAPPMService;
    public static String DataCenterperm;
    public static String Session;
    public static String SMB;
    public static String CAPPMSettings;
    public static String GeoSpatialSettings;
    public static String EmailServerSettings;
    public static String WindowsADSettings;
    public static String PredictiveSettings;
    public static String PasswordPreference;
    public static String AuditTrailSettings;
    public static String SchedulingMonitoring;
    public static String DocumentMigration;
    public static String DataManagementConfiguration;
    public static String DocumentManagement;
    public static String ServerMonitor;
    public static String AuditTrail;
    public static String Encryption;
    public static String CustomFieldSettings;
    public static String Admin;
    public static String CreateUser;
    public static String CreateUserGroup;
    public static String ViewUserDetails;
    public static String ActivateBlockUser;
    public static String ChangePassword;
    public static String RemoveUser;
    public static String EditUser;
    public static String ViewUserGroupDetails;
    public static String ActivateBlockUserGroup;
    public static String EditUserGroup;
    public static String AssignCustomField;
    public static String Userperm;
    public static String CreateGeoSpatialAnalysis;
    public static String ViewGeoSpatialAnalysisDetails;
    public static String RemoveGeoSpatialAnalysis;
    public static String EditGeoSpatialAnalysis;
    public static String GeoSpatial;
    public static String Designer;
    public static String Survey;
    public static String Sentiments;
    public static String SocialMedia;
    public static String DataPreparation;
    public static String Play;
    public static String CreateWorkSpace;
    public String custommsg=null;


    //***************************USER FUNCTIONS************************************//

    public  void createnewuser(String spaceKey,String userid,String authToken,String uniqueId,String userName,String fullName,String password,String grpID,String authtokenparam,String spacekeyparam) {

        try {
            String url = Utils.getUrl("createnewuser");
            String projecturl=Utils.getproperty("projectpath");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            .param("uniqueId", uniqueId)
                            .param("userName", userName + Helper.generateRandomString())
                            .param("fullName", fullName )
                            .param("emailID", uniqueId )
                            .param("password", password)
                            .param("projectPath", projecturl)
                            .param("selectedUserGroups[]", grpID)
                            .param("token", authtokenparam)
                            .param("spacekey", spacekeyparam)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            HashMap<String, Object> user = (HashMap) users.get("user");

            Thread.sleep(2000);
            newuseriduser = user.get("id").toString();
            message = users.get("message").toString();
            success = users.get("success").toString();
            emailidcreate=user.get("emailID").toString();

            LOGGER.info("newuseriduser" + newuseriduser);
            LOGGER.info(("createusr=" + response.asString()));

            Assert.assertNotNull(newuseriduser);
            Assert.assertNotNull(emailidcreate);
            Assert.assertEquals( message,"User created successfully!");
            Assert.assertEquals( success,"true");
        } catch (Exception e) {

            createnewuser(spaceKeyadmin, uidadmin, authTokenadmin, uniqueid + Helper.generateRandomString(), usrname, fulnme, pass_admin, "", authTokenadmin, spaceKeyadmin);

        }
    }

    public static void createnewuserFunctional(String spaceKey,String userid,String authTokenn,String uniqueId,String userName,String fullName,String password,String grpID,String authtokenparam,String spacekeyparam,Integer statuscode) {
        try {
            Thread.sleep(2000);
            String url = Utils.getUrl("createnewuser");
            String projecturl=Utils.getproperty("projectpath");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authTokenn)
                            .param("uniqueId", uniqueId)
                            .param("userName", userName + Helper.generateRandomString())
                            .param("fullName", fullName )
                            .param("emailID", uniqueId )
                            .param("password", password)
                            .param("projectPath", projecturl)
                            .param("selectedUserGroups[]", grpID)
                            .param("token", authtokenparam)
                            .param("spacekey", spacekeyparam)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("users");
                HashMap<String, Object> user = (HashMap) users.get("user");
                Thread.sleep(2000);
                newuseridfunuser = user.get("id").toString();
                emailidcreatefun = user.get("emailID").toString();

                LOGGER.info("newuseriduser" + newuseridfunuser);
                LOGGER.info(("createusr=" + response.asString()));

                Assert.assertNotNull(newuseridfunuser);
                if(newuseridfunuser==null){
                    createnewuserFunctional(spaceKey, uid, authToken, uniqueid + Helper.generateRandomString(), usrname, fulnme, pass_admin, "", authToken, spaceKey, HttpStatus.SC_OK);
                }
                Assert.assertNotNull(emailidcreatefun);
                Assert.assertNotEquals(newuseridfunuser,"null");
            }
        } catch (Exception e) {
            createnewuserFunctional(spaceKey, uid, authToken, uniqueid + Helper.generateRandomString(), usrname, fulnme, pass_admin, "", authToken, spaceKey, HttpStatus.SC_OK);
                    }
    }

    public static void getUserInfoByToken(String authToken,Integer statuscode) {
        try {
            String url = Utils.getUrl("getUserInfoByToken");
            Response response =
                    given().param("token", authToken)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("users");
                HashMap<String, Object> user = (HashMap) users.get("user");
                List<HashMap<String, Object>> permission = (ArrayList<HashMap<String, Object>>) users.get("permissions");

                HashMap<String, Object> preference = (HashMap) users.get("preference");
                HashMap<String, Object> userID = (HashMap) preference.get("userID");

                tokenval = users.get("authToken");

                apitoken = userID.get("apiToken");
                LOGGER.info(("getusrinfobytoken=" + response.asString()));
                Assert.assertEquals(users.get("success").toString(),"true");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //This service is called just after login
    public static void getMenuPermissionForUser(String uidnew,String authtoknew) {
        try {
            String url = Utils.getUrl("getmenupermissionforuser");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userID", uidnew)
                            .header("authToken", authtoknew)
                            .param("token", authtoknew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> getmenupermissionforuser = from(response.asString()).get("");
            HashMap<String, Object> getmenupermissionforusersucess = (HashMap)getmenupermissionforuser.get("menuContext");

            successmenu=getmenupermissionforusersucess.get("success").toString();
            LOGGER.info(("getmenupermissionforuser=" + response.asString()));

            Assert.assertEquals(successmenu,"true");

            String menujson="{menuContext={success=true, fileMenuContexts=[], folderMenuContexts=[], menuContexts=[]}}";

            //Conversion of Hashmap to Permission form
            JSONObject menuobjjson = new JSONObject();
            menuobjjson.putAll(getmenupermissionforuser);

            //Json validation
            Assert.assertEquals(getmenupermissionforuser.toString(),menujson.toString());

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //This service is called just after login for Notification
    public static void pluginServiceLogin(String uidnew,String authtoknew,Integer statuscode ) {
        try {

            String url = Utils.getUrl("pluginServiceLogin");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userID", uidnew)
                            .header("authToken", authtoknew)
                            .param("token", authtoknew)
                            .param("spacekey", spaceKey)
                            .param("consumerName", Utils.getproperty("consumerNameLogin"))
                            .param("serviceName", Utils.getproperty("serviceNameLogin"))
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> pluginServiceLogin = from(response.asString()).get("");

                successplugin = pluginServiceLogin.get("success").toString();
                LOGGER.info(("pluginServiceLogin=" + response.asString()));

                Assert.assertEquals(successplugin, "true");

               /* String menujson = "{\"notificationList\":[],\"notificationMessages\":null,\"success\":true,\"errorMessage\":null,\"errorCode\":null,\"stackTrace\":null,\"message\":null,\"notifications\":null,\"messageNotificationList\":[]}";

                //Conversion of Hashmap to Permission form
                JSONObject menuobjjson = new JSONObject();
                menuobjjson.putAll(pluginServiceLogin);

                //Json validation
                Assert.assertEquals(menuobjjson.toString(), menujson.toString());*/
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public static void updateProfile(String spaceKey,String userid,String authToken,String uniqueId,String userName,String fullName,String password,String userID,String authtokenparam,String spacekeyparam,Integer statuscode){
        String url = Utils.getUrl("updatecreateuser");
        String projecturl=Utils.getproperty("projectpath");
        String customproperties="[{\"key\":\"manager\",\"value\":\""+Utils.getproperty("")+"\"}]";

        //Response data for Updateuser
        Response response =
                given()
                        .header("spaceKey", spaceKey)
                        .header("userid", userid)
                        .header("authToken", authToken)
                        .param("uniqueId", uniqueId )
                        .param("userName", userName + Helper.generateRandomString())
                        .param("fullName", fullName)
                        .param("emailID", uniqueId )
                        .param("password", password)
                        .param("userID", userID)
                        .param("projectPath", projecturl)
                        .param("description", Utils.getproperty("description"))
                        .param("address", Utils.getproperty("address"))
                        .param("mobileNumber", Utils.getproperty("mobileno"))
                        .param("landNumber", Utils.getproperty("landlineno"))
                        .param("country", Utils.getproperty("country"))
                        .param("state", Utils.getproperty("state"))
                        .param("city", Utils.getproperty("city"))
                        .param("pincode", Utils.getproperty("pincode"))
                        .param("customproperties", customproperties)

                        .param("token", authtokenparam)
                        .param("spacekey", spacekeyparam)
                        .when()
                        .post(url)
                        .then()
                        .assertThat()
                        .statusCode(statuscode)
                        .extract().response();
        if (statuscode==305){

            Assert.assertEquals(statuscode.intValue(),305);

        }
        else {
            HashMap<String, Object> users = from(response.asString()).get("users");
            HashMap<String, Object> user = (HashMap) users.get("user");
            Integer upid = (Integer) user.get("id");

            Assert.assertNotNull(upid);

            message = users.get("message").toString();
            success = users.get("success").toString();
            emailID = user.get("emailID").toString();

            Assert.assertEquals(message, "User updated successfully!");
            Assert.assertEquals(success, "true");

            LOGGER.info(("updateusr=" + response.asString()));
        }
    }

    public static void blockuser(String spaceKey,String userid,String authToken,String userID,String operationType,String authTokenparam,String spaceKeyparam,Integer statuscode) {
        try {
            LOGGER.info("BLOCKID=====" + newuseridfunuser);
            String url = Utils.getUrl("blockuser");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            .param("userID", userID)
                            .param("operationType", operationType)
                            .param("token", authTokenparam)
                            .param("spacekey", spaceKeyparam)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("users");
                message = users.get("message").toString();
                success = users.get("success").toString();
                Assert.assertEquals(message, "User blocked successfully!");
                Assert.assertEquals(success, "true");
                LOGGER.info(("blockusr=" + response.asString()));
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public static void deleteuser(String spaceKey,String userid,String authToken,String userID,String operationType,String authTokenparam,String spaceKeyparam,Integer statuscode) {
        try {
            String url = Utils.getUrl("removeuser");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            .param("userID", userID)
                            .param("operationType", operationType)
                            .param("token", authTokenparam)
                            .param("spacekey", spaceKeyparam)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("users");
                message = users.get("message").toString();
                success = users.get("success").toString();
                Assert.assertEquals(message, "User deleted successfully!");
                Assert.assertEquals(success, "true");
                LOGGER.info(("Delusr=" + response.asString()));
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public static void activateuser(String spaceKey,String userid,String authToken,String userID,String operationType,String authTokenparam,String spaceKeyparam,Integer statuscode) {
        try {
            String url = Utils.getUrl("activateuser");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            .param("userID", userID)
                            .param("operationType", operationType)
                            .param("token", authTokenparam)
                            .param("spacekey", spaceKeyparam)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("users");
                message = users.get("message").toString();
                success = users.get("success").toString();
                Assert.assertEquals(message, "User activated successfully!");
                Assert.assertEquals(success, "true");
                LOGGER.info(("activateusr=" + response.asString()));
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void getuserlist(String spaceKey,String userid,String authToken,String from,String rows,String userFilter,String authTokenparam,String spaceKeyparam,Integer statuscode ) {
        try {
            String url = Utils.getUrl("getuserlist");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            .param("from", from)
                            .param("rows", rows)
                            .param("userFilter", userFilter)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();

            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("users");
                List<HashMap<String, Object>> user = (ArrayList<HashMap<String, Object>>) users.get("users");
                List<Integer> ids = from(response.asString()).get("users.users.id");
                for (Integer id : ids) {
                    Assert.assertNotNull(id);
                }
                for (HashMap<String, Object> userId : user) {
                    if (userId.containsKey("fullName") && userId.get("fullName").toString().equals("RestAutomation")) {
                        usrid = userId.get("id").toString();
                        status = userId.get("status").toString();
                        nme = userId.get("fullName").toString();
                    }
                }
                getuserid = user.get(0).get("id").toString();
                LOGGER.info("usrid===" + usrid);
                Assert.assertEquals(users.get("success").toString(), "true");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public  void getuserlistDel(String spaceKey,String userid,String authToken,String from,String rows,String userFilter,String authTokenparam,String spaceKeyparam,Integer statuscode ) {
        try {
            String url = Utils.getUrl("getuserlist");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            .param("from", from)
                            .param("rows", rows)
                            .param("userFilter", userFilter)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();

            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("users");
                List<HashMap<String, Object>> user = (ArrayList<HashMap<String, Object>>) users.get("users");
                List<Integer> ids = from(response.asString()).get("users.users.id");
                for (Integer id : ids) {
                    Assert.assertNotNull(id);
                }
                for (HashMap<String, Object> userId : user) {
                    if (userId.containsKey("fullName") && userId.get("fullName").toString().equals("RestAutomation")) {
                        usrid = userId.get("id").toString();
                        status = userId.get("status").toString();
                        nme = userId.get("fullName").toString();
                        deleteuser(spaceKeyadmin,uidadmin,authTokenadmin,usrid,optypdel,authTokenadmin,spaceKeyadmin,HttpStatus.SC_OK);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }    }

    public static void resetpassword(String spaceKey,String userid,String authToken,String userID,String operationType,String authTokenparam,String spaceKeyparam,Integer statuscode) {
        try {
            String url = Utils.getUrl("resetuser");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            .param("userID", userID)
                            .param("operationType", operationType)
                            .param("token", authTokenparam)
                            .param("spacekey", spaceKeyparam)
                            .param("projectPath", projectpath)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("users");
                message = users.get("message").toString();
                success = users.get("success").toString();
                Assert.assertEquals(message, "Reset password sent successfully to the registered user email");
                Assert.assertEquals(success, "true");
                LOGGER.info(("resetpasswrd=" + response.asString()));
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void getAllChildPermission(String spaceKey,String userid,String authToken,Integer statuscode) {
        try {
            Response responsepermit =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpermit)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);
            }
            else {
                HashMap<String, Object> userspermit = from(responsepermit.asString()).get("permissions");
                List<HashMap<String, Object>> userspermituser = (ArrayList<HashMap<String, Object>>) userspermit.get("permissionsList");

                org.json.JSONArray servicepermission=new org.json.JSONArray(userspermituser);

                allpermission=servicepermission.toString();
                LOGGER.info(("getallchildpermsn=" + responsepermit.asString()));

            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    //***************************USERGROUP FUNCTIONS***************************//

    //Folder&File Permission
    public static void getAllMenuContext(String spaceKey, String uidnew,String authtoknew) {
        try {

            String url = Utils.getUrl("getAllMenuContext");
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", uidnew)
                            .header("authtoken", authtoknew)
                            .param("token", authtoknew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> menuContextAll = from(response.asString()).get("");
            HashMap<String,Object> menuContext = (HashMap)menuContextAll.get("menuContext");
            List<HashMap<String, Object>> fileMenuContexts = (ArrayList<HashMap<String, Object>>) menuContext.get("fileMenuContexts");
            List<HashMap<String, Object>> folderMenuContexts = (ArrayList<HashMap<String, Object>>) menuContext.get("folderMenuContexts");

            Modify_Document_File=fileMenuContexts.get(0).get("id");
            Rename_File=fileMenuContexts.get(1).get("id");
            Delete_File=fileMenuContexts.get(2).get("id");
            Copy_File=fileMenuContexts.get(3).get("id");
            Add_To_Favorite_File=fileMenuContexts.get(4).get("id");
            Remove_From_Favorite_File=fileMenuContexts.get(5).get("id");
            Properties_File=fileMenuContexts.get(6).get("id");
            Share_With_File=fileMenuContexts.get(7).get("id");
            Exclude_Users_File=fileMenuContexts.get(8).get("id");
            Copy_To_File=fileMenuContexts.get(9).get("id");
            Move_To_File=fileMenuContexts.get(10).get("id");

            Create_Folder=folderMenuContexts.get(0).get("id");
            Link_a_URL_Folder=folderMenuContexts.get(1).get("id");
            Rename_Folder=folderMenuContexts.get(2).get("id");
            Delete_Folder=folderMenuContexts.get(3).get("id");
            Copy_Folder=folderMenuContexts.get(4).get("id");
            Paste_Folder=folderMenuContexts.get(5).get("id");
            Add_To_Favorite_Folder=folderMenuContexts.get(6).get("id");
            Remove_From_Favorite_Folder=folderMenuContexts.get(7).get("id");
            Create_Geospatial_Folder=folderMenuContexts.get(8).get("id");
            Properties_Folder=folderMenuContexts.get(9).get("id");
            Create_Story_Folder=folderMenuContexts.get(10).get("id");
            Move_To_Folder=folderMenuContexts.get(11).get("id");

            Assert.assertEquals(menuContext.get("success").toString(),"true");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public static void createnewGroupPerm(String spacekey,String userID,String authtoken,String groupName,String userId,Integer statuscode) {
        try {
            Thread.sleep(2000);
            urlcreatenewgrp = Utils.getUrl("createnewgrp");
            Response response =
                    given()
                            .header("spacekey", spacekey)
                            .header("userID", userID)
                            .header("authtoken", authtoken)
                            .param("groupName", groupName+ Helper.generateRandomString())
                            .param("addedPermissions[]",  Userperm)
                            .param("addedPermissions[]",  AssignCustomField)
                            .param("addedPermissions[]",  EditUserGroup)
                            .param("addedPermissions[]",  ActivateBlockUserGroup)
                            .param("addedPermissions[]",  ViewUserGroupDetails)
                            .param("addedPermissions[]",  EditUser)
                            .param("addedPermissions[]",  RemoveUser)
                            .param("addedPermissions[]",  ChangePassword)
                            .param("addedPermissions[]",  ActivateBlockUser)
                            .param("addedPermissions[]",  ViewUserDetails)
                            .param("addedPermissions[]",  CreateUserGroup)
                            .param("addedPermissions[]",  CreateUser)

                            .param("addedPermissions[]",  DataCenterperm)
                            .param("addedPermissions[]",  ShareCAPPMService)
                            .param("addedPermissions[]",  RemoveCAPPMService)
                            .param("addedPermissions[]",  EditCAPPMService)
                            .param("addedPermissions[]",  ShareDataConnector)
                            .param("addedPermissions[]",  RemoveDataConnector)
                            .param("addedPermissions[]",  CreateDataStore)
                            .param("addedPermissions[]",  EditDataService)
                            .param("addedPermissions[]",  RemoveDataService)
                            .param("addedPermissions[]",  ViewDataServiceDetails)
                            .param("addedPermissions[]",  ShareDataService)
                            .param("addedPermissions[]",  EditDataConnector)
                            .param("addedPermissions[]",  ViewDataConnectorDetails)
                            .param("addedPermissions[]",  CreateDataService)
                            .param("addedPermissions[]",  CreateDataConnector)
                            .param("addedPermissions[]",  CreateCAPPMWSDL)
                            .param("addedPermissions[]",  EditDataStore)
                            .param("addedPermissions[]",  RemoveDataStore)
                            .param("addedPermissions[]",  ViewDataStoreDetails)
                            .param("addedPermissions[]",  ShareDataStore)

                            .param("addedPermissions[]",  Admin)
                            .param("addedPermissions[]",  CustomFieldSettings)
                            .param("addedPermissions[]",  Encryption)
                            .param("addedPermissions[]",  AuditTrail)
                            .param("addedPermissions[]",  ServerMonitor)
                            .param("addedPermissions[]",  DocumentManagement)
                            .param("addedPermissions[]",  DataManagementConfiguration)
                            .param("addedPermissions[]",  DocumentMigration)
                            .param("addedPermissions[]",  SchedulingMonitoring)
                            .param("addedPermissions[]",  AuditTrailSettings)
                            .param("addedPermissions[]",  PasswordPreference)
                            .param("addedPermissions[]",  PredictiveSettings)
                            .param("addedPermissions[]",  WindowsADSettings)
                            .param("addedPermissions[]",  EmailServerSettings)
                            .param("addedPermissions[]",  GeoSpatialSettings)
                            .param("addedPermissions[]",  CAPPMSettings)
                            .param("addedPermissions[]",  Session)
                            .param("addedPermissions[]",  SMB)

                            .param("addedPermissions[]",  GeoSpatial)
                            .param("addedPermissions[]",  EditGeoSpatialAnalysis)
                            .param("addedPermissions[]",  RemoveGeoSpatialAnalysis)
                            .param("addedPermissions[]",  ViewGeoSpatialAnalysisDetails)
                            .param("addedPermissions[]",  CreateGeoSpatialAnalysis)

                            .param("addedPermissions[]",  Designer)
                            .param("addedPermissions[]",  CreateWorkSpace)

                            .param("addedPermissions[]",  Utils.getproperty("Predictive"))
                            .param("addedPermissions[]",  Utils.getproperty("Share Custom Python script"))
                            .param("addedPermissions[]",  Utils.getproperty("View Custom Python Script"))
                            .param("addedPermissions[]",  Utils.getproperty("Edit Custom Python Script"))
                            .param("addedPermissions[]",  Utils.getproperty("created Custom Python script available to user"))
                            .param("addedPermissions[]",  Utils.getproperty("created custom Python script available to group"))
                            .param("addedPermissions[]",  Utils.getproperty("Create Custom Python Script"))
                            .param("addedPermissions[]",  Utils.getproperty("Share Custom Scala script"))
                            .param("addedPermissions[]",  Utils.getproperty("View Custom Scala Script"))
                            .param("addedPermissions[]",  Utils.getproperty("Edit Custom Scala Script"))
                            .param("addedPermissions[]",  Utils.getproperty("Create Custom Scala Script"))
                            .param("addedPermissions[]",  Utils.getproperty("created custom Scala script available to group"))
                            .param("addedPermissions[]",  Utils.getproperty("created Custom Scala script available to user"))
                            .param("addedPermissions[]",  Utils.getproperty("Deploy Workflow"))
                            .param("addedPermissions[]",  Utils.getproperty("Share Custom R script"))
                            .param("addedPermissions[]",  Utils.getproperty("created custom R script available to group"))
                            .param("addedPermissions[]",  Utils.getproperty("created Custom R script available to user"))
                            .param("addedPermissions[]",  Utils.getproperty("Live Job Status of Spark"))
                            .param("addedPermissions[]",  Utils.getproperty("Share Model"))
                            .param("addedPermissions[]",  Utils.getproperty("View Model"))
                            .param("addedPermissions[]",  Utils.getproperty("Save Model"))
                            .param("addedPermissions[]",  Utils.getproperty("View Custom R Script"))
                            .param("addedPermissions[]",  Utils.getproperty("Edit Custom R Script"))
                            .param("addedPermissions[]",  Utils.getproperty("Create Custom R Script"))
                            .param("addedPermissions[]",  Utils.getproperty("Share Workflow"))
                            .param("addedPermissions[]",  Utils.getproperty("View Workflow"))
                            .param("addedPermissions[]",  Utils.getproperty("Edit Workflow"))
                            .param("addedPermissions[]",  Utils.getproperty("Created Workflow Available to Group"))
                            .param("addedPermissions[]",  Utils.getproperty("Created Workflow Available to User"))
                            .param("addedPermissions[]",  Utils.getproperty("Create Workflow"))
                            .param("addedPermissions[]",  Utils.getproperty("View Schedule Job"))
                            .param("addedPermissions[]",  Utils.getproperty("Edit Schedule Job"))
                            .param("addedPermissions[]",  Utils.getproperty("Create Schedule Job"))

                            .param("addedPermissions[]",  Survey)

                            .param("addedPermissions[]",  Sentiments)

                            .param("addedPermissions[]",  SocialMedia)

                            .param("addedPermissions[]",  DataPreparation)

                            .param("addedPermissions[]",  Play)

                            .param("menuPermissions[]",  Create_Folder)
                            .param("menuPermissions[]",  Link_a_URL_Folder)
                            .param("menuPermissions[]",  Rename_Folder)
                            .param("menuPermissions[]",  Delete_Folder)
                            .param("menuPermissions[]",  Copy_Folder)
                            .param("menuPermissions[]",  Paste_Folder)
                            .param("menuPermissions[]",  Add_To_Favorite_Folder)
                            .param("menuPermissions[]",  Remove_From_Favorite_Folder)
                            .param("menuPermissions[]",  Create_Geospatial_Folder)
                            .param("menuPermissions[]",  Properties_Folder)
                            .param("menuPermissions[]",  Create_Story_Folder)
                            .param("menuPermissions[]",  Move_To_Folder)

                            .param("menuPermissions[]",  Modify_Document_File)
                            .param("menuPermissions[]",  Rename_File)
                            .param("menuPermissions[]",  Delete_File)
                            .param("menuPermissions[]",  Copy_File)
                            .param("menuPermissions[]",  Add_To_Favorite_File)
                            .param("menuPermissions[]",  Remove_From_Favorite_File)
                            .param("menuPermissions[]",  Properties_File)
                            .param("menuPermissions[]", Share_With_File)
                            .param("menuPermissions[]",  Exclude_Users_File)
                            .param("menuPermissions[]", Copy_To_File)
                            .param("menuPermissions[]",  Move_To_File)
                            .param("token", authtoken)
                            .param("spacekey", spacekey)
                            .param("userIDs[]", userId)
                            .when()
                            .post(urlcreatenewgrp)
                            .then()
                            .assertThat()
                            .statusCode( statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                LOGGER.info("response" + response.asString());
                Thread.sleep(1000);
                HashMap<String, Object> users = from(response.asString()).get("userGroups");
                HashMap<String, Object> user = (HashMap) users.get("userGroup");

                Thread.sleep(2000);
                newgroupid = user.get("id").toString();
                message = users.get("message").toString();
                success = users.get("success").toString();
                usergroupname=user.get("name").toString();
                Assert.assertEquals(message, "Group added successfully!");
                Assert.assertEquals(success, "true");
                LOGGER.info(("createnewgrp=" + response.asString()));
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public static void getusergrouplist(String spaceKey,String userid,String authToken,String page,String rows,String userFilter,String authTokenparam,String spaceKeyparam,Integer statuscode) {
        try {
            String urlusergrouplist = Utils.getUrl("getusergrouplist");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            .param("page", page)
                            .param("rows", rows)
                            .param("userFilter", userFilter)
                            .param("token", authTokenparam)
                            .param("spacekey", spaceKeyparam)
                            .when()
                            .post(urlusergrouplist)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("userGroups");
                List<HashMap<String, Object>> user = (ArrayList<HashMap<String, Object>>) users.get("userGroupsList");

                List<Integer> ids = from(response.asString()).get("userGroups.userGroupsList.id");
                for (Integer id : ids) {
                    Assert.assertNotNull(id);
                }
                grpid = user.get(0).get("id").toString();
                Assert.assertEquals(users.get("success").toString(), "true");
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public static void blockgroup(String spaceKey,String userid,String authToken,String groupID,String operationType,String authTokenparam,String spaceKeyparam,Integer statuscode) {
        try {
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            .param("groupID", groupID)
                            .param("operationType", operationType)
                            .param("token", authTokenparam)
                            .param("spacekey", spaceKeyparam)
                            .when()
                            .post(urlgrpblock_activate)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("userGroups");
                message = users.get("message").toString();
                success = users.get("success").toString();
                Assert.assertEquals(message, "User Group Blocked!");
                Assert.assertEquals(success, "true");
                LOGGER.info(("blockgrp=" + response.asString()));
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public static void activategroup(String spaceKey,String userid,String authToken,String groupID,String operationType,String authTokenparam,String spaceKeyparam,Integer statuscode) {
        try {
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            .param("groupID", groupID)
                            .param("operationType", operationType)
                            .param("token", authTokenparam)
                            .param("spacekey", spaceKeyparam)
                            .when()
                            .post(urlgrpblock_activate)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("userGroups");
                message = users.get("message").toString();
                success = users.get("success").toString();
                Assert.assertEquals(message, "User Group Activated!");
                Assert.assertEquals(success, "true");
                LOGGER.info(("activategrp=" + response.asString()));
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void updateusergroupDataCenter(String spaceKey,String userid,String authToken,String groupName,Object menuPermissionsfoler,Object menuPermissionsfile,String groupID,String authTokenparam,String spaceKeyparam,String userIDs,Integer statuscode ) {
        try {
            urlupdateusergroup = Utils.getUrl("updateusergroup");

            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", userid)
                            .header("authtoken", authToken)
                            .param("groupName", groupName + Helper.generateRandomString())
                            .param("addedPermissions[]",  DataCenterperm)
                            .param("addedPermissions[]",  ShareCAPPMService)
                            .param("addedPermissions[]",  RemoveCAPPMService)
                            .param("addedPermissions[]",  EditCAPPMService)
                            .param("addedPermissions[]",  ShareDataConnector)
                            .param("addedPermissions[]",  RemoveDataConnector)
                            .param("addedPermissions[]",  CreateDataStore)
                            .param("addedPermissions[]",  EditDataService)
                            .param("addedPermissions[]",  RemoveDataService)
                            .param("addedPermissions[]",  ViewDataServiceDetails)
                            .param("addedPermissions[]",  ShareDataService)
                            .param("addedPermissions[]",  EditDataConnector)
                            .param("addedPermissions[]",  ViewDataConnectorDetails)
                            .param("addedPermissions[]",  CreateDataService)
                            .param("addedPermissions[]",  CreateDataConnector)
                            .param("addedPermissions[]",  CreateCAPPMWSDL)
                            .param("addedPermissions[]",  EditDataStore)
                            .param("addedPermissions[]",  RemoveDataStore)
                            .param("addedPermissions[]",  ViewDataStoreDetails)
                            .param("addedPermissions[]",  ShareDataStore)
                            .param("menuPermissions[]",  menuPermissionsfoler)
                            .param("menuPermissions[]",  menuPermissionsfile)
                            .param("spacekey", spaceKeyparam)
                            .param("groupID", groupID)
                            .param("userIDs[]", userIDs)
                            .when()
                            .post(urlupdateusergroup)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("userGroups");
                message = users.get("message").toString();
                success = users.get("success").toString();
                Assert.assertEquals(message, "Group updated successfully!");
                Assert.assertEquals(success, "true");
                LOGGER.info(("updateusrgrp=" + response.asString()));
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void updateusergroupAdmin(String spaceKey,String userid,String authToken,String groupName,Object menuPermissionsfoler,Object menuPermissionsfile,String groupID,String authTokenparam,String spaceKeyparam,String userIDs,Integer statuscode ) {
        try {
            urlupdateusergroup = Utils.getUrl("updateusergroup");

            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", userid)
                            .header("authtoken", authToken)
                            .param("groupName", groupName + Helper.generateRandomString())
                            .param("addedPermissions[]",  Admin)
                            .param("addedPermissions[]",  CustomFieldSettings)
                            .param("addedPermissions[]",  Encryption)
                            .param("addedPermissions[]",  AuditTrail)
                            .param("addedPermissions[]",  ServerMonitor)
                            .param("addedPermissions[]",  DocumentManagement)
                            .param("addedPermissions[]",  DataManagementConfiguration)
                            .param("addedPermissions[]",  DocumentMigration)
                            .param("addedPermissions[]",  SchedulingMonitoring)
                            .param("addedPermissions[]",  AuditTrailSettings)
                            .param("addedPermissions[]",  PasswordPreference)
                            .param("addedPermissions[]",  PredictiveSettings)
                            .param("addedPermissions[]",  WindowsADSettings)
                            .param("addedPermissions[]",  EmailServerSettings)
                            .param("addedPermissions[]",  GeoSpatialSettings)
                            .param("addedPermissions[]",  CAPPMSettings)
                            .param("addedPermissions[]",  Session)
                            .param("addedPermissions[]",  SMB)
                            .param("menuPermissions[]",  menuPermissionsfoler)
                            .param("menuPermissions[]",  menuPermissionsfile)
                            .param("spacekey", spaceKeyparam)
                            .param("groupID", groupID)
                            .param("userIDs[]", userIDs)
                            .when()
                            .post(urlupdateusergroup)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("userGroups");
                message = users.get("message").toString();
                success = users.get("success").toString();
                Assert.assertEquals(message, "Group updated successfully!");
                Assert.assertEquals(success, "true");
                LOGGER.info(("updateusrgrp=" + response.asString()));
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void updateusergroupUser(String spaceKey,String userid,String authToken,String groupName,Object menuPermissionsfoler,Object menuPermissionsfile,String groupID,String authTokenparam,String spaceKeyparam,String userIDs,Integer statuscode ) {
        try {
            urlupdateusergroup = Utils.getUrl("updateusergroup");

            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", userid)
                            .header("authtoken", authToken)
                            .param("groupName", groupName + Helper.generateRandomString())
                            .param("addedPermissions[]",  Userperm)
                            .param("addedPermissions[]",  AssignCustomField)
                            .param("addedPermissions[]",  EditUserGroup)
                            .param("addedPermissions[]",  ActivateBlockUserGroup)
                            .param("addedPermissions[]",  ViewUserGroupDetails)
                            .param("addedPermissions[]",  EditUser)
                            .param("addedPermissions[]",  RemoveUser)
                            .param("addedPermissions[]",  ChangePassword)
                            .param("addedPermissions[]",  ActivateBlockUser)
                            .param("addedPermissions[]",  ViewUserDetails)
                            .param("addedPermissions[]",  CreateUserGroup)
                            .param("addedPermissions[]",  CreateUser)
                            .param("menuPermissions[]",  menuPermissionsfoler)
                            .param("menuPermissions[]",  menuPermissionsfile)
                            .param("spacekey", spaceKeyparam)
                            .param("groupID", groupID)
                            .param("userIDs[]", userIDs)
                            .when()
                            .post(urlupdateusergroup)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();

            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("userGroups");
                message = users.get("message").toString();
                success = users.get("success").toString();
                Assert.assertEquals(message, "Group updated successfully!");
                Assert.assertEquals(success, "true");
                LOGGER.info(("updateusrgrp=" + response.asString()));
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void updateusergroupPlay(String spaceKey,String userid,String authToken,String groupName,Object menuPermissionsfoler,Object menuPermissionsfile,String groupID,String authTokenparam,String spaceKeyparam,String userIDs,Integer statuscode ) {
        try {
            urlupdateusergroup = Utils.getUrl("updateusergroup");

            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", userid)
                            .header("authtoken", authToken)
                            .param("groupName", groupName + Helper.generateRandomString())
                            .param("addedPermissions[]",  Play)
                            .param("menuPermissions[]",  menuPermissionsfoler)
                            .param("menuPermissions[]",  menuPermissionsfile)
                            .param("spacekey", spaceKeyparam)
                            .param("groupID", groupID)
                            .param("userIDs[]", userIDs)
                            .when()
                            .post(urlupdateusergroup)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("userGroups");
                message = users.get("message").toString();
                success = users.get("success").toString();
                Assert.assertEquals(message, "Group updated successfully!");
                Assert.assertEquals(success, "true");
                LOGGER.info(("updateusrgrp=" + response.asString()));
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void updateusergroupSurvey(String spaceKey,String userid,String authToken,String groupName,Object menuPermissionsfoler,Object menuPermissionsfile,String groupID,String authTokenparam,String spaceKeyparam,String userIDs,Integer statuscode ) {
        try {
            urlupdateusergroup = Utils.getUrl("updateusergroup");

            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", userid)
                            .header("authtoken", authToken)
                            .param("groupName", groupName + Helper.generateRandomString())
                            .param("addedPermissions[]",  Survey)
                            .param("menuPermissions[]",  menuPermissionsfoler)
                            .param("menuPermissions[]",  menuPermissionsfile)
                            .param("spacekey", spaceKeyparam)
                            .param("groupID", groupID)
                            .param("userIDs[]", userIDs)
                            .when()
                            .post(urlupdateusergroup)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("userGroups");
                message = users.get("message").toString();
                success = users.get("success").toString();
                Assert.assertEquals(message, "Group updated successfully!");
                Assert.assertEquals(success, "true");
                LOGGER.info(("updateusrgrp=" + response.asString()));
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void updateusergroupSMB(String spaceKey,String userid,String authToken,String groupName,Object menuPermissionsfoler,Object menuPermissionsfile,String groupID,String authTokenparam,String spaceKeyparam,String userIDs,Integer statuscode ) {
        try {
            urlupdateusergroup = Utils.getUrl("updateusergroup");

            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", userid)
                            .header("authtoken", authToken)
                            .param("groupName", groupName + Helper.generateRandomString())
                            .param("addedPermissions[]",  SocialMedia)
                            .param("menuPermissions[]",  menuPermissionsfoler)
                            .param("menuPermissions[]",  menuPermissionsfile)
                            .param("spacekey", spaceKeyparam)
                            .param("groupID", groupID)
                            .param("userIDs[]", userIDs)
                            .when()
                            .post(urlupdateusergroup)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("userGroups");
                message = users.get("message").toString();
                success = users.get("success").toString();
                Assert.assertEquals(message, "Group updated successfully!");
                Assert.assertEquals(success, "true");
                LOGGER.info(("updateusrgrp=" + response.asString()));
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void updateusergroupSentiment(String spaceKey,String userid,String authToken,String groupName,Object menuPermissionsfoler,Object menuPermissionsfile,String groupID,String authTokenparam,String spaceKeyparam,String userIDs,Integer statuscode ) {
        try {
            urlupdateusergroup = Utils.getUrl("updateusergroup");

            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", userid)
                            .header("authtoken", authToken)
                            .param("groupName", groupName + Helper.generateRandomString())
                            .param("addedPermissions[]",  Sentiments)
                            .param("menuPermissions[]",  menuPermissionsfoler)
                            .param("menuPermissions[]",  menuPermissionsfile)
                            .param("spacekey", spaceKeyparam)
                            .param("groupID", groupID)
                            .param("userIDs[]", userIDs)
                            .when()
                            .post(urlupdateusergroup)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("userGroups");
                message = users.get("message").toString();
                success = users.get("success").toString();
                Assert.assertEquals(message, "Group updated successfully!");
                Assert.assertEquals(success, "true");
                LOGGER.info(("updateusrgrp=" + response.asString()));
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void updateusergroupDesigner(String spaceKey,String userid,String authToken,String groupName,Object menuPermissionsfoler,Object menuPermissionsfile,String groupID,String authTokenparam,String spaceKeyparam,String userIDs,Integer statuscode ) {
        try {
            urlupdateusergroup = Utils.getUrl("updateusergroup");

            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", userid)
                            .header("authtoken", authToken)
                            .param("groupName", groupName + Helper.generateRandomString())
                            .param("addedPermissions[]",  Designer)
                            .param("addedPermissions[]",  CreateWorkSpace)
                            .param("menuPermissions[]",  menuPermissionsfoler)
                            .param("menuPermissions[]",  menuPermissionsfile)
                            .param("spacekey", spaceKeyparam)
                            .param("groupID", groupID)
                            .param("userIDs[]", userIDs)
                            .when()
                            .post(urlupdateusergroup)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("userGroups");
                message = users.get("message").toString();
                success = users.get("success").toString();
                Assert.assertEquals(message, "Group updated successfully!");
                Assert.assertEquals(success, "true");
                LOGGER.info(("updateusrgrp=" + response.asString()));
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void updateusergroupETL(String spaceKey,String userid,String authToken,String groupName,Object menuPermissionsfoler,Object menuPermissionsfile,String groupID,String authTokenparam,String spaceKeyparam,String userIDs,Integer statuscode ) {
        try {
            urlupdateusergroup = Utils.getUrl("updateusergroup");

            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", userid)
                            .header("authtoken", authToken)
                            .param("groupName", groupName + Helper.generateRandomString())
                            .param("addedPermissions[]",  DataPreparation)
                            .param("menuPermissions[]",  menuPermissionsfoler)
                            .param("menuPermissions[]",  menuPermissionsfile)
                            .param("spacekey", spaceKeyparam)
                            .param("groupID", groupID)
                            .param("userIDs[]", userIDs)
                            .when()
                            .post(urlupdateusergroup)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("userGroups");
                message = users.get("message").toString();
                success = users.get("success").toString();
                Assert.assertEquals(message, "Group updated successfully!");
                Assert.assertEquals(success, "true");
                LOGGER.info(("updateusrgrp=" + response.asString()));
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void updateusergroupGeo(String spaceKey,String userid,String authToken,String groupName,Object menuPermissionsfoler,Object menuPermissionsfile,String groupID,String authTokenparam,String spaceKeyparam,String userIDs,Integer statuscode ) {
        try {
            urlupdateusergroup = Utils.getUrl("updateusergroup");

            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", userid)
                            .header("authtoken", authToken)
                            .param("groupName", groupName + Helper.generateRandomString())
                            .param("addedPermissions[]",  GeoSpatial)
                            .param("addedPermissions[]",  EditGeoSpatialAnalysis)
                            .param("addedPermissions[]",  RemoveGeoSpatialAnalysis)
                            .param("addedPermissions[]",  ViewGeoSpatialAnalysisDetails)
                            .param("addedPermissions[]",  CreateGeoSpatialAnalysis)
                            .param("menuPermissions[]",  menuPermissionsfoler)
                            .param("menuPermissions[]",  menuPermissionsfile)
                            .param("spacekey", spaceKeyparam)
                            .param("groupID", groupID)
                            .param("userIDs[]", userIDs)
                            .when()
                            .post(urlupdateusergroup)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("userGroups");
                message = users.get("message").toString();
                success = users.get("success").toString();
                Assert.assertEquals(message, "Group updated successfully!");
                Assert.assertEquals(success, "true");
                LOGGER.info(("updateusrgrp=" + response.asString()));
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Give the detail of particular usergroup,assigned user and list of users(used in usergroupflow)
    public  void getusergroupdetails(String grpiddetail,Integer statuscode) {
        try {
            urlusergroupdetails = Utils.getUrl("getusergroupdetails");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", uid)
                            .header("authToken", authToken)
                            .param("groupID", grpiddetail)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlusergroupdetails)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("userGroups");
                HashMap<String, Object> user = (HashMap) users.get("userGroup");
                List<HashMap<String, Object>> assigneduser = (ArrayList<HashMap<String, Object>>) users.get("assignedUsers");


                statusdetialgroup = user.get("status").toString();
                namedetailgroup = user.get("name").toString();
                success = users.get("success").toString();
                assignuserid=assigneduser.get(0).get("id");

                Assert.assertEquals("true", success);
                LOGGER.info(("getusrgrpdetails=" + response.asString()));
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void saveOrUpdateEmailConfSettings(String spacekey,String userID,String authtoken,Integer statuscode ){
        try {
            saveOrUpdateEmailConfSettings = Utils.getUrl("saveOrUpdateEmailConfSettings");
            String data = "{\"id\":\"\",\"type\":3,\"status\":1,\"settings\":\"{\\\"id\\\":\\\"\\\",\\\"enableTLS\\\":\\\"true\\\",\\\"enableSSL\\\":\\\"\\\",\\\"updatedDate\\\":\\\"\\\",\\\"spaceKey\\\":\\\"" + spaceKey + "\\\",\\\"userID\\\":\\\"\\\",\\\"emailHost\\\":\\\"smtp.emailsrvr.com\\\",\\\"emailPort\\\":\\\"25\\\",\\\"emailUserName\\\":\\\"projectadmin@bdbizviz.com\\\",\\\"encryptnType\\\":\\\"tls\\\",\\\"emailPassword\\\":\\\"bizviz@12\\\",\\\"emailFrom\\\":\\\"projectadmin@bdbizviz.com\\\"}\",\"spaceKey\":\"" + spaceKey + "\"}";
            Response responsepluginmailConfSettings =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userid", uid)
                            .header("authtoken", authToken)
                            //Param
                            .param("isSecure", "true")
                            .param("consumerName", "BIZVIZSETTINGS")
                            .param("serviceName", "saveSettings")
                            .param("data", data)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(saveOrUpdateEmailConfSettings)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode == 305) {

                Assert.assertEquals(statuscode.intValue(), 305);

            } else {
                HashMap<String, Object> mailConfSettings = from(responsepluginmailConfSettings.asString()).get("");
                String emailresponse = "{\"reserv1\":null,\"reserv2\":null,\"reserv3\":null,\"reserv4\":null,\"reserv5\":null,\"createdDate\":null,\"isActive\":0,\"lastUpdatedDate\":null,\"active\":1,\"id\":167215105,\"type\":\"3\",\"status\":1,\"settings\":\"{\\\"id\\\":\\\"\\\",\\\"enableTLS\\\":\\\"true\\\",\\\"enableSSL\\\":\\\"\\\",\\\"updatedDate\\\":\\\"\\\",\\\"spaceKey\\\":\\\"" + spaceKey + "\\\",\\\"userID\\\":\\\"\\\",\\\"emailHost\\\":\\\"smtp.emailsrvr.com\\\",\\\"emailPort\\\":\\\"25\\\",\\\"emailUserName\\\":\\\"projectadmin@bdbizviz.com\\\",\\\"encryptnType\\\":\\\"tls\\\",\\\"emailPassword\\\":\\\"bizviz@12\\\",\\\"emailFrom\\\":\\\"projectadmin@bdbizviz.com\\\"}\",\"spaceKey\":\"" + spaceKey + "\"}";

            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    public  void forgetPasswordResetLink(String emailID,String spaceKey,Integer statuscode) {
        try {
            String url = Utils.getUrl("forgetpasswordresetlink");

            Response response =
                    given()
                            .param("emailID", emailID)
                            .param("spaceKey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("users");

                success = users.get("success").toString();
                String msg = (String) users.get("message");

                Assert.assertEquals(msg, "Password reset Link has been sent to your mail.");
                Assert.assertEquals(success, "true");

                LOGGER.info(("forgetPasswordResetLink=" + response.asString()));
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void getallusers(String spaceKey,String uid,String authToken,Integer statuscode) {
        try {
            String url = Utils.getUrl("getallusers");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", uid)
                            .header("authToken", authToken)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("userGroups");

                List<Integer> ids = from(response.asString()).get("userGroups.users.id");
                for (Integer id : ids) {
                    Assert.assertNotNull(id);
                }

                Assert.assertEquals(users.get("success").toString(), "true");
                LOGGER.info(("getallusrs=" + response.asString()));
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void getuserdetails(String spaceKey,String uid,String authToken,String usrid,Integer statuscode) {
        try {
            String url = Utils.getUrl("getuserdetails");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", uid)
                            .header("authToken", authToken)
                            .param("userID", usrid)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {

                HashMap<String, Object> users = from(response.asString()).get("users");
                success = users.get("success").toString();
                Assert.assertEquals(success,"true");
                LOGGER.info(("getusrdetails=" + response.asString()));

            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void updateGroupUsersCustomfields(String spaceKey,String uid,String authToken,String key,String value,String selectedUsers,Integer statuscode) {
        try {
            String url = Utils.getUrl("updateGroupUsersCustomfields");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", uid)
                            .header("authToken", authToken)
                            .param("key", key)
                            .param("value", value)
                            .param("selectedUsers", selectedUsers)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {

                HashMap<String, Object> users = from(response.asString()).get("users");
                success = users.get("success").toString();
                custommsg=users.get("message").toString();
                Assert.assertEquals(success,"true");
                LOGGER.info(("getusrdetails=" + response.asString()));
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

}