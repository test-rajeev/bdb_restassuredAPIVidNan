package com.bdbizviz.restassured.platform.SecurityCheck;

import com.bdbizviz.restassured.platform.DataCenter.DataCenter;
import com.bdbizviz.restassured.platform.DataCenter.DataCenterHelper;
import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.User;
import com.bdbizviz.restassured.platform.Util.Utils;

import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;

/**
 * Created by bizviz on 19/2/18.
 */
public class DataCenterSecurityCheck extends DataCenterHelper {

    public static final Logger log = Logger.getLogger(DataCenterSecurityCheck.class.getName());
    public static User usernan;
    public static User usernanauth;
    public static String authTokennan;
    public static String uidnan;
    public static String spaceKeynan;

    @BeforeClass
    public  void setupDataCenterSecurity() throws Exception {
        prop = Utils.getProps();//Fetch all Permission data of properties Permission file and store in prop

        DataCenter.setupDataCenter();

        //Create a new user
        createnewuserFunctional(spaceKeyadmin,uidadmin,authTokenadmin,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authTokenadmin,spaceKey, HttpStatus.SC_OK);

        //User which is not assigned to any group for security check
        usernan=Helper.getCustomerKey(emailidcreatefun,space_admin);
        usernanauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
        spaceKeynan = useradmin.getSpacekey();
        authTokennan=usernanauth.getAuthToken();
        uidnan=usernan.getId();

    }

    @Test
    public  void getAllDataStoreNeg() {

        String data="{\"id\":0,\"datasourcetype\":\"\"}";
        getAllDataStore(spaceKeynan,uidnan,authTokennan,data,HttpStatus.SC_USE_PROXY);
        log.info("Successfull execution");


    }

    @Test
    public  void getDataSourceListNeg() {
        try{
            getDataSourceList(spaceKeynan,uidnan,authTokennan,HttpStatus.SC_USE_PROXY);
            log.info("Successfull execution");
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getAllDataSetLNeg")
    public  void getAllDataSetLNeg(){
        try{
            getAllDataSet(spaceKeynan,uidnan,authTokennan,"0",HttpStatus.SC_USE_PROXY);
            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //---------------------------------------MYSQL(Security checking using user credential who is not assigned to any usergroup)-------------------------------------//
    @Test(description = "getDataSourceInfoByTypeNeg")
    public static void getDataSourceInfoByTypeMYSQLNeg(){
        try{
            getDataSourceInfoByType(spaceKeynan, uidnan, authTokennan,dbType,HttpStatus.SC_USE_PROXY);
            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getQueryInfoMYSQLNeg")
    public static void getQueryInfoMYSQLNeg() {
        try {
            String data=null;

            data="{\"id\":\""+datasourceidNew+"\",\"query\":\""+dataStoreName+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbType+"\"}";

            getQueryInfo(spaceKeynan,uidnan,authTokennan,data,HttpStatus.SC_USE_PROXY);
            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "dataConnFlowLNeg")
    public  void dataConnFlowLNeg(){
        try{
            dataConnFlowLNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameMysql,dbUserName,dbPassword,dbPortNumber,dbHostName,dbName,datasourceidNew,dbType,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataSourceFlowNeg")
    public  void shareUserDataSourceFlowNeg(){
        try{
            shareUserDataSourceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameMysql,dbUserName,dbPassword,dbPortNumber,dbHostName,dbName,dbType,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataSourceToExcludeNeg")
    public  void shareGroupDataSourceToExcludeNeg(){
        try{
            shareGroupDataSourceToExcludeNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameMysql,dbUserName,dbPassword,dbPortNumber,dbHostName,dbName,dbType,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "queryServiceFlowNeg")
    public  void queryServiceFlowNeg(){
        try{
            queryServiceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameMysql,dbUserName,dbPassword,dbPortNumber,dbHostName,dbName,dbType,dsQuery,Utils.getproperty("dsQueryupdate1"),querynameMysql,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataServiceFlowNeg")
    public  void shareUserDataServiceFlowNeg(){
        try{
            shareUserDataServiceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameMysql,dbUserName,dbPassword,dbPortNumber,dbHostName,dbName,dbType,dsQuery,querynameMysql,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataServiceToExcludeNeg")
    public  void shareGroupDataServiceToExcludeNeg(){
        try{
            shareGroupDataServiceToExcludeNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameMysql,dbUserName,dbPassword,dbPortNumber,dbHostName,dbName,dbType,dsQuery,querynameMysql,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    //---------------------------------------MSSQL(Security checking using user credential who is not assigned to any usergroup)-------------------------------------//
    @Test(description = "getDataSourceInfoByTypeMSSQLNeg")
    public static void getDataSourceInfoByTypeMSSQLNeg(){
        try{
            getDataSourceInfoByType(spaceKeynan, uidnan, authTokennan,dbTypeMSsql,HttpStatus.SC_USE_PROXY);
            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getQueryInfoMSSQLNeg")
    public static void getQueryInfoMSSQLNeg() {
        try {
            String data=null;

            data="{\"id\":\""+datasourceidNew+"\",\"query\":\""+dataStoreName+"\",\"dbname\":\""+dbNameMSsql+"\",\"type\":\""+dbTypeMSsql+"\"}";

            getQueryInfo(spaceKeynan,uidnan,authTokennan,data,HttpStatus.SC_USE_PROXY);
            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "dataConnFlowMSSQLNeg")
    public  void dataConnFlowMSSQLNeg(){
        try{
            dataConnFlowLNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,datasourceidNew,dbTypeMSsql,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataSourceFlowMSSQLNeg")
    public  void shareUserDataSourceFlowMSSQLNeg(){
        try{
            shareUserDataSourceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataSourceToExcludeMSSQLNeg")
    public  void shareGroupDataSourceToExcludeMSSQLNeg(){
        try{
            shareGroupDataSourceToExcludeNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "queryServiceFlowMSSQLNeg")
    public  void queryServiceFlowMSSQLNeg(){
        try{
            queryServiceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,dsQueryMSsql1,Utils.getproperty("dsQueryMSsql2"),querynameMSsql,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataServiceFlowMSSQLNeg")
    public  void shareUserDataServiceFlowMSSQLNeg(){
        try{
            shareUserDataServiceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,dsQueryMSsql1,querynameMSsql,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataServiceToExcludeMSSQLNeg")
    public  void shareGroupDataServiceToExcludeMSSQLNeg(){
        try{
            shareGroupDataServiceToExcludeNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameMSsql,dbUserNameMSsql,dbPasswordMSsql,dbPortNumberMSsql,dbHostNameMSsql,dbNameMSsql,dbTypeMSsql,dsQueryMSsql1,querynameMSsql,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    //---------------------------------------Oracle(Security checking using user credential who is not assigned to any usergroup)-------------------------------------//
    @Test(description = "getDataSourceInfoByTypeOracleNeg")
    public static void getDataSourceInfoByTypeOracleNeg(){
        try{
            getDataSourceInfoByType(spaceKeynan, uidnan, authTokennan,dbTypeOracle,HttpStatus.SC_USE_PROXY);
            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getQueryInfoOracleNeg")
    public static void getQueryInfoOracleNeg() {
        try {
            String data=null;

            data="{\"id\":\""+datasourceidNew+"\",\"query\":\""+dataStoreName+"\",\"dbname\":\""+dbHostNameOracle+"\",\"type\":\""+dbTypeOracle+"\"}";

            getQueryInfo(spaceKeynan,uidnan,authTokennan,data,HttpStatus.SC_USE_PROXY);
            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "dataConnFlowOracleNeg")
    public  void dataConnFlowOracleNeg(){
        try{
            dataConnFlowLNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameOracle,dbUserNameOracle,dbPasswordOracle,dbPortNumberOracle,dbHostNameOracle,dbServiceNameOracle,datasourceidNew,dbTypeOracle,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataSourceFlowOracleNeg")
    public  void shareUserDataSourceFlowOracleNeg(){
        try{
            shareUserDataSourceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameOracle,dbUserNameOracle,dbPasswordOracle,dbPortNumberOracle,dbHostNameOracle,dbServiceNameOracle,dbTypeOracle,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataSourceToExcludeOracleNeg")
    public  void shareGroupDataSourceToExcludeOracleNeg(){
        try{
            shareGroupDataSourceToExcludeNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameOracle,dbUserNameOracle,dbPasswordOracle,dbPortNumberOracle,dbHostNameOracle,dbServiceNameOracle,dbTypeOracle,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "queryServiceFlowOracleNeg")
    public  void queryServiceFlowOracleNeg(){
        try{
            queryServiceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameOracle,dbUserNameOracle,dbPasswordOracle,dbPortNumberOracle,dbHostNameOracle,dbServiceNameOracle,dbTypeOracle,dsQueryOracle,dsQueryOracle,querynameOracle,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataServiceFlowOracleNeg")
    public  void shareUserDataServiceFlowOracleNeg(){
        try{
            shareUserDataServiceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameOracle,dbUserNameOracle,dbPasswordOracle,dbPortNumberOracle,dbHostNameOracle,dbServiceNameOracle,dbTypeOracle,dsQueryOracle,querynameOracle,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataServiceToExcludeOracleNeg")
    public  void shareGroupDataServiceToExcludeOracleNeg(){
        try{
            shareGroupDataServiceToExcludeNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameOracle,dbUserNameOracle,dbPasswordOracle,dbPortNumberOracle,dbHostNameOracle,dbServiceNameOracle,dbTypeOracle,dsQueryOracle,querynameOracle,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    //---------------------------------------HIVE(Security checking using user credential who is not assigned to any usergroup)-------------------------------------//
    @Test(description = "getDataSourceInfoByTypeHIVENeg")
    public static void getDataSourceInfoByTypeHIVENeg(){
        try{
            getDataSourceInfoByType(spaceKeynan, uidnan, authTokennan,dbTypeHive,HttpStatus.SC_USE_PROXY);
            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getQueryInfoHIVENeg")
    public static void getQueryInfoHIVENeg() {
        try {
            String data=null;

            data="{\"id\":\""+datasourceidNew+"\",\"query\":\""+dataStoreName+"\",\"dbname\":\""+dbHostNameHive+"\",\"type\":\""+dbTypeHive+"\"}";

            getQueryInfo(spaceKeynan,uidnan,authTokennan,data,HttpStatus.SC_USE_PROXY);
            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "dataConnFlowHIVENeg")
    public  void dataConnFlowHIVENeg(){
        try{
            dataConnFlowLNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameHive,dbUserNameHive,dbPasswordHive,dbPortNumberHive,dbHostNameHive,"",datasourceidNew,dbTypeHive,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataSourceFlowHIVENeg")
    public  void shareUserDataSourceFlowHIVENeg(){
        try{
            shareUserDataSourceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameHive,dbUserNameHive,dbPasswordHive,dbPortNumberHive,dbHostNameHive,"",dbTypeHive,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataSourceToExcludeHIVENeg")
    public  void shareGroupDataSourceToExcludeHIVENeg(){
        try{
            shareGroupDataSourceToExcludeNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameHive,dbUserNameHive,dbPasswordHive,dbPortNumberHive,dbHostNameHive,"",dbTypeHive,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "queryServiceFlowHIVENeg")
    public  void queryServiceFlowHIVENeg(){
        try{
            queryServiceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameHive,dbUserNameHive,dbPasswordHive,dbPortNumberHive,dbHostNameHive,"",dbTypeHive,dsQueryHive,dsQueryHive,querynameHive,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataServiceFlowHIVENeg")
    public  void shareUserDataServiceFlowHIVENeg(){
        try{
            shareUserDataServiceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameHive,dbUserNameHive,dbPasswordHive,dbPortNumberHive,dbHostNameHive,"",dsQueryHive,dsQueryHive,querynameHive,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataServiceToExcludeHIVENeg")
    public  void shareGroupDataServiceToExcludeHIVENeg(){
        try{
            shareGroupDataServiceToExcludeNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameHive,dbUserNameHive,dbPasswordHive,dbPortNumberHive,dbHostNameHive,"",dsQueryHive,dsQueryHive,querynameHive,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //---------------------------------------SPARKSQL(Security checking using user credential who is not assigned to any usergroup)-------------------------------------//
    @Test(description = "getDataSourceInfoByTypeSPARKSQLNeg")
    public static void getDataSourceInfoByTypeSPARKSQLNeg(){
        try{
            getDataSourceInfoByType(spaceKeynan, uidnan, authTokennan,dbTypeSparkSql,HttpStatus.SC_USE_PROXY);
            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getQueryInfoSPARKSQLNeg")
    public static void getQueryInfoSPARKSQLNeg() {
        try {
            String data=null;

            data="{\"id\":\""+datasourceidNew+"\",\"query\":\""+dataStoreName+"\",\"dbname\":\""+dbHostNameHive+"\",\"type\":\""+dbTypeSparkSql+"\"}";

            getQueryInfo(spaceKeynan,uidnan,authTokennan,data,HttpStatus.SC_USE_PROXY);
            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "dataConnFlowSPARKSQLNeg")
    public  void dataConnFlowSPARKSQLNeg(){
        try{
            dataConnFlowLNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameSparkSql,dbUserNameHive,dbPasswordHive,dbPortNumberHive,dbHostNameHive,"",datasourceidNew,dbTypeSparkSql,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataSourceFlowSPARKSQLNeg")
    public  void shareUserDataSourceFlowSPARKSQLNeg(){
        try{
            shareUserDataSourceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameSparkSql,dbUserNameHive,dbPasswordHive,dbPortNumberHive,dbHostNameHive,"",dbTypeSparkSql,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataSourceToExcludeSPARKSQLNeg")
    public  void shareGroupDataSourceToExcludeSPARKSQLNeg(){
        try{
            shareGroupDataSourceToExcludeNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameSparkSql,dbUserNameHive,dbPasswordHive,dbPortNumberHive,dbHostNameHive,"",dbTypeSparkSql,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "queryServiceFlowSPARKSQLNeg")
    public  void queryServiceFlowSPARKSQLNeg(){
        try{
            queryServiceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameSparkSql,dbUserNameHive,dbPasswordHive,dbPortNumberHive,dbHostNameHive,"",dbTypeSparkSql,dsQueryHive,dsQueryHive,querynameSparkSql,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataServiceFlowSPARKSQLNeg")
    public  void shareUserDataServiceFlowSPARKSQLNeg(){
        try{
            shareUserDataServiceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameSparkSql,dbUserNameHive,dbPasswordHive,dbPortNumberHive,dbHostNameHive,"",dsQueryHive,dsQueryHive,querynameSparkSql,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataServiceToExcludeSPARKSQLNeg")
    public  void shareGroupDataServiceToExcludeSPARKSQLNeg(){
        try{
            shareGroupDataServiceToExcludeNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameSparkSql,dbUserNameHive,dbPasswordHive,dbPortNumberHive,dbHostNameHive,"",dsQueryHive,dsQueryHive,querynameSparkSql,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //---------------------------------------CASSENDRA(Security checking using user credential who is not assigned to any usergroup)-------------------------------------//
    @Test(description = "getDataSourceInfoByTypeCASSENDRANeg")
    public static void getDataSourceInfoByTypeCASSENDRANeg(){
        try{
            getDataSourceInfoByType(spaceKeynan, uidnan, authTokennan,dbTypeCassendra,HttpStatus.SC_USE_PROXY);
            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getQueryInfoCASSENDRANeg")
    public static void getQueryInfoCASSENDRANeg() {
        try {
            String data=null;

            data="{\"id\":\""+datasourceidNew+"\",\"query\":\""+dataStoreName+"\",\"dbname\":\""+dbHostNameCassendra+"\",\"type\":\""+dbTypeCassendra+"\"}";

            getQueryInfo(spaceKeynan,uidnan,authTokennan,data,HttpStatus.SC_USE_PROXY);
            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    /* @Test(description = "dataConnFlowCASSENDRANeg")
     public  void dataConnFlowCASSENDRANeg(){
         try{
             String datasourceidafterdel=null;

             //Checkconnection service before creation
             checkConnectionCassendra(spaceKeynan,uidnan,authTokennan,HttpStatus.SC_USE_PROXY);

             //Create a new connector
             createDataConnector(spaceKeynan,uidnan,authTokennan,dataSourceNameCassendra,dbUserNameCassendra, dbPasswordCassendra, dbPortNumberCassendra, dbHostNameCassendra,"null", dbTypeCassendra,innerobjdata,HttpStatus.SC_USE_PROXY);

             //Fetches the detail of newly created data connector for update
             viewDataSourceDetails(spaceKeynan,uidnan,authTokennan,datasourceid,HttpStatus.SC_USE_PROXY);

             //Checkconnection service before creation
             checkConnectionCassendraUpdate(spaceKeynan,uidnan,authTokennan,HttpStatus.SC_USE_PROXY);

             //Update the newly created data connector
             updateDataSourceDetails(spaceKeynan,uidnan,authTokennan,dbUserNameCassendra,null,dbPortNumberCassendra,dbHostNameCassendra,"null",datasourceid,dbTypeCassendra,innerobjdataupdate,HttpStatus.SC_USE_PROXY);

             //Reconnect the same data connector
             reconnect(spaceKeynan,uidnan,authTokennan,datasourceid,HttpStatus.SC_USE_PROXY);

             //Finally delete that same data connector
             deletedDataSource(spaceKeynan,uidnan,authTokennan,datasourceid,HttpStatus.SC_USE_PROXY);
         } catch (Exception e) {

             e.printStackTrace();
         }
     }
 */
    @Test(description = "shareUserDataSourceFlowCASSENDRANeg")
    public  void shareUserDataSourceFlowCASSENDRANeg(){
        try{
            shareUserDataSourceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameCassendra,dbUserNameCassendra,dbPasswordCassendra,dbPortNumberCassendra,dbHostNameCassendra,"",dbTypeCassendra,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataSourceToExcludeCASSENDRANeg")
    public  void shareGroupDataSourceToExcludeCASSENDRANeg(){
        try{
            shareGroupDataSourceToExcludeNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameCassendra,dbUserNameCassendra,dbPasswordCassendra,dbPortNumberCassendra,dbHostNameCassendra,"",dbTypeCassendra,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "queryServiceFlowCASSENDRANeg")
    public  void queryServiceFlowCASSENDRANeg(){
        try{
            queryServiceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameCassendra,dbUserNameCassendra,dbPasswordCassendra,dbPortNumberCassendra,dbHostNameCassendra,"",dbTypeCassendra,dsQueryCassendra,dsQueryCassendra,querynameCassendra,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataServiceFlowCASSENDRANeg")
    public  void shareUserDataServiceFlowCASSENDRANeg(){
        try{
            shareUserDataServiceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameCassendra,dbUserNameCassendra,dbPasswordCassendra,dbPortNumberCassendra,dbHostNameCassendra,"",dsQueryCassendra,dsQueryCassendra,querynameCassendra,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataServiceToExcludeCASSENDRANeg")
    public  void shareGroupDataServiceToExcludeCASSENDRANeg(){
        try{
            shareGroupDataServiceToExcludeNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameCassendra,dbUserNameCassendra,dbPasswordCassendra,dbPortNumberCassendra,dbHostNameCassendra,"",dsQueryCassendra,dsQueryCassendra,querynameCassendra,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //---------------------------------------OData(Security checking using user credential who is not assigned to any usergroup)-------------------------------------//
    @Test(description = "getDataSourceInfoByTypeODataNeg")
    public static void getDataSourceInfoByTypeODataNeg(){
        try{
            getDataSourceInfoByType(spaceKeynan, uidnan, authTokennan,dbTypeOData,HttpStatus.SC_USE_PROXY);
            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getQueryInfoODataNeg")
    public static void getQueryInfoODataNeg() {
        try {
            String data=null;

            data="{\"id\":\""+datasourceidNew+"\",\"query\":\""+dataStoreName+"\",\"dbname\":\""+dbHostNameOData+"\",\"type\":\""+dbTypeOData+"\"}";

            getQueryInfo(spaceKeynan,uidnan,authTokennan,data,HttpStatus.SC_USE_PROXY);
            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "dataConnFlowODataNeg")
    public  void dataConnFlowODataNeg(){
        try{
            dataConnFlowLNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameOdata,dbUserNameOData,dbPasswordOData,"",dbHostNameOData,"",datasourceidNew,dbTypeOData,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataSourceFlowODataNeg")
    public  void shareUserDataSourceFlowODataNeg(){
        try{
            shareUserDataSourceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameOdata,dbUserNameOData,dbPasswordOData,"",dbHostNameOData,"",dbTypeOData,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataSourceToExcludeODataNeg")
    public  void shareGroupDataSourceToExcludeODataNeg(){
        try{
            shareGroupDataSourceToExcludeNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameOdata,dbUserNameOData,dbPasswordOData,"",dbHostNameOData,"",dbTypeOData,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "queryServiceFlowODataNeg")
    public  void queryServiceFlowODataNeg(){
        try{
            queryServiceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameOdata,dbUserNameOData,dbPasswordOData,"",dbHostNameOData,"",dbTypeOData,dsQueryOData,dsQueryOData,querynameOdata,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareUserDataServiceFlowODataNeg")
    public  void shareUserDataServiceFlowODataNeg(){
        try{
            shareUserDataServiceFlowNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameOdata,dbUserNameOData,dbPasswordOData,"",dbHostNameOData,"",dsQueryOData,dsQueryOData,querynameOdata,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "shareGroupDataServiceToExcludeODataNeg")
    public  void shareGroupDataServiceToExcludeODataNeg(){
        try{
            shareGroupDataServiceToExcludeNeg(spaceKey,uid,authToken,spaceKeynan,uidnan,authTokennan,dataSourceNameOdata,dbUserNameOData,dbPasswordOData,"",dbHostNameOData,"",dsQueryOData,dsQueryOData,querynameOdata,HttpStatus.SC_USE_PROXY,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void dataConnFlowLNeg(String spacekeyadmin, String uidadmin, String authtokenadmin, String spaceKeynan, String uidnan, String authTokennan, String dataSourceNameMysql, String dbUserName, String dbPassword, String dbPortNumber, String dbHostName, String dbName, String datasourceid, String dbType, Integer HttpStatus, Integer HttpStatusadmin){
        try{
            checkDataSource(spaceKeynan,uidnan,authTokennan,dataSourceNameMysql,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,HttpStatus);

            createDataConnector(spaceKeynan,uidnan,authTokennan,dataSourceNameMysql,dbUserName, dbPassword, dbPortNumber, dbHostName, dbName, dbType,"null",HttpStatus);

            //Fetches the detail of newly created data connector for update
            viewDataSourceDetails(spaceKeynan,uidnan,authTokennan,datasourceid,HttpStatus);

            //Before updating check the datconnector
            checkDataSourceEdit(spaceKeynan,uidnan,authTokennan,dbUserName,null,dbPortNumber,dbHostName,dbName,datasourceid,dbType,null,HttpStatus);

            //Update the newly created data connector
            updateDataSourceDetails(spaceKeynan,uidnan,authTokennan,dbUserName,null,dbPortNumber,dbHostName,dbName,datasourceid,dbType,null,HttpStatus);

            //Reconnect the same data connector
            reconnect(spaceKeynan,uidnan,authTokennan,datasourceid,HttpStatus);

            //Finally delete that same data connector
            deletedDataSource(spaceKeynan,uidnan,authTokennan,datasourceid,HttpStatus);

            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void shareUserDataSourceFlowNeg(String spacekeyadmin, String uidadmin, String authtokenadmin, String spaceKeynan, String uidnan, String authTokennan, String dataSourceNameMysql, String dbUserName, String dbPassword, String dbPortNumber, String dbHostName, String dbName, String dbType, Integer HttpStatus, Integer HttpStatusadmin) {
        try {

            //Sharedatasource to share the data connector to user(AutmateGrouAugust)
            shareUserDataSource(spaceKeynan,uidnan,authTokennan,datasourceidNew,newuseridfunuser,HttpStatus);

            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void shareGroupDataSourceToExcludeNeg(String spacekeyadmin, String uidadmin, String authtokenadmin, String spaceKeynan, String uidnan, String authTokennan, String dataSourceNameMysql, String dbUserName, String dbPassword, String dbPortNumber, String dbHostName, String dbName, String dbType, Integer HttpStatus, Integer HttpStatusadmin) {
        try {

            //Sharegroupdatasource
            shareGroupDataSource(spaceKeynan,uidnan,authTokennan,datasourceidNew,newgroupid,HttpStatus);

            //Exclude user from group
            excludeShareDataSource(spaceKeynan,uidnan,authTokennan,datasourceidNew,newgroupid,newuseridfunuser,datasourceid,HttpStatus);

            log.info("Successfull execution");
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void queryServiceFlowNeg(String spacekeyadmin, String uidadmin, String authtokenadmin, String spaceKey, String uid, String authToken, String dataSourceNameMysql, String dbUserName, String dbPassword, String dbPortNumber, String dbHostName, String dbName, String dbType, String dsQuery, String dsQueryupdate, String querynameMysql, Integer HttpStatus, Integer HttpStatusadmin){
        try{


            //Test query service before creation
            String data=null;
            data="{\"query\":\""+dsQuery+"\",\"id\":\""+datasourceidNew+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbType+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,data,HttpStatus);

            //Create new Queryservice
            createqueryservice(spaceKey,uid,authToken,querynameMysql,dbName, dsQuery, datasourceidNew,HttpStatus);

            //Fetching the list of query service in a data connector
            getAllDataSet(spaceKey,uid,authToken,"0",HttpStatus);

            //Fetches the detail of newly created query service for update
            viewEditQueryService(spaceKey,uid,authToken,seriveiddatasetNew.toString(),HttpStatus);

            //Test query service before creation
            String dataedit=null;
            dataedit="{\"query\":\""+dsQueryupdate+"\",\"id\":\""+datasourceidNew+"\",\"dbname\":\""+dbName+"\",\"type\":\""+dbType+"\",\"filter\":\"{}\"}";

            runDataService(spaceKey,uid,authToken,dataedit,HttpStatus);

            //Update the newly created query service
            //updateQueryService(spaceKey,uid,authToken,dbName,dsQueryupdate,datasourceidNew,seriveiddatasetNew.toString(),HttpStatus);

            //Publish the Dataset
            publishDataSet(spaceKey,uid,authToken,seriveiddatasetNew,HttpStatus);

            //Call this function to check published data set is avaialble in dashboard designer
            listQueryServices(spaceKey,uid,authToken,datasourceidNew,HttpStatus);

            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void shareUserDataServiceFlowNeg(String spacekeyadmin, String uidadmin, String authtokenadmin, String spaceKey, String uid, String authToken, String dataSourceNameMysql, String dbUserName, String dbPassword, String dbPortNumber, String dbHostName, String dbName, String dbType, String dsQuery, String querynameMysql, Integer HttpStatus, Integer HttpStatusadmin) {
        try {

            //Sharedatasource to share the queryservice to user(AutmateGrouAugust)
            shareUserDataService(spaceKey,uid,authToken,seriveiddatasetNew,newuseridfunuser,HttpStatus);

            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void shareGroupDataServiceToExcludeNeg(String spacekeyadmin, String uidadmin, String authtokenadmin, String spaceKey, String uid, String authToken, String dataSourceNameMysql, String dbUserName, String dbPassword, String dbPortNumber, String dbHostName, String dbName, String dbType, String dsQuery, String querynameMysql, Integer HttpStatus, Integer HttpStatusadmin) {
        try{

            //SharegroupDataService
            shareGroupDataService(spaceKey,uid,authToken,seriveiddatasetNew.toString(),newgroupid,HttpStatus);

            //Exclude user from group
            excludeShareDataService(spaceKey,uid,authToken,seriveiddatasetNew.toString(),newgroupid,newuseridfunuser,HttpStatus);

            log.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

}
