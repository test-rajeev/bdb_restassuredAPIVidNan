package com.bdbizviz.restassured.platform.SecurityCheck;

import com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper;
import com.bdbizviz.restassured.platform.UserManagement.UserManagement;
import com.bdbizviz.restassured.platform.Util.Utils;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.User;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.bdbizviz.restassured.platform.BS.BusinessStoryHelper.storyname;
import static com.bdbizviz.restassured.platform.Designer.DesignerHelper.urlgetdocumentinfobyid;
import static com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper.*;
import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;

public class HomeUiSecurityCheck extends UserManagement {
    private static final Logger LOGGER = Logger.getLogger(HomeUiSecurityCheck.class.getName());
    public static User usernan;
    public static User usernanauth;
    public static String authTokennan;
    public static String uidnan;
    public static String spaceKeynan;

    String commit = "";


    @BeforeClass
    public void setupHomeUI(){
        prop = Utils.getProps();

        //Craete a new user
        createnewuserFunctional(spaceKeyadmin,uidadmin,authTokenadmin,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authTokenadmin,spaceKey, HttpStatus.SC_OK);

        //User which is not assigned to any group for security check
        usernan=Helper.getCustomerKey(emailidcreatefun,space_admin);
        usernanauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
        spaceKeynan = useradmin.getSpacekey();
        authTokennan=usernanauth.getAuthToken();
        uidnan=usernan.getId();
    }

    @Test(description = "getalldocuments")
    public void getListviewNeg() {

        try {
            getlistview(uidnan,spaceKeynan,authTokennan,HttpStatus.SC_OK);
            LOGGER.info("successful execution");
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createFolderNeg")
    public void createFolderNeg() {
        try {
            createFolderInMyDocs(uidnan, HomeUiHelper.myDocumentId,position,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "createDocumentNeg")
    public void createDocumentNeg() {
        try {
            createDocMyDocHomeUi(uidnan,spaceKeynan,authTokennan, HttpStatus.SC_USE_PROXY);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "getFavouriteDocuments")
    public void getfavouriteDocuments() {

        try {
            getFavouriteDocuments(uidnan,spaceKeynan,authTokennan, HttpStatus.SC_USE_PROXY);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description ="creating the folder and renaming it,add foler to fav and delete")
    public static void CreateFolToDelFlowNeg(){
        try{
            //Creating Folder
            createFolderInHomeUi(uidnan, myDocumentId, position,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);
            LOGGER.info(("folderid:" +folderid_Home));

            int statusCode = HttpStatus.SC_USE_PROXY;
            Response response =
                    given() .header("spacekey", spaceKeynan)
                            .header("authtoken", authTokennan)
                            .header("userid", uidnan)
                            .param("id",folderid_Home)
                            .param("title", folTitleRename)
                            .param("doctype", doctype)
                            .param("token",authTokennan)
                            .param("spacekey",spaceKeynan)
                            .when()
                            .post(urlrenameNode)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                LOGGER.info(("trees:" + trees.toString()));

                //***Assert message to check folder renaming***//
                String msg = response.path("trees.message").toString();
                Assert.assertEquals(msg, "Folder renamed successfully!");
            }
            //add fol to favourites
            addFolToFav(uidnan,folderid_Home, authTokennan, spaceKeynan,HttpStatus.SC_USE_PROXY);

            //remove fol
            removeNode(uidnan,folderid_Home, authTokennan, spaceKeynan,HttpStatus.SC_USE_PROXY);
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    @Test(description="crearting the Document and renaming it, add document to fav and delete")
    public static void CreateDocInFolToDelDocumentFlowNeg(){
        try{
            //CreateFolAnd Document inside Folder
            createFolderInMyDocs(uidnan, myDocumentId,position,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            int statusCode = HttpStatus.SC_USE_PROXY;
            Response response =
                    given() //headers
                            .header("spaceKey", spaceKeynan)
                            .header("authToken", authTokennan)
                            .header("userID", uidnan)
                            //params
                            .param("id", docId)
                            .param("title", docTitleRename)
                            .param("doctype", doctypefile)
                            .param("token", authTokennan)
                            .param("spacekey", spaceKeynan)
                            .when()
                            .post(urlrenameNode)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                LOGGER.info(("trees_RenameDoc:" + trees.toString()));

                //***Assert message to check Document renaming***//
                String msg = response.path("trees.message").toString();
                Assert.assertEquals(msg, "Document renamed successfully!");
            }
            // Adding Document to Favourites
            if(statusCode == HttpStatus.SC_OK) {
                addDocToFav(uidnan, folderid, authTokennan, spaceKeynan, HttpStatus.SC_USE_PROXY);

                // moveDocument();
                removeNodeDocument(uidnan, folderid, authTokennan, spaceKeynan, HttpStatus.SC_USE_PROXY);

            //****getListView****//
            Response response1 =
                    given() //headers
                            .header("spaceKey", spaceKeynan)
                            .header("authToken", authTokennan)
                            .header("userID", uidnan)
                            //params
                            .param("nodeid", myDocumentId)
                            .param("orderType", orderType)
                            .param("token", authTokennan)
                            .param("spacekey", spaceKeynan)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> respMap = from(response1.asString()).get("");
            HashMap<String, Object> trees1 = (HashMap<String, Object>) respMap.get("trees");
            List< HashMap<String, Object> > treesList1 = (ArrayList<HashMap<String, Object>>) trees1.get("treesList");
            id = (Integer)treesList1.get(0).get("id");

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Test(description ="copyFolderNeg")
    public static void copyFolderNeg(){
        try{
            createFolderInHomeUi(uidnan, myDocumentId, position,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);
            String dashboardType = Utils.getproperty("dashboardType");

            int statusCode = HttpStatus.SC_USE_PROXY;
            Response response =
                    given()
                            //headers
                            .header("userid", uidnan)
                            .header("spaceKey", spaceKeynan)
                            .header("authToken", authTokennan)
                            //params
                            .param("source", folderid_Home)
                            .param("title", copyTitle)
                            .param("destination", myDocumentId)
                            .param("dashboardType",  Integer.valueOf(dashboardType))
                            .param("token", authTokennan)
                            .param("spacekey", spaceKeynan)
                            .when()
                            .post(urlcopyPaste)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> responseMap = from(response.asString()).get("");
                LOGGER.info(("response_CopyFolder:" + responseMap.toString()));

                //****Assert to check success message***//
                Assert.assertEquals(responseMap.get("success").toString(), "true");

                //***Deleting the created folder***//
                LOGGER.info(("folderid_Home:" + folderid_Home));
            }
            Response response1 =
                    given()
                            //headers
                            .header("userID", uidnan)
                            .header("spaceKey", spaceKeynan)
                            .header("authToken", authTokennan)
                            //params
                            .param("id", folderid_Home)
                            .param("token", authTokennan)
                            .param("spacekey", spaceKeynan)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> trees1 = from(response1.asString()).get("trees");
                System.out.println(("trees_DelFolder:" + trees1.toString()));
            }
            //****getListView to get the id of copied folder****//
            statusCode = HttpStatus.SC_OK;
            Response response2 =
                    given()
                            //headers
                            .header("userid", uidnan)
                            .header("spaceKey", spaceKeynan)
                            .header("authToken", authTokennan)
                            //params
                            .param("nodeid", myDocumentId)
                            .param("token", authTokennan)
                            .param("spacekey", spaceKeynan)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> respMap = from(response2.asString()).get("");
                HashMap<String, Object> trees2 = (HashMap<String, Object>) respMap.get("trees");
                List<HashMap<String, Object>> treesList2 = (ArrayList<HashMap<String, Object>>) trees2.get("treesList");

                for (HashMap<String, Object> treeListObj : treesList2) {
                    if (treeListObj.containsKey("title") && treeListObj.get("title").toString().equals(Utils.getproperty("copyTitle"))) {
                        copyId = treeListObj.get("id").toString();
                    }
                }
            }
            //***Deleting the copied folder***//
            LOGGER.info(("copyId:" +copyId ));
            statusCode = HttpStatus.SC_USE_PROXY;
            Response response3 =
                    given()
                            //headers
                            .header("spacekey", spaceKeynan)
                            .header("userid", Integer.valueOf(uidnan))
                            .header("authtoken", authTokennan)
                            //params
                            .param("id", copyId)
                            .param("token", authTokennan)
                            .param("spacekey", spaceKeynan)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> trees3 = from(response3.asString()).get("trees");
                System.out.println(("trees_DelCopiedFol:" + trees3.toString()));
            }

        }
        catch(Exception e){
            e.printStackTrace();
        }

    }

    @Test(description ="copyDocumentNeg")
    public static void copyDocumentNeg(){
        try{
            int x = 0;
            Long postion = new Long(x);

            int dashDocType = 0;
            Long dashDoc = new Long(dashDocType);

            createDocInMyDoc(uidnan, doctypefile,dashDoc ,myDocumentId,postion,authTokennan,spaceKeynan, HttpStatus.SC_USE_PROXY);
            String dashboardType = Utils.getproperty("dashboardType").toString();

            int statusCode = HttpStatus.SC_USE_PROXY;
            Response response =
                    given() .header("spacekey", spaceKeynan)
                            .header("userID", Integer.valueOf(uidnan))
                            .header("authtoken", authTokennan)
                            .param("source", docId)
                            .param("title",copyDocTitle)
                            .param("destination", myDocumentId)
                            .param("dashboardType",Integer.valueOf(dashboardType))
                            .param("spacekey", spaceKeynan)
                            .param("token", authTokennan)
                            .when()
                            .post(urlcopyPaste)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> responseMap = from(response.asString()).get("");
                LOGGER.info(("response_CopyDocument:" + responseMap.toString()));

                //****Assert to check success message***//
                Assert.assertEquals(responseMap.get("success").toString(), "true");
            }
            //*****To remove the created document****//
            Response responseDel1 =
                    given() .header("spacekey", spaceKeynan)
                            .header("userid", Integer.valueOf(uidnan))
                            .header("authtoken", authTokennan)
                            .param("id", docId)
                            .param("token", authTokennan)
                            .param("spacekey", spaceKeynan)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> trees1 = from(responseDel1.asString()).get("trees");
                HashMap<String, Object> tree1 = (HashMap) trees1.get("tree");
                delDocId = (Integer) tree1.get("id");
                LOGGER.info(("trees:" + trees1.toString()));
            }
            //******getListView to get the id of copied document******//
            statusCode = HttpStatus.SC_OK;
            Response responseGetList2 =
                    given()
                            .header("spacekey", spaceKeynan)
                            .header("userID", Integer.valueOf(uidnan))
                            .header("authtoken", authTokennan)
                            .param("nodeid", myDocumentId)
                            .param("orderType", orderType)
                            .param("token", authTokennan)
                            .param("spacekey", spaceKeynan)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> respMap2 = from(responseGetList2.asString()).get("");
                HashMap<String, Object> trees2 = (HashMap<String, Object>) respMap2.get("trees");
                List<HashMap<String, Object>> treesList2 = (ArrayList<HashMap<String, Object>>) trees2.get("treesList");

                for (HashMap<String, Object> treeListObj : treesList2) {
                    if (treeListObj.containsKey("title") && treeListObj.get("title").toString().equals(Utils.getproperty("copyDocTitle").toString())) {
                        copyIdDoc = (String) treeListObj.get("id");
                    }
                }
            }
            //***Deleting the copied document***//
            LOGGER.info(("copyId:" +copyIdDoc ));
            statusCode = HttpStatus.SC_USE_PROXY;
            Response responseDel2 =
                    given()
                            .header("spacekey", spaceKeynan)
                            .header("userID", Integer.valueOf(uidnan))
                            .header("authtoken", authTokennan)
                            .param("id", copyIdDoc)
                            .param("token", authTokennan)
                            .param("spacekey", spaceKeynan)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> trees3 = from(responseDel2.asString()).get("trees");
                LOGGER.info(("trees_DeleteCopyDoc:" + trees3.toString()));
            }
            //****getListView to compare json****//
            statusCode = HttpStatus.SC_OK;
            Response responseGetList4 =
                    given()
                            .header("spacekey", spaceKeynan)
                            .header("userID", Integer.valueOf(uidnan))
                            .header("authtoken", authTokennan)
                            .param("nodeid", myDocumentId)
                            .param("orderType", orderType)
                            .param("token", authTokennan)
                            .param("spacekey", spaceKeynan)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> respMap4 = from(responseGetList4.asString()).get("");
                HashMap<String, Object> treesGetList4 = (HashMap<String, Object>) respMap4.get("trees");
                List<HashMap<String, Object>> treesList4 = (ArrayList<HashMap<String, Object>>) treesGetList4.get("treesList");
                id = (Integer) treesList4.get(0).get("id");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "creating the folder and moving the same")
    public static void moveFolderNeg(){
        try{
            //createFolder
            createFolderInHomeUi(uidnan, myDocumentId, position,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            int statusCode = HttpStatus.SC_USE_PROXY;
            Response response =
                    given()
                            //headers
                            .header("userid", uidnan)
                            .header("spaceKey", spaceKeynan)
                            .header("authtoken", authTokennan)
                            //params
                            .param("source",folderid_Home)
                            .param("moveto",Utils.getproperty("moveto"))
                            .param("destination",myDocumentId)
                            .param("title",folTitleRename)
                            .param("token",authTokennan)
                            .param("spacekey",spaceKeynan)
                            .when()
                            .post(urlcutPaste)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                LOGGER.info(("trees:" + trees.toString()));

                //****To assert that the folder is moved successfully****//
                String success = trees.get("success").toString();
                Assert.assertEquals(success, "true");
            }
            //****To delete the moved folder****//
            LOGGER.info(("folderid:" +folderid_Home ));

            Response response1 =
                    given()
                            //headers
                            .header("userid", uidnan)
                            .header("spaceKey", spaceKeynan)
                            .header("authtoken", authTokennan)
                            //params
                            .param("id",folderid_Home)
                            .param("token",authTokennan)
                            .param("spacekey",spaceKeynan)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> trees1 = from(response1.asString()).get("trees");
                LOGGER.info(("trees:" + trees1.toString()));

                //***Assert message to check folder has deleted***//
                Assert.assertEquals(trees1.get("message").toString(), "Folder deleted successfully!");
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }

    }

    @Test(description = "creating the document and moving the same")
    public static void moveDocumentNeg(){
        try{
            //create Document
            createDocMyDocHomeUi(uidnan, spaceKeynan,authTokennan, HttpStatus.SC_USE_PROXY);

            int statusCode = HttpStatus.SC_USE_PROXY;
            if(statusCode == HttpStatus.SC_OK) {
                Response response =
                        given()
                                .header("spaceKey", spaceKeynan)
                                .header("authtoken", authTokennan)
                                .header("userid", uidnan)
                                .param("source", docId_HomeUi)
                                .param("moveto", Utils.getproperty("moveto"))
                                .param("destination", folderid_Home)
                                .param("title", Utils.getproperty("documentTitle"))
                                .param("token", authTokennan)
                                .param("spacekey", spaceKeynan)
                                .when()
                                .post(urlcutPaste)
                                .then()
                                .assertThat()
                                .statusCode(statusCode)
                                .extract().response();
                if (statusCode == HttpStatus.SC_OK) {
                    HashMap<String, Object> trees = from(response.asString()).get("trees");
                    LOGGER.info(("trees:" + trees.toString()));
                    String success = trees.get("success").toString();

                    //***Assert message to check document has moved successfully ***//
                    Assert.assertEquals(trees.get("success").toString(), success);
                }
                //****To remove moved document***
                Response response1 =
                        given()
                                .header("spacekey", spaceKeynan)
                                .header("authtoken", authTokennan)
                                .header("userid", uidnan)
                                .param("id", docId_HomeUi)
                                .param("token", authTokennan)
                                .param("spacekey", spaceKeynan)
                                .when()
                                .post(urlremoveNode)
                                .then()
                                .assertThat()
                                .statusCode(statusCode)
                                .extract().response();
                if (statusCode == HttpStatus.SC_OK) {
                    HashMap<String, Object> trees1 = from(response1.asString()).get("trees");
                    LOGGER.info(("trees:" + trees1.toString()));

                    //***Assert message to check folder has deleted***//
                    Assert.assertEquals(trees1.get("message").toString(), "Document deleted successfully!");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Test(description ="Create User, share Document to User and delete document,delete user")
    public static void getDocumentListNeg(){

        try {
            //Create Folder and document inside
            createFolderInMyDocs(uidnan, myDocumentId,position,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            //Creating User
            createnewuserFunctional(spaceKeynan,uidnan,authTokennan,uniqueid+ Helper.generateRandomString(),usrname,fullname+ Helper.generateRandomString(),pass_admin,"",authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            //Assigning in group
            createnewGroupPerm(spaceKeynan,uidnan,authTokennan,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_USE_PROXY);
            LOGGER.info("selUserGrpId==" + newgroupid);

            //ShareDocumentToUser
            Thread.sleep(1000);
            shareDocUserNeg(docId,uid,authToken,spaceKey, HttpStatus.SC_USE_PROXY);
            System.out.println("emailId ======"+emailidcreatefun);
            System.out.println("createUserId ======"+newuseridfunuser);

            //Login with new user passing valid password
            User usernew = Helper.getCustomerKey(emailidcreatefun,space_admin);
            User userobjauthnew = Helper.getAuthToken(emailidcreatefun,pass_admin, space_admin);
            String authnew =  null;
            authnew = userobjauthnew.getAuthToken();
            String idnew = null;
            idnew = usernew.getId();

            //***calling documentListView by logging from the Selected user credentials***//
            int statusCode = HttpStatus.SC_USE_PROXY;
            Response response_DocumentList =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userid", Integer.valueOf(idnew))
                            .header("authtoken", authnew)

                            //params
                            .param("userId", idnew)
                            .param("nodeId", folderid)
                            .param("token",authnew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetDocumentList)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if (statusCode ==HttpStatus.SC_BAD_REQUEST && statusCode ==HttpStatus.SC_USE_PROXY ){
                LOGGER.info(("successful execution"));
            }
            else if(statusCode == HttpStatus.SC_OK){
                HashMap<String, Object> resp = from(response_DocumentList.asString()).get("");
                HashMap<String, Object> trees = (HashMap) resp.get("trees");
                List<HashMap<String, Object>> treesList = (ArrayList<HashMap<String, Object>>) trees.get("treesList");

                for (HashMap<String, Object> treeListObj : treesList) {
                    if (treeListObj.containsKey("id") && treeListObj.get("id").toString().equals(docId)) {
                    }
                }
                LOGGER.info(("trees_DocumentList:" + trees.toString()));
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Test(description =" Create User, group, crate DocumentShare the document to assigned usergroup and exclude the selected user")
    public static void excludeDocUserGroupNeg(){
        try{
            //Create Folder and document inside
            createFolderInMyDocs(uidnan, myDocumentId,position,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);
            System.out.println("selDocId:"+docId);

            //Creating User
            createnewuserFunctional(spaceKeynan,uidnan,authTokennan,uniqueid+ Helper.generateRandomString(),usrname,fullname+ Helper.generateRandomString(),pass_admin,"",authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            //Assigning in group
            createnewGroupPerm(spaceKeynan,uidnan,authTokennan,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_USE_PROXY);
            LOGGER.info("selUserGrpId==" + newgroupid);

            //Creating User
            createnewuserFunctional(spaceKeynan,uidnan,authTokennan,uniqueid+ Helper.generateRandomString(),usrname,fullname+ Helper.generateRandomString(),pass_admin,newgroupid,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            //Creating User
            createnewuserFunctional(spaceKeynan,uidnan,authTokennan,uniqueid+ Helper.generateRandomString(),usrname,fullname+ Helper.generateRandomString(),pass_admin,newgroupid,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            getusersfromgroups(uidnan,newgroupid, authTokennan, spaceKeynan,HttpStatus.SC_USE_PROXY);

            //Sharing Document to Usergroup
            Thread.sleep(1000);
            shareDocUserGroupNeg(docId,newgroupid, selUserId, uid, authToken,spaceKey,HttpStatus.SC_USE_PROXY);

            //Login with new user passing  valid password
            User usernew = Helper.getCustomerKey(selUsers_MailId,space_admin);
            User userobjauthnew = Helper.getAuthToken(selUsers_MailId,pass_admin, space_admin);
            String authnew =  null;
            authnew = userobjauthnew.getAuthToken();
            String idnew = null;
            idnew = usernew.getId();

            //get DocumentList
            if(idnew!= null) {
                documentList(myDocumentId, spaceKey, idnew, authnew, HttpStatus.SC_NOT_MODIFIED);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }


    @Test(description ="get the document info(when we modify the document)")
    public static void getDocumentInfoByIdNeg(){
        try{
            //*****Calling order by date service******//
            int statusCode = HttpStatus.SC_OK;
            String orderTypeDate = Utils.getproperty("orderTypeDate");
            urlgetListView = Utils.getUrl("getlistview");
            Response response =
                    given()
                            .header("spacekey", spaceKeynan)
                            .header("userid", Integer.valueOf(uidnan))
                            .header("authtoken", authTokennan)

                            .param("nodeid", myDocumentId)
                            .param("orderType", orderTypeDate)
                            .param("token", authTokennan)
                            .param("spacekey", spaceKeynan)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> responseMap = from(response.asString()).get("trees");
                LOGGER.info(("trees:" + responseMap.toString()));

                //****Assert to check success message***//
                Assert.assertEquals(responseMap.get("success").toString(), "true");
            }
            //calling createDoc function to fetch the docid
            int x = 0;
            Long postion = new Long(x);

            int dashDocType = 0;
            Long dashDoc = new Long(dashDocType);
            createDocInMyDoc(uidnan, doctypefile,dashDoc ,myDocumentId,postion,authTokennan,spaceKeynan, HttpStatus.SC_USE_PROXY);

            //adding getThumbnailByTreeID in a flow
            getThumbnailByTreeID(docId,uidnan,authTokennan,spaceKeynan, HttpStatus.SC_USE_PROXY);

            statusCode = HttpStatus.SC_USE_PROXY;
            Response response1 =
                    given()
                            .header("spacekey", spaceKeynan)
                            .header("userID", Integer.valueOf(uidnan))
                            .header("authtoken", authTokennan)
                            .param("docId", docId)
                            .param("token",authTokennan)
                            .param("spacekey", spaceKeynan)
                            .when()
                            .post(urlgetdocumentinfobyid)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> resp = from(response1.asString()).get("");
                HashMap<String, Object> trees = (HashMap) resp.get("trees");
                HashMap<String, Object> tree = (HashMap) trees.get("tree");
                LOGGER.info(("trees:" + trees.toString()));

                //****Assert to check id is not null***//
                String dcId = tree.get("id").toString();
                Assert.assertNotNull(dcId);
                Assert.assertEquals(docId, dcId);


            }
            removeNodeDocument(uidnan,docId,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

        }catch(Exception e){
            e.printStackTrace();
        }


    }

    //Delete the documents
    @Test(description = "delete thee documents from the home page")
    public static void deleteDocsAdminFlow(){
        try {
            //login from Admin.java account
            login();

            String orderType = null;
            int statusCode = HttpStatus.SC_OK;
            urlgetListView = Utils.getUrl("getlistview");
            Response response =
                    given() //headers
                            .header("spaceKey", spaceKey)
                            .header("userID", Integer.valueOf(uidadmin))
                            .header("authToken", authTokenadmin)

                            //params
                            .param("nodeid", myDocumentId)
                            .param("orderType", orderType)
                            .param("token", authTokenadmin)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                List<HashMap<String, Object>> treesList = (ArrayList<HashMap<String, Object>>) trees.get("treesList");

                for (HashMap<String, Object> treeObj : treesList) {

                    if (treeObj.containsKey("title") && treeObj.get("title").toString().equals("BIStory_Automate")) {
                        selDocId_GetList = treeObj.get("id").toString();
                        removeNodeDocument(uidadmin, selDocId_GetList, authTokenadmin, spaceKey, HttpStatus.SC_OK);

                    }
                    if (treeObj.containsKey("title") && treeObj.get("title").toString().equals("WebServiceDashboard_")) {
                        selDashboardId_GetList = treeObj.get("id").toString();
                        removeNodeDocument(uidadmin, selDashboardId_GetList, authTokenadmin, spaceKey, HttpStatus.SC_OK);

                    }if (treeObj.containsKey("title") && treeObj.get("title").toString().equals("MysqlDashboard")) {
                        selDashboardId_GetList = treeObj.get("id").toString();
                        removeNodeDocument(uidadmin, selDashboardId_GetList, authTokenadmin, spaceKey, HttpStatus.SC_OK);

                    }if (treeObj.containsKey("title") && treeObj.get("title").toString().equals("MssqlDashboard")) {
                        selDashboardId_GetList = treeObj.get("id").toString();
                        removeNodeDocument(uidadmin, selDashboardId_GetList, authTokenadmin, spaceKey, HttpStatus.SC_OK);

                    }if (treeObj.containsKey("title") && treeObj.get("title").toString().equals("OracleDashboard")) {
                        selDashboardId_GetList = treeObj.get("id").toString();
                        removeNodeDocument(uidadmin, selDashboardId_GetList, authTokenadmin, spaceKey, HttpStatus.SC_OK);

                    }if (treeObj.containsKey("title") && treeObj.get("title").toString().equals("SparkSqlDashboard")) {
                        selDashboardId_GetList = treeObj.get("id").toString();
                        removeNodeDocument(uidadmin, selDashboardId_GetList, authTokenadmin, spaceKey, HttpStatus.SC_OK);

                    }if (treeObj.containsKey("title") && treeObj.get("title").toString().equals("ODataDashboard")) {
                        selDashboardId_GetList = treeObj.get("id").toString();
                        removeNodeDocument(uidadmin, selDashboardId_GetList, authTokenadmin, spaceKey, HttpStatus.SC_OK);

                    }
                    if (treeObj.containsKey("title") && treeObj.get("title").toString().equals("Document2018")) {
                        selDocId = treeObj.get("id").toString();
                        removeNodeDocument(uidadmin, selDocId, authTokenadmin, spaceKey, HttpStatus.SC_OK);
                    }
                    if (treeObj.containsKey("title") && treeObj.get("title").toString().equals("RestAssuredFolder")) {
                        selFolId = treeObj.get("id").toString();
                        removeNodeDocument(uidadmin, selFolId, authTokenadmin, spaceKey, HttpStatus.SC_OK);
                    }
                    for (HashMap treesObj:treesList) {
                        if (treesObj.containsKey("title") && treesObj.get("title").toString().equals("QALinkUrl") ){
                            linkUrlId = treesObj.get("id").toString();
                            removeNodeDocument(uidadmin, linkUrlId, authTokenadmin, spaceKey, HttpStatus.SC_OK);
                        }
                    }
                    for (HashMap treesObj:treesList) {
                        if (treesObj.containsKey("title") && treesObj.get("title").toString().equals("dashboardLinkUrl") ){
                           String dashLink = treesObj.get("id").toString();
                            removeNodeDocument(uidadmin, dashLink, authTokenadmin, spaceKey, HttpStatus.SC_OK);
                        }
                    } for (HashMap treesObj:treesList) {
                        if (treesObj.containsKey("title") && treesObj.get("title").toString().equals("storyLinkUrl")) {
                            String storyLink = treesObj.get("id").toString();
                            removeNodeDocument(uidadmin, storyLink, authTokenadmin, spaceKey, HttpStatus.SC_OK);
                        }
                    }
                        for (HashMap treesObj:treesList) {
                        if (treesObj.containsKey("title") && treesObj.get("title").toString().equals("Test_") ){
                           String storyId = treesObj.get("id").toString();
                            removeNodeDocument(uidadmin, storyId, authTokenadmin, spaceKey, HttpStatus.SC_OK);
                        }
                    }
                }

                System.out.println("trees:" + trees.toString());
                LOGGER.info("StoryId:" + selDocId_GetList);
                LOGGER.info("Dashboardid:" + selDashboardId_GetList);

            }

        }catch(Exception e){
            e.printStackTrace();
        }

    }

    @Test(description = "delete thee documents from public documents")
    public static void deletepublicDocsAdminFlow() {
        try {
            //login function of Admin account
            login();

            String orderType = null;
            int statusCode = HttpStatus.SC_OK;
            urlgetListView = Utils.getUrl("getlistview");
            Response response =
                    given() //headers
                            .header("spaceKey", spaceKey)
                            .header("userID", Integer.valueOf(uidadmin))
                            .header("authToken", authTokenadmin)

                            //params
                            .param("nodeid", publicDocumentId)
                            .param("orderType", orderType)
                            .param("token", authTokenadmin)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if (statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                List<HashMap<String, Object>> treesList = (ArrayList<HashMap<String, Object>>) trees.get("treesList");

                for (HashMap<String, Object> treeObj : treesList) {

                    if (treeObj.containsKey("title") && treeObj.get("title").toString().equals("RestAssuredPublicFolder")) {
                       String  id = treeObj.get("id").toString();
                        removeNodeDocument(uidadmin, id, authTokenadmin, spaceKey, HttpStatus.SC_OK);

                    }

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}