package com.bdbizviz.restassured.platform.Util;

/**
 * Created by bizviz on 29/3/18.
 */
public class UserUtilesNonAdmin {
    private  String customerKeynonadmin;
    private  String spaceKeynonadmin;
    private  String authTokennonadmin;
    private  String userIDnonadmin;

    public String getCustomerKeynonadmin() {

        return customerKeynonadmin;
    }

    public void setCustomerKeynonadmin(String customerKeynonadmin) {

        this.customerKeynonadmin = customerKeynonadmin;
    }

    public String getUserIDnonadmin() {

        return userIDnonadmin;
    }

    public void setUserIDnonadmin(String userIDnonadmin) {

        this.userIDnonadmin = userIDnonadmin;
    }

    public String getAuthTokennonadmin() {

        return authTokennonadmin;
    }

    public void setAuthTokennonadmin(String authTokennonadmin)
    {

        this.authTokennonadmin = authTokennonadmin;
    }

    public String getSpaceKeynonadmin() {

        return spaceKeynonadmin;
    }

    public void setSpaceKeynonadmin(String spaceKeynonadmin) {

        this.spaceKeynonadmin = spaceKeynonadmin;
    }
}
