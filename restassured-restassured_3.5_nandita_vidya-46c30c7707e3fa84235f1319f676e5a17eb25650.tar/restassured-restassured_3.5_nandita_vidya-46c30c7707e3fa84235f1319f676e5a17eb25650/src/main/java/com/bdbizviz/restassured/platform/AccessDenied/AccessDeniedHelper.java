package com.bdbizviz.restassured.platform.AccessDenied;

import com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper;
import com.bdbizviz.restassured.platform.UserManagement.UserManagementHelper;
import com.bdbizviz.restassured.platform.Util.Utils;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.Assert;

import javax.rmi.CORBA.Util;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.bdbizviz.restassured.platform.Admininstration.AdminHelper.isSecure;
import static com.bdbizviz.restassured.platform.Designer.DesignerHelper.urlgetAllWorkspaceAndDashboard;
import static com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper.*;
import static com.bdbizviz.restassured.platform.UserManagement.UserManagementHelper.spaceKey;
import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;

/**
 * Created by bizviz on 16/2/18.
 */
public class AccessDeniedHelper  extends UserManagementHelper{
    private static final Logger LOGGER = Logger.getLogger( AccessDeniedHelper.class.getName() );
    String commit = "";

    //Sentiment
    public static void pluginServiceSentiment(String spaceKey,String uidnew, String authtoknew) {
        try {

            String url = Utils.getUrl("pluginServiceLogin");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userID", uidnew)
                            .header("authToken", authtoknew)
                            .param("token", authtoknew)
                            .param("spacekey", spaceKey)
                            .param("consumerName", Utils.getproperty("consumerNameSentiment"))
                            .param("serviceName", Utils.getproperty("serviceNameSentiment"))
                            .param("data", "{}")
                            .param("isSecure", "true")
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //SMB
    public static void pluginServiceSMB(String spaceKey,String uidnew, String authtoknew) {
        try {
            String url = Utils.getUrl("pluginServiceLogin");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userID", uidnew)
                            .header("authToken", authtoknew)
                            .param("token", authtoknew)
                            .param("spacekey", spaceKey)
                            .param("isSecure", "true")
                            .param("consumerName", Utils.getproperty("consumerNameSmb"))
                            .param("serviceName", Utils.getproperty("serviceNameSmb"))
                            .param("data", "temp")
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //SMB1
    public static void pluginServiceSMB1(String spaceKey,String uidnew, String authtoknew) {
        try {

            String url = Utils.getUrl("pluginServiceLogin");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userID", uidnew)
                            .header("authToken", authtoknew)
                            .param("token", authtoknew)
                            .param("spacekey", spaceKey)
                            .param("isSecure", "true")
                            .param("consumerName", Utils.getproperty("consumerNameSmb"))
                            .param("serviceName", Utils.getproperty("serviceNameSmb1"))
                            .param("data", "temp")
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    //Admin Module
    public static void adminModule(String spaceKey,String uidnew, String authtoknew) {
        try {

            String url = Utils.getUrl("getPermissionsByCatagory");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userID", uidnew)
                            .header("authToken", authtoknew)

                            //params
                            .param("category", Utils.getproperty("category") )
                            .param("token", authtoknew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> adminModule_resp = from(response.asString()).get("");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Admin module2 when clicked on Audit-Trail
    public static void getAllUsers(String spaceKey,String uidnew, String authtoknew) {
        try {
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uidnew))
                            .header("authtoken", authtoknew)
                            //params
                            /*.param("isSecure", isSecure)*/
                            .param("token", authtoknew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getallusers"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> resp = from(response.asString()).get("");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Play get All workspaces
    public static void getAllPlayWorkspaceAndContent(String spaceKey,String uidnew, String authtoknew){
        try{
            String url = Utils.getUrl("getAllPlayWorkspaceAndContent");
            String type = "4" ;
            String  geometryType = "";
            Response response_Geo =
                    given()  //headers
                            .header("userID", Integer.valueOf(uidnew))
                            .header("spacekey", spaceKey)
                            .header("authtoken", authtoknew)
                            //req params
                            .param("type", type)
                            .param("token",authtoknew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> resp = from(response_Geo.asString()).get("");
        }catch(Exception e){
            e.printStackTrace();
        }

    }

    //Predictive
    public static void pluginServicePredictive(String spaceKey,String uidnew, String authtoknew, String data) {
        try {

            String url = Utils.getUrl("pluginServiceLogin");
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", uidnew)
                            .header("authtoken", authtoknew)
                            //params
                            .param("token", authtoknew)
                            .param("spacekey", spaceKey)
                            .param("isSecure", "true")
                            .param("consumerName", Utils.getproperty("consumerNamePA"))
                            .param("serviceName", Utils.getproperty("serviceNamePA"))
                            .param("data", data)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> pluginServicePredictive = from(response.asString()).get("");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Predictive-Rserver
    public static void pluginServicepredictiveRServer(String spaceKey,String uidnew, String authtoknew) {
        try {
            String url = Utils.getUrl("pluginServiceLogin");
            String data = "{}";
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", uidnew)
                            .header("authtoken", authtoknew)
                            //params
                            .param("token", authtoknew)
                            .param("spacekey", spaceKey)
                            .param("isSecure", "true")
                            .param("consumerName", Utils.getproperty("consumerNamePA"))
                            .param("serviceName", Utils.getproperty("serviceNameRPA"))
                            .param("data", data)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> pluginServicePredictive = from(response.asString()).get("");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Predictive-GetAllWorkflows
    public static void pluginServicepredictiveGetAllWorkflows(String spaceKey,String uidnew, String authtoknew) {
        try {
            String url = Utils.getUrl("pluginServiceLogin");
            String data = "{\"type\":2}";
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", uidnew)
                            .header("authtoken", authtoknew)
                            //params
                            .param("token", authtoknew)
                            .param("spacekey", spaceKey)
                            .param("isSecure", "true")
                            .param("consumerName", Utils.getproperty("consumerNamePA"))
                            .param("serviceName", Utils.getproperty("serviceNamegetAllWorkflowPredictive"))
                            .param("data", data)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> pluginServicePredictive = from(response.asString()).get("");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Get all geospatial settings
    public static void getAllGeoSpatialSettings(String spaceKey,String uidnew, String authtoknew){
        try{
            String url = Utils.getUrl("getAllGeoSpatialSettings");
            String  geometryType = "";
            Response response_Geo =
                    given()  //headers
                            .header("userID", Integer.valueOf(uidnew))
                            .header("spacekey", spaceKey)
                            .header("authtoken", authtoknew)
                            //req params
                            .param("geometryType", geometryType)
                            .param("token",authtoknew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> resp = from(response_Geo.asString()).get("");
        }catch(Exception e){
            e.printStackTrace();
        }

    }

    //getAllWorkspaceAndDashboard
    public static void getAllWorkspaceAndDashboard(String spaceKey, String uidnew, String authtoknew) {
        try {
            String url = Utils.getUrl("getAllWorkspaceAndDashboard");
            Response response =
                    given()
                            .header("userID", uidnew)
                            .header("spacekey", spaceKey)
                            .header("authtoken", authtoknew)
                            //params
                            .param("token", authtoknew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> DesignerResp = from(response.asString()).get("DesignerResp");
            List<HashMap<String, Object>>dashboards = (ArrayList<HashMap<String,Object>>) DesignerResp.get("dashboards");
            System.out.println("DesignerResp:" + DesignerResp);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //surveyPluginService
    public static void surveyPluginService(String spaceKey, String uidnew, String authtoknew, String data) {
        try {
            String url = Utils.getUrl("pluginServiceLogin");
            String customerId = null;
            String ut = null;
            String email = null;
            String params = "";
            String userType = "1";

            Response response =
                    given()
                            .header("userid", uidnew)
                            .header("spacekey", spaceKey)
                            .header("authtoken", authtoknew)
                            //params
                            .param("consumerName", Utils.getproperty("consumerNameSurvey"))
                            .param("customerId", customerId)
                            .param("ut", ut)
                            .param("email", email)
                            .param("userid", uidnew)
                            .param("userType",userType )
                            .param("params",params )
                            .param("data", data)
                            .param("serviceName", Utils.getproperty("serviceNameSurvey"))
                            .param("token", authtoknew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> surveyResp = from(response.asString()).get("");
            System.out.println("surveyResp:" + surveyResp);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void getUserInfoByToken(String authToken ) {
        try {
            Response response = given()
                    .param("token", authToken)
                    .when()
                    .post(Utils.getUrl( "getUserInfoByToken"))
                    .then()
                    .statusCode(HttpStatus.SC_OK)
                    .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            List<HashMap<String, Object>> treesList = (ArrayList<HashMap<String, Object>>) users.get("trees");
            for (HashMap treesList_Obj :treesList) {
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("My Documents")){
                    myDocumentId = treesList_Obj.get("id").toString();
                }
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Public Documents")) {
                    publicDocumentId = treesList_Obj.get("id").toString();
                }
                else if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Shared Documents")) {
                    shareDocumentId = treesList_Obj.get("id").toString();
                }
            }


            LOGGER.info(("ShareDocumentId is==" +shareDocumentId));
            LOGGER.info(("MyDocumentId is==" +myDocumentId));
            LOGGER.info(("PublicDocumentId is==" +publicDocumentId));

            //****To assert checking id's are not null***//
            List<Integer> ids = from(response.asString()).get("users.trees.id");
            for (Integer id : ids) {
                Assert.assertNotNull(id);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void getlistview(String spaceKey,String uidnew, String authtoknew, int statusCode) {
        try {
            String orderType = null;
            Response response2 =
                    given()
                            //headers
                            .header("userID", uidnew)
                            .header("spaceKey", spaceKey)
                            .header("authToken", authToken)
                            //params
                            .param("nodeid", HomeUiHelper.myDocumentId)
                            .param("orderType", orderType)
                            .param("token", authtoknew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String, Object> respMap = from(response2.asString()).get("");
            HashMap<String, Object> trees2 = (HashMap<String, Object>) respMap.get("trees");
            List< HashMap<String, Object> > treesList2 = (ArrayList<HashMap<String, Object>>) trees2.get("treesList");

            for (HashMap<String, Object> treeListObj:treesList2) {
                if (treeListObj.containsKey("title") && treeListObj.get("title").toString().equals(Utils.getproperty("copyTitle"))) {
                    copyId = treeListObj.get("id").toString();
                }
            }
            for (HashMap<String, Object> treeListObj:treesList2) {
                if (treeListObj.containsKey("title") && treeListObj.get("title").toString().equals(Utils.getproperty("copyDocTitle"))) {
                    copyIdDoc = treeListObj.get("id").toString();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
