package com.bdbizviz.restassured.platform.Designer;

import com.bdbizviz.restassured.platform.DataCenter.DataCenterHelper;
import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.Utils;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.logging.Logger;
import static com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper.*;

public class DesignerImpl extends DesignerHelper {
    private static final Logger LOGGER = Logger.getLogger(DesignerImpl.class.getName());


    @BeforeClass
    public static void setupDesigner() {

        prop = Utils.getProps();//Fetch all json data of properties json file and store in prop
        urlCrtWS = Utils.getUrl( "createworkspace");
        urlCrtDB = Utils.getUrl( "createdashboard");
        urlsaveDB = Utils.getUrl( "savedashboard");
        urlgetEndpointUrl = Utils.getUrl("getEndpointUrl");
        urlgetRecords = Utils.getUrl("getRecords");
        urlgetFieldValues = Utils.getUrl("getFieldValues");
        urluploadDB = Utils.getUrl( "uploaddashboard");
        urlopenDB = Utils.getUrl( "openDashboard");
        urlgetdocumentinfobyid = Utils.getUrl( "getdocumentinfobyid");
        urlUserPreferences = Utils.getUrl( "getuserdesignerpreferences");
        urlgetAllWorkspaceAndDashboard = Utils.getUrl( "getAllWorkspaceAndDashboard");
        urlgettrashitems = Utils.getUrl( "gettrashitems");
        urlupdateDashboardOrWorkspace = Utils.getUrl( "updateDashboardOrWorkspace");
        urltrashdashboard = Utils.getUrl( "trashdashboard");
        urldeleteDashboardPermanently = Utils.getUrl( "deleteDashboardPermanently");
        urlrestoredashboardfromtrash = Utils.getUrl( "restoredashboardfromtrash");
        urlgetUserInfoByToken = Utils.getUrl( "getUserInfoByToken");
        workspaceName_WebService = Utils.getproperty("workspaceName_WebService");
        dashboardName = Utils.getproperty("dashboardName");
        workspaceName_Advanced = Utils.getproperty("workspaceName_Advanced");
        workspaceName_New = Utils.getproperty("workspaceName_New");
        dashboardName_Advanced = Utils.getproperty("dashboardName_Advanced");
        workspaceJSON = Utils.getproperty("workspaceJSON");
        typefile = Utils.getproperty("typefile");
        imagename = Utils.getproperty("imagename");
        originalfilename = Utils.getproperty("originalfilename");
        array = Utils.getproperty("dependencyDetails");
        dashboardtype = Utils.getproperty("dashboardtype");
        moveRestWorkSpace = Utils.getproperty("moveWorkspace");
        position = Long.valueOf(Utils.getproperty("position"));

        String newCommit = "";

        user = Helper.getCustomerKey(emailidcreate,space_admin);
        userauth = Helper.getAuthToken(emailidcreate,pass_admin,space_admin);
        spaceKey = user.getSpacekey();
        uid = user.getId();
        authToken = userauth.getAuthToken();


    }

    @Test(description = "getUserInfoByToken")
    public void getuserInfoByToken() {

        try {
            getUserInfoByToken(authToken);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getuserdesignerpreferences")
    public void getuserdesignerpreferences() {

        try {
            getuserdesignerpreferences(uid, spaceKey,authToken, HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getAllWorkspaceAndDashboard")
    public void getAllWorkspaceAndDashboard() {

        try {
            getAllWorkspaceAndDashboard(uid, spaceKey,authToken,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "gettrashitems")
    public void gettrashitems() {

        try {
            gettrashitems(uid, spaceKey,authToken,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "CreateWorkspace")
    public void createWorkspace() {

        try {
            fetchWorkspace(uid, spaceKey,authToken,workspaceName_Advanced,workspaceJSON,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "CreateDashboard")
    public void createDashboard() {

        try {
            String dashboardParameters = "{\"workspaceId\":\"" + workspaceId + "\",\"dashboardName\":\"" + dashboardName + "\",\"dashboardJSON\":\"{}\"}";
            fetchDashboardWebservice(dashboardParameters,uid, spaceKey,authToken,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "openDashboard")
    public void openDashboard() {
        try {
            openDashboard(uid, spaceKey,authToken,HttpStatus.SC_OK);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "RestoreWorkspace")
    public void RestoreWorkspace() {

        try {
            String dashboardParameters_restore = "{\"dashboardId\":\""+workspaceId+"\",\"workspaceId\":\""+workspaceId+"\"}";
            restoredashboardfromtrash(dashboardParameters_restore,uid, spaceKey,authToken,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getdocumentInfo")
    public void getdocumentinfobyid() {

        try {
            getDocumentInfoByID(uid, spaceKey,authToken,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "publishDashboard")
    public void publishDashboard() {

        try {
            publishDashboard(uid, spaceKey,authToken,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "saveDashboard")
    public void saveDashboard() {

        try {
           // saveDashboard(uid, spaceKey,authToken,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //flow1
    @Test(description = "CreateWorkSpaceToDeleteWorkSpace")
    public void CreateWorkSpaceToDeleteWorkSpace() {

        try {
            //Create Worksapce
            fetchWorkspace(uid, spaceKey,authToken,workspaceName_Advanced,workspaceJSON,HttpStatus.SC_OK);

            //Rename Workspace
            String dashboardParameters = "{\"dashboardId\":\""+workspaceId+"\",\"dashboardName\":\"RestWorkspaceNew\"}";
            renameOrmoveWorkspace(dashboardParameters,uid,spaceKey,authToken,HttpStatus.SC_OK);

            //Trash Workspace
            String dashboardParameters_del = "{\"dashboardId\":\""+dashboardId+"\",\"workspaceId\":\""+workspaceId+"\"}";
            trashWorkspace(dashboardParameters_del,uid,spaceKey,authToken,HttpStatus.SC_OK);

            //Get all trash items
            gettrashitems(uid, spaceKey,authToken,HttpStatus.SC_OK);

            //restore Workspace
            String dashboardParameters_restore = "{\"dashboardId\":\""+workspaceId+"\",\"workspaceId\":\""+workspaceId+"\"}";
            restoredashboardfromtrash(dashboardParameters_restore,uid, spaceKey,authToken,HttpStatus.SC_OK);

            //Trash Workspace
            trashWorkspace(dashboardParameters_del,uid,spaceKey,authToken,HttpStatus.SC_OK);

            //Delete workspace permantely
            String dashboardParameters_permanant = "{\"dashboardId\":\"["+dashboardId+"]\",\"workspaceId\":\"["+dashboardId+"]\"}";
            deleteDashboardPermanently(dashboardParameters_permanant,uid,spaceKey,authToken,HttpStatus.SC_OK);


        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //flow2
    @Test(description = "movedashboard from one workspace to other")
    public void moveDashboard() {
        try {
            //Create Worksapce
            //  fetchWorkspace(uid, spaceKey,authToken,workspaceName_Advanced,workspaceJSON);
            fetchWorkspace(uid, spaceKey,authToken,moveRestWorkSpace,workspaceJSON,HttpStatus.SC_OK);

            //Create Dashboard
            String dashboardParameters = "{\"workspaceId\":\"" + workspaceId + "\",\"dashboardName\":\"" + dashboardName + "\",\"dashboardJSON\":\"{}\"}";
            fetchDashboardWebservice(dashboardParameters,uid, spaceKey,authToken,HttpStatus.SC_OK);

            //Create Worksapce
            fetchWorkspace(uid, spaceKey,authToken,workspaceName_New,workspaceJSON,HttpStatus.SC_OK);

            //Move Workspace
            String dashboardParameters_move = "{\"dashboardId\":\""+dashboardId+"\",\"workspaceId\":\""+workspaceId+"\"}";
            renameOrmoveWorkspace(dashboardParameters_move,uid,spaceKey,authToken,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //flow3
    @Test(description = "CreateDashboardToDeleteDashboard")
    public void CreateDashboardToDeleteDashboard() {

        try {
            //Create Worksapce
            fetchWorkspace(uid, spaceKey,authToken,workspaceName_Advanced,workspaceJSON,HttpStatus.SC_OK);

            //Rename Workspace
            String dashboardParameters = "{\"dashboardId\":\""+workspaceId+"\",\"dashboardName\":\"RestFlowWorkspace\"}";
            renameOrmoveWorkspace(dashboardParameters,uid,spaceKey,authToken,HttpStatus.SC_OK);

            //create Dashboard
            String dashboardParameters_createDash = "{\"workspaceId\":\"" + workspaceId + "\",\"dashboardName\":\"" + dashboardName + "\",\"dashboardJSON\":\"{}\"}";
            fetchDashboardWebservice(dashboardParameters_createDash,uid, spaceKey,authToken,HttpStatus.SC_OK);

            //Open Dashboard
            openDashboard(uid, spaceKey,authToken,HttpStatus.SC_OK);

            //Rename dashboard
            String dashboardParameters_rename = "{\"dashboardId\":\""+dashboardId+"\",\"dashboardName\":\"RenamedWebServiceDashboard\"}";
            renameOrmoveWorkspace(dashboardParameters_rename,uid,spaceKey,authToken,HttpStatus.SC_OK);

            //getAllDashboards And worksapces
            getAllWorkspaceAndDashboard(uid, spaceKey,authToken,HttpStatus.SC_OK);

            //Move Dashboard from one workspace to other
            String dashboardParameters_move = "{\"dashboardId\":\""+dashboardId+"\",\"workspaceId\":\""+getWorkSpaceId+"\"}";
            renameOrmoveWorkspace(dashboardParameters_move,uid,spaceKey,authToken,HttpStatus.SC_OK);

            //Trash Workspace
            String dashboardParameters_del = "{\"dashboardId\":\""+workspaceId+"\",\"workspaceId\":\""+workspaceId+"\"}";
            trashWorkspace(dashboardParameters_del,uid,spaceKey,authToken,HttpStatus.SC_OK);

            //Get all trash items
            gettrashitems(uid, spaceKey,authToken,HttpStatus.SC_OK);

            //Delete workspace permantely
            String dashboardParameters_permanant = "{\"dashboardId\":\"["+dashboardId+"]\",\"workspaceId\":\"["+dashboardId+"]\"}";
            deleteDashboardPermanently(dashboardParameters_permanant,uid,spaceKey,authToken,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }


}