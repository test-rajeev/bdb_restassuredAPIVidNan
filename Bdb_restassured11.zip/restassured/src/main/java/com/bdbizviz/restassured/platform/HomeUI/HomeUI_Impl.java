package com.bdbizviz.restassured.platform.HomeUI;

import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.User;
import com.bdbizviz.restassured.platform.Util.Utils;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.bdbizviz.restassured.platform.Designer.DesignerHelper.*;
import static com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper.orderType;
import static com.bdbizviz.restassured.platform.UserManagement.UserManagement.login;
import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;

public class HomeUI_Impl extends  HomeUiHelper {
    private static final Logger LOGGER = Logger.getLogger(HomeUI_Impl.class.getName());
    public static String mydocId = "";
    public static String publicdocId = "";
    public static String sharedocId = "";
    public static String dashboardNameNew;
    public static String linkUrlIdnew;

    String newCommit = "";


    @BeforeClass
    public static void setupHomeUi(){
        prop = Utils.getProps();//Fetch all json data of properties json file and store in prop
        position = Long.valueOf(Utils.getproperty("position"));
        folderType= Utils.getproperty("folderType");
        dashboardTypeFolder= Utils.getproperty("dashboardTypeFolder");
        imagenameFile= Utils.getproperty("imagenamefile");
        folTitle= Utils.getproperty("folTitle");
        folTitleRename=Utils.getproperty("folTitleRename");
        doctype=Utils.getproperty("doctype");
        doctypefile=Utils.getproperty("doctypefile");
        docTitleRename=Utils.getproperty("docTitleRename");
        copyTitle=Utils.getproperty("copyTitle");
        copyDocTitle=Utils.getproperty("copyDocTitle");
        bIStoryname=Utils.getproperty("bIStoryname");
        wrksapceName=Utils.getproperty("wrksapceName");
        dashName = Utils.getproperty("dashName");
        dashboardNameNew = Utils.getproperty("dashboardNameNew");

        urlgetUserInfoByToken = Utils.getUrl( "getUserInfoByToken");
        urlgetAllDocuments = Utils.getUrl("getalldocuments");
        urlsaveFolData = Utils.getUrl("saveFolderData");
        urlrenameNode = Utils.getUrl("renameNode");
        urlgetFavouriteDocuments = Utils.getUrl("getfavouritedocuments");
        urlcopyPaste = Utils.getUrl("copyPaste");
        urlgetListView = Utils.getUrl("getlistview");
        urlassignAllPrivilege = Utils.getUrl("assignAllPrivilege");
        urlgetDocumentList = Utils.getUrl("getDocumentList");
        urlgetUsersfromGroups = Utils.getUrl("getUsersfromGroups");
        urlcutPaste = Utils.getUrl("cutPasteFolder");
        urlpluginService = Utils.getUrl("pluginservice");
        urlgetWikiByDocId = Utils.getUrl("getWikiByDocId");
        urlgetCubeData = Utils.getUrl("getDsData");
        urlcreateOrUpdateWiki = Utils.getUrl("createOrUpdateWiki");
        urlloadPrivilege = Utils.getUrl("loadPrivilege");
        urldmAssignExcludePrivilege = Utils.getUrl("dmAssignExcludePrivilege");


        //Non-Admin user
        user = Helper.getCustomerKey(emailidcreate,space_admin);
        userauth = Helper.getAuthToken(emailidcreate,pass_admin,space_admin);
        spaceKey = user.getSpacekey();
        uid = user.getId();
        authToken = userauth.getAuthToken();


       // restassured@bdbizviz.comert/BizViz@123
    }

    @Test(description = "getUserInfoByToken")
    public void getUserInfoByToken() {

        try {
            getUserInfoByToken(authToken);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getFavouriteDocuments")
    public void getFavouriteDocuments() {
        try {
            getFavouriteDocuments(uid,spaceKey,authToken, HttpStatus.SC_OK);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "getalldocuments")
    public void getListview() {

        try {
            getlistview(uid,spaceKey,authToken,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createDocumentOnHomeUI")
    public void createDocMyDocHomeUi() {

        try {
            createDocMyDocHomeUi(uid,spaceKey,authToken, HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createFolderAndDocument")
    public void createFolderInMyDocs() {

        try {
            createFolderInMyDocs(uid,HomeUiHelper.myDocumentId,position,authToken,spaceKey,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createFolderInPublicFolder")
    public void createFolderInPublicDoc() {

        try {
            createFolderInPublicDoc(uid,HomeUiHelper.publicDocumentId,position,authToken,spaceKey);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createDocumentInFolderPublicFolder")
    public void createDocInFolderPublicDoc() {

        try {

            createDocInFolderPublicDoc(uid,HomeUiHelper.createFol_pubId,position,authToken,spaceKey);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //======A unquie function to perform mul service calls by using folder id====//
    @Test(description ="creating the folder and renaming it, add folder to fav and delete")
    public static void createFolToDelFlow(){
        try{
            //Creating Folder
            createFolderInHomeUi(uid, myDocumentId, position,authToken,spaceKey,HttpStatus.SC_OK);
            LOGGER.info(("folderid:" +folderid_Home));

            Response response =
                    given() .header("spaceKey", spaceKey)
                            .header("authtoken", authToken)
                            .header("userID", uid)
                            .param("id",folderid_Home)
                            .param("title", folTitleRename)
                            .param("doctype", doctype)
                            .param("token",authToken)
                            .param("spacekey",spaceKey)
                            .when()
                            .post(urlrenameNode)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> trees = from(response.asString()).get("trees");
            LOGGER.info(("trees:" +trees.toString()));

            //***Assert message to check folder renaming***//
            String msg =response.path("trees.message").toString();
            // Assert.assertEquals(msg,"Folder renamed successfully!" );

            //add fol to favourites
            addFolToFav(uid,folderid_Home, authToken, spaceKey,HttpStatus.SC_OK);

            //remove fol
            removeNode(uid,folderid_Home, authToken, spaceKey,HttpStatus.SC_OK);
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    //flow2
    //====A unquie function to perform mul service calls by using document id====//
    @Test(description="crearting the Document and renaming it,add document to fav and delete")
    public static void createDocInFolToDelDocumentFlow(){
        try{
            //CreateFolAnd Document inside Folder
            createFolderInMyDocs(uid, myDocumentId,position,authToken,spaceKey,HttpStatus.SC_OK);
            Response response =
                    given() //headers
                            .header("spaceKey", spaceKey)
                            .header("authToken", authToken)
                            .header("userID", uid)
                            //params
                            .param("id", docId)
                            .param("title", docTitleRename)
                            .param("doctype", doctypefile)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlrenameNode)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees = from(response.asString()).get("trees");
            LOGGER.info(("trees_RenameDoc:" +trees.toString()));

            //***Assert message to check Document renaming***//
            String msg =response.path("trees.message").toString();
            //  Assert.assertEquals(msg,"Document renamed successfully!" );

            // Adding Document to Favourites
            addDocToFav(uid,folderid,authToken,spaceKey,HttpStatus.SC_OK);

            // moveDocument();
            removeNodeDocument(uid,folderid,authToken,spaceKey,HttpStatus.SC_OK);



        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //flow3
    @Test(description ="creating the Folder and deleting it")
    public static void copyFolder(){
        try{
            getUserInfoByToken(authToken);
            createFolderInHomeUi(uid, HomeUiHelper.myDocumentId, position,authToken,spaceKey,HttpStatus.SC_OK);
            String dashboardType = Utils.getproperty("dashboardType");

            Response response =
                    given()
                            //headers
                            .header("userID", uid)
                            .header("spaceKey", spaceKey)
                            .header("authToken", authToken)

                            //params
                            .param("source", folderid_Home)
                            .param("title", copyTitle)
                            .param("destination", HomeUiHelper.myDocumentId)
                            .param("dashboardType",  Integer.valueOf(dashboardType))
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlcopyPaste)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> responseMap = from(response.asString()).get("");
            LOGGER.info(("response_CopyFolder:" +responseMap.toString()));

            //****Assert to check success message***//
            // Assert.assertEquals(responseMap.get("success").toString(), "true");

            //***Deleting the created folder***//
            LOGGER.info(("folderid_Home:" +folderid_Home ));

            Response response1 =
                    given()
                            //headers
                            .header("userID", uid)
                            .header("spaceKey", spaceKey)
                            .header("authToken", authToken)
                            //params
                            .param("id", folderid_Home)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees1 = from(response1.asString()).get("trees");
            System.out.println(("trees_DelFolder:" +trees1.toString()));

            //****getListView to get the id of copied folder****//
            String orderType = null;
            Response response2 =
                    given()
                            //headers
                            .header("userID", uid)
                            .header("spaceKey", spaceKey)
                            .header("authToken", authToken)
                            //params
                            .param("nodeid", HomeUiHelper.myDocumentId)
                            .param("orderType", orderType)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> respMap = from(response2.asString()).get("");
            HashMap<String, Object> trees2 = (HashMap<String, Object>) respMap.get("trees");
            List< HashMap<String, Object> > treesList2 = (ArrayList<HashMap<String, Object>>) trees2.get("treesList");

            for (HashMap<String, Object> treeListObj:treesList2) {
                if (treeListObj.containsKey("title") && treeListObj.get("title").toString().equals(Utils.getproperty("copyTitle"))) {
                    copyId = treeListObj.get("id").toString();
                }
            }

            //***Deleting the copied folder***//
            LOGGER.info(("copyId:" +copyId ));
            urlremoveNode = Utils.getUrl("removeNode");
            Response response3 =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            //params
                            .param("id", copyId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees3 = from(response3.asString()).get("trees");
            System.out.println(("trees_DelCopiedFol:" +trees3.toString()));

            //****getListView to compare json****//
            urlgetListView = Utils.getUrl("getlistview");
            Response responseGetList4 =
                    given()
                            //headers
                            .header("userID", uid)
                            .header("spaceKey", spaceKey)
                            .header("authToken", authToken)
                            //params
                            .param("nodeid", myDocumentId)
                            .param("orderType", orderType)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> respMap4 = from(responseGetList4.asString()).get("");
            HashMap<String, Object> treesGetList4 = (HashMap<String, Object>) respMap4.get("trees");
            List< HashMap<String, Object> > treesList4 = (ArrayList<HashMap<String, Object>>) treesGetList4.get("treesList");
            //  id = (Integer)treesList4.get(0).get("id");

        }
        catch(Exception e){
            e.printStackTrace();
        }

    }

    //flow4
    @Test(description ="creating the Document inside folder and copy pasting in my documents")
    public static void copyDocument(){
        try{
            int x = 0;
            Long postion = new Long(x);

            int dashDocType = 0;
            Long dashDoc = new Long(dashDocType);

            createDocInMyDoc(uid, doctypefile,dashDoc ,myDocumentId,postion,authToken,spaceKey, HttpStatus.SC_OK);
            String dashboardType = Utils.getproperty("dashboardType");

            Response response =
                    given() .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            .param("source", docId)
                            .param("title",copyDocTitle)/*copyDocTitle=Copy of myDoc_Sep18*/
                            .param("destination", myDocumentId)
                            .param("dashboardType",Integer.valueOf(dashboardType))
                            .param("spacekey", spaceKey)
                            .param("token", authToken)
                            .when()
                            .post(urlcopyPaste)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> responseMap = from(response.asString()).get("");
            LOGGER.info(("response_CopyDocument:" +responseMap.toString()));

            //****Assert to check success message***//
            Assert.assertEquals(responseMap.get("success").toString(),"true" );

            //*****To remove the created document****//
            Response responseDel1 =
                    given() .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            .param("id", docId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees1 = from(responseDel1.asString()).get("trees");
            HashMap<String, Object> tree1 = (HashMap)trees1.get("tree");
            delDocId = (Integer) tree1.get("id");
            LOGGER.info(("trees:" +trees1.toString()));

            //****To check whether created document is successfully deleted ****//
            //  Assert.assertNull(delDocId);

            //******getListView to get the id of copied document******//
            Response responseGetList2 =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            .param("nodeid", myDocumentId)
                            .param("orderType", orderType)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> respMap2 = from(responseGetList2.asString()).get("");
            HashMap<String, Object> trees2 = (HashMap<String, Object>) respMap2.get("trees");
            List< HashMap<String, Object> > treesList2 = (ArrayList<HashMap<String, Object>>) trees2.get("treesList");

            for (HashMap<String, Object> treeListObj:treesList2) {
                if (treeListObj.containsKey("title") && treeListObj.get("title").toString().equals(Utils.getproperty("copyDocTitle"))) {
                    copyIdDoc = (Integer) treeListObj.get("id");
                }
            }
            //***Deleting the copied document***//
            LOGGER.info(("copyId:" +copyIdDoc ));
            Response responseDel2 =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            .param("id", copyIdDoc)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees3 = from(responseDel2.asString()).get("trees");
            LOGGER.info(("trees_DeleteCopyDoc:" +trees3.toString()));

            //****getListView to compare json****//
            Response responseGetList4 =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            .param("nodeid", myDocumentId)
                            .param("orderType", orderType)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> respMap4 = from(responseGetList4.asString()).get("");
            HashMap<String, Object> treesGetList4 = (HashMap<String, Object>) respMap4.get("trees");
            List< HashMap<String, Object> > treesList4 = (ArrayList<HashMap<String, Object>>) treesGetList4.get("treesList");
            // id = (Integer)treesList4.get(0).get("id");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //flow5
    @Test(description = "creating the folder and moving the same")
    public static void moveFolder(){
        try{
            createFolderInHomeUi(uid, myDocumentId, position,authToken,spaceKey,HttpStatus.SC_OK);

            Response response =
                    given()
                            //headers
                            .header("userid", uid)
                            .header("spaceKey", spaceKey)
                            .header("authToken", authToken)
                            //params
                            .param("source",folderid_Home)
                            .param("moveto",Utils.getproperty("moveto"))
                            .param("destination",myDocumentId)
                            .param("title",folTitleRename)
                            .param("token",authToken)
                            .param("spacekey",spaceKey)
                            .when()
                            .post(urlcutPaste)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> trees = from(response.asString()).get("trees");
            LOGGER.info(("trees:" +trees.toString()));

            //****To assert that the folder is moved successfully****//
            String success = trees.get("success").toString();
            Assert.assertEquals(success,"true" );

            //****To delete the moved folder****//
            LOGGER.info(("folderid:" +folderid_Home ));

            Response response1 =
                    given()
                            //headers
                            .header("userid", uid)
                            .header("spaceKey", spaceKey)
                            .header("authtoken", authToken)
                            //params
                            .param("id",folderid_Home)
                            .param("token",authToken)
                            .param("spacekey",spaceKey)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees1 = from(response1.asString()).get("trees");
            LOGGER.info(("trees:" +trees1.toString()));

            //***Assert message to check folder has deleted***//
            //   Assert.assertEquals(trees1.get("message").toString(),"Folder deleted successfully!" );


        }
        catch(Exception e){
            e.printStackTrace();
        }

    }

    //flow6
    @Test(description = "creating the document and moving the same")
    public static void moveDocument(){
        try{
            //create Document
            createDocMyDocHomeUi(uid, spaceKey,authToken, HttpStatus.SC_OK);

            //moveToList
            moveToList(docId_HomeUi,uid, folderid_Home, authToken, spaceKey,HttpStatus.SC_OK );

            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("authtoken", authToken)
                            .header("userid", uid)
                            .param("source",docId_HomeUi)
                            .param("moveto",Utils.getproperty("moveto"))
                            .param("destination",folderid_Home)
                            .param("title", Utils.getproperty("documentTitle"))
                            .param("token",authToken)
                            .param("spacekey",spaceKey)
                            .when()
                            .post(urlcutPaste)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> trees = from(response.asString()).get("trees");
            LOGGER.info(("trees:" +trees.toString()));

            //***Assert message to check document has moved successfully ***//
            //  Assert.assertEquals(trees.get("success").toString(), success );

            //****To remove moved document***
            Response response1 =
                    given()
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            .header("userid", uid)
                            .param("id",docId_HomeUi)
                            .param("token",authToken)
                            .param("spacekey",spaceKey)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees1 = from(response1.asString()).get("trees");
            LOGGER.info(("trees:" +trees1.toString()));

            //***Assert message to check folder has deleted***//
            // Assert.assertEquals(trees1.get("message").toString(),"Document deleted successfully!" );


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //flow7
    @Test(description ="Create User, share Document to User and delete document,delete user")
    public static void getDocumentList(){

        try {
            //Create Folder and document inside
            createFolderInMyDocs(uid, myDocumentId,position,authToken,spaceKey,HttpStatus.SC_OK);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("NEWCREATEGRPID==" + newgroupid);

            //ShareDocumentToUser
            shareDocUser(docId,uid,authToken,spaceKey, HttpStatus.SC_OK);
            System.out.println("emailId ======"+emailidcreatefun);
            System.out.println("createUserId ======"+newuseridfunuser);

            //Login with new user passing valid password
            User usernew = Helper.getCustomerKey(emailidcreatefun,space_admin);
            User userobjauthnew = Helper.getAuthToken(emailidcreatefun,pass_admin, space_admin);
            String authnew =  null;
            authnew = userobjauthnew.getAuthToken();
            String idnew = null;
            idnew = usernew.getId();

            //***calling documentListView by logging from the Selected user credentials***//
            Response response_DocumentList =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userid", Integer.valueOf(idnew))
                            .header("authtoken", authnew)

                            //params
                            .param("userId", idnew)
                            .param("nodeId", folderid)
                            .param("token",authnew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetDocumentList)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> resp = from(response_DocumentList.asString()).get("");
            HashMap<String,Object> trees = (HashMap)resp.get("trees");
            List<HashMap<String,Object>> treesList = (ArrayList<HashMap<String, Object>>)trees.get("treesList");

            for (HashMap<String, Object> treeListObj : treesList) {
                if (treeListObj.containsKey("id") &&   treeListObj.get("id").toString().equals(docId)) {
                    sharedDocid =  treeListObj.get("id").toString();
                }
            }

            LOGGER.info(("trees_DocumentList:" +trees.toString()));
            LOGGER.info(("sharedDocid:" +sharedDocid));

            //****Assert to check whether document is shared for user ***//
            Assert.assertEquals(sharedDocid, docId);

            //****removing the shared document****//
            urlremoveNode = Utils.getUrl("removeNode");
            Response response_removeDoc =
                    given()
                            //headers
                            .header("spaceKey", spaceKey)
                            .header("authtoken", authToken)
                            .header("userid", uid)
                            //params
                            .param("id", sharedDocid)
                            .param("spacekey", spaceKey)
                            .param("token", authToken)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees_removeDoc = from(response_removeDoc.asString()).get("trees");
            LOGGER.info(("trees:" +trees_removeDoc.toString()));

            //***Assert message to check document has deleted ***//
            String remove_msg =response_removeDoc.path("trees.message").toString();
            //   Assert.assertEquals(remove_msg,"Document deleted successfully!" );

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //flow8
    @Test(description =" Create User, group, crate DocumentShare the document to assigned usergroup and exclude the selected user")
    public static void excludeDocUserGroup(){
        try{

            //Create Folder and document inside
            createFolderInMyDocs(uid, myDocumentId,position,authToken,spaceKey,HttpStatus.SC_OK);
            System.out.println("selDocId:"+docId);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("selUserGrpId==" + newgroupid);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+ Helper.generateRandomString(),usrname,fullname+ Helper.generateRandomString(),pass_admin,newgroupid,authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);


            //getting User from groups
            getusersfromgroups(uid,newgroupid, authToken, spaceKey,HttpStatus.SC_OK );

            //Sharing Document to Usergroup
            shareDocUserGroup(docId,newgroupid, selUserId, uid, authToken,spaceKey,HttpStatus.SC_OK);

            //Login with new user passing  valid password
            User usernew = Helper.getCustomerKey(selUsers_MailId,space_admin);
            User userobjauthnew = Helper.getAuthToken(selUsers_MailId,pass_admin, space_admin);
            String authnew =  null;
            authnew = userobjauthnew.getAuthToken();
            String idnew = null;
            idnew = usernew.getId();

            //****DocumentList service to check whether the particular user has excluded to get the documents***//
            Response response1 =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userid", Integer.valueOf(idnew))
                            .header("authtoken", authnew)
                            //params
                            .param("userId", idnew)
                            .param("nodeId", myDocumentId)
                            .param("token",authnew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetDocumentList)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> resp = from(response1.asString()).get("");
            HashMap<String,Object> trees = (HashMap)resp.get("trees");
            List< HashMap<String, Object> > treesList = (ArrayList<HashMap<String, Object>>) trees.get("treesList");

            for(HashMap<String, Object> tree:treesList){
                if(tree.containsKey("id") && tree.get("id").equals(docId)){
                    sharedDocid =  tree.get("id").toString();
                }
            }
            LOGGER.info(("trees:" +trees.toString()));
            LOGGER.info(("sharedDocid:" +sharedDocid));

            //****Assert to check whether document is shared for the same user and document is shared excluding the user ***//
            Assert.assertEquals(selUserId, Integer.valueOf(idnew));

            //=====Calling remove node service to delete the created folder===//
            urlremoveNode = Utils.getUrl("removeNode");
            Response response_del =
                    given() //headers
                            .header("spaceKey", spaceKey)
                            .header("authToken", authToken)
                            .header("userid", uid)
                            //params
                            .param("id", folderid)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees_del = from(response_del.asString()).get("trees");
            LOGGER.info(("trees:" +trees_del.toString()));

            /**Assert message to check  folder deleted**/
            String msg_del = trees_del.get("message").toString();
            //  Assert.assertEquals(msg_del,"Folder deleted successfully!" );

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    //Flow 9
    //when we click on any document and click on properties//
    @Test(description ="get the document info(when we modify the document")
    public static void getDocumentInfoById(){
        try{
            //*****Calling order by date service******//
            String orderTypeDate = Utils.getproperty("orderTypeDate");
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            .param("nodeid", myDocumentId)
                            .param("orderType", orderTypeDate)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> responseMap = from(response.asString()).get("trees");
            LOGGER.info(("trees:" +responseMap.toString()));

            //****Assert to check success message***//
            Assert.assertEquals(responseMap.get("success").toString(),"true" );

            //calling createDoc function to fetch the docid
            int x = 0;
            Long postion = new Long(x);

            int dashDocType = 0;
            Long dashDoc = new Long(dashDocType);
            createDocInMyDoc(uid, doctypefile,dashDoc ,myDocumentId,postion,authToken,spaceKey, HttpStatus.SC_OK);

            //adding getThumbnailByTreeID in a flow
            getThumbnailByTreeID(docId,uid,authToken,spaceKey, HttpStatus.SC_OK);

            urlgetdocumentinfobyid = Utils.getUrl( "getdocumentinfobyid");
            Response response1 =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            .param("docId", docId)
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdocumentinfobyid)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> resp = from(response1.asString()).get("");
            HashMap<String,Object> trees = (HashMap)resp.get("trees");
            HashMap<String, Object> tree = (HashMap)trees.get("tree");
            LOGGER.info(("trees:" +trees.toString()));

            //****Assert to check id is not null***//
            String dcId =  tree.get("id").toString();
            Assert.assertNotNull(dcId);
            Assert.assertEquals(docId, dcId);

            //******Asserting whether compared json is same as expected****//

            //Hahmap to json conversion//
            JSONObject expectedJson = new JSONObject();
            expectedJson.putAll(resp);

            //Delete document
            removeNodeDocument(uid,docId,authToken,spaceKey,HttpStatus.SC_OK);

        }catch(Exception e){
            e.printStackTrace();
        }


    }

    //BI-Story Creation
    @Test(description = "creating and saving the Story in My documents")
    public static void createStoryFlow(){

        try {
            createStoryInFolderMyDoc(Utils.getproperty("consumerNameCreateStory"),Utils.getproperty("serviceNameCreateStory"),spaceKey,authToken,uid, HttpStatus.SC_OK);

            saveStoryData(storyId,authToken,spaceKey,uid,HttpStatus.SC_OK);

            getData(savedStoryId,authToken,spaceKey,uid,HttpStatus.SC_OK);

            getWikiByDocId(savedStoryId, authToken,spaceKey,uid,HttpStatus.SC_OK);

            getStoryById(Utils.getproperty("consumerNameCreateStory"),Utils.getproperty("serviceNameStory"),authToken,spaceKey,uid,HttpStatus.SC_OK);

            getDeliveryResultByOwnerId(Utils.getproperty("consumerNamegetDeliveryResultByOwnerId"), Utils.getproperty("serviceNamegetDeliveryResultByOwnerId"),authToken,spaceKey,uid,HttpStatus.SC_OK);

            getDataStoreDetails(Utils.getproperty("consumerNamegetCubeDetails"), Utils.getproperty("serviceNamegetDatastoreDetails"),authToken,spaceKey,uid,HttpStatus.SC_OK);

            getCubeInfo(Utils.getproperty("consumerNamegetCubeById"), Utils.getproperty("serviceNamegetCubeInfo"),authToken,spaceKey,uid, HttpStatus.SC_OK);

            serviceNamegetCubeData = bizvizCubeId + spaceKey;
            String cubeDataDimen = "{\"title\":\"Untitled\",\"desc\":\"By Location_Id\",\"defaultChartClass\":\"MixedChart\",\"chartProperties\":{\"Object.Chart.xAxis.LabelFontSize\":\"12\",\"Object.Chart.yAxis.LabelFontSize\":\"12\",\"Object.Chart.Precision\":\"0\",\"Object.Chart.secondaryAxisShow\":false,\"Object.Chart.SecondaryAxisPrecision\":\"0\",\"Object.Chart.SecondaryAxisSecondaryFormatter\":\"Number\",\"Object.Chart.SecondaryAxisSecondaryUnit\":\"auto\",\"Object.Chart.SecondaryFormater\":\"Number\",\"Object.Chart.Unit\":\"None\",\"Object.Chart.SecondaryUnit\":\"auto\",\"Object.Chart.showSlider\":false,\"Object.Chart.baseZero\":false},\"filter\":{},\"filterList\":\"None\",\"mergedCubes\":[],\"currentCube\":null,\"isMergeEnabled\":false,\"mergedCubeDetails\":{},\"aggregation\":{\"op\":\"sum\",\"sfx\":\"\",\"pfx\":\"\",\"measure\":\"\"},\"category\":[{\"dimension\":\"Location_Id\",\"interval\":\"\",\"sourceID\":"+bizvizCubeId+"}],\"series\":[],\"transDim\":\"\",\"customField\":[],\"rules\":[],\"properties\":{\"legend\":{\"enable\":false,\"orientation\":1,\"style\":1},\"excludeView\":{\"enable\":false},\"showDataLabel\":true,\"cardFilter\":{\"enabled\":false,\"field\":\"None\"},\"dataRestriction\":{}},\"querytype\":\"simple\",\"mergedDataStore\":{},\"masterDataStore\":\""+bizvizCubeId+"\"}";
            getCubeData(cubeDataDimen,Utils.getproperty("consumerNamegetCubeData"), serviceNamegetCubeData,authToken,spaceKey,uid,HttpStatus.SC_OK);

            String cubeDataMeasure = "{\"title\":\"Sum( Order_Amount )\",\"desc\":\"By Location_Id\",\"defaultChartClass\":\"MixedChart\",\"chartProperties\":{\"Object.Chart.xAxis.LabelFontSize\":\"12\",\"Object.Chart.yAxis.LabelFontSize\":\"12\",\"Object.Chart.Precision\":\"0\",\"Object.Chart.secondaryAxisShow\":false,\"Object.Chart.SecondaryAxisPrecision\":\"0\",\"Object.Chart.SecondaryAxisSecondaryFormatter\":\"Number\",\"Object.Chart.SecondaryAxisSecondaryUnit\":\"auto\",\"Object.Chart.SecondaryFormater\":\"Number\",\"Object.Chart.Unit\":\"None\",\"Object.Chart.SecondaryUnit\":\"auto\",\"Object.Chart.showSlider\":false,\"Object.Chart.baseZero\":false,\"Object.Chart.showLegends\":false},\"filter\":{},\"filterList\":\"None\",\"mergedCubes\":[],\"currentCube\":null,\"isMergeEnabled\":false,\"mergedCubeDetails\":{},\"aggregation\":{\"op\":\"sum\",\"sfx\":\"\",\"pfx\":\"\",\"measure\":\"\"},\"category\":[{\"dimension\":\"Location_Id\",\"interval\":\"\",\"sourceID\":"+bizvizCubeId+"}],\"series\":[{\"measure\":\"Order_Amount\",\"op\":\"sum\",\"sourceID\":"+bizvizCubeId+"}],\"transDim\":\"\",\"customField\":[],\"rules\":[],\"properties\":{\"legend\":{\"enable\":false,\"orientation\":1,\"style\":1},\"excludeView\":{\"enable\":false},\"showDataLabel\":true,\"cardFilter\":{\"enabled\":false,\"field\":\"None\"},\"dataRestriction\":{}},\"querytype\":\"simple\",\"mergedDataStore\":{},\"masterDataStore\":\""+bizvizCubeId+"\"}";
            getCubedataDimen2(cubeDataMeasure,Utils.getproperty("consumerNamegetCubedataDimen2"), serviceNamegetCubeData,authToken,spaceKey,uid,HttpStatus.SC_OK);

            String cubeDataMeasureTwo = "{\"title\":\"Sum( Order_Amount )\",\"desc\":\"By Location_Id\",\"defaultChartClass\":\"MixedChart\",\"chartProperties\":{\"Object.Chart.xAxis.LabelFontSize\":\"12\",\"Object.Chart.yAxis.LabelFontSize\":\"12\",\"Object.Chart.Precision\":\"0\",\"Object.Chart.secondaryAxisShow\":false,\"Object.Chart.SecondaryAxisPrecision\":\"0\",\"Object.Chart.SecondaryAxisSecondaryFormatter\":\"Number\",\"Object.Chart.SecondaryAxisSecondaryUnit\":\"auto\",\"Object.Chart.SecondaryFormater\":\"Number\",\"Object.Chart.Unit\":\"None\",\"Object.Chart.SecondaryUnit\":\"auto\",\"Object.Chart.showSlider\":false,\"Object.Chart.baseZero\":false,\"Object.Chart.showLegends\":false},\"filter\":{},\"filterList\":\"None\",\"mergedCubes\":[],\"currentCube\":null,\"isMergeEnabled\":false,\"mergedCubeDetails\":{},\"aggregation\":{\"op\":\"sum\",\"sfx\":\"\",\"pfx\":\"\",\"measure\":\"\"},\"category\":[{\"dimension\":\"Location_Id\",\"interval\":\"\",\"sourceID\":"+bizvizCubeId+"}],\"series\":[{\"measure\":\"Order_Amount\",\"op\":\"sum\",\"sourceID\":"+bizvizCubeId+"},{\"measure\":\"Commission\",\"op\":\"sum\",\"sourceID\":"+bizvizCubeId+"}],\"transDim\":\"\",\"customField\":[],\"rules\":[],\"properties\":{\"legend\":{\"enable\":false,\"orientation\":1,\"style\":1},\"excludeView\":{\"enable\":false},\"showDataLabel\":true,\"cardFilter\":{\"enabled\":false,\"field\":\"None\"},\"dataRestriction\":{}},\"querytype\":\"simple\",\"mergedDataStore\":{},\"masterDataStore\":\""+bizvizCubeId+"\"}";
            getCubedataDimen2(cubeDataMeasureTwo,Utils.getproperty("consumerNamegetCubedataDimen2"), serviceNamegetCubeData,authToken,spaceKey,uid,HttpStatus.SC_OK);

            String filterdata = "{\"filter\":{},\"dimForFilter\":[\"Location_Id\"],\"dimension\":[{\"name\":\"Location_Id\",\"interval\":\"\"}],\"measure\":[],\"facts\":{},\"elasticSearch\":{\"isEnabled\":true},\"limit\":[\"0\"]}";
            getDistinctDimName(filterdata,Utils.getproperty("consumerNamegetCubedataDimen2"), serviceNamegetCubeData,authToken,spaceKey,uid,HttpStatus.SC_OK);

            String filterCubeData = "{\"title\":\"Sum( Order_Amount )\",\"desc\":\"By Location_Id\",\"defaultChartClass\":\"MixedChart\",\"chartProperties\":{\"Object.Chart.xAxis.LabelFontSize\":\"12\",\"Object.Chart.yAxis.LabelFontSize\":\"12\",\"Object.Chart.Precision\":\"0\",\"Object.Chart.secondaryAxisShow\":false,\"Object.Chart.SecondaryAxisPrecision\":\"0\",\"Object.Chart.SecondaryAxisSecondaryFormatter\":\"Number\",\"Object.Chart.SecondaryAxisSecondaryUnit\":\"auto\",\"Object.Chart.SecondaryFormater\":\"Number\",\"Object.Chart.Unit\":\"None\",\"Object.Chart.SecondaryUnit\":\"auto\",\"Object.Chart.showSlider\":false,\"Object.Chart.baseZero\":false,\"Object.Chart.showLegends\":false},\"filter\":{\"Location_Id\":[\"301161\",\"301721\",\"301781\",\"301451\",\"301306\",\"301252\",\"301509\",\"301564\",\"301326\"]},\"filterList\":\"None\",\"mergedCubes\":[],\"currentCube\":null,\"isMergeEnabled\":false,\"mergedCubeDetails\":{},\"aggregation\":{\"op\":\"sum\",\"sfx\":\"\",\"pfx\":\"\",\"measure\":\"\"},\"category\":[{\"dimension\":\"Location_Id\",\"interval\":\"\",\"sourceID\":"+bizvizCubeId+"}],\"series\":[{\"measure\":\"Order_Amount\",\"op\":\"sum\",\"sourceID\":"+bizvizCubeId+"},{\"measure\":\"Commission\",\"op\":\"sum\",\"sourceID\":"+bizvizCubeId+"}],\"transDim\":\"\",\"customField\":[],\"rules\":[],\"properties\":{\"legend\":{\"enable\":false,\"orientation\":1,\"style\":1},\"excludeView\":{\"enable\":false},\"showDataLabel\":true,\"cardFilter\":{\"enabled\":false,\"field\":\"None\"},\"dataRestriction\":{}},\"querytype\":\"simple\",\"mergedDataStore\":{},\"masterDataStore\":\""+bizvizCubeId+"\"}";
            getCubedataDimen2(filterCubeData,Utils.getproperty("consumerNamegetCubedataDimen2"), serviceNamegetCubeData,authToken,spaceKey,uid,HttpStatus.SC_OK);

            saveCubeView(Utils.getproperty("consumerNamesaveCubeView"),Utils.getproperty("serviceNamesaveCubeView"),authToken,spaceKey,uid,HttpStatus.SC_OK);

            CreateViewLog(Utils.getproperty("consumerNameCreateViewLog"),Utils.getproperty("serviceNameCreateViewLog"),authToken, spaceKey,uid,HttpStatus.SC_OK);

            String dataStr = "{\"spaceKey\":\""+spaceKey+"\",\"storyDefenition\":\"{\\\"theme\\\":\\\"none\\\",\\\"version\\\":\\\"3.2.0\\\",\\\"story\\\":[{\\\"cube\\\":"+bizvizCubeId+",\\\"cubeview\\\":[{\\\"ref\\\":\\\"c19176e5-e638-4047-a535-884612fbb1d0\\\",\\\"id\\\":"+cubeViewId+",\\\"data\\\":\\\"{\\\\\\\"measure\\\\\\\":[{\\\\\\\"name\\\\\\\":\\\\\\\"Order_Amount\\\\\\\",\\\\\\\"op\\\\\\\":\\\\\\\"sum\\\\\\\"},{\\\\\\\"name\\\\\\\":\\\\\\\"Commission\\\\\\\",\\\\\\\"op\\\\\\\":\\\\\\\"sum\\\\\\\"}],\\\\\\\"dimension\\\\\\\":[{\\\\\\\"name\\\\\\\":\\\\\\\"Location_Id\\\\\\\",\\\\\\\"interval\\\\\\\":\\\\\\\"\\\\\\\"}],\\\\\\\"facts\\\\\\\":{\\\\\\\"Location_Id\\\\\\\":[\\\\\\\"301161\\\\\\\",\\\\\\\"301721\\\\\\\",\\\\\\\"301781\\\\\\\",\\\\\\\"301451\\\\\\\",\\\\\\\"301306\\\\\\\",\\\\\\\"301252\\\\\\\",\\\\\\\"301509\\\\\\\",\\\\\\\"301564\\\\\\\",\\\\\\\"301326\\\\\\\"]},\\\\\\\"transDim\\\\\\\":\\\\\\\"\\\\\\\",\\\\\\\"elasticSearch\\\\\\\":{\\\\\\\"isEnabled\\\\\\\":true},\\\\\\\"limit\\\\\\\":[\\\\\\\"0\\\\\\\"]}\\\"}]}],\\\"storyProperties\\\":{\\\"viewOrder\\\":[\\\"c19176e5-e638-4047-a535-884612fbb1d0\\\"],\\\"viewCfg\\\":{\\\"c19176e5-e638-4047-a535-884612fbb1d0\\\":{\\\"chartProperties\\\":{},\\\"size\\\":{\\\"w\\\":4,\\\"h\\\":5},\\\"sizeRestriction\\\":{}}},\\\"theme\\\":0},\\\"action\\\":{}}\",\"name\":\""+bIStoryname+"\",\"id\":"+storyId+",\"isActive\":0,\"createdDate\":null,\"lastUpdatedDate\":null}";
            String consumerNamesaveStory = Utils.getproperty("consumerNamesaveStory");
            String serviceNamesaveStory = Utils.getproperty("serviceNamesaveStory");
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", "true")
                            .param("consumerName", consumerNamesaveStory)
                            .param("serviceName", serviceNamesaveStory)
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpluginService)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees = from(response.asString()).get("");
            String name= trees.get("name").toString();
            LOGGER.info(("trees:" +trees.toString()));

            //****Asserting for create document****//
            Assert.assertEquals(name, bIStoryname);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Comments Workflow
    @Test(description = "commentsFlow")
    public static void commentsFlow(){
        try {
            getListViewStory(authToken,spaceKey,uid,HttpStatus.SC_OK);
            int statusCode = HttpStatus.SC_OK;

            //fetching wikiId
            Response response_WikiById =
                    given()
                            // headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authToken", authToken)
                            // params
                            .param("docId", selDocId_GetList)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetWikiByDocId)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> wikiResp = from(response_WikiById.asString()).get("wikiResp");
            HashMap<String, Object> wiki = (HashMap) wikiResp.get("wiki");
            wikiId = (Integer)wiki.get("id");
            System.out.println("wiki :" + wikiResp.get("wiki"));
            HashMap<String, Object> docId = (HashMap) wiki.get("docId");

            //***Assert to check id is not null and success message***//
            Integer respId = (Integer) docId.get("id");
            //  Assert.assertNotNull(wikiId);
            Assert.assertNotNull(respId);
            Assert.assertEquals(wikiResp.get("success"), true);

            //Adding comments
            Date dt = new Date();
            Long epoch  = System.currentTimeMillis();
            String name = "RestAutomation" + epoch;
            String data="{\""+name+"\":{\"owner\":\"RestAutomation\",\"comment\":\"AddedComment\",\"status\":\"true\",\"time\":\""+dt+"\",\"deletedby\":\"none\"}}";
            Response response_Comments =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            .param("data", data)
                            .param("blogStatus", "true")
                            .param("docId", selDocId_GetList)
                            /* .param("id", wikiId)*/
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlcreateOrUpdateWiki)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String, Object> resp_comment = from(response_Comments.asString()).get("wikiResp");
            HashMap<String, Object> wiki_comment = (HashMap) wikiResp.get("wiki");
            //  wikiId = (Integer)wiki_comment.get("id");
            System.out.println("wiki_comment :" + wikiResp.get("wiki"));
            HashMap<String, Object> docId_resp = (HashMap) wiki_comment.get("docId");


            LOGGER.info("comment"+resp_comment);

            //***Assert to check id is not null and success message***//
            //  Assert.assertNotNull(wikiId);
            Assert.assertNotNull(docId_resp);
            Assert.assertEquals(wikiResp.get("success"), true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //OpenDoc Story Flow
    @Test(description = "StoryOpenDocFlow")
    public static void openDocStoryFlow(){
        try{
            //getListView to get Story Id
            getListViewStory(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //Get the storyId from create story service, fetgch it from story service-Incomplete
            loadPrivilege(selDocId_GetList, authToken,spaceKey,uid,HttpStatus.SC_OK);

            urlgetdocumentinfobyid = Utils.getUrl( "getdocumentinfobyid");
            Response response1 =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            .param("docId", selDocId_GetList)
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdocumentinfobyid)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> resp = from(response1.asString()).get("");
            HashMap<String,Object> trees = (HashMap)resp.get("trees");
            HashMap<String, Object> tree = (HashMap)trees.get("tree");
            LOGGER.info(("trees:" +trees.toString()));

            //****Assert to check id is not null***//
            String dcId =  tree.get("id").toString();
            Assert.assertNotNull(dcId);
            Assert.assertEquals(selDocId_GetList, dcId);

            //adding getThumbnailByTreeID in a flow
            getThumbnailByTreeID(selDocId_GetList,uid,authToken,spaceKey, HttpStatus.SC_OK);

            //Creating ApiToken
            createApiToken(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //getData of Story
            savedStoryId = Integer.valueOf(selDocId_GetList);
            getData(savedStoryId,authToken,spaceKey,uid,HttpStatus.SC_OK);

            //Cubedata service call after click on open doc Url
            String filterCubeData = "{\"measure\":[{\"name\":\"Order_Amount\",\"op\":\"sum\"},{\"name\":\"Commission\",\"op\":\"sum\"}],\"dimension\":[{\"name\":\"Location_Id\",\"interval\":\"\"}],\"facts\":{\"Location_Id\":[\"301161\",\"301721\",\"301781\",\"301451\",\"301306\",\"301252\",\"301509\",\"301564\",\"301326\"]},\"transDim\":\"\",\"elasticSearch\":{\"isEnabled\":true},\"limit\":[\"0\"]}";
            System.out.println(filterCubeData);

            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authToken", authToken)
                            // req data
                            .param("consumerName", Utils.getproperty("consumerNamegetCubedataDimen2"))
                            .param("serviceName", serviceNamegetCubeData)
                            .param("data", filterCubeData)
                            .param("isSecure", "true")
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetCubeData)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            //  List<HashMap<String, Object>>respCubedata = from(response.asString()).get("");
            LOGGER.info(("resp:" +response.toString()));

            String expectedCubeDataJson = "[{\"Location_Id\":\"301161\",\"sum_Order_Amount\":\"250521.260000004782341420650482177734375\",\"sum_Commission\":\"45039\"},{\"Location_Id\":\"301721\",\"sum_Order_Amount\":\"124236.07000000003608874976634979248046875\",\"sum_Commission\":\"4372.75\"},{\"Location_Id\":\"301781\",\"sum_Order_Amount\":\"59482.1099999992802622728049755096435546875\",\"sum_Commission\":\"2854.1099999999669307726435363292694091796875\"},{\"Location_Id\":\"301451\",\"sum_Order_Amount\":\"70954.519999999436549842357635498046875\",\"sum_Commission\":\"2966\"},{\"Location_Id\":\"301306\",\"sum_Order_Amount\":\"74518.25\",\"sum_Commission\":\"5723\"},{\"Location_Id\":\"301252\",\"sum_Order_Amount\":\"53867.8499999999985448084771633148193359375\",\"sum_Commission\":\"4363\"},{\"Location_Id\":\"301509\",\"sum_Order_Amount\":\"60356.8399999998291605152189731597900390625\",\"sum_Commission\":\"7014.5199999999385909177362918853759765625\"},{\"Location_Id\":\"301564\",\"sum_Order_Amount\":\"38165.220000000859727151691913604736328125\",\"sum_Commission\":\"1308.74000000002479282557033002376556396484375\"},{\"Location_Id\":\"301326\",\"sum_Order_Amount\":\"41540.749999999417923390865325927734375\",\"sum_Commission\":\"3231.79999999996243786881677806377410888671875\"}]";


            /*for (HashMap<String,Object> respCubedataObj: respCubedata) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.putAll(respCubedataObj);

                // Assert.assertEquals(jsonObject.toString(),expectedCubeDataJson );
            }*/


        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //OpenDoc Dashboard flow
    @Test(description = "DashboardOpenDocFlow")
    public static void openDocDashboardFlow(){
        try{
            //getListView to get Story Id
            getListViewStory(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //Get the dashboardId from getListView
            loadPrivilege(selDashboardId_GetList, authToken,spaceKey,uid,HttpStatus.SC_OK);

            urlgetdocumentinfobyid = Utils.getUrl( "getdocumentinfobyid");
            Response response1 =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            .param("docId", selDashboardId_GetList)
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdocumentinfobyid)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> resp = from(response1.asString()).get("");
            HashMap<String,Object> trees = (HashMap)resp.get("trees");
            HashMap<String, Object> tree = (HashMap)trees.get("tree");
            LOGGER.info(("trees:" +trees.toString()));

            //****Assert to check id is not null***//
            String dcId =  tree.get("id").toString();
            Assert.assertNotNull(dcId);
            Assert.assertEquals(selDashboardId_GetList, dcId);

            //adding getThumbnailByTreeID in a flow
            getThumbnailByTreeID(selDashboardId_GetList,uid,authToken,spaceKey, HttpStatus.SC_OK);

            //Creating ApiToken
            createApiToken(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //getData of Dashboard
            savedDashId = Integer.valueOf(selDashboardId_GetList);
            getData(savedDashId,authToken,spaceKey,uid,HttpStatus.SC_OK);

            String data = "{\"dcType\":[{\"type\":\"mysql\"}]}";
            getEndpointUrl(data, uid, spaceKey,authToken,HttpStatus.SC_OK);

            //Delete Storydocument
            //   removeNodeDocument(uid,selDocId_GetList,authToken,spaceKey,HttpStatus.SC_OK);


        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //********story sharetoUser and sharetoUserGroup and shareAsCopy api's*****

    //ShareStoryToUser
    @Test(description ="Create User add to group, share dashboard to User,Login with user details, get the id, exclude document and delete user")
    public static void shareStoryToUser(){

        try {
            //getListView to get Story Id
            getListViewStory(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("NEWCREATEGRPID==" + newgroupid);

            //ShareDashboardToUser
            shareDocUser(selDocId_GetList,uid,authToken,spaceKey, HttpStatus.SC_OK);
            System.out.println("emailId ======"+emailidcreatefun);
            System.out.println("createUserId ======"+newuseridfunuser);

            //Login with new user passing valid password
            User usernew = Helper.getCustomerKey(emailidcreatefun,space_admin);
            User userobjauthnew = Helper.getAuthToken(emailidcreatefun,pass_admin, space_admin);
            String authnew =  null;
            authnew = userobjauthnew.getAuthToken();
            String idnew = null;
            idnew = usernew.getId();

            LOGGER.info("Successful Login");
            System.out.println("Authtoken is ====" + authnew );
            System.out.println("userId is ====" + idnew );

            //Calling getUserInfoToken of user
            shareDocumentId = null;
            Response response = given()
                    .param("token", authnew)
                    .when()
                    .post(urlgetUserInfoByToken)
                    .then()
                    .statusCode(HttpStatus.SC_OK)
                    .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            List<HashMap<String, Object>> treesList_userInfoToken = (ArrayList<HashMap<String, Object>>) users.get("trees");
            for (HashMap treesObj_userInfoToken :treesList_userInfoToken) {
                if (treesObj_userInfoToken.containsKey("title") && treesObj_userInfoToken.get("title").toString().equals("My Documents")){
                    myDocumentId = treesObj_userInfoToken.get("id").toString();
                }
                if (treesObj_userInfoToken.containsKey("title") && treesObj_userInfoToken.get("title").toString().equals("Public Documents")) {
                    publicDocumentId = treesObj_userInfoToken.get("id").toString();
                }
                else if (treesObj_userInfoToken.containsKey("title") && treesObj_userInfoToken.get("title").toString().equals("Shared Documents")) {
                    shareDocumentId = treesObj_userInfoToken.get("id").toString();
                }
            }
            //****getlistView service to check whether the particular user got the document as copy***//
            //======logging in from the user1======//
            urlgetListView = Utils.getUrl("getlistview");
            sharedDoclistId = null;
            Response response_GetlistView =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(idnew))
                            .header("authtoken", authnew)
                            //params
                            .param("nodeid", shareDocumentId)
                            .param("orderType", "")
                            .param("token",authnew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees1 = from(response_GetlistView.asString()).get("trees");
            List< HashMap<String, Object> > treesList = (ArrayList<HashMap<String, Object>>) trees1.get("treesList");

            for (HashMap treesObj:treesList) {
                if (treesObj.containsKey("title") && treesObj.get("title").toString().equals("BIStory_Automate") ){
                    sharedDoclistId = treesObj.get("id").toString();
                }
            }
            LOGGER.info(("sharedDoclistId:" +sharedDoclistId));
            LOGGER.info(("resp_getListViewShared:" +trees1));


            //****Assert to check whether document is shared for user ***//
            Assert.assertEquals(sharedDoclistId, selDocId_GetList);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //ShareStoryTOUserGroup and exclude story to one user
    @Test(description =" Create User, group, crate DashboardShare the dashboard to assigned usergroup and exclude the selected user")
    public static void excludeStoryToUserGroup(){
        try{
            //Creating story
            createStoryFlow();

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);
            LOGGER.info("Firstuser==" + newuseridfunuser);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("selUserGrpId==" + newgroupid);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+ Helper.generateRandomString(),usrname,fullname+ Helper.generateRandomString(),pass_admin,newgroupid,authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);
            LOGGER.info("2nduser==" + newuseridfunuser);

            //getting User from groups
            getusersfromgroups(uid,newgroupid, authToken, spaceKey,HttpStatus.SC_OK );

            //Sharing Document to Usergroup
            String storyId = savedStoryId.toString();
            shareDocUserGroup(storyId,newgroupid, selUserId, uid, authToken,spaceKey,HttpStatus.SC_OK);

            //Login with new user passing valid password to whom dashboard is not shared
            User usernew = Helper.getCustomerKey(selUsers_MailId,space_admin);
            User userobjauthnew = Helper.getAuthToken(selUsers_MailId,pass_admin, space_admin);
            String authnew =  null;
            authnew = userobjauthnew.getAuthToken();
            String idnew = null;
            idnew = usernew.getId();

            LOGGER.info("Successful Login");
            System.out.println("Authtoken is ====" + authnew );
            System.out.println("userId is ====" + idnew );

            //Calling getUserInfoToken of user
            Response response = given()
                    .param("token", authnew)
                    .when()
                    .post(urlgetUserInfoByToken)
                    .then()
                    .statusCode(HttpStatus.SC_OK)
                    .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            List<HashMap<String, Object>> treesList_userInfoToken = (ArrayList<HashMap<String, Object>>) users.get("trees");
            for (HashMap treesList_Obj :treesList_userInfoToken) {
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("My Documents")){
                    mydocId = treesList_Obj.get("id").toString();
                }
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Public Documents")) {
                    publicdocId = treesList_Obj.get("id").toString();
                }
                else if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Shared Documents")) {
                    sharedocId = treesList_Obj.get("id").toString();
                }
            }

            urlgetListView = Utils.getUrl("getlistview");
            sharedDoclistId = null;
            Response response_GetlistView =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(idnew))
                            .header("authtoken", authnew)
                            //params
                            .param("nodeid", sharedocId)
                            .param("orderType", "")
                            .param("token",authnew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees1 = from(response_GetlistView.asString()).get("trees");
            List< HashMap<String, Object> > treesList = (ArrayList<HashMap<String, Object>>) trees1.get("treesList");

            for (HashMap treesObj:treesList) {
                if (treesObj.containsKey("title") && treesObj.get("title").toString().equals("BIStory_Automate") ){
                    sharedDoclistId = treesObj.get("id").toString();
                }
            }
            LOGGER.info(("sharedDoclistId:" +sharedDoclistId));
            LOGGER.info(("resp_getListViewShared:" +trees1));

            //****Assert to check whether document is shared for the same user and document is shared excluding the user ***//
            Assert.assertEquals(selUserId, Integer.valueOf(idnew));
            Assert.assertNull(sharedDoclistId);

            //Delete user function called to delete the created user
           deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    //ShareStoryTOUserGroup and exclude story to one user
    @Test(description =" Create User, group, crate DashboardShare the dashboard to assigned usergroup and exclude the selected user")
    public static void excludeStoryToUserGroupShareAndUnshare(){
        try{
            //Creating story
            createStoryFlow();

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);
            LOGGER.info("Firstuser==" + newuseridfunuser);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("selUserGrpId==" + newgroupid);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+ Helper.generateRandomString(),usrname,fullname+ Helper.generateRandomString(),pass_admin,newgroupid,authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);
            LOGGER.info("2nduser==" + newuseridfunuser);

            //getting User from groups
            getusersfromgroups(uid,newgroupid, authToken, spaceKey,HttpStatus.SC_OK );

            //Sharing Document to Usergroup
            String storyId = savedStoryId.toString();
            shareDocUserGroupShare(storyId,newgroupid, selUserId, uid, authToken,spaceKey,HttpStatus.SC_OK);

            shareDocUserGroupCheck(storyId,newgroupid, selUserId, uid, authToken,spaceKey,HttpStatus.SC_OK);

            //Login with new user passing valid password to whom dashboard is not shared
            User usernew = Helper.getCustomerKey(selUsers_MailId,space_admin);
            User userobjauthnew = Helper.getAuthToken(selUsers_MailId,pass_admin, space_admin);
            String authnew =  null;
            authnew = userobjauthnew.getAuthToken();
            String idnew = null;
            idnew = usernew.getId();

            LOGGER.info("Successful Login");
            System.out.println("Authtoken is ====" + authnew );
            System.out.println("userId is ====" + idnew );

            //Calling getUserInfoToken of user
            Response response = given()
                    .param("token", authnew)
                    .when()
                    .post(urlgetUserInfoByToken)
                    .then()
                    .statusCode(HttpStatus.SC_OK)
                    .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            List<HashMap<String, Object>> treesList_userInfoToken = (ArrayList<HashMap<String, Object>>) users.get("trees");
            for (HashMap treesList_Obj :treesList_userInfoToken) {
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("My Documents")){
                    mydocId = treesList_Obj.get("id").toString();
                }
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Public Documents")) {
                    publicdocId = treesList_Obj.get("id").toString();
                }
                else if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Shared Documents")) {
                    sharedocId = treesList_Obj.get("id").toString();
                }
            }

            urlgetListView = Utils.getUrl("getlistview");
            sharedDoclistId = null;
            Response response_GetlistView =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(idnew))
                            .header("authtoken", authnew)
                            //params
                            .param("nodeid", sharedocId)
                            .param("orderType", "")
                            .param("token",authnew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees1 = from(response_GetlistView.asString()).get("trees");
            List< HashMap<String, Object> > treesList = (ArrayList<HashMap<String, Object>>) trees1.get("treesList");

            for (HashMap treesObj:treesList) {
                if (treesObj.containsKey("title") && treesObj.get("title").toString().equals("BIStory_Automate") ){
                    sharedDoclistId = treesObj.get("id").toString();
                }
            }
            LOGGER.info(("sharedDoclistId:" +sharedDoclistId));
            LOGGER.info(("resp_getListViewShared:" +trees1));

            //****Assert to check whether document is shared for the same user and document is shared excluding the user ***//
            Assert.assertEquals(selUserId, Integer.valueOf(idnew));
            if(sharedDoclistId != null) {
                Assert.assertNotNull(sharedDoclistId);
            }
            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    //ShareAsCopy
    @Test(description = "ShareAsCopy")
    public static void storyShareCopy(){
        try {
            //getListView to get Story Id
            getListViewStory(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("selUserGrpId==" + newgroupid);

            String data="{\"id\":0,\"datasourcetype\":\"\"}";
            getAllDataStore(spaceKey,uid,authToken,data,HttpStatus.SC_OK);

            //shareAsCopy method calling
            shareAsCopy(selDocId_GetList, newuseridfunuser,authToken, spaceKey,uid, HttpStatus.SC_OK);

            //Login with new user passing  valid password
            User usernew = Helper.getCustomerKey(emailidcreatefun,space_admin);
            User userobjauthnew = Helper.getAuthToken(emailidcreatefun,pass_admin, space_admin);
            String authnew =  null;
            authnew = userobjauthnew.getAuthToken();
            String idnew = null;
            idnew = usernew.getId();

            LOGGER.info("Successful Login");
            System.out.println("Authtoken is ====" + authnew );
            System.out.println("userId is ====" + idnew );

            //Calling getUserInfoToken of user
            shareDocumentId = null;
            urlgetUserInfoByToken = Utils.getUrl( "getUserInfoByToken");
            Response response = given()
                    .param("token", authnew)
                    .when()
                    .post(urlgetUserInfoByToken)
                    .then()
                    .statusCode(HttpStatus.SC_OK)
                    .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            List<HashMap<String, Object>> treesList_userInfoToken = (ArrayList<HashMap<String, Object>>) users.get("trees");
            for (HashMap treesList_Obj :treesList_userInfoToken) {
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("My Documents")){
                     mydocId = treesList_Obj.get("id").toString();
                }
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Public Documents")) {
                    publicdocId = treesList_Obj.get("id").toString();
                }
                else if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Shared Documents")) {
                    Thread.sleep(1000);
                    sharedocId = treesList_Obj.get("id").toString();
                }
            }

            //Comparing the datastoreid of admin and after copying story
            getAllSharedDataStore(spaceKey,uid,authToken,data,HttpStatus.SC_OK);
            Assert.assertEquals(dataStoreId, shareddataStoreId);


            //****getlistView service to check whether the particular user got the document as copy***//
            //======logging in from the user1======//
            urlgetListView = Utils.getUrl("getlistview");
            Response response_GetlistView =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(idnew))
                            .header("authtoken", authnew)
                            //params
                            .param("nodeid", sharedocId)
                            .param("orderType", "")
                            .param("token",authnew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees1 = from(response_GetlistView.asString()).get("trees");
            List< HashMap<String, Object> > treesList = (ArrayList<HashMap<String, Object>>) trees1.get("treesList");

            for (HashMap treesListObj:treesList) {
                if (treesListObj.containsKey("title") && treesListObj.get("title").toString().equals("BIStory_Automate") ){
                    sharedDoclistId = treesListObj.get("id").toString();
                }
            }
            LOGGER.info(("sharedDoclistId:" +sharedDoclistId));
            LOGGER.info(("resp_getListViewShared:" +trees1));

            //***asserting that the document has copied to user***//
            Assert.assertNotNull(sharedDoclistId);

            //****removing the shared document****//
            Response response_removeDoc =
                    given() //headers
                            .header("spaceKey", spaceKey)
                            .header("authToken", authToken)
                            .header("userID", uid)
                            //params
                            .param("id", sharedDoclistId)
                            .param("spacekey", spaceKey)
                            .param("token", authToken)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees_removeDoc = from(response_removeDoc.asString()).get("trees");
            LOGGER.info(("trees:" +trees_removeDoc.toString()));

            /**Assert message to check document has deleted **/
            String remove_msg =response_removeDoc.path("trees.message").toString();
            Assert.assertEquals(remove_msg,"Document deleted successfully!" );

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch (Exception e){
            e.printStackTrace();
        }

    }


    //********Dashboard sharetoUser and sharetoUserGroup api's*****//

    @Test(description ="Create User add to group, share dashboard to User,Login with user details, get the id, exclude document and delete user")
    public static void shareDashboardToUser(){

        try {
            //getListView to get Story Id
            getListViewStory(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("NEWCREATEGRPID==" + newgroupid);

            //ShareDashboardToUser
            shareDocUser(selDashboardId_GetList,uid,authToken,spaceKey, HttpStatus.SC_OK);
            System.out.println("emailId ======"+emailidcreatefun);
            System.out.println("createUserId ======"+newuseridfunuser);

            //Login with new user passing valid password
            User usernew = Helper.getCustomerKey(emailidcreatefun,space_admin);
            User userobjauthnew = Helper.getAuthToken(emailidcreatefun,pass_admin, space_admin);
            String authnew =  null;
            authnew = userobjauthnew.getAuthToken();
            String idnew = null;
            idnew = usernew.getId();

            //Calling getUserInfoToken of user
            shareDocumentId = null;
            Response response = given()
                    .param("token", authnew)
                    .when()
                    .post(urlgetUserInfoByToken)
                    .then()
                    .statusCode(HttpStatus.SC_OK)
                    .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            List<HashMap<String, Object>> treesList_userInfoToken = (ArrayList<HashMap<String, Object>>) users.get("trees");
            for (HashMap treesList_Obj :treesList_userInfoToken) {
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("My Documents")){
                    myDocumentId = treesList_Obj.get("id").toString();
                }
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Public Documents")) {
                    publicDocumentId = treesList_Obj.get("id").toString();
                }
                else if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Shared Documents")) {
                    shareDocumentId = treesList_Obj.get("id").toString();
                }
            }
            //***calling documentListView by logging from the Selected user credentials***//
            Response response_DocumentList =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userid", Integer.valueOf(idnew))
                            .header("authtoken", authnew)

                            //params
                            .param("userId", idnew)
                            .param("nodeId", shareDocumentId)
                            .param("token",authnew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetDocumentList)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> resp = from(response_DocumentList.asString()).get("");
            HashMap<String,Object> trees = (HashMap)resp.get("trees");
            List<HashMap<String,Object>> treesList = (ArrayList<HashMap<String, Object>>)trees.get("treesList");

            for (HashMap<String, Object> treeListObj : treesList) {
                if (treeListObj.containsKey("id") &&   treeListObj.get("id").toString().equals(selDashboardId_GetList)) {
                    sharedDocid =  treeListObj.get("id").toString();
                }
            }

            LOGGER.info(("trees_DocumentList:" +trees.toString()));
            LOGGER.info(("sharedDocid:" +sharedDocid));

            //****Assert to check whether document is shared for user ***//
            Assert.assertEquals(sharedDocid, selDashboardId_GetList);

            //Exclude document to shared user
            dmAssignExcludePrivilege(sharedDocid,newuseridfunuser,authnew,spaceKey,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch (Exception e){
            e.printStackTrace();
        }
    }


    @Test(description =" Create User, group, crate DashboardShare the dashboard to assigned usergroup and exclude the selected user")
    public static void excludeDashboardToUserGroup(){
        try{

            fetchWorkspace(uid, spaceKey,authToken,workspaceName_Advanced,workspaceJSON,HttpStatus.SC_OK);

            String dashboardParameters = "{\"workspaceId\":\"" + workspaceId + "\",\"dashboardName\":\"" + dashboardName + "\",\"dashboardJSON\":\"{}\"}";
            fetchDashboardWebservice(dashboardParameters,uid, spaceKey,authToken,HttpStatus.SC_OK);

            publishDashboard(uid, spaceKey,authToken,HttpStatus.SC_OK);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("selUserGrpId==" + newgroupid);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+ Helper.generateRandomString(),usrname,fullname+ Helper.generateRandomString(),pass_admin,newgroupid,authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);

            //getting User from groups
            getusersfromgroups(uid,newgroupid, authToken, spaceKey,HttpStatus.SC_OK );

            //Sharing Document to Usergroup
            shareDocUserGroup(publishDashboardId,newgroupid, selUserId, uid, authToken,spaceKey,HttpStatus.SC_OK);

            //Login with new user passing valid password to whom dashboard is not shared
            User usernew = Helper.getCustomerKey(selUsers_MailId,space_admin);
            User userobjauthnew = Helper.getAuthToken(selUsers_MailId,pass_admin, space_admin);
            String authnew =  null;
            authnew = userobjauthnew.getAuthToken();
            String idnew = null;
            idnew = usernew.getId();

            LOGGER.info("Successful Login");
            System.out.println("Authtoken is ====" + authnew );
            System.out.println("userId is ====" + idnew );

            //Calling getUserInfoToken of user
            Response response = given()
                    .param("token", authnew)
                    .when()
                    .post(urlgetUserInfoByToken)
                    .then()
                    .statusCode(HttpStatus.SC_OK)
                    .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            List<HashMap<String, Object>> treesList_userInfoToken = (ArrayList<HashMap<String, Object>>) users.get("trees");
            for (HashMap treesList_Obj :treesList_userInfoToken) {
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("My Documents")){
                    mydocId = treesList_Obj.get("id").toString();
                }
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Public Documents")) {
                    publicdocId = treesList_Obj.get("id").toString();
                }
                else if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Shared Documents")) {
                    sharedocId = treesList_Obj.get("id").toString();
                }
            }

            urlgetListView = Utils.getUrl("getlistview");
            sharedDoclistId = null;
            Response response_GetlistView =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(idnew))
                            .header("authtoken", authnew)
                            //params
                            .param("nodeid", sharedocId)
                            .param("orderType", "")
                            .param("token",authnew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees1 = from(response_GetlistView.asString()).get("trees");
            List< HashMap<String, Object> > treesList = (ArrayList<HashMap<String, Object>>) trees1.get("treesList");

            for (HashMap treesObj:treesList) {
                if (treesObj.containsKey("title") && treesObj.get("title").toString().equals("WebServiceDashboard") ){
                    sharedDoclistId = treesObj.get("id").toString();
                }
            }
            LOGGER.info(("sharedDoclistId:" +sharedDoclistId));
            LOGGER.info(("resp_getListViewShared:" +trees1));

            //****Assert to check whether document is shared for the same user and document is shared excluding the user ***//
            Assert.assertEquals(selUserId, Integer.valueOf(idnew));
            Assert.assertNull(sharedDoclistId);

            removeNode(uid,publishDashboardId, authToken, spaceKey,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Test(description =" Create User, group, crate DashboardShare the dashboard to assigned usergroup and exclude the selected user")
    public static void excludeDashboardToUserGroupShareAndUnshare(){
        try{

            fetchWorkspace(uid, spaceKey,authToken,workspaceName_Advanced,workspaceJSON,HttpStatus.SC_OK);

            String dashboardParameters = "{\"workspaceId\":\"" + workspaceId + "\",\"dashboardName\":\"" + dashboardName + "\",\"dashboardJSON\":\"{}\"}";
            fetchDashboardWebservice(dashboardParameters,uid, spaceKey,authToken,HttpStatus.SC_OK);

            publishDashboard(uid, spaceKey,authToken,HttpStatus.SC_OK);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("selUserGrpId==" + newgroupid);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+ Helper.generateRandomString(),usrname,fullname+ Helper.generateRandomString(),pass_admin,newgroupid,authToken,spaceKey,HttpStatus.SC_OK);
            Thread.sleep(1000);

            //Sharing Document to Usergroup
            shareDocUserGroupShare(publishDashboardId,newgroupid, selUserId, uid, authToken,spaceKey,HttpStatus.SC_OK);

            shareDocUserGroupCheck(publishDashboardId,newgroupid, selUserId, uid, authToken,spaceKey,HttpStatus.SC_OK);

            //Login with new user passing valid password to whom dashboard is not shared
            User usernew = Helper.getCustomerKey(emailidcreatefun,space_admin);
            User userobjauthnew = Helper.getAuthToken(emailidcreatefun,pass_admin, space_admin);
            String authnew =  null;
            authnew = userobjauthnew.getAuthToken();
            String idnew = null;
            idnew = usernew.getId();

            LOGGER.info("Successful Login");
            System.out.println("Authtoken is ====" + authnew );
            System.out.println("userId is ====" + idnew );

            //Calling getUserInfoToken of user
            Response response = given()
                    .param("token", authnew)
                    .when()
                    .post(urlgetUserInfoByToken)
                    .then()
                    .statusCode(HttpStatus.SC_OK)
                    .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            List<HashMap<String, Object>> treesList_userInfoToken = (ArrayList<HashMap<String, Object>>) users.get("trees");
            for (HashMap treesList_Obj :treesList_userInfoToken) {
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("My Documents")){
                    mydocId = treesList_Obj.get("id").toString();
                }
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Public Documents")) {
                    publicdocId = treesList_Obj.get("id").toString();
                }
                else if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Shared Documents")) {
                    sharedocId = treesList_Obj.get("id").toString();
                }
            }

            urlgetListView = Utils.getUrl("getlistview");
            sharedDoclistId = null;
            Response response_GetlistView =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(idnew))
                            .header("authtoken", authnew)
                            //params
                            .param("nodeid", sharedocId)
                            .param("orderType", "")
                            .param("token",authnew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees1 = from(response_GetlistView.asString()).get("trees");
            List< HashMap<String, Object> > treesList = (ArrayList<HashMap<String, Object>>) trees1.get("treesList");

            for (HashMap treesObj:treesList) {
                if (treesObj.containsKey("title") && treesObj.get("title").toString().equals("WebServiceDashboard") ){
                    sharedDoclistId = treesObj.get("id").toString();
                }
            }
            LOGGER.info(("sharedDoclistId:" +sharedDoclistId));
            LOGGER.info(("resp_getListViewShared:" +trees1));

            //****Assert to check whether document is shared for the same user and document is shared excluding the user ***//
            Assert.assertEquals(newuseridfunuser, idnew);
            if(sharedDoclistId != null) {
                Assert.assertNotNull(sharedDoclistId);
            }

            removeNode(uid,publishDashboardId, authToken, spaceKey,HttpStatus.SC_OK);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken,newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        }catch(Exception e){
            e.printStackTrace();
        }
    }


    //*****LinkUrl and modify document flow******//

    @Test(description ="Linkurl flow")
    public static void linkUrlFlow(){
        try{
            //Link url
            String linkurlName  = "QALinkUrl";
            saveWebLinkData(linkurlName,Utils.getproperty("treeRelLinkUrl"),spaceKey,uid, authToken, HttpStatus.SC_OK);

            //dashboardparameters
            saveDashBoardParameters(linkUrlId, spaceKey, uid, authToken,HttpStatus.SC_OK);

            urlgetListView = Utils.getUrl("getlistview");
            Response response_GetlistView =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            //params
                            .param("nodeid", myDocumentId)
                            .param("orderType", "")
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees_getListView = from(response_GetlistView.asString()).get("trees");
            List< HashMap<String, Object> > treesList = (ArrayList<HashMap<String, Object>>) trees_getListView.get("treesList");

            for (HashMap treesObj:treesList) {
                if (treesObj.containsKey("title") && treesObj.get("title").toString().equals("QALinkUrl") ){
                    linkUrlId = treesObj.get("id").toString();
                }
            }
            LOGGER.info(("sharedDoclistId:" +linkUrlId));
            LOGGER.info(("resp_getListViewShared:" +trees_getListView));



        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Test(description ="modifyDocumentFlow")
    public static void linkUrlDashboardFlow(){
        try{
            //getListView to get dashboard Id
            getListViewStory(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //Link url
            String linkurlName  = "dashboardLinkUrl";
            String treeRelIdNew = "https://qa.bdbizviz.com/opendocument.html?docid="+selDashboardId_GetList+"";
            System.out.println("treeRelId ===" + treeRelIdNew);
            saveWebLinkData(linkurlName,treeRelIdNew,spaceKey,uid, authToken, HttpStatus.SC_OK);

            //dashboardparameters
            saveDashBoardParametersmodifyDoc(linkUrlId, spaceKey, uid, authToken,HttpStatus.SC_OK);

            urlgetListView = Utils.getUrl("getlistview");
            Response response_GetlistView =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            //params
                            .param("nodeid", myDocumentId)
                            .param("orderType", "")
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees_getListView = from(response_GetlistView.asString()).get("trees");
            List< HashMap<String, Object> > treesList = (ArrayList<HashMap<String, Object>>) trees_getListView.get("treesList");

            for (HashMap treesObj:treesList) {
                if (treesObj.containsKey("title") && treesObj.get("title").toString().equals("QALinkUrl") ){
                    linkUrlIdnew = treesObj.get("id").toString();
                }
            }
            LOGGER.info(("linkUrlIdnew:" +linkUrlId));
            LOGGER.info(("resp_getListViewShared:" +trees_getListView));

            Assert.assertNotNull(linkUrlIdnew);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Test(description ="modifyDocumentFlow")
    public static void linkUrlStoryFlow(){
        try{
            //getListView to get dashboard Id
            getListViewStory(authToken,spaceKey,uid,HttpStatus.SC_OK);

            //Link url
            String linkurlName  = "storyLinkUrl";
            String treeRelIdNew = "https://qa.bdbizviz.com/opendocument.html?docid="+selDocId_GetList+"";
            System.out.println("treeRelId ===" + treeRelIdNew);
            saveWebLinkData(linkurlName,treeRelIdNew,spaceKey,uid, authToken, HttpStatus.SC_OK);

            //dashboardparameters
            saveDashBoardParametersmodifyDoc(linkUrlId, spaceKey, uid, authToken,HttpStatus.SC_OK);

            urlgetListView = Utils.getUrl("getlistview");
            Response response_GetlistView =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            //params
                            .param("nodeid", myDocumentId)
                            .param("orderType", "")
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees_getListView = from(response_GetlistView.asString()).get("trees");
            List< HashMap<String, Object> > treesList = (ArrayList<HashMap<String, Object>>) trees_getListView.get("treesList");

            for (HashMap treesObj:treesList) {
                if (treesObj.containsKey("title") && treesObj.get("title").toString().equals("QALinkUrl") ){
                    linkUrlIdnew = treesObj.get("id").toString();
                }
            }
            LOGGER.info(("linkUrlIdnew:" +linkUrlId));
            LOGGER.info(("resp_getListViewShared:" +trees_getListView));

            Assert.assertNotNull(linkUrlIdnew);

        }catch(Exception e){
            e.printStackTrace();
        }
    }



















}