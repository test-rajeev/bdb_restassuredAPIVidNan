package com.bdbizviz.restassured.platform.SecurityCheck;

import com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper;
import com.bdbizviz.restassured.platform.UserManagement.UserManagement;
import com.bdbizviz.restassured.platform.UserManagement.UserManagementHelper;
import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.User;
import com.bdbizviz.restassured.platform.Util.Utils;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.logging.Logger;

import static com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper.createApiToken;

/**
 * Created by bizviz on 17/2/18.
 */
public class UserManagementSecurityCheck extends UserManagementHelper{

    public static final Logger LOGGER = Logger.getLogger(UserManagementSecurityCheck.class.getName());
    public static User usernan;
    public static User usernanauth;
    public static String authTokennan;
    public static String uidnan;
    public static String spaceKeynan;

    @BeforeClass
    public  void setupUserMangSecurity() {
        prop = Utils.getProps();//Fetch all json data of properties json file and store in prop

        UserManagement.setupUserMang();

        //Craete a new user
        createnewuserFunctional(spaceKeyadmin,uidadmin,authTokenadmin,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authTokenadmin,spaceKey,HttpStatus.SC_OK);

        //User which is not assigned to any group for security check
        usernan=Helper.getCustomerKey(emailidcreatefun,space_admin);
        usernanauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
        spaceKeynan = useradmin.getSpacekey();
        authTokennan=usernanauth.getAuthToken();
        uidnan=usernan.getId();

    }

//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-------USER_MANAGEMENT Negative Test Cases--------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@//

//***************************************Authorization Testing using user "tyu" cred which is not assigned to any group**************************//


    @Test(description = "getUserListNeg")
    public void getUserListNeg() {
        try {
            usernan=Helper.getCustomerKey(emailidcreatefun,space_admin);
            usernanauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authTokennan=usernanauth.getAuthToken();
            uidnan=usernan.getId();
            spaceKeynan = useradmin.getSpacekey();

            getuserlist(spaceKeynan,uidnan,authTokennan,Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createUserNeg")
    public void createUserNeg() {
        try {

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKeynan,uidnan,authTokennan,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            //Delete user function called to delete the created user
            deleteuser(spaceKeynan,uidnan,authTokennan, newuseriduser,optypdel,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "updateUserNeg")
    public void updateUserNeg() {
        try {

            //Update new user
            updateProfile(spaceKeynan,uidnan,authTokennan,emailidcreate,updateusrname,fulnme,null,uidnan,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "blockUserNeg")
    public void blockUserNeg() {
        try {
            getuserlist(spaceKeynan,uidnan,authTokennan,Utils.getproperty("from"),Utils.getproperty("rows"),blockfilter,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            blockuser(spaceKeynan,uidnan,authTokennan,getuserid,optypblock,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "activateUserNeg")
    public void activateUserNeg() {
        try {

            getuserlist(spaceKeynan,uidnan,authTokennan,Utils.getproperty("from"),Utils.getproperty("rows"),blockfilter,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            //Activateuser function called
            activateuser(spaceKeynan,uidnan,authTokennan,getuserid,optypactivate,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "deleteUserNeg")
    public void deleteUserNeg() {
        try {

            getuserlist(spaceKeynan,uidnan,authTokennan,Utils.getproperty("from"),Utils.getproperty("rows"),blockfilter,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            //Delete user function called to delete the created user
            deleteuser(spaceKeynan,uidnan,authTokennan,getuserid,optypdel,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "resetPasswordNeg")
    public void resetPasswordNeg() {
        try {

            getuserlist(spaceKeynan,uidnan,authTokennan,Utils.getproperty("from"),Utils.getproperty("rows"),blockfilter,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            //Reset Password function called
            resetpassword(spaceKeynan,uidnan,authTokennan,getuserid,optypreset,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //-------------------UserGroup-----------------------//

    @Test(description = "getUserGroupListNeg")
    public void getUserGroupListNeg() {
        try {

            //******************Fetches all the usergroup list************//
            getusergrouplist(spaceKeynan,uidnan,authTokennan,Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);
            LOGGER.info("UPDATEGRPID==" + grpid);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createUserGroupNeg")
    public void createUserGroupNeg() {
        try {

            //******************Createnewusergroup**********************//
            createnewGroupPerm(spaceKeynan,uidnan,authTokennan,Groupnameuser+Helper.generateRandomString(),"",HttpStatus.SC_USE_PROXY);
            LOGGER.info("NEWCREATEGRPID==" + newgroupid);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "updateUserGroupNeg")
    public void updateUserGroupNeg() {
        try {

            getusergrouplist(spaceKeynan,uidnan,authTokennan,Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            //Update new usergroup
            updateusergroup(spaceKeynan,uidnan,authTokennan,Utils.getproperty("GroupnameUpdate"),Utils.getproperty("User"), Utils.getproperty("Create User"),Utils.getproperty("View User Details"),newgroupid,authTokennan,spaceKeynan,grpid,HttpStatus.SC_USE_PROXY);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "blockUserGroupNeg")
    public void blockUserGroupNeg() {
        try {

            getusergrouplist(spaceKeynan,uidnan,authTokennan,Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            blockgroup(spaceKeynan,uidnan,authTokennan,grpid,optypgrpblock,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "activateUserGroupNeg")
    public void activateUserGroupNeg() {
        try {

            getusergrouplist(spaceKeynan,uidnan,authTokennan,Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            //Activateuser function called
            activategroup(spaceKeynan,uidnan,authTokennan,grpid,optypactivate,authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    //-------------------------Others---------------------------------//

    @Test(description = "getallusersNeg")
    public void getallusersNeg() {
        try {

            getallusers(spaceKeynan,uidnan,authTokennan,HttpStatus.SC_USE_PROXY);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Give the detail of particular user,detail of admin user and list of usergroups
    @Test(description = "getuserdetailsNeg")
    public void getuserdetailsNeg() {
        try {

            getuserdetails(spaceKeynan,uidnan,authTokennan,uidnan,HttpStatus.SC_USE_PROXY);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getuserdetailsNeg")
    public void apiTokenFlowNeg(){
        try{

           //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKeynan,uidnan, HomeUiHelper.token,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",HomeUiHelper.token,spaceKeynan,HttpStatus.SC_NOT_MODIFIED);

        }catch (Exception e){
            e.printStackTrace();
        }
    }

}