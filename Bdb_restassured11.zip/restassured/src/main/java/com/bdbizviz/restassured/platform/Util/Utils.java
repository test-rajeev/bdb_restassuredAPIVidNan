package com.bdbizviz.restassured.platform.Util;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Logger;

public class Utils {
    private static final Logger LOGGER = Logger.getLogger(Utils.class.getSimpleName());

    public static String BASE = null;
    public static JSONObject props = null;
    private static JSONObject propsjson=null;
    private static JSONObject menujson=null;

    //for parsing and storing all properties.json value in a object props
    public static JSONObject getProps() {
        Object obj = null;
        JSONObject propertiesJSON = null;

        try {
            JSONParser parser = new JSONParser();
            obj = parser.parse(new FileReader("./src/main/resources/properties.json"));
            propertiesJSON = (JSONObject) obj;
            props = propertiesJSON;

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return propertiesJSON;
    }

    //For fetching url from properties.json file
    public static String getUrl(String serviceName) {
        JSONObject bizvizblr = (JSONObject) props.get("bizvizblr");
        JSONArray urls = (JSONArray) bizvizblr.get("urls");
        JSONObject urlsObj = (JSONObject) urls.get(0);
        BASE = (String) urlsObj.get("base");
        String serviceUrl = (String) urlsObj.get(serviceName);
        String finalUrl = BASE + (serviceUrl != null ? serviceUrl : null);
        return finalUrl;
    }

    //For fetching properties.json property values
    public static String getproperty( String propertyname) {
        JSONObject bizvizblr = (JSONObject) props.get("bizvizblr");
        String serviceUrl = (String) bizvizblr.get(propertyname);
        return serviceUrl;
    }

    //Paring json for validation during json comparision
    public static JSONObject getJson(String path) {
        Object objjson = null;
        JSONObject propertiesJson = null;

        try {
            JSONParser parser = new JSONParser();
            objjson = parser.parse(new FileReader(path));
            propertiesJson = (JSONObject) objjson;
            propsjson = propertiesJson;

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return propertiesJson;
    }

}