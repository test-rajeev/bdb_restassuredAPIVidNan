package com.bdbizviz.restassured.platform.DataCenter;

import com.bdbizviz.restassured.platform.UserManagement.UserManagementHelper;
import com.bdbizviz.restassured.platform.Util.Utils;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.Assert;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;

/**
 * Created by bizviz on 5/2/18.
 */
public class DataCenterHelper extends UserManagementHelper {
    public static final Logger log = Logger.getLogger(DataCenterHelper.class.getName());

    public static String updatedatasrcname=null;

    //Variable declaration of MYSQL datatype detail
    public static String dataSourceName=null;
    public static String dbUserName=null;
    public static String dbPassword=null;
    public static String dbPortNumber=null;
    public static String dbHostName=null;
    public static String dbName=null;
    public static String dbType=null;
    public static String dsQuery=null;
    public static String queryname=null;
    public static String dataSourceNameMysql;

    //Variable declartion of Url for all the services
    public static String urlcreatedatasource=null;
    public static String urlcreatequerryservice=null;
    public static String urlcheckdatasource=null;

    public static String isExistsMetadta=null;
    public static String serviceNameCreation=null;
    public static String consumerName;
    public static String serviceName;
    public static String urlsavecube;
    public static Object cubeid;
    public static Object storename;
    public static String urlexecuteSheduler;
    public static String urlinitialcubeCreation;
    public static String pluginid;
    public static String pluginname;
    public static String pluginidupdate;
    public static String pluginidindex;
    public static String pluginnameindex;
    public static String pluginnameupdate;
    public static String dataStoreId;
    public  String datasourceid;
    public  String seriveiddataset;
    public static String urlgetAllDataSet;
    public static Object nividhQueryName_DataSet;
    public static String nividhQueryName_DataConnector;
    public static String queryLink;

    public static String urlgetdatsourcelist;
    public static String urllistquerryservices;
    public static String urltestquerryservice;
    public static String urltestquerrycassendra;
    public static String urlviewdatasourcedetails;
    public static String urlgetdatasourceinfobytype;
    public static String urlcheckconnection;
    public static String urlupdatedatasourcedetails;
    public static String urlreconnect;
    public static String urldeleteddatasource;
    public static String urlgetprivilegedetails;
    public static String urlloadprivileges;
    public static String urlsharedatasource;
    public static String urlgetusersfromgroups;
    public static String urlupdatequeryservice;
    public static String urldeletequeryservice;
    public static String urlgetDataStoreInfo;
    public static String urlpluginservice;
    public static String dbUserNameMSsql;
    public static String dataSourceNameMSsql;
    public static String dbPasswordMSsql;
    public static String dbPortNumberMSsql;
    public static String dbHostNameMSsql;
    public static String dbNameMSsql;
    public static String dbTypeMSsql;
    public static String dsQueryMSsql1;
    public static String dsQueryMSsql2;
    public static String dsQueryMSsql3;
    public static String dsQueryMSsql4;
    public static String dsQueryMSsql5;
    public static String dsQueryMSsql6;
    public static String dsQueryMSsql7;
    public static String serviceNameDelCube;
    public static String serviceNameIndex;
    public static String dsQueryOData;
    public static String dbTypeOData;
    public static String dbHostNameOData;
    public static String dbPasswordOData;
    public static String dataSourceNameOdata;
    public static String dbUserNameOData;
    public static String consistencylevelCassendratwo;
    public static String consistencylevelCassendra;
    public static String dsQueryCassendra;
    public static String dbTypeCassendra;
    public static String dbHostNameCassendra;
    public static String dbPortNumberCassendra;
    public static String dbPasswordCassendra;
    public static String dataSourceNameCassendra;
    public static String dbUserNameCassendra;
    public static String dbTypeSparkSql;
    public static String dataSourceNameSparkSql;
    public static String dbPortNumberSparkSql;
    public static String dsQueryHive;
    public static String dbTypeHive;
    public static String dbHostNameHive;
    public static String dbPortNumberHive;
    public static String dbPasswordHive;
    public static String dataSourceNameHive;
    public static String dbUserNameHive;
    public static String dsQueryOracle;
    public static String dbTypeOracle;
    public static String dbServiceNameOracle;
    public static String dbHostNameOracle;
    public static String dbPortNumberOracle;
    public static String dbPasswordOracle;
    public static String dataSourceNameOracle;
    public static String dbUserNameOracle;
    public static String objdata;
    public static String innerobjdata;
    public static String innerobjdataupdate;
    public static String objdataupdate;
    public static String GroupnameGeneral;
    public static String idbytype;
    public static String namebytype;
    public static String datasrcid;
    public static Object datasrcname;
    public static Response result;
    public static String idedit;
    public static String idtype;
    public static String nametype;
    public static String idtypegoogle;
    public static String nametypegoogle;
    public static String idtypejira;
    public static String nametypejira;
    public static String idviewdatasrc;
    public static String quryserviceid;
    public static String queryservicename;
    public static String nividhQueryName;
    public static String getdataid;
    public static String getdataname;
    public static String viewquryid;
    public static String newgroupidtest;
    public static String querynameMysql;
    public static String querynameMSsql;
    public static String querynameOracle;
    public static String querynameHive;
    public static String querynameSparkSql;
    public static String querynameCassendra;
    public static String querynameOdata;
    public String datasourceidnew;
    public String datasourceidnewusr;
    public String namebytypenewusr;
    public String namebytypenew;
    public static String idnew;
    public static String dataStoreName;
    public static String queryName;
    public static String datasourceidNew;
    public static String hostName;
    public static String databaseName;
    public static String userName;
    public static String seriveiddatasetNew;

    String newCommit = "";



    //---------------------------All methods which are used in a flow--------------------------//

    public static void getQueryInfo(String spacekey,String userID,String authtoken,String data,Integer statuscode) {

        Response response=
                given()
                        //Header
                        .header("spacekey", spacekey)
                        .header("userID", userID)
                        .header("authtoken", authtoken)
                        //Body
                        .param("isSecure",isExistsMetadta )
                        .param("consumerName",Utils.getproperty("cubeconsumerName"))
                        .param("serviceName", Utils.getproperty("cubeserviceName"))
                        .param("data",data )
                        .param("token", authtoken)
                        .param("spacekey", spacekey)
                        .when()
                        .post(Utils.getUrl("getQueryInfo"))
                        .then()
                        .assertThat()
                        .statusCode(statuscode)
                        .extract().response();
        HashMap<String, Object> dataSourcesListgetdatastoreinfo = from(response.asString()).get("");

        Assert.assertEquals(dataSourcesListgetdatastoreinfo.get("sucess").toString(),"true");
        log.info("getDataStoreInfo====="+response.asString());

    }

    //Fetches All Data Stores
    public static void getCubeData(String spacekey,String userID,String authtoken,String data) {
        try {
            Response response=
                    given()
                            //Header
                            .header("spacekey", spacekey)
                            .header("userID", userID)
                            .header("authtoken", authtoken)
                            //Body
                            .param("consumerName",Utils.getproperty("cubeDataConsumerName") )
                            .param("serviceName",Utils.getproperty("cubeDataServiceName") )
                            .param("data",data )
                            .param("isSecure",isExistsMetadta )
                            .param("token", authtoken)
                            .param("spacekey", spacekey)
                            .when()
                            .post(Utils.getUrl("getCubeData"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>> dataSourcesListgetdatastoreinfo = from(response.asString()).get("");

            log.info("dataSourcesListgetdatastoreinfo====="+dataSourcesListgetdatastoreinfo);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Fetches All Data Stores
    public static void getAllDataStore(String spacekey,String userID,String authtoken,String data,Integer statuscode) {
        try {
            Response response=
                    given()
                            //Header
                            .header("spacekey", spacekey)
                            .header("userID", userID)
                            .header("authtoken", authtoken)
                            //Body
                            .param("data",data )
                            .param("token", authtoken)
                            .param("spacekey", spacekey)
                            .when()
                            .post(Utils.getUrl("getAllDataStore"))
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> dataSourcesListgetdatastoreinfo = from(response.asString()).get("");
                List< HashMap<String, Object> > bizvizCubes = (ArrayList<HashMap<String, Object>>) dataSourcesListgetdatastoreinfo.get("bizvizCubes");

                for (HashMap bizvizCubesObj:bizvizCubes) {
                    if (bizvizCubesObj.containsKey("title") && bizvizCubesObj.get("title").toString().equals("RestAutomationDataStore") ){
                        dataStoreId = bizvizCubesObj.get("id").toString();
                    }
                }
                Assert.assertEquals(dataSourcesListgetdatastoreinfo.get("success").toString(), "true");
                log.info("getDataStoreInfo=====" + response.asString());
                log.info("dataStoreId=====" + dataStoreId);
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Fetches All Types Of Data Conn
    public static void getDataSourceList(String spacekey,String userID,String authtoken,Integer statuscode) {
        try {
            Response response =
                    given()
                            //Header
                            .header("spacekey", spacekey)
                            .header("userID", userID)
                            .header("authtoken", authtoken)

                            //Body
                            .param("from", 0)
                            .param("rows", 99999)
                            .param("token", authtoken)
                            .param("spacekey", spacekey)
                            .when()
                            .post(urlgetdatsourcelist)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> dataSources = from(response.asString()).get("dataSources");
                List<HashMap<String, Object>> dataSourcesList = (ArrayList<HashMap<String, Object>>) dataSources.get("dataSourcesList");

                //Fetching all the ids and checking that they are not null
                List<Integer> ids = from(response.asString()).get("dataSources.dataSourcesList.dataSourceID");
                for (Integer id : ids) {
                    Assert.assertNotNull(id);

                }

                datasrcid = dataSourcesList.get(0).get("dataSourceID").toString();
                datasrcname = dataSourcesList.get(0).get("dataSourceName");

                Assert.assertEquals(dataSources.get("success").toString(), "true");

                if (dataSources.get("success").toString() == "true") {
                    log.info("dataSources" + dataSources);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            // log.error("FAIL");
        }
    }

    //Checkdataconnector before creating
    public static void checkDataSource(String spaceKey,String uid,String authtoken,String datasourcename, String usrname,String passwrd,String portno,String hostnme,String dbnme,String typedb,Integer statuscode){

        Response responsechkdataasrc =
                given()
                        //Header
                        .header("spacekey", spaceKey)
                        .header("userID", uid)
                        .header("authtoken", authtoken)
                        //Param
                        .param("dataSourceName", datasourcename)
                        .param("userName", usrname)
                        .param("password", passwrd)
                        .param("portNumber", portno)
                        .param("hostName", hostnme)
                        .param("databaseName", dbnme)
                        .param("dataSourceType", typedb)
                        .param("token", authtoken)
                        .param("spacekey", spaceKey)
                        .when()
                        .post(urlcheckdatasource)
                        .then()
                        .assertThat()
                        .statusCode(statuscode)
                        .extract().response();
        if (statuscode==305){

            Assert.assertEquals(statuscode.intValue(),305);

        }
        else {
            String result=responsechkdataasrc.asString();

            Assert.assertEquals(result,"true");

            log.info("checkdatasourceresult====="+responsechkdataasrc.asString());}}

    //Creting a new dataconnector
    public  void createDataConnector(String spaceKey,String uid,String authToken,String datasourcename,String usrname,String passwrd,String portno,String hostnme,String dbnme,String typedb,String advanced,Integer statuscode) {

        Response responsecreatedatasrc =
                given()
                        //Header
                        .header("spacekey", spaceKey)
                        .header("userID", uid)
                        .header("authtoken", authToken)
                        //Param
                        .param("dataSourceName", datasourcename)
                        .param("userName", usrname)
                        .param("password", passwrd)
                        .param("portNumber", portno)
                        .param("hostName", hostnme)
                        .param("databaseName", dbnme)
                        .param("dataSourceType", typedb)
                        .param("advanced", advanced)
                        .param("token", authToken)
                        .param("spacekey", spaceKey)
                        .when()
                        .post(urlcreatedatasource)
                        .then()
                        .assertThat()
                        .statusCode(statuscode)
                        .extract().response();
        if (statuscode == 305) {

            Assert.assertEquals(statuscode.intValue(), 305);

        } else {
            HashMap<String, Object> dataSourcescreatedatasrc = from(responsecreatedatasrc.asString()).get("dataSources");
            HashMap<String, Object> dataSource = (HashMap) dataSourcescreatedatasrc.get("dataSource");

            String msgcreatedatasrc = (String) dataSourcescreatedatasrc.get("message");
            datasourceid = dataSource.get("dataSourceID").toString();
            datasourceidNew = dataSource.get("dataSourceID").toString();
            dataSourceName = dataSource.get("dataSourceName").toString();
            hostName = dataSource.get("hostName").toString();
            databaseName = dataSource.get("databaseName").toString();
            userName = dataSource.get("userName").toString();


            Assert.assertEquals(msgcreatedatasrc, "DataConnector created successfully!");
            Assert.assertEquals(dataSourcescreatedatasrc.get("success").toString(), "true");

            log.info("createdatasourcedataSources=====" + responsecreatedatasrc.asString());
        }

    }
    //Delete a data connector
    public static void deletedDataSource(String spaceKey,String uid,String authToken,String dataSourceId ,Integer statuscode) {
        try {
            Response responsedel =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("dataSourceId",dataSourceId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urldeleteddatasource)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                result = responsedel;
                log.info("deleteddatasourceresult=====" + responsedel.asString());
                Assert.assertEquals(result.asString(), "true");
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Fetches the list of Data Connector by database type
    public static void getDataSourceInfoByType(String spaceKey,String uid,String authToken,String datasourcetype,Integer statuscode) {
        try {
            Response responsegetdatasrcbytyp =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("datasourcetype", datasourcetype)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetdatasourceinfobytype)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {

                HashMap<String, Object> dataSourcesgetdatasrcbytyp = from(responsegetdatasrcbytyp.asString()).get("");
                List<HashMap<String, Object>> dataSourcesListgetdatasrcbytyp = (ArrayList<HashMap<String, Object>>) dataSourcesgetdatasrcbytyp.get("dataSourcesList");

                idedit = dataSourcesListgetdatasrcbytyp.get(0).get("dataSourceID").toString();
                //Checking that all id in datasourcelist is nott null
                List<Integer> ids = from(responsegetdatasrcbytyp.asString()).get("dataSourcesList.dataSourceID");
                for (Integer id : ids) {
                    Assert.assertNotNull(id);
                }

                for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                    if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restautGoogleApi")) {
                        idtypegoogle = iddb.get("dataSourceID").toString();
                        nametypegoogle = iddb.get("dataSourceName").toString();
                    }
                }
                for (HashMap<String, Object> iddb : dataSourcesListgetdatasrcbytyp) {
                    if (iddb.containsKey("dataSourceName") && iddb.get("dataSourceName").toString().equals("restautjiraApi")) {
                        idtypejira = iddb.get("dataSourceID").toString();
                        nametypejira = iddb.get("dataSourceName").toString();
                    }
                }

                Assert.assertEquals(dataSourcesgetdatasrcbytyp.get("success").toString(), "true");
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //View data source detials begore updation
    public static void viewDataSourceDetails(String spaceKey,String uid,String authToken,String dataSourceID,Integer statuscode) {
        try {
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("dataSourceID", dataSourceID)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlviewdatasourcedetails)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> dataSources = from(response.asString()).get("dataSources");
                Map<String, Object> dataSource = (Map) dataSources.get("dataSource");
                idviewdatasrc = dataSource.get("dataSourceID").toString();

                log.info("viewdatasourcedetailsdataid=====" + idviewdatasrc);

                Assert.assertNotNull(idviewdatasrc);
                Assert.assertEquals(dataSources.get("success").toString(), "true");

                log.info("viewdatasourcedetailsdataSources=====" + response.asString());
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Test data source before updation
    public static void checkDataSourceEdit(String spaceKey,String uid,String authToken,String userName,String password,String portNumber,String hostName,String databaseName,String dataSourceID,String dataSourceType,String extraval,Integer statuscode ) {
        try {
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("dataSourceName", updatedatasrcname)
                            .param("userName", userName)
                            .param("password",password)
                            .param("portNumber", portNumber)
                            .param("hostName", hostName)
                            .param("databaseName", databaseName)
                            .param("dataSourceID",dataSourceID)
                            .param("dataSourceType", dataSourceType)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlcheckdatasource)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                String result = response.asString();

                Assert.assertEquals(result, "true");

                log.info("checkdatasourceresult=====" + response.asString());
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Update Data source(Data Connector)
    public static void updateDataSourceDetails(String spaceKey,String uid,String authToken,String userName,String password,String portNumber,String hostName,String databaseName,String dataSourceID,String dataSourceType,String advanced,Integer statuscode ) {
        try {
            Response responseupdate =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("dataSourceName", updatedatasrcname)
                            .param("userName", userName)
                            .param("password",password )
                            .param("portNumber", portNumber)
                            .param("hostName", hostName)
                            .param("databaseName", databaseName)
                            .param("dataSourceID",dataSourceID)
                            .param("dataSourceType", dataSourceType)
                            .param("advanced",advanced)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlupdatedatasourcedetails)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> dataSourcesupdate = from(responseupdate.asString()).get("dataSources");
                String msg = (String) dataSourcesupdate.get("message");

                Assert.assertEquals(msg, "DataConnector updated successfully!");
                Assert.assertEquals(dataSourcesupdate.get("success").toString(), "true");

                log.info("updatedatasourcedetailsdataSources=====" + responseupdate.asString());
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Reconnect data connector
    public static void reconnect(String spaceKey,String uid,String authToken,String dataSourceId,Integer statuscode ) {
        try {
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("dataSourceId",dataSourceId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlreconnect)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                log.info("respone===" + response.asString());
                HashMap<String, Object> dataSourcesupdate = from(response.asString()).get("");
                Boolean reconect = (Boolean) dataSourcesupdate.get("Boolean");

                Assert.assertEquals(reconect.toString(), "true");
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //get details of users in a user group for sharing connector
    public static void getPrivilegeDetails(String spaceKey,String uid,String authToken,String dataSourceId ) {
        try {
            Response responseprivilege =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("dataSourceId",dataSourceId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetprivilegedetails)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response() ;


            HashMap<String, Object> dataSourcesprivilege = from(responseprivilege.asString()).get("userprivilegeResp");

            String dataid=(String) dataSourcesprivilege.get("dataSourceId");

            Assert.assertEquals(dataid.toString(),idbytype);

            log.info("getprivilegedetailsdataSources====="+responseprivilege.asString());

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Share data source to a user
    public static void shareUserDataSource(String spaceKey,String uid,String authToken,String pluginId,String selectedUsers,Integer statuscode) {
        try {
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("pluginId",pluginId)
                            .param("selectedUsers[]", selectedUsers)
                            .param("parentId","null")
                            .param("type", 1)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsharedatasource)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                String result = response.asString();

                log.info("shareUserDataSourceresult=====" + response.asString());
                Assert.assertEquals(result.toString(), "true");

            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Share data source to a group
    public static void shareGroupDataSource(String spaceKey,String uid,String authToken,String pluginId,String selectedGroups,Integer statuscode) {
        try {
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("pluginId",pluginId)
                            .param("selectedGroups[]",selectedGroups)
                            .param("parentId","")
                            .param("type", 1)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsharedatasource)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                String result = response.asString();

                log.info("shareGroupDataSourceresult=====" + response.asString());
                Assert.assertEquals(result, "true");
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Fetches users from a group for sharing connector and query
    public static void getUsersFromGroups(String groupIds,Integer statuscode) {
        try {
            Response responsegetusr =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("groupIds[]", groupIds)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetusersfromgroups)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> dataSourcesgrps = from(responsegetusr.asString()).get("userGroups");
                List<HashMap<String, Object>> dataSourcesassignesusrs = (ArrayList<HashMap<String, Object>>) dataSourcesgrps.get("assignedUsers");

                log.info("getusersfromgroupsdataSources=====" + responsegetusr.asString());
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Exclude user from group for sharedataconector
    public static void excludeShareDataSource(String spaceKey,String uid,String authToken,String pluginId,String selUserGrpId,String selUserId,String parentId,Integer statuscode ) {
        try {
            Response responseexcludesrc =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("pluginId",pluginId)
                            .param("selectedGroups[]",selUserGrpId)
                            .param("excludedUsers[]",selUserId)
                            .param("parentId",parentId)
                            .param("type", 1)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsharedatasource)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                String resultexcludesrc = responseexcludesrc.asString();

                log.info("excludeShareDataSourceresult=====" + responseexcludesrc);
                Assert.assertEquals(resultexcludesrc, "true");
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Test query service before creation
    public static void runDataService(String spaceKey,String uid,String authToken, String data,Integer statuscode) {

        Response responsetestquery =
                given()
                        //Header
                        .header("spacekey", spaceKey)
                        .header("userID", uid)
                        .header("authtoken", authToken)
                        //Body
                        .param("data", data)
                        .param("token", authToken)
                        .param("spacekey", spaceKey)
                        .when()
                        .post(Utils.getUrl("runDataService"))
                        .then()
                        .assertThat()
                        .statusCode(statuscode)
                        .extract().response();
        if (statuscode==305){

            Assert.assertEquals(statuscode.intValue(),305);

        }
        else {
            HashMap<String, Object> dataSourcestestquery = from(responsetestquery.asString()).get("");
            log.info("testquerryservicedataSources=====" + responsetestquery.asString());
            Assert.assertNotEquals(dataSourcestestquery,"[]");
            log.info("fff");
        }
    }

    //Create a query service(Data service)
    public  void createqueryservice(String spaceKey,String uid,String authToken,String queryName,String databaseName,String query,String dataSourceID,Integer statuscode) {
        try {
            Response responsecreatequery =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("queryName", queryName)
                            .param("databaseName", databaseName)
                            .param("query", query)
                            .param("dataSourceID", dataSourceID)
                            .param("filterQuery", query)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlcreatequerryservice)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> dataSourcescreatequery = from(responsecreatequery.asString()).get("queryServices");
                seriveiddataset = dataSourcescreatequery.get("serviceId").toString();
                seriveiddatasetNew = dataSourcescreatequery.get("serviceId").toString();
                String msgcreatequery = (String) dataSourcescreatequery.get("message");

                Assert.assertEquals(msgcreatequery, "Dataset created successfully!");
                Assert.assertEquals(dataSourcescreatequery.get("success").toString(), "true");

                log.info("createquerryservicedataSources=====" + responsecreatequery.asString());
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Fetches the list of queries in a data connector
    public static void listQueryServices(String spaceKey,String uid,String authToken,String dataSourceID,Integer statuscode ) {
        try {
            Response responselistQuery =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("from", 0)
                            .param("rows", 9999)
                            .param("dataSourceID",dataSourceID)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .param("userid", uid)
                            .when()
                            .post(urllistquerryservices)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> queryServices = from(responselistQuery.asString()).get("queryServices");
                List<HashMap<String, Object>> queryServicesList = (ArrayList) queryServices.get("queryServicesList");

                for (HashMap<String, Object> idlist : queryServicesList) {
                    if (idlist.containsKey("queryName") && idlist.get("queryName").toString().equals("restqueryautomationupdate")) {
                        quryserviceid = idlist.get("serviceId").toString();
                        queryservicename = idlist.get("queryName").toString();
                    }
                }

                Assert.assertEquals(queryServices.get("success").toString(), "true");

                //log.info("listqueryservicesquryserviceid====="+responselistQuery.asString());
                log.info("quryserviceid=====" + quryserviceid);
                log.info("queryservicename=====" + queryservicename);
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    public  void getAllDataSet(String spaceKey,String uid,String authToken,String isPublished,Integer statuscode ) {
        try {
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userid", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("isPublished",isPublished)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getAllDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                List<HashMap<String, Object>> dataSources = from(response.asString()).get("");

                //Fetching all the ids and checking that they are not null
                List<Integer> ids = from(response.asString()).get("serviceId");
                for (Integer id : ids) {
                    Assert.assertNotNull(id);

                }
                for (HashMap<String, Object> getAllDataSetsObj : dataSources) {
                    if (getAllDataSetsObj.containsKey("serviceId") && getAllDataSetsObj.get("serviceId").toString().equals(seriveiddataset)) {
                        nividhQueryName = getAllDataSetsObj.get("nividhQueryName").toString();
                        queryLink = getAllDataSetsObj.get("queryLink").toString();
                        queryName = getAllDataSetsObj.get("queryName").toString();
                    }

                }

                getdataid = dataSources.get(0).get("serviceId").toString();
                getdataname = dataSources.get(0).get("queryName").toString();
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public static void publishDataSet(String spaceKey,String uid,String authToken,String id,Integer statuscode ) {
        try {
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("id",id)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("publishDataSet"))
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> publishdataset = from(response.asString()).get("");
                String msg = publishdataset.get("message").toString();
                String success = publishdataset.get("success").toString();

                Assert.assertEquals(msg, "Dataset published successfully!");
                Assert.assertEquals(success, "true");

                log.info("publish===" + publishdataset);
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //view detail of query service before updation
    public static void viewEditQueryService(String spaceKey,String uid,String authToken,String serviceId,Integer statuscode) {
        try {
            String url = Utils.getUrl("vieweditqueryservice");
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("serviceId", serviceId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> queryServices = from(response.asString()).get("queryServices");
                HashMap<String, Object> queryService = (HashMap) queryServices.get("queryService");
                viewquryid = queryService.get("serviceId").toString();

                log.info("vieweditqueryservicequryid=====" + viewquryid);

                Assert.assertNotNull(viewquryid);
                Assert.assertEquals(queryServices.get("success").toString(), "true");

                log.info("vieweditqueryservicequeryServices=====" + response.asString());
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Update query service
    public static void updateQueryService(String spaceKey,String uid,String authToken,String databaseName,String query,String dataSourceID,String serviceId,Integer statuscode) {
        try {
            String updatequeryname=Utils.getproperty("updatequeryname");

            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("queryName", updatequeryname)
                            .param("databaseName", databaseName)
                            .param("query", query)
                            .param("dataSourceID", dataSourceID)
                            .param("filterQuery", "")
                            .param("serviceId",serviceId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlupdatequeryservice)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> dataSources = from(response.asString()).get("queryServices");
                String msg = (String) dataSources.get("message");

                Assert.assertEquals(msg, "Dataset updated successfully!");
                Assert.assertEquals(dataSources.get("success").toString(), "true");

                log.info("updatequeryservicedataSources=====" + response.asString());
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Delete query service
    public static void deleteQueryService(String spaceKey,String uid,String authToken,String serviceId,Integer statuscode) {
        try {
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("serviceId",serviceId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urldeletequeryservice)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> delete = from(response.asString()).get("queryServices");
                String msg = (String) delete.get("message");
                Assert.assertEquals(delete.get("success").toString(), "true");

                log.info("deletequeryserviceresult=====" + response.asString());
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //pluginId=datasourceId
    //Share data service to a user
    public static void shareUserDataService(String spaceKey,String uid,String authToken,String pluginId,String selectedUsers,Integer statuscode) {
        try {
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("pluginId",pluginId)
                            .param("selectedUsers[]", selectedUsers)
                            .param("parentId","")
                            .param("type", 2)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsharedatasource)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                String result = response.asString();

                Assert.assertEquals(result, "true");
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Share data service to a group
    public static void shareGroupDataService(String spaceKey,String uid,String authToken,String pluginId,String selectedGroups,Integer statuscode ) {
        try {
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("pluginId",pluginId)
                            .param("selectedGroups[]", selectedGroups)
                            .param("parentId","")
                            .param("type", 2)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsharedatasource)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                String result = response.asString();

                log.info("shareGroupDataServiceresult=====" + result);
                Assert.assertEquals(result, "true");
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Exclude user from group for sharedata service
    public static void excludeShareDataService(String spaceKey,String uid,String authToken,String pluginId,String selectedGroups,String excludedUsers,Integer statuscode ) {
        try {
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("pluginId",pluginId)
                            .param("selectedGroups[]", selectedGroups)
                            .param("excludedUsers[]",excludedUsers)
                            .param("parentId","")
                            .param("type", 2)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsharedatasource)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                String result = response.asString();

                log.info("excludeShareDataServiceresult=====" + result);
                Assert.assertEquals(result, "true");
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public static void checkConnectionCassendra(String spaceKey,String uid,String authToken,Integer statuscode){
        Response responsechkdataasrc =
                given()
                        //Header
                        .header("spacekey", spaceKey)
                        .header("userID", uid)
                        .header("authtoken", authToken)
                        //Param
                        .param("type", dbTypeCassendra)
                        .param("data",objdata)
                        .param("token", authToken)
                        .param("spacekey", spaceKey)
                        .when()
                        .post(urlcheckconnection)
                        .then()
                        .assertThat()
                        .statusCode(statuscode)
                        .extract().response();
        if (statuscode==305){

            Assert.assertEquals(statuscode.intValue(),305);

        }
        else {
            String result = responsechkdataasrc.asString();
            log.info("checkconn=====" + result);
            Assert.assertEquals(result, "{\"Boolean\":true}");
        }
    }

    public static void checkConnectionCassendraUpdate(String spaceKey,String uid,String authToken,Integer statuscode){
        Response responsechkdatasrcupdate =
                given()
                        //Header
                        .header("spacekey", spaceKey)
                        .header("userID", uid)
                        .header("authtoken", authToken)
                        //Param
                        .param("type", dbTypeCassendra)
                        .param("data",objdataupdate)
                        .param("token", authToken)
                        .param("spacekey", spaceKey)
                        .when()
                        .post(urlcheckconnection)
                        .then()
                        .assertThat()
                        .statusCode(statuscode)
                        .extract().response();
        if (statuscode==305){

            Assert.assertEquals(statuscode.intValue(),305);

        }
        else {
            String resultupdate = responsechkdatasrcupdate.asString();
            Assert.assertEquals(resultupdate, "{\"Boolean\":true}");
            log.info("checkdatasourceresult=====" + responsechkdatasrcupdate.asString());
        }
    }

    public static void downloadDataSet(String filename,String token,String queryservicename) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(filename));
        try {
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();

            while (line != null) {
                sb.append(line);
                sb.append("\n");
                line = br.readLine();
            }

            //Service to get all Download Data
            String url = Utils.getUrl("download");
            Response response =
                    given(). param("token",token)
                            .param("queryServiceName", queryservicename)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            log.info("sb"+sb.toString());
            log.info("response"+response.asString());

            Assert.assertEquals(response.asString(),sb.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }

        finally {
            br.close();
        }

    }

    public static void createnewGroupPermm(String spacekey,String userID,String authtoken,String groupName) {
        try {
            getAllMenuContext(spaceKey,uid,authToken);

            Response response =
                    given()
                            .header("spacekey", spacekey)
                            .header("userID", userID)
                            .header("authtoken", authtoken)
                            .param("groupName", groupName)
                            .param("addedPermissions[]",  Utils.getproperty("User"))
                            .param("addedPermissions[]",  Utils.getproperty("Assign Custom Field"))
                            .param("addedPermissions[]",  Utils.getproperty("Edit UserGroup"))
                            .param("addedPermissions[]",  Utils.getproperty("Activate/Block UserGroup"))
                            .param("addedPermissions[]",  Utils.getproperty("View UserGroup Details"))
                            .param("addedPermissions[]",  Utils.getproperty("Edit User"))
                            .param("addedPermissions[]",  Utils.getproperty("Remove User"))
                            .param("addedPermissions[]",  Utils.getproperty("Change Password"))
                            .param("addedPermissions[]",  Utils.getproperty("Activate/Block User"))
                            .param("addedPermissions[]",  Utils.getproperty("View User Details"))
                            .param("addedPermissions[]",  Utils.getproperty("Create UserGroup"))
                            .param("addedPermissions[]",  Utils.getproperty("Create User"))
                            .param("addedPermissions[]",  Utils.getproperty("Data Center"))
                            .param("addedPermissions[]",  Utils.getproperty("Share CA PPM Service"))
                            .param("addedPermissions[]",  Utils.getproperty("Remove CA PPM Service"))
                            .param("addedPermissions[]",  Utils.getproperty("Edit CA PPM Service"))
                            .param("addedPermissions[]",  Utils.getproperty("Share Data Connector"))
                            .param("addedPermissions[]",  Utils.getproperty("Remove Data Connector"))
                            .param("addedPermissions[]",  Utils.getproperty("Create Data Store"))
                            .param("addedPermissions[]",  Utils.getproperty("Edit Data Service"))
                            .param("addedPermissions[]",  Utils.getproperty("Remove Data Service"))
                            .param("addedPermissions[]",  Utils.getproperty("View Data Service Details"))
                            .param("addedPermissions[]",  Utils.getproperty("Share Data Service"))
                            .param("addedPermissions[]",  Utils.getproperty("Edit Data Connector"))
                            .param("addedPermissions[]",  Utils.getproperty("View Data Connector Details"))
                            .param("addedPermissions[]",  Utils.getproperty("Create Data Service"))
                            .param("addedPermissions[]",  Utils.getproperty("Create Data Connector"))
                            .param("addedPermissions[]",  Utils.getproperty("Create CA PPM WSDL"))
                            .param("addedPermissions[]",  Utils.getproperty("Edit Data Store"))
                            .param("addedPermissions[]",  Utils.getproperty("Remove Data Store"))
                            .param("addedPermissions[]",  Utils.getproperty("View Data Store Details"))
                            .param("addedPermissions[]",  Utils.getproperty("Share Data Store"))
                            .param("addedPermissions[]",  Utils.getproperty("Admin"))
                            .param("addedPermissions[]",  Utils.getproperty("Custom Field Settings"))
                            .param("addedPermissions[]",  Utils.getproperty("Encryption"))
                            .param("addedPermissions[]",  Utils.getproperty("Audit Trail"))
                            .param("addedPermissions[]",  Utils.getproperty("Server Monitor"))
                            .param("addedPermissions[]",  Utils.getproperty("CDN Settings"))
                            .param("addedPermissions[]",  Utils.getproperty("Document Management"))
                            .param("addedPermissions[]",  Utils.getproperty("Data Management Configuration"))
                            .param("addedPermissions[]",  Utils.getproperty("Document Migration"))
                            .param("addedPermissions[]",  Utils.getproperty("Scheduling Monitoring"))
                            .param("addedPermissions[]",  Utils.getproperty("Audit Trail Settings"))
                            .param("addedPermissions[]",  Utils.getproperty("Password Preference"))
                            .param("addedPermissions[]",  Utils.getproperty("Predictive Settings"))
                            .param("addedPermissions[]",  Utils.getproperty("Windows AD Settings"))
                            .param("addedPermissions[]",  Utils.getproperty("Email Server Settings"))
                            .param("addedPermissions[]",  Utils.getproperty("GeoSpatial Settings"))
                            .param("addedPermissions[]",  Utils.getproperty("CA PPM Settings"))
                            .param("addedPermissions[]",  Utils.getproperty("Session"))
                            .param("addedPermissions[]",  Utils.getproperty("GeoSpatial"))
                            .param("addedPermissions[]",  Utils.getproperty("Edit GeoSpatial Analysis"))
                            .param("addedPermissions[]",  Utils.getproperty("Remove GeoSpatial Analysis"))
                            .param("addedPermissions[]",  Utils.getproperty("View GeoSpatial Analysis Details"))
                            .param("addedPermissions[]",  Utils.getproperty("Create GeoSpatial Analysis"))
                            .param("addedPermissions[]",  Utils.getproperty("Designer"))
                            .param("addedPermissions[]",  Utils.getproperty("Create WorkSpace"))
                            .param("addedPermissions[]",  Utils.getproperty("Predictive"))
                            .param("addedPermissions[]",  Utils.getproperty("Share Custom Scala script"))
                            .param("addedPermissions[]",  Utils.getproperty("View Custom Scala Script"))
                            .param("addedPermissions[]",  Utils.getproperty("Edit Custom Scala Script"))
                            .param("addedPermissions[]",  Utils.getproperty("Create Custom Scala Script"))
                            .param("addedPermissions[]",  Utils.getproperty("created custom Scala script available to group"))
                            .param("addedPermissions[]",  Utils.getproperty("created Custom Scala script available to user"))
                            .param("addedPermissions[]",  Utils.getproperty("Deploy Workflow"))
                            .param("addedPermissions[]",  Utils.getproperty("Share Custom R script"))
                            .param("addedPermissions[]",  Utils.getproperty("created custom R script available to group"))
                            .param("addedPermissions[]",  Utils.getproperty("created Custom R script available to user"))
                            .param("addedPermissions[]",  Utils.getproperty("Live Job Status of Spark"))
                            .param("addedPermissions[]",  Utils.getproperty("Share Model"))
                            .param("addedPermissions[]",  Utils.getproperty("View Model"))
                            .param("addedPermissions[]",  Utils.getproperty("Save Model"))
                            .param("addedPermissions[]",  Utils.getproperty("View Custom R Script"))
                            .param("addedPermissions[]",  Utils.getproperty("Edit Custom R Script"))
                            .param("addedPermissions[]",  Utils.getproperty("Create Custom R Script"))
                            .param("addedPermissions[]",  Utils.getproperty("Share Workflow"))
                            .param("addedPermissions[]",  Utils.getproperty("View Workflow"))
                            .param("addedPermissions[]",  Utils.getproperty("Edit Workflow"))
                            .param("addedPermissions[]",  Utils.getproperty("Created Workflow Available to Group"))
                            .param("addedPermissions[]",  Utils.getproperty("Created Workflow Available to User"))
                            .param("addedPermissions[]",  Utils.getproperty("Create Workflow"))
                            .param("addedPermissions[]",  Utils.getproperty("View Schedule Job"))
                            .param("addedPermissions[]",  Utils.getproperty("Edit Schedule Job"))
                            .param("addedPermissions[]",  Utils.getproperty("Create Schedule Job"))
                            .param("addedPermissions[]",  Utils.getproperty("Survey"))
                            .param("addedPermissions[]",  Utils.getproperty("Sentiments"))
                            .param("addedPermissions[]",  Utils.getproperty("Social Media"))
                            .param("addedPermissions[]",  Utils.getproperty("Data Preparation"))
                            .param("addedPermissions[]",  Utils.getproperty("Play"))
                            .param("menuPermissions[]",  Create_Folder)
                            .param("menuPermissions[]",  Link_a_URL_Folder)
                            .param("menuPermissions[]",  Rename_Folder)
                            .param("menuPermissions[]",  Delete_Folder)
                            .param("menuPermissions[]",  Copy_Folder)
                            .param("menuPermissions[]",  Paste_Folder)
                            .param("menuPermissions[]",  Add_To_Favorite_Folder)
                            .param("menuPermissions[]",  Remove_From_Favorite_Folder)
                            .param("menuPermissions[]",  Create_Geospatial_Folder)
                            .param("menuPermissions[]",  Properties_Folder)
                            .param("menuPermissions[]",  Create_Story_Folder)
                            .param("menuPermissions[]",  Move_To_Folder)

                            .param("menuPermissions[]",  Modify_Document_File)
                            .param("menuPermissions[]",  Rename_File)
                            .param("menuPermissions[]",  Delete_File)
                            .param("menuPermissions[]",  Copy_File)
                            .param("menuPermissions[]",  Add_To_Favorite_File)
                            .param("menuPermissions[]",  Remove_From_Favorite_File)
                            .param("menuPermissions[]",  Properties_File)
                            .param("menuPermissions[]", Share_With_File)
                            .param("menuPermissions[]",  Exclude_Users_File)
                            .param("menuPermissions[]", Copy_To_File)
                            .param("menuPermissions[]",  Move_To_File)
                            .param("token", authtoken)
                            .param("spacekey", spacekey)
                            .when()
                            .post(urlcreatenewgrp)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> users = from(response.asString()).get("userGroups");
            HashMap<String, Object> user = (HashMap) users.get("userGroup");
            newgroupidtest = user.get("id").toString();
            message = users.get("message").toString();
            success = users.get("success").toString();
            Assert.assertEquals("Group added successfully!", message);
            Assert.assertEquals("true", success);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public  void pluginSaveCubee(String spacekey,String userid,String authToken ){
        try
        {
            urlsavecube=Utils.getUrl("datastore");
            String data="{\"datasource\":\""+datasourceid+"\",\"lastRunDate\":null,\"defenition\":\"{\\\"dataDef\\\":{\\\"filetype\\\":\\\"mysql\\\",\\\"databasename\\\":\\\"BizViz_Automation_WT\\\",\\\"query\\\":\\\"\\\\nSelect order_id,location_id as Location_Id,ACCOUNT_HOLDER_ID,LOCATION_DROP_OFF_ID,space_key as Franchise_IOId,total_amount as Order_Amount,FROM_UNIXTIME((transaction_date)/1000,'%Y-%m-%d') as Transaction_Date,total_commission as Commission from orders\\\\nwhere total_amount>0 and TOTAL_COMMISSION>0\\\"},\\\"columnNames\\\":{\\\"order_id\\\":\\\"long\\\",\\\"Location_Id\\\":\\\"long\\\",\\\"ACCOUNT_HOLDER_ID\\\":\\\"long\\\",\\\"LOCATION_DROP_OFF_ID\\\":\\\"long\\\",\\\"Franchise_IOId\\\":\\\"string\\\",\\\"Order_Amount\\\":\\\"double\\\",\\\"Transaction_Date\\\":\\\"string\\\",\\\"Commission\\\":\\\"double\\\"},\\\"adhocResults\\\":[\\\"{\\\\\\\"measures\\\\\\\":{\\\\\\\"order_id\\\\\\\":327793246263,\\\\\\\"Location_Id\\\\\\\":301747,\\\\\\\"ACCOUNT_HOLDER_ID\\\\\\\":152527,\\\\\\\"LOCATION_DROP_OFF_ID\\\\\\\":321118,\\\\\\\"Order_Amount\\\\\\\":42.0,\\\\\\\"Commission\\\\\\\":2.0},\\\\\\\"facts\\\\\\\":{\\\\\\\"Franchise_IOId\\\\\\\":\\\\\\\"7385\\\\\\\",\\\\\\\"Transaction_Date\\\\\\\":\\\\\\\"2016-01-24\\\\\\\"}}\\\"],\\\"fieldDef\\\":{\\\"facts\\\":[\\\"Franchise_IOId\\\",\\\"order_id\\\",\\\"Location_Id\\\",\\\"ACCOUNT_HOLDER_ID\\\",\\\"LOCATION_DROP_OFF_ID\\\"],\\\"measures\\\":[\\\"Order_Amount\\\",\\\"Commission\\\"],\\\"time\\\":[\\\"Transaction_Date\\\"]},\\\"elasticSearch\\\":{\\\"isEnabled\\\":true,\\\"properties\\\":{\\\"Franchise_IOId\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"order_id\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"Location_Id\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"ACCOUNT_HOLDER_ID\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"LOCATION_DROP_OFF_ID\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"Order_Amount\\\":{\\\"type\\\":\\\"double\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"Commission\\\":{\\\"type\\\":\\\"double\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"Transaction_Date\\\":{\\\"type\\\":\\\"date\\\",\\\"index\\\":\\\"not_analyzed\\\"}}},\\\"drillDef\\\":[{\\\"title\\\":\\\"Drill Def\\\",\\\"drillOrder\\\":[\\\"Franchise_IOId\\\",\\\"Location_Id\\\"]}],\\\"batchProcess\\\":{\\\"fieldName\\\":\\\"\\\",\\\"distinctQuery\\\":\\\"\\\",\\\"batchquery\\\":\\\"\\\"},\\\"dataRestriction\\\":{\\\"Franchise_IOId\\\":\\\"spacekey\\\",\\\"order_id\\\":\\\"orderid\\\"},\\\"scheduleInfo\\\":\\\"0 0 12 1 1/1 ? *\\\",\\\"scheduleDef\\\":{\\\"interval\\\":\\\"monthly\\\",\\\"option\\\":\\\"every\\\",\\\"optionArgs\\\":{\\\"choiceDay\\\":\\\"1\\\",\\\"choiceMonth\\\":\\\"1\\\"},\\\"time\\\":{\\\"hour\\\":12,\\\"min\\\":0}},\\\"notification\\\":{\\\"status\\\":true,\\\"mailid\\\":\\\"\\\"},\\\"enableNLP\\\":true,\\\"formulaJSON\\\":{},\\\"deltaProcess\\\":{\\\"isDeltaProcess\\\":false,\\\"deltaQuery\\\":\\\"\\\",\\\"delta\\\":\\\"\\\"}}\",\"createdBy\":{\"id\":"+uid+"},\"updatedBy\":{\"id\":"+uid+"},\"name\":\""+dataStoreName+"\",\"id\":null,\"type\":1,\"status\":1,\"createdDate\":null,\"lastUpdatedDate\":null,\"isActive\":0,\"spaceKey\":\""+spaceKey+"\"}";

            Response responsepluginSaveCube =
                    given()
                            //Header
                            .header("spacekey", spacekey)
                            .header("userid", userid)
                            .header("authtoken", authToken)
                            //Param
                            .param("isSecure", "true")
                            .param("consumerName","CUBEPROCESSSERVICE")
                            .param("serviceName","saveCube")
                            .param("data",data)
                            .param("token", authToken)
                            .param("spacekey", spacekey)
                            .when()
                            .post(urlsavecube)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> pluginSaveCube = from(responsepluginSaveCube.asString()).get("");
            HashMap<String,Object> bizvizCube = (HashMap)pluginSaveCube.get("bizvizCube");
            cubeid=bizvizCube.get("id");
            storename=bizvizCube.get("name");
            log.info("pluginSaveCube"+pluginSaveCube);

        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    public  void pluginExecuteSheduler(String spacekey,String userid,String authToken ){
        try
        {
            urlexecuteSheduler=Utils.getUrl("datastore");
            String data="{\"shedulername\":\""+cubeid+"@@@@"+dataStoreName+"\",\"routeid\":\""+cubeid+"\",\"cronexpression\":\"0 0 12 1 1/1 ? *\",\"bizvizqueue\":\"cube\",\"consumername\":[\"CUBEPROCESSSERVICE\"],\"servicename\":[\"scheduledCube\"],\"timezoneoffset\":-330,\"query\":\"\\nSelect order_id,location_id as Location_Id,ACCOUNT_HOLDER_ID,LOCATION_DROP_OFF_ID,space_key as Franchise_IOId,total_amount as Order_Amount,FROM_UNIXTIME((transaction_date)/1000,'%Y-%m-%d') as Transaction_Date,total_commission as Commission from orders\\nwhere total_amount>0 and TOTAL_COMMISSION>0\",\"datasourceid\":\""+datasourceid+"\",\"datasetid\":\"undefined\",\"dbname\":\"BizViz_Automation_WT\",\"cubeid\":\""+cubeid+"\",\"serviceId\":"+cubeid+",\"userid\":\""+uid+"\",\"filter\":\"\",\"facts\":[\"Franchise_IOId\",\"order_id\",\"Location_Id\",\"ACCOUNT_HOLDER_ID\",\"LOCATION_DROP_OFF_ID\"],\"measures\":[\"Order_Amount\",\"Commission\"],\"time\":[\"Transaction_Date\"],\"formulaJSON\":{},\"isNotifaction\":true,\"mailid\":\"\",\"enableNLP\":true,\"elasticSearch\":{\"isEnabled\":true,\"properties\":{\"Franchise_IOId\":{\"type\":\"string\",\"index\":\"not_analyzed\"},\"order_id\":{\"type\":\"string\",\"index\":\"not_analyzed\"},\"Location_Id\":{\"type\":\"string\",\"index\":\"not_analyzed\"},\"ACCOUNT_HOLDER_ID\":{\"type\":\"string\",\"index\":\"not_analyzed\"},\"LOCATION_DROP_OFF_ID\":{\"type\":\"string\",\"index\":\"not_analyzed\"},\"Order_Amount\":{\"type\":\"double\",\"index\":\"not_analyzed\"},\"Commission\":{\"type\":\"double\",\"index\":\"not_analyzed\"},\"Transaction_Date\":{\"type\":\"date\",\"index\":\"not_analyzed\"}}},\"batchProcess\":{\"fieldName\":\"\",\"distinctQuery\":\"\",\"batchquery\":\"\"},\"deltaProcess\":{\"isDeltaProcess\":false,\"deltaQuery\":\"\",\"delta\":\"\"},\"spaceKey\":\""+spaceKey+"\"}";

            Response responsepluginExecuteSheduler =
                    given()
                            //Header
                            .header("spacekey", spacekey)
                            .header("userid", userid)
                            .header("authtoken", authToken)
                            //Param
                            .param("isSecure", "true")
                            .param("consumerName","CUBEPROCESSSERVICE")
                            .param("serviceName","executeSheduler")
                            .param("data",data)
                            .param("token", authToken)
                            .param("spacekey", spacekey)
                            .when()
                            .post(urlexecuteSheduler)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            String result =  responsepluginExecuteSheduler.asString();
            log.info("pluginExecuteSheduler"+result);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    public  void pluginInitialCubeCreation(String spacekey,String userid,String authToken ){
        try
        {
            urlinitialcubeCreation=Utils.getUrl("datastore");
            String data="{\"shedulername\":\""+cubeid+"@@@@"+dataStoreName+"\",\"routeid\":\""+cubeid+"\",\"bizvizqueue\":\"refreshcube\",\"consumername\":[\"CUBEPROCESSSERVICE\"],\"servicename\":[\"initialCubeCreation\"],\"timezoneoffset\":-330,\"query\":\"\\nSelect order_id,location_id as Location_Id,ACCOUNT_HOLDER_ID,LOCATION_DROP_OFF_ID,space_key as Franchise_IOId,total_amount as Order_Amount,FROM_UNIXTIME((transaction_date)/1000,'%Y-%m-%d') as Transaction_Date,total_commission as Commission from orders\\nwhere total_amount>0 and TOTAL_COMMISSION>0\",\"datasourceid\":\""+datasourceid+"\",\"datasetid\":\"undefined\",\"dbname\":\"BizViz_Automation_WT\",\"cubeid\":\""+cubeid+"\",\"filetype\":\"mysql\",\"serviceId\":"+cubeid+",\"userid\":\""+uid+"\",\"filter\":\"\",\"facts\":[\"Franchise_IOId\",\"order_id\",\"Location_Id\",\"ACCOUNT_HOLDER_ID\",\"LOCATION_DROP_OFF_ID\"],\"measures\":[\"Order_Amount\",\"Commission\"],\"time\":[\"Transaction_Date\"],\"formulaJSON\":{},\"isNotifaction\":true,\"mailid\":\"\",\"enableNLP\":true,\"elasticSearch\":{\"isEnabled\":true,\"properties\":{\"Franchise_IOId\":{\"type\":\"string\",\"index\":\"not_analyzed\"},\"order_id\":{\"type\":\"string\",\"index\":\"not_analyzed\"},\"Location_Id\":{\"type\":\"string\",\"index\":\"not_analyzed\"},\"ACCOUNT_HOLDER_ID\":{\"type\":\"string\",\"index\":\"not_analyzed\"},\"LOCATION_DROP_OFF_ID\":{\"type\":\"string\",\"index\":\"not_analyzed\"},\"Order_Amount\":{\"type\":\"double\",\"index\":\"not_analyzed\"},\"Commission\":{\"type\":\"double\",\"index\":\"not_analyzed\"},\"Transaction_Date\":{\"type\":\"date\",\"index\":\"not_analyzed\"}}},\"batchProcess\":{\"fieldName\":\"\",\"distinctQuery\":\"\",\"batchquery\":\"\"},\"deltaProcess\":{\"isDeltaProcess\":false,\"deltaQuery\":\"\",\"delta\":\"\"},\"spaceKey\":\""+spaceKey+"\"}";
            Response responsepluginInitialCubeCreation =
                    given()
                            //Header
                            .header("spacekey", spacekey)
                            .header("userid", userid)
                            .header("authtoken", authToken)
                            //Param
                            .param("isSecure", "true")
                            .param("consumerName","CUBEPROCESSSERVICE")
                            .param("serviceName","initialCubeCreation")
                            .param("data",data)
                            .param("token", authToken)
                            .param("spacekey", spacekey)
                            .when()
                            .post(urlinitialcubeCreation)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            String result =  responsepluginInitialCubeCreation.asString();
            log.info("pluginInitialCubeCreation"+result);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    public  void plugingetLatestSchedulerHistory(String spacekey,String userid,String authToken ){
        try
        {
            urlsavecube=Utils.getUrl("datastore");
            String data="{\"shedulerName\":\""+cubeid+"\"}";

            Response responsepluginLatestSchedulerHistory =
                    given()
                            //Header
                            .header("spacekey", spacekey)
                            .header("userid", userid)
                            .header("authtoken", authToken)
                            //Param
                            .param("isSecure", "true")
                            .param("consumerName","CUBEPROCESSSERVICE")
                            .param("serviceName","getLatestSchedulerHistory")
                            .param("data",data)
                            .param("token", authToken)
                            .param("spacekey", spacekey)
                            .when()
                            .post(urlsavecube)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> plugingetLatestSchedulerHistory = from(responsepluginLatestSchedulerHistory.asString()).get("");
            HashMap<String,Object>schedulerHistory = (HashMap)plugingetLatestSchedulerHistory.get("schedulerHistory");

            String success=plugingetLatestSchedulerHistory.get("success").toString();
            String status=schedulerHistory.get("remarks").toString();

            Assert.assertEquals(success,"true");
            Assert.assertEquals(status,"{\"status\":\"Sucesss\",\"message\":\"Loaded data saved successfully\",\"remarks\":\"Successfully saved the data in to memory\"}");

            log.info("plugingetLatestSchedulerHistory"+plugingetLatestSchedulerHistory);

        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void pluginServices(String isSecure,String consumerName,String serviceName,String Data) {
        try {
            Response responseplugin =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("isSecure",isSecure )
                            .param("consumerName",consumerName)
                            .param("serviceName",serviceName)
                            .param("data",Data)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpluginservice)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            String resultplugincreatn=responseplugin.asString();
            log.info("pluginservicecreation====="+resultplugincreatn);

            Assert.assertEquals("true",resultplugincreatn);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public static void pluginserviceGetAllMetadata() {
        try {
            String data="{\"id\":0}";
            Response responseplugin =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("isSecure",isExistsMetadta )
                            .param("consumerName",consumerName)
                            .param("serviceName",serviceName)
                            .param("data",data)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpluginservice)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> alldataplugin = from(responseplugin.asString()).get("");
            List<HashMap<String, Object>> bizvizCubes = (ArrayList<HashMap<String, Object>>) alldataplugin.get("bizvizCubes");

            for (HashMap<String, Object> ids : bizvizCubes) {
                if (ids.containsKey("name") &&   ids.get("name").toString().equals("restassure")) {
                    pluginid = ids.get("id").toString();
                    pluginname=ids.get("name").toString();
                }
            }

            log.info("responseplugin====="+responseplugin.asString());

            log.info("pluginid====="+pluginid);
            log.info("pluginname====="+pluginname);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public static void pluginserviceGetIndex() {
        try {
            //Fetches all the meta data list and from that list fetches the updated meta data id
            String data="{\"id\":0}";
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("isSecure",isExistsMetadta )
                            .param("consumerName",consumerName)
                            .param("serviceName",serviceName)
                            .param("data",data)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpluginservice)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> alldataplugin = from(response.asString()).get("");
            List<HashMap<String, Object>> bizvizCubes = (ArrayList<HashMap<String, Object>>) alldataplugin.get("bizvizCubes");

            for (HashMap<String, Object> ids : bizvizCubes) {
                if (ids.containsKey("name") &&   ids.get("name").toString().equals("restassureupdate")) {
                    pluginidupdate = ids.get("id").toString();
                    pluginnameupdate=ids.get("name").toString();
                }
            }
            log.info("pluginid====="+pluginidupdate);
            log.info("pluginname====="+pluginnameupdate);

            //Fetches the index detail of updated meta data
            String dataindex="{\"id\":"+pluginidupdate+"}".toString();
            Response responseplugin =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("isSecure",isExistsMetadta )
                            .param("consumerName",consumerName)
                            .param("serviceName",serviceNameIndex)
                            .param("data",dataindex)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpluginservice)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> dataplugin = from(responseplugin.asString()).get("");
            HashMap<String ,Object>plugin=(HashMap<String ,Object>)dataplugin.get("bizvizCube");

            if (plugin.containsKey("name") &&   plugin.get("name").toString().equals("restassureupdate")) {
                pluginidindex = plugin.get("id").toString();
                pluginnameindex=plugin.get("name").toString();
            }

            log.info("responseplugin====="+responseplugin.asString());

            log.info("pluginidindex====="+pluginidindex);
            log.info("pluginnameindex====="+pluginnameindex);

            Assert.assertEquals("true",dataplugin.get("success").toString());
            Assert.assertEquals(pluginidupdate,pluginidindex);
            Assert.assertEquals(pluginnameupdate,pluginnameindex);

            //Delete Cube
            String datadelcube="{\"id\":"+pluginidupdate+"}".toString();
            Response responsedelcube =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            //Body
                            .param("isSecure",isExistsMetadta )
                            .param("consumerName",consumerName)
                            .param("serviceName",serviceNameDelCube)
                            .param("data",datadelcube)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpluginservice)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();


        } catch (Exception e) {

            e.printStackTrace();
        }
    }

}