package com.bdbizviz.restassured.platform.Util;

/**
 * Created by bizviz on 2/2/18.
 */
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.TestNGException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;

public class Helper {
    public static String urllogin = Utils.getUrl("login");
    public static String resetauth;

    //Login function to get authToken
    public static User getAuthToken(String suserId, String passlog, String spaceName) throws TestNGException {
        User keyobj = getCustomerKey(suserId, spaceName);
        Response response =
                given()
                        .header("Content-Type", "application/x-www-form-urlencoded")
                        .header("Accept", "*/*")
                        .param("spaceKey", keyobj.getSpacekey())
                        .param("userid", suserId)
                        .param("customerkey", keyobj.getCustomerKey())
                        .param("password", passlog)
                        .param("authType", "ep")
                        .when()
                        .post(urllogin)
                        .then()
                        .statusCode(HttpStatus.SC_OK)
                        .extract().response();
        HashMap<String, Object> response_Login = from(response.asString()).get("");
        System.out.println("response_authToken:" + response_Login);

        User authobj = new User();
        if (response.path("users.authToken") != null) {
            authobj.setAuthToken(response.path("users.authToken").toString());
            Assert.assertNotNull(authobj.getAuthToken(), "CustomerKey Not Found");
        }
        return authobj;
    }

    //Customer key function to get spaceKey,customerKey to fetch authToken from login
    public static User getCustomerKey(String suserId, String spaceName) throws TestNGException {
        User custkeyobj = new User();
        String url = Utils.getUrl("getcustomerKey");
        Response response =
                given()
                        .header("content-type", "application/x-www-form-urlencoded")
                        .header("accept", "*/*")
                        .param("userid", suserId)
                        .when()
                        .post(url)
                        .then()
                        .statusCode(HttpStatus.SC_OK)
                        .extract().response();
        ArrayList<HashMap<String, Object>> space = from(response.asString()).get("space");
        for (int i = 0; i < space.size(); i++) {
            if (spaceName.equals(space.get(i).get("spaceName").toString())) {
                custkeyobj.setCustomerKey(space.get(i).get("customerKey").toString());
                custkeyobj.setSpacekey(space.get(i).get("spaceKey").toString());
                custkeyobj.setId(space.get(i).get("userId").toString());
            }

        }
        Assert.assertNotNull(custkeyobj.getCustomerKey(),"CustomerKey Not Found");

        return custkeyobj;
    }

    //Generation of Random Strings
    public static String generateRandomString() {
        char[] chars = "abcdefghijklmnopqrstuvwxyz".toCharArray();
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 3; i++) {
            char c = chars[random.nextInt(chars.length)];
            sb.append(c);
        }
        return sb.toString();
    }

    //Login function to get authToken
    public static String getAuthTokenReset(String suserId, String passlog, String spaceName) throws TestNGException {
        User keyobj = getCustomerKey(suserId, spaceName);
        Response response =
                given()
                        .header("Content-Type", "application/x-www-form-urlencoded")
                        .header("Accept", "*/*")
                        .param("spaceKey", keyobj.getSpacekey())
                        .param("userid", suserId)
                        .param("customerkey", keyobj.getCustomerKey())
                        .param("password", passlog)
                        .param("authType", "ep")
                        .when()
                        .post(urllogin)
                        .then()
                        .statusCode(HttpStatus.SC_OK)
                        .extract().response();
        HashMap<String, Object> s = from(response.asString()).get("users");
        resetauth = s.get("success").toString();
        return s.get("success").toString();
    }

}