package com.bdbizviz.restassured.platform.HomeUI;


import com.bdbizviz.restassured.platform.Designer.DesignerHelper;
import com.bdbizviz.restassured.platform.UserManagement.UserManagement;
import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.User;
import com.bdbizviz.restassured.platform.Util.Utils;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.bdbizviz.restassured.platform.Admininstration.AdminHelper.urlpluginService;
import static com.bdbizviz.restassured.platform.DataCenter.DataCenterHelper.dataStoreId;
import static com.bdbizviz.restassured.platform.DataCenter.DataCenterHelper.databaseName;
import static com.bdbizviz.restassured.platform.DataCenter.DataCenterHelper.urlgetusersfromgroups;
import static com.bdbizviz.restassured.platform.Designer.DesignerHelper.imagename;
import static com.bdbizviz.restassured.platform.Designer.DesignerHelper.typefile;
import static com.bdbizviz.restassured.platform.UserManagement.UserManagementHelper.*;
import static com.bdbizviz.restassured.platform.UserManagement.UserManagementHelper.authToken;
import static com.bdbizviz.restassured.platform.UserManagement.UserManagementHelper.spaceKey;
import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;

public class HomeUiHelper {

    private static final Logger LOGGER = Logger.getLogger( HomeUiHelper.class.getName() );
    public static String urlgetUserInfoByToken;
    public static String myDocumentId;
    public static String publicDocumentId;
    public static String shareDocumentId;
    public static Long position;
    public static String urlgetAllDocuments;
    public static String urlgetFavouriteDocuments;
    public static String selDocId_GetList;
    public static String urlgetListView;
    public static String urlcopyPaste;
    public static String docId_HomeUi;
    public static String folderType;
    public static String dashboardTypeFolder;
    public static String folTitle;
    public static String folderid;
    public static String folName;
    public static String docId;
    public static String docName;
    public static String imagenameFile;
    public static String file = "";
    public static String description = "";
    public static int saveFolid = 0;
    public static int dashboardTypeDocument = 5;
    public static String urlsaveFolData;
    public static String urlloadPrivilege;;
    public static String urlrenameNode;
    public static String createFol_pubId;
    public static String createFol_pubFolName;
    public static String folderid_Home;
    public static String doctype;
    public static String folTitleRename;
    public static String urlsaveFavouriteDocuments;
    public static String urlremoveNode;
    public static String create_pubDocId;
    public static String doctypefile;
    public static Integer id;
    public static String docTitleRename;
    public static String copyTitle;
    public static String copyId;
    public static String copyDocTitle;
    public static String urlassignAllPrivilege;
    public static String urlgetUsersfromGroups;
    public static Integer selUserId;
    public static String selUsers_MailId;
    public static Integer delDocId;
    public static Integer copyIdDoc;
    public static String urlgetDocumentList;
    public static String urlcutPaste;
    public static String sharedDocid;
    public static String urlmoveToList;
    public static String folId;
    public static String bIStoryname;
    public static Integer storyId;
    public static String urlsaveStoryData;
    public static Integer savedStoryId;
    public static String urlpluginService;
    public static String urlgetData;
    public static String urlgetWikiByDocId;
    public static Integer tree_RelId;
    public static Integer bizvizCubeId;
    public static String urlgetCubeData;
    public static Integer cubeViewId;
    public static String urlgetDistinctDimName;
    public static String selDashboardId_GetList;
    public static String token;
    public static String urlshareAsCopy;
    public static String emailID_getUserList;
    public static String serviceNamegetCubeData ="";
    public static String urlcreateOrUpdateWiki;
    public static Integer wikiId;
    public static String StoryId;
    public static String createStoryId;
    public static Integer savedDashId;
    public static String sharedDoclistId;
    public static String wrksapceName;
    public static String dashName;
    public static String orderType = null;
    public static String selDocId;
    public static String selFolId;
    public static String urldmAssignExcludePrivilege;
    public static String shareddataStoreId;
    public static String urlsaveWebLinkData;
    public static String urlsaveDashBoardParameters;
    public static String linkUrlId;
    public static String urlgetDashboardByIdWithoutData;
    public static String modifyDocId;
    public static String urlsaveData;
    public static String saveDataId;

    String newwCommit = "";

    public static void userLogin(String emailId, String password, String spacekey){
        try{
            User usernew = Helper.getCustomerKey(emailId,spacekey);
            User userobjauthnew = Helper.getAuthToken(emailId,password, spacekey);
            String authnew =  null;
            authnew = userobjauthnew.getAuthToken();
            String idnew = null;
            idnew = usernew.getId();

            //Calling getUserInfoToken of user
            shareDocumentId = null;
            Response response = given()
                    .param("token", authnew)
                    .when()
                    .post(urlgetUserInfoByToken)
                    .then()
                    .statusCode(HttpStatus.SC_OK)
                    .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            List<HashMap<String, Object>> treesList_userInfoToken = (ArrayList<HashMap<String, Object>>) users.get("trees");
            for (HashMap treesList_Obj :treesList_userInfoToken) {
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("My Documents")){
                    myDocumentId = treesList_Obj.get("id").toString();
                }
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Public Documents")) {
                    publicDocumentId = treesList_Obj.get("id").toString();
                }
                else if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Shared Documents")) {
                    shareDocumentId = treesList_Obj.get("id").toString();
                }
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void getUserInfoByToken(String authToken ) {
        try {
            Response response = given()
                    .param("token", authToken)
                    .when()
                    .post(urlgetUserInfoByToken)
                    .then()
                    .statusCode(HttpStatus.SC_OK)
                    .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            List<HashMap<String, Object>> treesList = (ArrayList<HashMap<String, Object>>) users.get("trees");
            for (HashMap treesList_Obj :treesList) {
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("My Documents")){
                    myDocumentId = treesList_Obj.get("id").toString();
                }
                if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Public Documents")) {
                    publicDocumentId = treesList_Obj.get("id").toString();
                }
                else if (treesList_Obj.containsKey("title") && treesList_Obj.get("title").toString().equals("Shared Documents")) {
                    shareDocumentId = treesList_Obj.get("id").toString();
                }
            }


            LOGGER.info(("ShareDocumentId is==" +shareDocumentId));
            LOGGER.info(("MyDocumentId is==" +myDocumentId));
            LOGGER.info(("PublicDocumentId is==" +publicDocumentId));

            //****To assert checking id's are not null***//
            List<Integer> ids = from(response.asString()).get("users.trees.id");
            for (Integer id : ids) {
                Assert.assertNotNull(id);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //lists the all documents
    public static void getalldocuments(String uid, String spaceKey, String authToken ){
        try {
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", Integer.valueOf(uid))
                            .header("authToken", authToken)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetAllDocuments)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> resp = from(response.asString()).get("");
            HashMap<String, Object> trees = (HashMap) resp.get("trees");
            LOGGER.info(("trees:" +trees));

        }
        catch (Exception e) {
            e.printStackTrace();
        }


    }

    //getting the FavouriteDocumentsList
    public static void getFavouriteDocuments(String uid, String spaceKey, String authToken, int statusCode) {
        try {
            String treeId = "12345";
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            .param("treeID", treeId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetFavouriteDocuments)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK ) {
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                List<HashMap<String, Object>> treesList = (ArrayList<HashMap<String, Object>>) trees.get("treesList");

                //******Asserting whether moved folder id is in ids****//
                Assert.assertEquals(trees.get("success"), true);
                LOGGER.info(("trees_getFavouriteDocuments:" + trees.toString()));

            }
            LOGGER.info("successful execution");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // getting the listview of all the documents
    public static void getlistview(String uid, String spaceKey, String authToken, int statusCode){
        try {

            Response response =
                    given() //headers
                            .header("spaceKey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authToken", authToken)

                            //params
                            .param("nodeid", myDocumentId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                List<HashMap<String, Object>> treesList = (ArrayList<HashMap<String, Object>>) trees.get("treesList");

                for (HashMap<String, Object> treeObj : treesList) {

                    if (treeObj.containsKey("title") && treeObj.get("title").toString().equals("myDoc_HomeUi")) {
                        selDocId_GetList = treeObj.get("id").toString();
                    }
                }
                System.out.println("trees:" + trees.toString());

                //******Asserting whether the id is not null****//
                // Assert.assertNotNull(selDocId_GetList);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //Creating Document directly in My documents
    public static void createDocMyDocHomeUi(String uid, String spaceKey, String authToken, int statusCode) {
        try {
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("authToken", authToken)
                            .header("userid", uid)
                            //params
                            .param("position", position)
                            .param("type", Utils.getproperty("typefile"))
                            .param("parentid", myDocumentId)
                            .param("dashboardtype", dashboardTypeDocument)
                            .param("id", saveFolid)
                            .param("imagename", Utils.getproperty("imagenamefile"))
                            .param("title", Utils.getproperty("documentTitle"))
                            .param("description", description)
                            .param("treeRel", Utils.getproperty("treeRel"))
                            .param("file", file)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveFolData)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                HashMap<String, Object> tree = (HashMap) trees.get("tree");
                docId_HomeUi = tree.get("id").toString();

                LOGGER.info(("docId_HomeUi:" + docId_HomeUi));
                LOGGER.info(("tree:" + tree));

                //****Asserting for create document****//
                Assert.assertEquals("Successfully save the dashboard", trees.get("message").toString());
                Assert.assertNotNull(docId_HomeUi);
            }
            LOGGER.info("successful execution");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    // creating folder and Document inside Folder
    public static void createFolderInMyDocs(String uid, String parentId,Long position,String authToken,String spaceKey, int statusCode) {
        try {
            Response response =
                    given().//headers
                            header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            .header("userID", uid)
                            //params
                            .param("position", position)
                            .param("type", folderType)
                            .param("parentid", parentId)
                            .param("id", saveFolid)
                            .param("dashboardtype", dashboardTypeFolder)
                            .param("imagename", Utils.getproperty("imagename"))
                            .param("title", folTitle)
                            .param("description", description)
                            .param("file", file)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveFolData)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String, Object> trees = null;
            if(statusCode==HttpStatus.SC_OK){
                trees = from(response.asString()).get("trees");
                if (trees != null) {
                    HashMap<String, Object> tree = (HashMap) trees.get("tree");
                    folderid = tree.get("id").toString();
                    folName = tree.get("title").toString();
                    LOGGER.info(("trees_CreateFol:" + trees));

                    //****Asserting for create folder****//
                    Assert.assertEquals(trees.get("message").toString(),"Successfully save the dashboard" );
                    Assert.assertNotNull(folderid);
                }
            }
            //****creating document inside folder****//
            //  statusCode = HttpStatus.SC_USE_PROXY;
            Response response_Doc =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("authToken", authToken)
                            .header("userID", uid)
                            //params
                            .param("position", position)
                            .param("type", Utils.getproperty("typefile"))
                            .param("parentid", folderid)
                            .param("dashboardtype", dashboardTypeDocument)
                            .param("id", saveFolid)
                            .param("imagename", imagenameFile)
                            .param("title", Utils.getproperty("documentTitle"))
                            .param("description", description)
                            .param("treeRel", Utils.getproperty("treeRel"))
                            .param("file", file)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveFolData)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode==HttpStatus.SC_OK){
                HashMap<String, Object> trees_Doc = from(response_Doc.asString()).get("trees");
                if(trees_Doc!=null) {
                    HashMap<String, Object> tree_Doc = (HashMap) trees_Doc.get("tree");
                    docId = tree_Doc.get("id").toString();
                    docName = tree_Doc.get("title").toString();
                    LOGGER.info(("trees_CreateDocument:" + trees_Doc));

                    //****Asserting for create document****//
                    Assert.assertEquals("Successfully save the dashboard", trees.get("message").toString());
                    Assert.assertNotNull(docId);

                    LOGGER.info(("docId:" + docId));
                }
            }
            LOGGER.info("successful execution");
        }catch(Exception e){
            e.printStackTrace();

        }
    }

    //creating folder in my documents and this particular service is not used in flow
    public static void createFolderInHomeUi(String userId, String parentId,Long position,String authToken,String spaceKey,int statusCode) {

        try {
            Response response =
                    given().//headers
                            header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            .header("userid", userId)
                            //params
                            .param("position", position)
                            .param("type", folderType)
                            .param("parentid", parentId)
                            .param("id", saveFolid)
                            .param("dashboardtype", dashboardTypeFolder)
                            .param("imagename",Utils.getproperty("imagename"))
                            .param("title",folTitle)
                            .param("description", description)
                            .param("file", file)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveFolData)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode==HttpStatus.SC_OK){
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                HashMap<String, Object> tree = null;
                if (trees != null) {
                    tree = (HashMap) trees.get("tree");
                    folderid_Home = tree.get("id").toString();

                    //****Asserting for create folder****//
                    Assert.assertEquals( trees.get("message").toString(),"Successfully save the dashboard");
                    Assert.assertNotNull(folderid_Home);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    //Creating Document  in My documents
    public static void createDocInMyDoc(String userId,String  fileType,Long dashboardTypeDocument, String folderid,Long position,String authToken,String spaceKey, int statusCode) {

        try {
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("authtoken", authToken)
                            .header("userid", userId)

                            //params
                            .param("position", position)
                            .param("type", fileType)
                            .param("parentid", folderid)
                            .param("dashboardtype", dashboardTypeDocument)
                            .param("id", saveFolid)
                            .param("imagename", imagenameFile)
                            .param("title", Utils.getproperty("documentTitle"))
                            .param("description", description)
                            .param("treeRel", Utils.getproperty("treeRel"))
                            .param("file", file)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveFolData)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode==HttpStatus.SC_OK){
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                HashMap<String, Object> tree = (HashMap) trees.get("tree");
                docId = tree.get("id").toString();
                docName = response.path("trees.tree.title").toString();

                LOGGER.info("DocumentId is==" + docId);
                LOGGER.info("trees==" + trees);

                //****Asserting for create document****//
                Assert.assertEquals(trees.get("message").toString(), "Successfully save the dashboard");
                Assert.assertNotNull(docId);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //Creating Folder in Public Documents
    public static void createFolderInPublicDoc(String uid, String parentId,Long position,String authToken,String spaceKey){
        try{
            Response response =
                    given()
                            //headers
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            .header("spaceKey", spaceKey)

                            //params
                            .param("position",position)
                            .param("type",folderType)
                            .param("parentid",parentId)
                            .param("dashboardtype",dashboardTypeFolder)
                            .param("id",saveFolid)
                            .param("imagename",imagename)
                            .param("title",Utils.getproperty("folPublicTitle"))
                            .param("description", description)
                            .param("file", file)
                            .param("token",authToken)
                            .param("spacekey",spaceKey)
                            .when()
                            .post(urlsaveFolData)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            HashMap<String, Object> trees = from(response.asString()).get("trees");
            HashMap<String, Object> tree = (HashMap) trees.get("tree");
            createFol_pubId = tree.get("id").toString();
            createFol_pubFolName = tree.get("title").toString();

            LOGGER.info(("trees:" +trees));


            //***assert for creating folder****//
            String msg =response.path("trees.message").toString();
            Assert.assertEquals(msg,"Successfully save the dashboard" );
            Assert.assertNotNull(createFol_pubId);

        }
        catch(Exception e){
            e.printStackTrace();
        }


    }

    // Creating document in folder in public documents
    public  static void createDocInFolderPublicDoc(String uid, String parentId,Long position,String authToken,String spaceKey) {
        try {
            Response response =
                    given()
                            //headers
                            .header("userID", uid)
                            .header("authToken", authToken)
                            .header("spaceKey", spaceKey)
                            //params
                            .param("position", position)
                            .param("type", Utils.getproperty("typefile"))
                            .param("parentid", parentId)
                            .param("dashboardtype",dashboardTypeDocument)
                            .param("id", saveFolid)
                            .param("imagename",imagenameFile)
                            .param("title",Utils.getproperty("docPublicTitle"))
                            .param("description", description)
                            .param("file", file)
                            .param("treeRel", Utils.getproperty("treeRel"))
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveFolData)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees = from(response.asString()).get("trees");
            HashMap<String, Object> tree = (HashMap) trees.get("tree");
            create_pubDocId=tree.get("id").toString();
            LOGGER.info(("trees:" +trees));



            //***assert message to check  creating document ****//
            Assert.assertEquals("Successfully save the dashboard", trees.get("message").toString());
            Assert.assertNotNull(create_pubDocId);

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    //Add fol to favourites
    public static void addFolToFav(String userId,String treeID, String authToken, String spaceKey,int statusCode){
        try{
            urlsaveFavouriteDocuments = Utils.getUrl("savefavouritedocuments");
            Response response_addFolderFavourites =
                    given()
                            //headers
                            .header("userid", userId)
                            .header("authtoken", authToken)
                            .header("spaceKey", spaceKey)
                            //params
                            .param("treeID",treeID)
                            .param("token",authToken)
                            .param("spacekey",spaceKey)
                            .when()
                            .post(urlsaveFavouriteDocuments)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode==HttpStatus.SC_OK){
                HashMap<String,Object> trees = from(response_addFolderFavourites.asString()).get("trees");
                LOGGER.info(("trees:" +trees.toString()));

                //***Assert message to check  folder added to favouites***//
                String msg = trees.get("message").toString();
                Assert.assertEquals(msg, "Folder added to favorites!");
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }


    }

    // moveToList, while moving document to folder
    public static void moveToList(String docId, String userId, String parentId, String authToken, String spaceKey,int statusCode ){
        try{

            urlmoveToList = Utils.getUrl("moveToList");
            String curDirTypevalue = "1";
            String moveto = "0";
            String title = "back";

            Response response =
                    given() //headers
                            .header("spaceKey", spaceKey)
                            .header("authToken", authToken)
                            .header("userID", userId)
                            //params
                            .param("docid", docId)
                            .param("doctype", typefile)
                            .param("dashboardType", dashboardTypeDocument)
                            .param("parentid", parentId)
                            .param("cutdocid", docId)
                            .param("title", title)
                            .param("moveto",moveto )
                            .param("curDirTypevalue", curDirTypevalue)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlmoveToList)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode==HttpStatus.SC_OK){
                HashMap<String, Object> response_move = from(response.asString()).get("");
                HashMap<String, Object> trees = (HashMap<String, Object>) response_move.get("trees");
                List<HashMap<String, Object>>treesList = (ArrayList<HashMap<String, Object>>)response_move.get("treesList");
                LOGGER.info(("trees_response_move:" +response_move.toString()));

                //***Assert message to check  folder deleted***//
                String msg = trees.get("success").toString();
                //  Assert.assertEquals(msg, "true");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Deleting the folder
    public static void removeNode(String userId, String id, String authToken, String spaceKey,int statusCode ){
        try{
            urlremoveNode = Utils.getUrl("removeNode");

            Response response =
                    given() //headers
                            .header("spaceKey", spaceKey)
                            .header("authToken", authToken)
                            .header("userID", userId)
                            //params
                            .param("id", id)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode==HttpStatus.SC_OK){
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                LOGGER.info(("trees:" +trees.toString()));

                //***Assert message to check  folder deleted***//
                String msg = trees.get("message").toString();
                //   Assert.assertEquals(msg, "Folder deleted successfully!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // adding that folder to favourites!..
    public static void addDocToFav(String userId,String treeID, String authToken, String spaceKey,int statusCode ){
        try {
            urlsaveFavouriteDocuments = Utils.getUrl("savefavouritedocuments");
            Response response = given()
                    .header("userid", userId)
                    .header("authtoken", authToken)
                    .header("spacekey", spaceKey)
                    .param("treeID", treeID)
                    .param("token", authToken)
                    .param("spacekey", spaceKey)
                    .when()
                    .post(urlsaveFavouriteDocuments)
                    .then()
                    .assertThat()
                    .statusCode(statusCode)
                    .extract()
                    .response();

            if(statusCode==HttpStatus.SC_OK){
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                LOGGER.info(("trees_AddFavorites:" +trees.toString()));

                //***Assert message to check  document added to favourites***//
                String msg =response.path("trees.message").toString();
                Assert.assertEquals("Folder added to favorites!", msg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    //Deleting the Document
    public static void removeNodeDocument(String userId, String id, String authToken, String spaceKey,int statusCode){
        try{
            urlremoveNode = Utils.getUrl("removeNode");
            Response response =
                    given() //headers
                            .header("spaceKey", spaceKey)
                            .header("authtoken", authToken)
                            .header("userid", userId)
                            //params
                            .param("id", id)
                            .param("spacekey", spaceKey)
                            .param("token", authToken)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode==HttpStatus.SC_OK){
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                LOGGER.info(("trees_RemoveDoc:" + trees.toString()));

                //***Assert message to check document has deleted ***//
                String msg = response.path("trees.message").toString();
                // Assert.assertEquals("Document deleted successfully!", msg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //Share the document to assigned user
    public static void shareDocUser(String docId, String userId,String authToken, String spaceKey, int statusCode ){
        try {
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            .param("treeID", docId)
                            .param("type", Utils.getproperty("typeAssignPrivilege"))
                            .param("docType",doctypefile)
                            .param("assignedUserRecords[]", newuseridfunuser )
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlassignAllPrivilege)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode!=HttpStatus.SC_BAD_REQUEST && statusCode!=HttpStatus.SC_USE_PROXY){
                HashMap<String, Object> userGroups = from(response.asString()).get("userGroups");
                LOGGER.info(("userGroups:" + userGroups.toString()));

                //****Assert to check message***//
                String msg = userGroups.get("message").toString();
                Assert.assertEquals(msg,"Document privilege updated successfully" );
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //Exclude the document shared in document management
    public static void dmAssignExcludePrivilege(String docId, String userId,String authToken, String spaceKey, int statusCode ){
        try {

            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", Integer.valueOf(userId))
                            .header("authtoken", authToken)

                            .param("treeID", docId)
                            .param("type", Utils.getproperty("typeAssignPrivilege"))
                            .param("docType",doctypefile)
                            .param("excludeUserRecords[]", userId )
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urldmAssignExcludePrivilege)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode!=HttpStatus.SC_BAD_REQUEST && statusCode!=HttpStatus.SC_USE_PROXY){
                HashMap<String, Object> userGroups = from(response.asString()).get("userGroups");
                LOGGER.info(("userGroups:" + userGroups.toString()));

                //****Assert to check message and success***//
                String msg = userGroups.get("message").toString();
                Assert.assertEquals(msg,"Document privilege updated successfully" );
              //  Assert.assertEquals(userGroups.get(success),true );
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    //Share the document to assigned user
    public static void shareDocUserNeg(String docId, String userId,String authToken, String spaceKey, int statusCode ){
        try {
            //Sharing the document
            statusCode = HttpStatus.SC_OK;
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            .param("treeID", docId)
                            //params
                            .param("type", Utils.getproperty("typeAssignPrivilege"))
                            .param("docType",doctypefile)
                            .param("assignedUserRecords[]",newuseridfunuser )
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlassignAllPrivilege)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if (statusCode ==HttpStatus.SC_BAD_REQUEST && statusCode ==HttpStatus.SC_USE_PROXY ){
                LOGGER.info(("successful execution"));
            }
            else {
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //Share the document to assigned userGroup
    public static void shareDocUserGroup(String docId, String assignedUserGroupRecords,Integer excludeUserRecords, String userId,String authToken, String spaceKey, int statusCode ){
        try {
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            //params
                            .param("docType", doctypefile)
                            .param("treeID", docId)
                            .param("type", "User")
                            .param("excludeUserRecords[]",excludeUserRecords)
                            .param("assignedUserGroupRecords[]", assignedUserGroupRecords)
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlassignAllPrivilege)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if (statusCode ==HttpStatus.SC_BAD_REQUEST && statusCode ==HttpStatus.SC_USE_PROXY ){
                LOGGER.info(("successful execution"));

            }
            else {
                HashMap<String, Object> userGroups = from(response.asString()).get("userGroups");
                LOGGER.info(("userGroups:" + userGroups.toString()));

                //****Assert to check message***//
                String msg = userGroups.get("message").toString();
                Assert.assertEquals(msg,"Document privilege updated successfully" );
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    //Share the document to assigned userGroup
    public static void shareDocUserGroupShare(String docId, String assignedUserGroupRecords,Integer excludeUserRecords, String userId,String authToken, String spaceKey, int statusCode ){
        try {
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            //params
                            .param("docType", doctypefile)
                            .param("treeID", docId)
                            .param("type", "User")
                            .param("assignedUserGroupRecords[]", assignedUserGroupRecords)
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlassignAllPrivilege)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if (statusCode ==HttpStatus.SC_BAD_REQUEST && statusCode ==HttpStatus.SC_USE_PROXY ){
                LOGGER.info(("successful execution"));

            }
            else {
                HashMap<String, Object> userGroups = from(response.asString()).get("userGroups");
                LOGGER.info(("userGroups:" + userGroups.toString()));

                //****Assert to check message***//
                String msg = userGroups.get("message").toString();
                Assert.assertEquals(msg,"Document privilege updated successfully" );
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //Share the document to assigned userGroup
    public static void shareDocUserGroupCheck(String docId, String assignedUserGroupRecords,Integer excludeUserRecords, String userId,String authToken, String spaceKey, int statusCode ){
        try {
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            //params
                            .param("treeID", docId)
                            .param("type", "User")
                            .param("docType", doctypefile)
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlassignAllPrivilege)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if (statusCode ==HttpStatus.SC_BAD_REQUEST && statusCode ==HttpStatus.SC_USE_PROXY ){
                LOGGER.info(("successful execution"));

            }
            else {
                HashMap<String, Object> userGroups = from(response.asString()).get("userGroups");
                LOGGER.info(("userGroups:" + userGroups.toString()));

                //****Assert to check message***//
                String msg = userGroups.get("message").toString();
                Assert.assertEquals(msg,"Document privilege updated successfully" );
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //Share the document to assigned userGroup
    public static void shareDocUserGroupNeg(String docId, String assignedUserGroupRecords,Integer excludeUserRecords, String userId,String authToken, String spaceKey, int statusCode ){
        try {
            statusCode = HttpStatus.SC_OK;
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            //params
                            .param("docType", doctypefile)
                            .param("treeID", docId)
                            .param("excludeUserRecords[]",excludeUserRecords)
                            .param("assignedUserGroupRecords[]", assignedUserGroupRecords)
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlassignAllPrivilege)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if (statusCode ==HttpStatus.SC_BAD_REQUEST && statusCode ==HttpStatus.SC_USE_PROXY ){
                LOGGER.info(("successful execution"));
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    //Get the users from group
    public static void getusersfromgroups(String userId, String selUserGrpId, String authToken, String spaceKey,int statusCode){
        Response response =
                given()
                        .header("spacekey", spaceKey)
                        .header("userID", Integer.valueOf(userId))
                        .header("authtoken", authToken)
                        .param("groupIds[]", selUserGrpId)
                        .param("token",authToken)
                        .param("spacekey", spaceKey)
                        .when()
                        .post(urlgetUsersfromGroups)
                        .then()
                        .assertThat()
                        .statusCode(statusCode)
                        .extract().response();
        if(statusCode==HttpStatus.SC_OK) {
            HashMap<String, Object> userGroups = from(response.asString()).get("userGroups");
            List<HashMap<String, Object>> assignedUsers = (ArrayList<HashMap<String, Object>>) userGroups.get("assignedUsers");
            LOGGER.info(("userGroups:" + userGroups.toString()));

            selUserId =(Integer) assignedUsers.get(1).get("id");
            selUsers_MailId =(String) assignedUsers.get(1).get("emailID");
            LOGGER.info(("selUserId:" + selUserId));
            System.out.println("=====" + "Selected 2nd User");

            //***Assert to check whether id's are not null****//
            List<Integer> ids = from(response.asString()).get("userGroups.assignedUsers.id");
            for (Integer id : ids) {
                Assert.assertNotNull(id);
            }
        }
    }

    // get the document info(when we modify the document)
    public static void getThumbnailByTreeID(String docId,String userId, String authToken, String spaceKey, int statusCode){
        try{
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            .param("docId", docId)
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getThumbnailByTreeID"))
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode!=HttpStatus.SC_BAD_REQUEST && statusCode!=HttpStatus.SC_USE_PROXY){
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                HashMap<String, Object> tree = (HashMap) trees.get("tree");
                LOGGER.info(("trees:" + trees.toString()));

                //****Assert to check id is not null***//
                String success = trees.get("success").toString();
                Assert.assertEquals(success,"true" );
            }


        }catch(Exception e){
            e.printStackTrace();
        }


    }

    //BI-Story Creation
    // Creating story in My documents
    public static void createStoryInFolderMyDoc(String consumerName, String serviceName, String spaceKey, String authToken, String userId, int statusCode){
        try{
            JSONObject data = new JSONObject();
            data.put("spaceKey",spaceKey);
            data.put("storyDefenition","{\"story\":[]}\",\"name\":\""+bIStoryname+"\",\"id\":null,\"isActive\":0,\"createdDate\":null,\"lastUpdatedDate\":null}}");

            String dataStr =  data.toString();
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", userId)
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", "true")
                            .param("consumerName", consumerName)
                            .param("serviceName", serviceName)
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpluginService)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees = from(response.asString()).get("");
            storyId = (Integer) trees.get("id");
            LOGGER.info(("trees:" +trees.toString()));

        }catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void saveStoryData(Integer treeRelId,String authToken, String spaceKey, String userId, int statusCode) {
        try {

            urlsaveStoryData = Utils.getUrl("saveStoryData");
            //  Long dashboardtype = Long.valueOf(Utils.getproperty("dashboardtypeStory")) ;
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authToken", authToken)
                            // params
                            .param("position", position)
                            .param("type", typefile)
                            .param("parentid", myDocumentId)
                            .param("id", 0)
                            .param("dashboardtype", 12)
                            .param("imagename", "")
                            .param("title", bIStoryname)
                            .param("description", "")
                            .param("file", "")
                            .param("treeRel", treeRelId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveStoryData)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String, Object> trees = from(response.asString()).get("trees");
            HashMap<String, Object> tree = (HashMap) trees.get("tree");
            savedStoryId = (Integer) tree.get("id");
            LOGGER.info(("Saved Story Id: " + savedStoryId));


            //****Asserting for create folder****//
            Assert.assertEquals(trees.get("message").toString(),"Successfully save the dashboard" );
            Assert.assertNotNull(savedStoryId);

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    // @Test(description = "Getting the data Story for Creation")
    public static void getData(Integer id, String authToken, String spaceKey, String userId, int statusCode) {
        try {
            urlgetData = Utils.getUrl( "getData");
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authToken", authToken)
                            .param("id", id)
                            .param("documentType", 12)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetData)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String, Object> resp = from(response.asString()).get("");
            System.out.println("resp:" + resp.toString());
           /* Assert.assertEquals("<iframe src=\"views/story/bizviz-story.html?id="+storyId+"\" width=\"100%\" height=\"100%\"></iframe>",
                    resp.toString());*/
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // @Test(description = "Getting the data of the document created inside mydocuments")
    public static void getWikiByDocId(Integer docid, String authToken, String spaceKey, String userId, int statusCode) {

        try {
            Response response =
                    given()
                            // headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authToken", authToken)
                            // params
                            .param("docId", docid)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetWikiByDocId)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();

            // savedStoryId
            HashMap<String, Object> wikiResp = from(response.asString()).get("wikiResp");
            HashMap<String, Object> wiki = (HashMap) wikiResp.get("wiki");
            tree_RelId = (Integer)wiki.get("tree_Rel");
            System.out.println("wiki :" + wikiResp.get("wiki"));
            HashMap<String, Object> docId = (HashMap) wiki.get("docId");

            //***Assert to check id is not null***//
            Integer respId = (Integer) docId.get("id");
            Assert.assertEquals(savedStoryId.toString(),respId.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // @Test(description = "Saving the Story in My documents")
    public static void getStoryById(String consumerName, String serviceName, String authToken, String spaceKey, String userId, int statusCode) {
        try {

          /*  JSONObject data = new JSONObject();
            Integer id = tree_RelId;
            data.put("id",id);*/
            String dataStr = "{\"id\":"+storyId+"}";
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", "true")
                            .param("consumerName", consumerName)
                            .param("serviceName", serviceName)
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpluginService)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> resp = from(response.asString()).get("");
            HashMap<String, Object>  businessStory= (HashMap<String, Object> ) resp.get("businessStory");
            String name  = (String) businessStory.get("name");
            LOGGER.info(("resp:" +resp.toString()));

            //****Asserting for create document****//
            //  Assert.assertEquals("Story_4thJuly", name);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void getDeliveryResultByOwnerId(String consumerName, String serviceName, String authToken, String spaceKey, String userId, int statuscode) {
        try {

            JSONObject data = new JSONObject();
            data.put("ownerId",Integer.valueOf(userId));
            String dataStr =  data.toString();
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", "true")
                            .param("consumerName", consumerName)
                            .param("serviceName", serviceName)
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpluginService)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> respData = from(response.asString()).get("");
            LOGGER.info(("respData:" +respData));
            List<HashMap<String, Object>> resp = (List<HashMap<String, Object>>)respData.get("resp");
            Boolean success = (Boolean) respData.get("success");

            //****Asserting for create document****//
            //  Assert.assertEquals("true", success.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void getDataStoreDetails(String consumerName, String serviceName, String authToken, String spaceKey, String userId, int statusCode) {
        try {
            String dataStr =  "{\"id\":0,\"datasourcetype\":\"all\"}";
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", "true")
                            .param("consumerName", consumerName)
                            .param("serviceName", serviceName)
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpluginService)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String, Object> resp = from(response.asString()).get("");
            LOGGER.info(("resp:" +resp.toString()));
            String success= resp.get("success").toString();
            // testps
            List< HashMap<String, Object> >  bizvizCubes = (List<HashMap<String, Object>>) resp.get("bizvizCubes");

            if(bizvizCubes!=null && !bizvizCubes.isEmpty()){
                for (HashMap<String, Object> bizvizCube: bizvizCubes) {
                    if(bizvizCube.containsKey("name") && bizvizCube.get("name").toString().equals("RestAutomationDataStore")){
                        bizvizCubeId = (Integer) bizvizCube.get("id");
                    }
                }
            }

            System.out.println("bizvizCubeId:" + bizvizCubeId);
            //****Asserting for create document****//
            Assert.assertEquals(success,"true" );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void getCubeInfo(String consumerName, String serviceName, String authToken, String spaceKey, String userId,  int statusCode) {

        try {
            JSONObject data = new JSONObject();
            Integer id = bizvizCubeId;
            data.put("id",id);
            String dataStr =  data.toString();
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", "true")
                            .param("consumerName", consumerName)
                            .param("serviceName", serviceName)
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpluginService)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String, Object> resp = from(response.asString()).get("");
            HashMap<String, Object>  bizvizCube= (HashMap<String, Object> ) resp.get("bizvizCube");
           /* String name  = (String) bizvizCube.get("name");
            LOGGER.info(("resp:" +resp.toString()));*/

            //****Asserting for create document****//
            //  Assert.assertEquals(name, "RestAutomationDataStore");

        } catch (Exception e) {
            e.printStackTrace();
            // LOGGER.info("context", e);
        }


    }


    //Dev server
    // @Test(description = "service call for dragging and dropping school_year dimension")
    public static void getCubeData( String dataStr,String consumerName, String serviceName, String authToken, String spaceKey, String userId, int statusCode) {
        try{

            System.out.println(dataStr);
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authToken", authToken)
                            // req data
                            .param("data", "")
                            .param("facts", "")
                            .param("viewId", 0)
                            .param("viewInfo", dataStr)
                            .param("consumerName", consumerName)
                            .param("serviceName", serviceName)
                            .param("isSecure", "true")
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetCubeData)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            //  List<HashMap<String, Object>>resp = from(response.asString()).get("");
            LOGGER.info(("respCubeData:" +response.toString()));
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //Dev Server
    //@Test(description = "service call for dragging and dropping body_mass index")
    public static void getCubedataDimen2(String dataStr, String consumerName, String serviceName, String authToken, String spaceKey, String userId,int statusCode) {

        try{
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authToken", authToken)
                            // req data
                            .param("data", "")
                            .param("facts", "")
                            .param("viewId", 0)
                            .param("viewInfo", dataStr)
                            .param("consumerName", consumerName)
                            .param("serviceName", serviceName)
                            .param("isSecure", "true")
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetCubeData)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
//            List<HashMap<String, Object>>resp = from(response.asString()).get("");
            LOGGER.info(("dataStr:" +dataStr.toString()));
            LOGGER.info(("resp:" +response.toString()));


        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void getDistinctDimName(String dataStr, String consumerName, String serviceName, String authToken, String spaceKey, String userId,int statusCode) {
        try{
            System.out.println(dataStr);
            urlgetDistinctDimName = Utils.getUrl("getDistinctDimName");
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authToken", authToken)
                            // req data
                            .param("consumerName", consumerName)
                            .param("serviceName", serviceName)
                            .param("data", dataStr)
                            .param("isSecure", "true")
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetDistinctDimName)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            List<HashMap<String, Object>>resp = from(response.asString()).get("");
            LOGGER.info(("resp:" +resp.toString()));


        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void saveCubeView(String consumerName, String serviceName, String authToken, String spaceKey, String userId, int statusCode) {

        try {
            Integer id  = bizvizCubeId;

            String dataStr = "{\"cube\":"+id+",\"serviceid\":\""+id+"\",\"name\":\"RestAutomationDataStore\",\"defenition\":\"{\\\"dataDef\\\":{\\\"filetype\\\":\\\"mysql\\\",\\\"databasename\\\":\\\""+databaseName+"\\\",\\\"query\\\":\\\"\\\\nSelect order_id,location_id as Location_Id,ACCOUNT_HOLDER_ID,LOCATION_DROP_OFF_ID,space_key as Franchise_IOId,total_amount as Order_Amount,FROM_UNIXTIME((transaction_date)/1000,'%Y-%m-%d') as Transaction_Date,total_commission as Commission from orders\\\\nwhere total_amount>0 and TOTAL_COMMISSION>0\\\"},\\\"columnNames\\\":{\\\"order_id\\\":\\\"long\\\",\\\"Location_Id\\\":\\\"long\\\",\\\"ACCOUNT_HOLDER_ID\\\":\\\"long\\\",\\\"LOCATION_DROP_OFF_ID\\\":\\\"long\\\",\\\"Franchise_IOId\\\":\\\"string\\\",\\\"Order_Amount\\\":\\\"double\\\",\\\"Transaction_Date\\\":\\\"string\\\",\\\"Commission\\\":\\\"double\\\"},\\\"adhocResults\\\":[\\\"{\\\\\\\"measures\\\\\\\":{\\\\\\\"order_id\\\\\\\":327793246263,\\\\\\\"Location_Id\\\\\\\":301747,\\\\\\\"ACCOUNT_HOLDER_ID\\\\\\\":152527,\\\\\\\"LOCATION_DROP_OFF_ID\\\\\\\":321118,\\\\\\\"Order_Amount\\\\\\\":42.0,\\\\\\\"Commission\\\\\\\":2.0},\\\\\\\"facts\\\\\\\":{\\\\\\\"Franchise_IOId\\\\\\\":\\\\\\\"7385\\\\\\\",\\\\\\\"Transaction_Date\\\\\\\":\\\\\\\"2016-01-24\\\\\\\"}}\\\"],\\\"fieldDef\\\":{\\\"facts\\\":[\\\"Franchise_IOId\\\",\\\"order_id\\\",\\\"Location_Id\\\",\\\"ACCOUNT_HOLDER_ID\\\",\\\"LOCATION_DROP_OFF_ID\\\"],\\\"measures\\\":[\\\"Order_Amount\\\",\\\"Commission\\\"],\\\"time\\\":[\\\"Transaction_Date\\\"]},\\\"elasticSearch\\\":{\\\"isEnabled\\\":true,\\\"properties\\\":{\\\"Franchise_IOId\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"order_id\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"Location_Id\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"ACCOUNT_HOLDER_ID\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"LOCATION_DROP_OFF_ID\\\":{\\\"type\\\":\\\"string\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"Order_Amount\\\":{\\\"type\\\":\\\"double\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"Commission\\\":{\\\"type\\\":\\\"double\\\",\\\"index\\\":\\\"not_analyzed\\\"},\\\"Transaction_Date\\\":{\\\"type\\\":\\\"date\\\",\\\"index\\\":\\\"not_analyzed\\\"}}},\\\"drillDef\\\":[{\\\"title\\\":\\\"Drill Def\\\",\\\"drillOrder\\\":[\\\"Franchise_IOId\\\",\\\"Location_Id\\\"]}],\\\"batchProcess\\\":{\\\"fieldName\\\":\\\"\\\",\\\"distinctQuery\\\":\\\"\\\",\\\"batchquery\\\":\\\"\\\"},\\\"dataRestriction\\\":{\\\"Franchise_IOId\\\":\\\"spacekey\\\",\\\"order_id\\\":\\\"orderid\\\"},\\\"scheduleInfo\\\":\\\"0 0 12 1 1/1 ? *\\\",\\\"scheduleDef\\\":{\\\"interval\\\":\\\"monthly\\\",\\\"option\\\":\\\"every\\\",\\\"optionArgs\\\":{\\\"choiceDay\\\":\\\"1\\\",\\\"choiceMonth\\\":\\\"1\\\"},\\\"time\\\":{\\\"hour\\\":12,\\\"min\\\":0}},\\\"notification\\\":{\\\"status\\\":true,\\\"mailid\\\":\\\"\\\"},\\\"enableNLP\\\":true,\\\"formulaJSON\\\":{},\\\"deltaProcess\\\":{\\\"isDeltaProcess\\\":false,\\\"deltaQuery\\\":\\\"\\\",\\\"delta\\\":\\\"\\\"}}\",\"cubeview\":[{\"lastRunDate\":null,\"createdBy\":{\"id\":"+userId+"},\"updatedBy\":{\"id\":"+userId+"},\"spaceKey\":\""+spaceKey+"\",\"name\":\"\",\"type\":1,\"id\":null,\"status\":1,\"createdDate\":null,\"lastUpdatedDate\":null,\"isActive\":0,\"privacyType\":true,\"defenition\":\"{\\\"title\\\":\\\"Sum( Order_Amount )\\\",\\\"desc\\\":\\\"By Location_Id\\\",\\\"defaultChartClass\\\":\\\"MixedChart\\\",\\\"chartProperties\\\":{\\\"Object.Chart.xAxis.LabelFontSize\\\":\\\"12\\\",\\\"Object.Chart.yAxis.LabelFontSize\\\":\\\"12\\\",\\\"Object.Chart.Precision\\\":\\\"0\\\",\\\"Object.Chart.secondaryAxisShow\\\":false,\\\"Object.Chart.SecondaryAxisPrecision\\\":\\\"0\\\",\\\"Object.Chart.SecondaryAxisSecondaryFormatter\\\":\\\"Number\\\",\\\"Object.Chart.SecondaryAxisSecondaryUnit\\\":\\\"auto\\\",\\\"Object.Chart.SecondaryFormater\\\":\\\"Number\\\",\\\"Object.Chart.SecondaryUnit\\\":\\\"auto\\\",\\\"Object.Chart.showSlider\\\":false,\\\"Object.Chart.baseZero\\\":false,\\\"Object.Chart.showLegends\\\":false},\\\"filter\\\":{\\\"Location_Id\\\":[\\\"301161\\\",\\\"301721\\\",\\\"301781\\\",\\\"301451\\\",\\\"301306\\\",\\\"301252\\\",\\\"301509\\\",\\\"301564\\\",\\\"301326\\\"]},\\\"filterList\\\":\\\"\\\",\\\"mergedCubes\\\":[],\\\"currentCube\\\":null,\\\"isMergeEnabled\\\":false,\\\"mergedCubeDetails\\\":{},\\\"aggregation\\\":{\\\"op\\\":\\\"sum\\\",\\\"sfx\\\":\\\"\\\",\\\"pfx\\\":\\\"\\\",\\\"measure\\\":\\\"\\\"},\\\"category\\\":[{\\\"dimension\\\":\\\"Location_Id\\\",\\\"interval\\\":\\\"\\\",\\\"sourceID\\\":"+id+",\\\"$$hashKey\\\":\\\"object:671\\\"}],\\\"series\\\":[{\\\"measure\\\":\\\"Order_Amount\\\",\\\"op\\\":\\\"sum\\\",\\\"sourceID\\\":"+id+",\\\"$$hashKey\\\":\\\"object:677\\\"},{\\\"measure\\\":\\\"Commission\\\",\\\"op\\\":\\\"sum\\\",\\\"sourceID\\\":"+id+",\\\"$$hashKey\\\":\\\"object:682\\\"}],\\\"transDim\\\":\\\"\\\",\\\"customField\\\":{\\\"list\\\":[],\\\"condition\\\":[]},\\\"properties\\\":{\\\"legend\\\":{\\\"enable\\\":false,\\\"orientation\\\":1,\\\"style\\\":1},\\\"excludeView\\\":{\\\"enable\\\":false},\\\"showDataLabel\\\":true,\\\"dataRestriction\\\":{}},\\\"querytype\\\":\\\"simple\\\",\\\"mergedDataStore\\\":{},\\\"masterDataStore\\\":\\\""+id+"\\\"}\"}]}";
            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authToken", authToken)
                            // req data
                            .param("isSecure", "true")
                            .param("consumerName", consumerName)
                            .param("serviceName", serviceName)
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpluginService)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> resp = from(response.asString()).get("");
            HashMap<String, Object> bizvizCube=(HashMap<String, Object> ) resp.get("bizvizCube");
            List<HashMap<String, Object> > cubeViews = ( List<HashMap<String, Object> > ) bizvizCube.get("cubeViews");
            cubeViewId = (Integer)cubeViews.get(0).get("id");
            LOGGER.info(("bizvizCube:" +bizvizCube.toString()));

            //****Asserting for create document****//
            Assert.assertEquals("RestAutomationDataStore", bizvizCube.get("name"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // @Test(description = "story save view ")
    public static void CreateViewLog(String consumerName, String serviceName, String authToken, String spaceKey, String userId, int statusCode) {
        try {

            String dataStr = "{\"viewLogList\":[{\"bizvizStrory\":" + storyId + ",\"cubeId\":" + bizvizCubeId + ",\"viewId\":" + cubeViewId + "}]}";
            System.out.println(dataStr);

            Response response =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authToken", authToken)
                            // req data
                            .param("consumerName", consumerName)
                            .param("serviceName", serviceName)
                            .param("data", dataStr)
                            .param("isSecure", "true")
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpluginService)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String, Object> resp = from(response.asString()).get("");
            LOGGER.info(("dataStr:" + dataStr.toString()));
            LOGGER.info(("resp:" + resp.toString()));


        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //when we click on properties mobile view//
    public static void loadPrivilege(String docId,String authToken, String spaceKey, String userId, int statusCode){
        try{

            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            .param("treeID", docId)
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlloadPrivilege)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> userGroups = from(response.asString()).get("userGroups");
            List< HashMap<String, Object> > users =(ArrayList<HashMap<String, Object>>)userGroups.get("users");
            List< HashMap<String, Object> > userGroupsList =(ArrayList<HashMap<String, Object>>)userGroups.get("userGroupsList");
            LOGGER.info(("userGroups:" +userGroups.toString()));

            //****Assert to check message***//
            List<Integer> ids = from(response.asString()).get("userGroups.users.id");
            for(Integer id: ids ){
                Assert.assertNotNull(id);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

    }

    //get the id of Story
    public static void getListViewStory(String authToken, String spaceKey, String userId, int statusCode){
        try {
            String orderType = null;
            Response response =
                    given() //headers
                            .header("spaceKey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authToken", authToken)

                            //params
                            .param("nodeid", myDocumentId)
                            .param("orderType", orderType)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                List<HashMap<String, Object>> treesList = (ArrayList<HashMap<String, Object>>) trees.get("treesList");

                for (HashMap<String, Object> treeObj : treesList) {

                    if (treeObj.containsKey("title") && treeObj.get("title").toString().equals("BIStory_Automate")) {
                        selDocId_GetList =  treeObj.get("id").toString();
                    }
                }
                for (HashMap<String, Object> treeObj : treesList) {

                    if (treeObj.containsKey("title") && treeObj.get("title").toString().equals("WebServiceDashboard")) {
                        selDashboardId_GetList =  treeObj.get("id").toString();
                    }
                }
                System.out.println("trees:" + trees.toString());
                LOGGER.info("StoryId:" + selDocId_GetList);
                LOGGER.info("Dashboardid:" + selDashboardId_GetList);

                //******Asserting whether the id is not null****//
                 Assert.assertNotNull(selDocId_GetList);
                Assert.assertNotNull(selDashboardId_GetList);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

    }

    public static void createApiToken(String authToken, String spaceKey, String userId, int statusCode) {
        try {
            String url = Utils.getUrl("createApiToken");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userId)
                            .header("authToken", authToken)
                            .param("generateAPITokenType", Utils.getproperty("createapitoken"))
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            String msg = (String) users.get("message");
            token=users.get("apitoken").toString();

            Assert.assertEquals( msg,"API Token created successfully!!!");
            Assert.assertEquals( users.get("success").toString(),"true");
            Assert.assertNotNull(token);


            LOGGER.info(("createApiToken=" + response.asString()));

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public static void getuserlist(String spaceKey,String userid,String authToken,String from,String rows,String userFilter,Integer statuscode ) {
        try {
            String url = Utils.getUrl("getuserlist");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            .param("from", from)
                            .param("rows", rows)
                            .param("userFilter", userFilter)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();

            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> users = from(response.asString()).get("users");
                List<HashMap<String, Object>> user = (ArrayList<HashMap<String, Object>>) users.get("users");
                List<Integer> ids = from(response.asString()).get("users.users.id");
                for (Integer id : ids) {
                    Assert.assertNotNull(id);
                }
                for (HashMap<String, Object> userId : user) {
                    if (userId.containsKey("fullName") && userId.get("fullName").toString().equals("RestAutomation")) {
                        usrid = userId.get("id").toString();
                        status = userId.get("status").toString();
                        nme = userId.get("fullName").toString();
                        emailID_getUserList = userId.get("emailID").toString();
                    }
                }
                getuserid = user.get(0).get("id").toString();
                LOGGER.info("usrid===" + usrid);
                System.out.println("emailID_getUserList;===" + emailID_getUserList);
                Assert.assertEquals(users.get("success").toString(), "true");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //share document as copy
    public static void shareAsCopy(String treeID, String seluserId, String authToken, String spaceKey,String userID, int statusCode ){
        try{
            urlshareAsCopy = Utils.getUrl("shareAsCopy");
            String doctypefile = Utils.getproperty("doctypefile");
            String dashboardType = Utils.getproperty("dashboardtypeStory");

            Response response =
                    given()  //headers
                            .header("spacekey", spaceKey)
                            .header("userID", userID)
                            .header("authtoken", authToken)
                            //req params
                            .param("docType", doctypefile)
                            .param("treeID", treeID)
                            .param("type", "User")
                            .param("assignedUserRecords[]", seluserId)
                            .param("dashboardType", 12)
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlshareAsCopy)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String,Object> resp = from(response.asString()).get("");
            LOGGER.info(("resp_ShareAsCopy:" +resp.toString()));


            String msg = resp.get("message").toString();
            //  Assert.assertEquals(msg,"Document copying process started. Please check Notification for confirmation");

        }catch(Exception e){
            e.printStackTrace();
        }

    }

    public static void getAllSharedDataStore(String spacekey,String userID,String authtoken,String data,Integer statuscode) {
        try {
            Response response=
                    given()
                            //Header
                            .header("spacekey", spacekey)
                            .header("userID", userID)
                            .header("authtoken", authtoken)
                            //Body
                            .param("data",data )
                            .param("token", authtoken)
                            .param("spacekey", spacekey)
                            .when()
                            .post(Utils.getUrl("getAllDataStore"))
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> dataSourcesListgetdatastoreinfo = from(response.asString()).get("");
                List< HashMap<String, Object> > bizvizCubes = (ArrayList<HashMap<String, Object>>) dataSourcesListgetdatastoreinfo.get("bizvizCubes");

                for (HashMap bizvizCubeObj:bizvizCubes) {
                    if (bizvizCubeObj.containsKey("title") && bizvizCubeObj.get("title").toString().equals("RestAutomationDataStore") ){
                        shareddataStoreId = bizvizCubeObj.get("id").toString();
                    }
                }
                Assert.assertEquals(dataSourcesListgetdatastoreinfo.get("success").toString(), "true");
                LOGGER.info("getDataStoreInfo=====" + response.asString());
                LOGGER.info("dataStoreId=====" + shareddataStoreId);
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public static void saveWebLinkData(String linkurlName,String treeRelId, String spaceKey,String userid,String authToken,Integer statuscode ) {
        try {
            urlsaveWebLinkData = Utils.getUrl("saveWebLinkData");
            String description = "";
            linkUrlId = null;
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            //params
                            .param("position", position)
                            .param("dashboardtype", dashboardTypeDocument)
                            .param("parentid", myDocumentId)
                            .param("type", typefile)
                            .param("id", saveFolid)
                            .param("imagename", imagenameFile)
                            .param("title", linkurlName)
                            .param("description", description)
                            .param("treeRel", treeRelId)
                            .param("file", "")
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveWebLinkData)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();

            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                HashMap<String, Object> tree = (HashMap) trees.get("tree");
                 linkUrlId = tree.get("id").toString();

                Assert.assertEquals(trees.get("message"), "Successfully save the dashboard");
                Assert.assertEquals(trees.get("success"), true);
                System.out.println("saveWebLinkData_LinkUrlid:" + linkUrlId);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void saveDashBoardParameters(String docId, String spaceKey,String userid,String authToken,Integer statuscode ) {
        try {
            urlsaveDashBoardParameters = Utils.getUrl("saveDashBoardParameters");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            //params
                            .param("docid", docId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveDashBoardParameters)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();

            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> trees = from(response.asString()).get("trees");
              //  Assert.assertEquals(trees.get("success").toString(), "true");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void saveDashBoardParametersmodifyDoc(String docId, String spaceKey,String userid,String authToken,Integer statuscode ) {
        try {

            urlsaveDashBoardParameters = Utils.getUrl("saveDashBoardParameters");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            //params
                            .param("paramType[]", 2)
                            .param("name[]", "token")
                            .param("docid", docId)
                            .param("propsName[]", "token")
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveDashBoardParameters)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();

            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                //  Assert.assertEquals(trees.get("success").toString(), "true");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void getDashboardByIdWithoutData(String docId, String spaceKey,String userid,String authToken,Integer statuscode ) {
        try {
            urlgetDashboardByIdWithoutData = Utils.getUrl("getDashboardByIdWithoutData");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            //params
                            .param("treeID", docId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetDashboardByIdWithoutData)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();

            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                HashMap<String, Object> tree = (HashMap) trees.get("tree");
                modifyDocId = tree.get("id").toString();
                Assert.assertEquals(trees.get("success"), false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // creating folder and Document inside Folder
    public static void saveData( String id, String treeRel,String uid, String parentId,Long position,String authToken,String spaceKey, Integer statuscode) {
        try {
            urlsaveData = Utils.getUrl("uploaddashboard");
            Response response =
                    given().//headers
                            header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            .header("userID", uid)
                            //params
                            .param("position", position)
                            .param("type", typefile)
                            .param("parentid", parentId)
                            .param("id", id)
                            .param("dashboardtype", dashboardTypeDocument)
                            .param("imagename", imagenameFile)
                            .param("title", "QALinkUrl")
                            .param("description", description)
                            .param("treeRel", treeRel)
                            .param("file", "")
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveData)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();
            if (statuscode == 305) {
                Assert.assertEquals(statuscode.intValue(), 305);

            } else {
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                HashMap<String, Object> tree = (HashMap) trees.get("tree");
                saveDataId = tree.get("id").toString();
                Assert.assertEquals(trees.get("message"), "Successfully save the dashboard");
                Assert.assertEquals(trees.get("success"), true);
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
            LOGGER.info("successful execution");

    }

    public static void saveDashBoardParametersModify(String docId, String spaceKey,String userid,String authToken,Integer statuscode ) {
        try {
            urlsaveDashBoardParameters = Utils.getUrl("saveDashBoardParameters");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", userid)
                            .header("authToken", authToken)
                            //params
                            .param("paramType[]", 2)
                            .param("name[]", authToken)
                            .param("docid", docId)
                            .param("propsName[]", authToken)
                            .param("id[]", "customParamName")
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveDashBoardParameters)
                            .then()
                            .assertThat()
                            .statusCode(statuscode)
                            .extract().response();

            if (statuscode==305){

                Assert.assertEquals(statuscode.intValue(),305);

            }
            else {
                HashMap<String, Object> trees = from(response.asString()).get("trees");
                Assert.assertEquals(trees.get("success"), "true");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }








}