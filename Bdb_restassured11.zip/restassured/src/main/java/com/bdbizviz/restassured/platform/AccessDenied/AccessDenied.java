package com.bdbizviz.restassured.platform.AccessDenied;

import com.bdbizviz.restassured.platform.DataCenter.DataCenterHelper;
import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.Utils;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper.getlistview;
import static com.bdbizviz.restassured.platform.HomeUI.HomeUiHelper.*;
import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;

/**
 * Created by bizviz on 16/2/18.
 */
public class AccessDenied extends AccessDeniedHelper {
    private static final Logger LOGGER = Logger.getLogger( AccessDenied.class.getName() );
    String update = "";

    String newCommit = "";

    @BeforeClass
    public static void setup() {
        //NonAdmin user
        user = Helper.getCustomerKey(emailid_admin,space_admin);
        userauth = Helper.getAuthToken(emailid_admin,pass_admin,space_admin);
        spaceKey = user.getSpacekey();
        uid = user.getId();
        authToken = userauth.getAuthToken();
    }

    //Called on click on Every Modules
    @Test(description = "getUserInfoByToken called on click of Every Modules")
    public void getUserInfoByTokenTestCase() {
        try {
            getUserInfoByToken(authToken, HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //LandingPage
    @Test(description = "getalldocuments")
    public void getListview() {

        try {
            getlistview(uid,spaceKey,authToken,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //HomePage
    @Test(description = "getAllMenuContext called on click of HomePage ")
    public void getAllMenuContext() {
        try {
            getAllMenuContext(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Bizviz notifications
    @Test(description = "pluginServiceNotification")
    public void pluginServiceNotification() {
        try {
            pluginServiceLogin(uid,authToken,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Admin.java Module
    @Test(description = "Get permission by category ")
    public void adminModule() {
        try {
            adminModule(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Admin.java Module
    @Test(description = "Get all Users ")
    public void getAllUsers() {
        try {
            getAllUsers(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //UserManagement
    @Test(description = "getuserlist called on click of UserManagement")
    public void getuserlist() {
        try {
            getuserlist(spaceKey,uid,authToken, Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getusergrouplist called on click of UserManagement")
    public void getusergrouplist() {
        try {
            getusergrouplist(spaceKey,uid,authToken,Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //DataCenter
    @Test(description = "getDataSourceInfoByType called on click of DataCenter")
    public void getDataSourceInfoByType() {
        try {
            DataCenterHelper.getDataSourceInfoByType(spaceKey,uid,authToken,"",HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Sentiment
    @Test(description = "pluginServiceSentiment called on click of Sentiment")
    public void pluginServiceSentiment() {
        try {
            pluginServiceSentiment(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //SMB
    @Test(description = "pluginServiceSMB called on click of SMB")
    public void pluginServiceSMB() {
        try {
            pluginServiceSMB(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "pluginServiceSMB1 called on click of SMB module and inside it on SMB")
    public void pluginServiceSMB1() {
        try {
            pluginServiceSMB1(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Play
    @Test(description = "getAllPlayWorkspaceAndContent")
    public void getAllPlayWorkspaceAndContent() {
        try {
            getAllPlayWorkspaceAndContent(spaceKey,uid,authToken);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //predictive
    @Test(description = "pluginServicePredictive called on click of predictive")
    public void pluginServicepredictive() {
        try {
            String data = "{\"id\":\"\",\"type\":12,\"status\":1,\"spaceKey\":\""+spaceKey+"\",\"settings\":\"\"}";
            pluginServicePredictive(spaceKey,uid,authToken,data);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //predictive-Rserver
    @Test(description = "pluginServicePredictive called on click of predictive RServer settings")
    public void pluginServicepredictiveRServer() {
        try {
            pluginServicepredictiveRServer(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //predictive-getAllWorkflows
    @Test(description = "pluginServicepredictiveGetAllWorkflows")
    public void pluginServicepredictiveGetAllWorkflows() {
        try {
            pluginServicepredictiveGetAllWorkflows(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Geo Settings
    @Test(description = "GetGeoSpatial Settings")
    public void getAllGeoSpatialSettings() {
        try {
            getAllGeoSpatialSettings(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Dashboard
    @Test(description = "Dashboard")
    public void getAllWorkspaceAndDashboard() {
        try {
            getAllWorkspaceAndDashboard(spaceKey,uid,authToken);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Survey
    @Test(description = "Survey")
    public void surveyPluginService() {
        try {
            String data = "{\"consumerName\":\"SURVEY\",\"customerId\":null,\"ut\":null,\"email\":null,\"params\":\"\",\"userid\":"+uid+",\"userType\":1}";
            surveyPluginService(spaceKey,uid,authToken,data);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }


     //*****HomeUI services to track the access denied*****//
    @Test(description ="creating the Folder and deleting it")
    public static void copyFolder(){

        try{
            createFolderInHomeUi(uid, myDocumentId, position,authToken,spaceKey,HttpStatus.SC_OK);
            String dashboardType = Utils.getproperty("dashboardType");

            Response response =
                    given()
                            //headers
                            .header("userID", uid)
                            .header("spaceKey", spaceKey)
                            .header("authToken", authToken)

                            //params
                            .param("source", folderid_Home)
                            .param("title", copyTitle)
                            .param("destination", myDocumentId)
                            .param("dashboardType",  Integer.valueOf(dashboardType))
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlcopyPaste)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String,Object> responseMap = from(response.asString()).get("");
            LOGGER.info(("response_CopyFolder:" +responseMap.toString()));

            //****Assert to check success message***//
            Assert.assertEquals(responseMap.get("success").toString(), "true");

            //***Deleting the created folder***//
            LOGGER.info(("folderid_Home:" +folderid_Home ));

            Response response1 =
                    given()
                            //headers
                            .header("userID", uid)
                            .header("spaceKey", spaceKey)
                            .header("authToken", authToken)
                            //params
                            .param("id", folderid_Home)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees1 = from(response1.asString()).get("trees");
            System.out.println(("trees_DelFolder:" +trees1.toString()));

            //****getListView to get the id of copied folder****//
            Response response2 =
                    given()
                            //headers
                            .header("userID", uid)
                            .header("spaceKey", spaceKey)
                            .header("authToken", authToken)
                            //params
                            .param("nodeid", myDocumentId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetListView)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> respMap = from(response2.asString()).get("");
            HashMap<String, Object> trees2 = (HashMap<String, Object>) respMap.get("trees");
            List< HashMap<String, Object> > treesList2 = (ArrayList<HashMap<String, Object>>) trees2.get("treesList");

            for (HashMap<String, Object> treeListObj:treesList2) {
                if (treeListObj.containsKey("title") && treeListObj.get("title").toString().equals(Utils.getproperty("copyTitle").toString())) {
                    copyId = treeListObj.get("id").toString();
                }
            }

            //***Deleting the copied folder***//
            LOGGER.info(("copyId:" +copyId ));
            Response response3 =
                    given()
                            //headers
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uid))
                            .header("authtoken", authToken)
                            //params
                            .param("id", copyId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlremoveNode)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> trees3 = from(response3.asString()).get("trees");
            System.out.println(("trees_DelCopiedFol:" +trees3.toString()));

            //****getListView to compare json****//
            Response responseGetList4 =
                    given()
                            //headers
                            .header("userID", uid)
                            .header("spaceKey", spaceKey)
                            .header("authToken", authToken)
                            //params
                            .param("nodeid", myDocumentId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getlistview"))
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> respMap4 = from(responseGetList4.asString()).get("");
            HashMap<String, Object> treesGetList4 = (HashMap<String, Object>) respMap4.get("trees");
            List< HashMap<String, Object> > treesList4 = (ArrayList<HashMap<String, Object>>) treesGetList4.get("treesList");
            id = (Integer)treesList4.get(0).get("id");

        }
        catch(Exception e){
            e.printStackTrace();
        }

    }


}