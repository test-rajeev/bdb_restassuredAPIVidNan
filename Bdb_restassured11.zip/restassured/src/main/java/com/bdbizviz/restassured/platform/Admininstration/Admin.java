package com.bdbizviz.restassured.platform.Admininstration;

import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.User;
import com.bdbizviz.restassured.platform.Util.Utils;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.logging.Logger;

import static io.restassured.RestAssured.given;

/**
 * Created by bizviz on 8/2/18.
 */
public class Admin  extends AdminHelper{
    public static final Logger LOGGER = Logger.getLogger(Admin.class.getName());

    @BeforeClass
    public static void setup() {
        prop = Utils.getProps();//Fetch all json data of properties json file and store in prop

        usrname = Utils.getproperty("userName");
        uid = Utils.getproperty("uid");
        fulnme = Utils.getproperty("fullName");
        updateuserprofilename = Utils.getproperty("updateuserprofilename");
        urlpluginService = Utils.getUrl("pluginService");
        urlgetAllGeoSpatialSettings = Utils.getUrl("getAllGeoSpatialSettings");
        projectpath = Utils.getUrl("projectpath");
        uniqueid = Utils.getproperty("uniqueid");
        passnew = Utils.getproperty("passnew");
        projectpath = Utils.getUrl("projectpath");
        updateusrname = Utils.getproperty("updateusrname");
        uniqueidupdate = Utils.getproperty("uniqueidupdate");
        isSecure = Utils.getproperty("isSecure");
        consumerName = Utils.getproperty("consumerNameAdmin");
        serviceNameGet = Utils.getproperty("serviceNameGet");
        serviceNameSave = Utils.getproperty("serviceNameSave");
        uniqueid = Utils.getproperty("uniqueid");
        urlgetlist = Utils.getUrl("getuserlist");

        //NonAdmin user
        user = Helper.getCustomerKey(emailidcreate,space_admin);
        userauth = Helper.getAuthToken(emailidcreate,pass_admin,space_admin);
        spaceKey = user.getSpacekey();
        uid = user.getId();
        authToken = userauth.getAuthToken();

    }


    @Test(description = "editEmailConfSettings")
    public static void editEmailConfSettings() {
        try {
            editEmailConfSettings(uid, authToken,spaceKey, HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getEmailConfSettings")
    public static void getEmailConfSettings() {
        try {
            getEmailConfSettings(uid, authToken,spaceKey, HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getPasswordStrategySettingsDetails")
    public static void getPasswordStrategySettingsDetails() {
        try {
            getPasswordStrategySettingsDetails(uid, authToken,spaceKey, HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "editPasswordStrategySettings")
    public static void editPasswordStrategySettings() {
        try {
            String dataStr = "{\"id\":\"\",\"type\":6,\"status\":\"1\",\"settings\":\"{\\\"id\\\":\\\"\\\",\\\"updatedDate\\\":\\\"\\\",\\\"passwordExpiry\\\":\\\"10\\\"," + "\\\"passwordStrength\\\":\\\"8\\\",\\\"passwordReuse\\\":\\\"1\\\",\\\"noOfUserLoginFail\\\":\\\"3\\\",\\\"createdBy\\\":null,\\\"spaceKey\\\":\\\""+spaceKey+"\\\"}\",\"spaceKey\":\""+spaceKey+"\"}";
            editPasswordStrategySettings(dataStr,uid, authToken,spaceKey, HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "validatePasswordStrategySettings")
    public static void validatePasswordStrategySettings() {
        try {
            //Edit password Settings
            String dataStr = "{\"id\":\"\",\"type\":6,\"status\":\"1\",\"settings\":\"{\\\"id\\\":\\\"\\\",\\\"updatedDate\\\":\\\"\\\",\\\"passwordExpiry\\\":\\\"10\\\"," + "\\\"passwordStrength\\\":\\\"8\\\",\\\"passwordReuse\\\":\\\"1\\\",\\\"noOfUserLoginFail\\\":\\\"2\\\",\\\"createdBy\\\":null,\\\"spaceKey\\\":\\\""+spaceKey+"\\\"}\",\"spaceKey\":\""+spaceKey+"\"}";
            editPasswordStrategySettings(dataStr,uid, authToken,spaceKey, HttpStatus.SC_OK);

            //Creating User
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            //Assigning in group
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("NEWCREATEGRPID==" + newuseridfunuser);


            //Login with new user passing in valid password
            User usernew = Helper.getCustomerKey(emailidcreatefun,space_admin);
            User userobjauthnew = Helper.getAuthToken(emailidcreatefun,passworduser_admin, space_admin);
            String authnew =  null;
            authnew= userobjauthnew.getAuthToken();
            String idnew = null;
            idnew = usernew.getId();

            System.out.println("authnew:" + authnew);
            LOGGER.info("idnew:" + idnew);

            //Login with the same user 2nd time passing in valid password
            User usernew_sec = Helper.getCustomerKey(emailidcreatefun,space_admin);
            User userobjauthnew_sec = Helper.getAuthToken(emailidcreatefun,passworduser_admin, space_admin);
            String authnew_sec = userobjauthnew_sec.getAuthToken();
            String idnew_sec = usernew.getId();


            System.out.println("authnew_sec:" + authnew_sec);
            LOGGER.info("idnew_sec:" + idnew_sec);

            //Assertion
            Assert.assertEquals(idnew, idnew_sec);
            // Assert.assertNull(authnew);


        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "editAuditTrailSettings")
    public static void editAuditTrailSettings() {
        try {
            String dataStr = "\"id\":\"\",\"type\":1,\"status\":1,\"settings\":\"{\\\"configurationSettings\\\":\\\"1\\\",\\\"atHost\\\":\\\"\\\",\\\"atPort\\\":\\\"\\\",\\\"atPassword\\\":\\\"\\\",\\\"atUserName\\\":\\\"\\\",\\\"atDBName\\\":\\\"\\\",\\\"atDBType\\\":\\\"\\\",\\\"status\\\":\\\"1\\\",\\\"infoStatus\\\":\\\"1\\\",\\\"debugstatus\\\":\\\"2\\\",\\\"errorstatus\\\":\\\"2\\\",\\\"timeZone\\\":\\\"\\\"}\",\"spaceKey\":\""+spaceKey+"\"}";
            editAuditTrailSettings(dataStr,uid, authToken,spaceKey, HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getAuditTrailSettings")
    public static void getAuditTrailSettings() {
        try {
            String dataStr = "{\"type\":1,\"status\":1,\"spaceKey\":"+spaceKey+",\"settings\":\"{}\"}";
            getAuditTrailSettings(dataStr,uid, authToken,spaceKey, HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "Get all Users")
    public void getAllUsers() {
        try {
            getAllUsers(spaceKey,uid,authToken, HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "get the audit log")
    public static void getAuditInformation() {
        try {
            getAuditInformation(uid, authToken,spaceKey, HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "editCustomFieldSettings")
    public static void editCustomFieldSettings() {
        try {
            String dataStr = "{\"id\":\"\",\"type\":101,\"status\":1,\"settings\":\"{\\\"customproperties\\\":\\\"[{\\\\\\\"key\\\\\\\":\\\\\\\"manager\\\\\\\",\\\\\\\"description\\\\\\\":\\\\\\\"manager\\\\\\\",\\\\\\\"inputtype\\\\\\\":\\\\\\\"manual\\\\\\\",\\\\\\\"mandatory\\\\\\\":\\\\\\\"yes\\\\\\\"}]\\\"}\",\"spaceKey\":\""+spaceKey+"\"}";
            editCustomFieldSettings(dataStr,uid, authToken,spaceKey, HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getCustomFieldSetting")
    public static void getCustomFieldSettings() {
        try {
            String dataStr = "{\"id\":\"\",\"type\":\"101\",\"status\":1,\"settings\":\"\",\"spaceKey\":\""+spaceKey+"\"}";
            getCustomFieldSettings(uid, authToken,spaceKey,dataStr, HttpStatus.SC_OK);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "SaveOrUpdateDataManagementSettings")
    public static void saveOrUpdateDataManagementSettings() {
        try {

            //***Data Service edit*****//
            String dataService = "{\"type\":10,\"status\":1,\"spaceKey\":\""+spaceKey+"\",\"settings\":\"{\\\"mysql\\\":8000,\\\"mssql\\\":8000,\\\"oracle\\\":6000,\\\"hive\\\":6000,\\\"hana\\\":6000,\\\"cassandra\\\":6000,\\\"odata\\\":6000,\\\"sparksql\\\":7000,\\\"file\\\":6000,\\\"redshift\\\":6000,\\\"cassandranative\\\":7000}\"}";

            saveOrUpdateDataManagementSettings(uid, authToken,spaceKey,dataService, HttpStatus.SC_OK);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "getDataManagementDetails")
    public static void getDataManagementDetails() {
        try {
            String dataStr = "{\"createdDate\":null,\"isActive\":0,\"lastUpdatedDate\":null,\"reserv1\":null,\"reserv2\":null,\"reserv3\":null,\"reserv4\":null,\"reserv5\":null,\"id\":null,\"status\":1,\"type\":10,\"spaceKey\":\""+spaceKey+"\",\"settings\":\"\"}";
            getDataManagementDetails(uid, authToken,spaceKey,dataStr, HttpStatus.SC_OK);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Test(description = "getPredictiveSettings")
    public static void getPredictiveSettings() {
        try {
            String dataStr = "{\"id\":null,\"type\":12,\"status\":1,\"settings\":\"\",\"spaceKey\":\""+spaceKey +"\"}";
            getPredictiveSettings(uid, authToken,spaceKey,dataStr, HttpStatus.SC_OK);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "getWinADConfSettings")
    public static void getWinADConfSettings() {
        try {
            String dataStr = "{\"id\":null,\"type\":4,\"status\":1,\"settings\":\"\",\"spaceKey\":\""+spaceKey+"\"}";
            getWinADConfSettings(uid, authToken,spaceKey,dataStr, HttpStatus.SC_OK);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "getAllGeoSpatialSettingsAdmin")
    public static void getAllGeoSpatialSettingsAdmin() {
        try {
            getAllGeoSpatialSettingsAdmin(uid, authToken,spaceKey, HttpStatus.SC_OK);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "getAllGeoShapeDatas")
    public static void getAllGeoShapeDatas() {
        try {
            String geometryType = "Polygon";
            getAllGeoShapeDatas(geometryType,uid, authToken,spaceKey, HttpStatus.SC_OK);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Test(description = "encryption")
    public static void encryption() {
        try {
            getActiveUsers(uid, authToken,spaceKey, HttpStatus.SC_OK);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "killsession workflow from login ,killing that login user session and using its data in other service")
    public static void killSessionFlow() {
        try {
            createnewuserFunctional(spaceKey, uid, authToken, uniqueid+Helper.generateRandomString(), usrname, fulnme, pass_admin, "", authToken, spaceKey,HttpStatus.SC_OK);

            usernan = Helper.getCustomerKey(emailidcreatefun, space_admin);
            usernanauth = Helper.getAuthToken(emailidcreate, pass_admin, space_admin);
            authTokennan = usernanauth.getAuthToken();
            uidnan = usernan.getId();

            //kill session data
            String url = Utils.getUrl("killsession");
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .param("userid", uid)
                            .param("data", "[" + uidnan + "]")
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            String result = response.asString();
            Assert.assertEquals(result,"true");

            LOGGER.info(("killsession=" + response.asString()));

            //pluginLogin
            String urlpluginlogin = Utils.getUrl("pluginServiceLogin");
            Response responsepluginlogin =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userID", uidnan)
                            .header("authToken", authTokennan)
                            .param("token", authTokennan)
                            .param("spacekey", spaceKey)
                            .param("consumerName", Utils.getproperty("consumerNameLogin"))
                            .param("serviceName", Utils.getproperty("serviceNameLogin"))
                            .when()
                            .post(urlpluginlogin)
                            .then()
                            .assertThat()
                            .statusCode(304).extract().response();
        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    //************************Server Monitoring*******************//

    @Test(description = "getMonitorDataNode")
    public static void getMonitorDataNode1() {
        try {

            getMonitorData(spaceKey, uid, authToken, "node1");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getMonitorDataNode")
    public static void getMonitorDataNode2() {
        try {
            Thread.sleep(4000);
            getMonitorData(spaceKey, uid, authToken, "node2");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getMonitorDataNode")
    public static void getMonitorDataNode3() {
        try {

            Thread.sleep(4000);
            getMonitorData(spaceKey, uid, authToken, "node3");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getMonitorDataNode")
    public static void getMonitorDataNode4() {
        try {
            Thread.sleep(4000);
            getMonitorData(spaceKey, uid, authToken, "node4");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getMonitorDataNode")
    public static void getMonitorDataNode5() {
        try {
            Thread.sleep(4000);
            getMonitorData(spaceKey, uid, authToken, "node5");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getMonitorDataNode")
    public static void getMonitorDataNode6() {
        try {
            Thread.sleep(4000);
            getMonitorData(spaceKey, uid, authToken, "node6");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getMonitorDataNode")
    public static void getMonitorDataNode7() {
        try {
            Thread.sleep(4000);
            getMonitorData(spaceKey, uid, authToken, "node7");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getMonitorDataNode")
    public static void getMonitorDataNode8() {
        try {
            Thread.sleep(4000);
            getMonitorData(spaceKey, uid, authToken, "node8");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }



}