package com.bdbizviz.restassured.platform.SecurityCheck;

/*import com.bdbizviz.restassured.platform.Admininstration.AdminHelper;*/
import com.bdbizviz.restassured.platform.Admininstration.AdminHelper;
import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.User;
import com.bdbizviz.restassured.platform.Util.Utils;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.logging.Logger;

import static io.restassured.RestAssured.given;

public class AdminSecurityCheck extends AdminHelper {
    private static final Logger LOGGER = Logger.getLogger(AdminSecurityCheck.class.getName());
    public static User usernan;
    public static User usernanauth;
    public static String authTokennan;
    public static String uidnan;
    public static String spaceKeynan;

    //users used foor kill session
    public static String uidcreate;
    public static String authTokencreate;
    public static User usercreate;
    public static User userauthcreate;

    String commitCode = "";
    String hhcommitCode = "";

    @BeforeClass
    public void setupAdmin(){
        //Craete a new user
        createnewuserFunctional(spaceKeyadmin,uidadmin,authTokenadmin,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authTokenadmin,spaceKey, HttpStatus.SC_OK);

        //User which is not assigned to any group for security check
        usernan=Helper.getCustomerKey(emailidcreatefun,space_admin);
        usernanauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
        spaceKeynan = useradmin.getSpacekey();
        authTokennan=usernanauth.getAuthToken();
        uidnan=usernan.getId();
    }

    @Test(description = "editEmailConfSettings")
    public static void editEmailconfSettingsNeg() {
        try {
            editEmailConfSettings(uidnan, authTokennan,spaceKeynan, HttpStatus.SC_USE_PROXY);
            LOGGER.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getEmailConfSettings")
    public static void getEmailconfSettingsNeg() {
        try {
            getEmailConfSettings(uidnan, authTokennan,spaceKeynan, HttpStatus.SC_USE_PROXY);

            LOGGER.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getPasswordStrategySettingsDetails")
    public static void getpasswordStrategySettingsDetailsNeg() {
        try {
            getPasswordStrategySettingsDetails(uidnan, authTokennan,spaceKeynan, HttpStatus.SC_USE_PROXY);

            LOGGER.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "editPasswordStrategySettings")
    public static void editpasswordStrategySettingsNeg() {
        try {
            String dataStr = "{\"id\":\"\",\"type\":6,\"status\":\"1\",\"settings\":\"{\\\"id\\\":\\\"\\\",\\\"updatedDate\\\":\\\"\\\",\\\"passwordExpiry\\\":\\\"10\\\"," + "\\\"passwordStrength\\\":\\\"8\\\",\\\"passwordReuse\\\":\\\"1\\\",\\\"noOfUserLoginFail\\\":\\\"3\\\",\\\"createdBy\\\":null,\\\"spaceKeynan\\\":\\\""+spaceKeynan+"\\\"}\",\"spaceKeynan\":\""+spaceKeynan+"\"}";
            editPasswordStrategySettings(dataStr,uidnan, authTokennan,spaceKeynan, HttpStatus.SC_USE_PROXY);

            LOGGER.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "validatePasswordStrategySettings")
    public  void validatePasswordStrategySettingsNeg() {
        try {
            //Edit password Settings
            String dataStr = "{\"id\":\"\",\"type\":6,\"status\":\"1\",\"settings\":\"{\\\"id\\\":\\\"\\\",\\\"updatedDate\\\":\\\"\\\",\\\"passwordExpiry\\\":\\\"10\\\"," + "\\\"passwordStrength\\\":\\\"8\\\",\\\"passwordReuse\\\":\\\"1\\\",\\\"noOfUserLoginFail\\\":\\\"2\\\",\\\"createdBy\\\":null,\\\"spaceKeynan\\\":\\\""+spaceKeynan+"\\\"}\",\"spaceKeynan\":\""+spaceKeynan+"\"}";
            editPasswordStrategySettings(dataStr,uidnan, authTokennan,spaceKeynan, HttpStatus.SC_USE_PROXY);

            //Creating User
            createnewuserFunctional(spaceKeynan,uidnan,authTokennan,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            //Assigning in group
            createnewGroupPerm(spaceKeynan,uidnan,authTokennan,Groupnameuser+Helper.generateRandomString(),newuseridfunuser,HttpStatus.SC_USE_PROXY);
            LOGGER.info("NEWCREATEGRPID==" + newuseridfunuser);


            //Login with new user passing in valid password
            User usernew = Helper.getCustomerKey(emailidcreatefun,space_admin);
            User userobjauthnew = Helper.getAuthToken(emailidcreatefun,passworduser_admin, space_admin);
            String authnew =  null;
            authnew= userobjauthnew.getAuthToken();
            String idnew = null;
            idnew = usernew.getId();

            System.out.println("authnew:" + authnew);
            LOGGER.info("idnew:" + idnew);

            //Login with the same user 2nd time passing in valid password
            User usernew_sec = Helper.getCustomerKey(emailidcreatefun,space_admin);
            User userobjauthnew_sec = Helper.getAuthToken(emailidcreatefun,passworduser_admin, space_admin);
            String authnew_sec = userobjauthnew_sec.getAuthToken();
            String idnew_sec = usernew.getId();


            System.out.println("authnew_sec:" + authnew_sec);
            LOGGER.info("idnew_sec:" + idnew_sec);

            //Assertion
            Assert.assertEquals(idnew, idnew_sec);

            LOGGER.info("Successfull execution");


        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "editAuditTrailSettings")
    public static void editauditTrailSettingsNeg() {
        try {
            String dataStr = "\"id\":\"\",\"type\":1,\"status\":1,\"settings\":\"{\\\"configurationSettings\\\":\\\"1\\\",\\\"atHost\\\":\\\"\\\",\\\"atPort\\\":\\\"\\\",\\\"atPassword\\\":\\\"\\\",\\\"atUserName\\\":\\\"\\\",\\\"atDBName\\\":\\\"\\\",\\\"atDBType\\\":\\\"\\\",\\\"status\\\":\\\"1\\\",\\\"infoStatus\\\":\\\"1\\\",\\\"debugstatus\\\":\\\"2\\\",\\\"errorstatus\\\":\\\"2\\\",\\\"timeZone\\\":\\\"\\\"}\",\"spaceKeynan\":\""+spaceKeynan+"\"}";
            editAuditTrailSettings(dataStr,uidnan, authTokennan,spaceKeynan, HttpStatus.SC_USE_PROXY);

            LOGGER.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getAuditTrailSettings")
    public static void getauditTrailSettingsNeg() {
        try {
            String dataStr = "{\"type\":1,\"status\":1,\"spaceKeynan\":"+spaceKeynan+",\"settings\":\"{}\"}";
            getAuditTrailSettings(dataStr,uidnan, authTokennan,spaceKeynan, HttpStatus.SC_USE_PROXY);

            LOGGER.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "Get all Users")
    public void getallUsersNeg() {
        try {
            getAllUsers(spaceKeynan,uidnan,authTokennan, HttpStatus.SC_USE_PROXY);

            LOGGER.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "get the audit log")
    public static void getauditInformationNeg() {
        try {
            getAuditInformation(uidnan, authTokennan,spaceKeynan,HttpStatus.SC_USE_PROXY);

            LOGGER.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "editCustomFieldSettings")
    public static void editcustomFieldSettingsNeg() {
        try {

            String dataStr = "{\"id\":\"\",\"type\":101,\"status\":1,\"settings\":\"{\\\"customproperties\\\":\\\"[{\\\\\\\"key\\\\\\\":\\\\\\\"manager\\\\\\\",\\\\\\\"description\\\\\\\":\\\\\\\"manager\\\\\\\",\\\\\\\"inputtype\\\\\\\":\\\\\\\"manual\\\\\\\",\\\\\\\"mandatory\\\\\\\":\\\\\\\"yes\\\\\\\"}]\\\"}\",\"spaceKeynan\":\""+spaceKeynan+"\"}";
            editCustomFieldSettings(dataStr,uidnan, authTokennan,spaceKeynan, HttpStatus.SC_USE_PROXY);

            LOGGER.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getcustomFieldSettings")
    public static void getCustomFieldSettingsNeg() {
        try {
            String dataStr = "{\"id\":\"\",\"type\":\"101\",\"status\":1,\"settings\":\"\",\"spaceKey\":\""+spaceKeynan+"\"}";
            getCustomFieldSettings(uidnan, authTokennan,spaceKeynan,dataStr,HttpStatus.SC_OK);

            LOGGER.info("Successfull execution");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "SaveOrUpdateDataManagementSettings")
    public static void saveorUpdateDataManagementSettingsNeg() {
        try {

            //***Data Service edit*****//
            String dataService = "{\"type\":10,\"status\":1,\"spaceKeynan\":\""+spaceKeynan+"\",\"settings\":\"{\\\"mysql\\\":8000,\\\"mssql\\\":8000,\\\"oracle\\\":6000,\\\"hive\\\":6000,\\\"hana\\\":6000,\\\"cassandra\\\":6000,\\\"odata\\\":6000,\\\"sparksql\\\":7000,\\\"file\\\":6000,\\\"redshift\\\":6000,\\\"cassandranative\\\":7000}\"}";

            saveOrUpdateDataManagementSettings(uidnan, authTokennan,spaceKeynan,dataService, HttpStatus.SC_USE_PROXY);

            LOGGER.info("Successfull execution");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "getDataManagementDetails")
    public static void getdataManagementDetailsNeg() {
        try {
            String dataStr = "{\"createdDate\":null,\"isActive\":0,\"lastUpdatedDate\":null,\"reserv1\":null,\"reserv2\":null,\"reserv3\":null,\"reserv4\":null,\"reserv5\":null,\"id\":null,\"status\":1,\"type\":10,\"spaceKeynan\":\""+spaceKeynan+"\",\"settings\":\"\"}";
            getDataManagementDetails(uidnan, authTokennan,spaceKeynan,dataStr, HttpStatus.SC_USE_PROXY);

            LOGGER.info("Successfull execution");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Test(description = "getPredictiveSettings")
    public static void getPredictiveSettingsNeg() {
        try {
            String dataStr = "{\"id\":null,\"type\":12,\"status\":1,\"settings\":\"\",\"spaceKeynan\":\"1111\"}";
            getPredictiveSettings(uidnan, authTokennan,spaceKeynan,dataStr, HttpStatus.SC_USE_PROXY);

            LOGGER.info("Successfull execution");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "getWinADConfSettings")
    public static void getWinADConfSettingsNeg() {
        try {
            String dataStr = "{\"id\":null,\"type\":4,\"status\":1,\"settings\":\"\",\"spaceKeynan\":\""+spaceKeynan+"\"}";
            getWinADConfSettings(uidnan, authTokennan,spaceKeynan,dataStr, HttpStatus.SC_USE_PROXY);

            LOGGER.info("Successfull execution");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "getAllGeoSpatialSettingsAdmin")
    public static void getAllGeoSpatialSettingsAdminNeg() {
        try {
            getAllGeoSpatialSettingsAdmin(uidnan, authTokennan,spaceKeynan, HttpStatus.SC_USE_PROXY);

            LOGGER.info("Successfull execution");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "getAllGeoShapeDatas")
    public static void getAllGeoShapeDatasNeg() {
        try {
            String geometryType = "Polygon";
            getAllGeoShapeDatas(geometryType,uidnan, authTokennan,spaceKeynan, HttpStatus.SC_USE_PROXY);

            LOGGER.info("Successfull execution");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Test(description = "encryption")
    public static void encryptionNeg() {
        try {
            getActiveUsers(uidnan, authTokennan,spaceKeynan, HttpStatus.SC_USE_PROXY);
            LOGGER.info("Successfull execution");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "killsession workflow from login ,killing that login user session and using its data in other service")
    public  void killSessionFlowNeg() {
        try {
            createnewuserFunctional(spaceKeynan, uidnan, authTokennan, uniqueid+Helper.generateRandomString(), usrname, fulnme, pass_admin, "", authTokennan, spaceKeynan,HttpStatus.SC_USE_PROXY);

            usercreate = Helper.getCustomerKey(emailidcreatefun, space_admin);
            userauthcreate = Helper.getAuthToken(emailidcreate, pass_admin, space_admin);
            authTokencreate = userauthcreate.getAuthToken();
            uidcreate = usercreate.getId();

            //kill session data
            String url = Utils.getUrl("killsession");
            Response response =
                    given()
                            //Header
                            .header("spaceKeynan", spaceKeynan)
                            .header("userID", uidnan)
                            .header("authTokennan", authTokennan)
                            .param("token", authTokennan)
                            .param("spaceKeynan", spaceKeynan)
                            .param("userid", uidnan)
                            .param("data", "[" + uidcreate + "]")
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_NOT_MODIFIED)
                            .extract().response();
            String result = response.asString();
            // Assert.assertEquals(result,"true");

            LOGGER.info(("killsession=" + response.asString()));

            //pluginLogin
            String urlpluginlogin = Utils.getUrl("pluginServiceLogin");
            Response responsepluginlogin =
                    given()
                            .header("spaceKeynan", spaceKeynan)
                            .header("userID", uidcreate)
                            .header("authTokennan", authTokencreate)
                            .param("token", authTokencreate)
                            .param("spaceKeynan", spaceKeynan)
                            .param("consumerName", Utils.getproperty("consumerNameLogin"))
                            .param("serviceName", Utils.getproperty("serviceNameLogin"))
                            .when()
                            .post(urlpluginlogin)
                            .then()
                            .assertThat()
                            .statusCode(304).extract().response();

            LOGGER.info("Successfull execution");
        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    //************************Server Monitoring*******************//

     @Test(description = "getMonitorDataNode")
    public static void getMonitorDataNodeNeg() {
        try {

            JSONObject actualjson = Utils.getJson("/home/bizviz/Downloads/restassured_User/src/main/resources/Nodes_No.json");
            JSONArray userArray = (JSONArray) actualjson.get("nodes");
            for (Object number : userArray) {
                JSONObject jsonNumber = (JSONObject) number;
                String nodes = (String) jsonNumber.get("node");

                getMonitorData(spaceKeynan, uidnan, authTokennan, nodes);
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

}