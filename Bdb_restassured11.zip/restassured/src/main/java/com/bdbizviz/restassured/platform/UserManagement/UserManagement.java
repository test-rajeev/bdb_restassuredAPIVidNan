package com.bdbizviz.restassured.platform.UserManagement;

import com.bdbizviz.restassured.platform.Util.Helper;
import com.bdbizviz.restassured.platform.Util.User;
import com.bdbizviz.restassured.platform.Util.Utils;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;


public class UserManagement extends UserManagementHelper {

    public static final Logger LOGGER = Logger.getLogger(UserManagement.class.getName());

    @BeforeClass
    public static void setupUserMang() {
        prop = Utils.getProps();//Fetch all json data of properties json file and store in prop

        usrname = Utils.getproperty("userName");
        fulnme = Utils.getproperty("fullName");
        updateuserprofilename = Utils.getproperty("updateuserprofilename");
        projectpath = Utils.getUrl("projectpath");
        uniqueid = Utils.getproperty("uniqueid");
        passnew = Utils.getproperty("passnew");
        projectpath = Utils.getUrl("projectpath");
        updateusrname = Utils.getproperty("updateusrname");
        uniqueidupdate = Utils.getproperty("uniqueidupdate");
        uniqueid = Utils.getproperty("uniqueid");
        optypblock = Utils.getproperty("operationTypeblockuser");
        optypactivate = Utils.getproperty("operationTypeactivateuser");
        optypdel = Utils.getproperty("operationTypedeleteuser");
        optypreset = Utils.getproperty("operationTypereset");
        activefilter = Utils.getproperty("activefilter");
        blockfilter = Utils.getproperty("blockfilter");
        deletefilter = Utils.getproperty("deletefilter");
        urlgetlist = Utils.getUrl("getuserlist");

        urlgrpblock_activate = Utils.getUrl("block_delusergrp");
        urlgrpstatuslist = Utils.getUrl("getusergroupstatuslist");

        urlusergroupdetails = Utils.getUrl("getusergroupdetails");
        urlupdateusergroup = Utils.getUrl("updateusergroup");
        optypgrpblock = Utils.getproperty("operationTypeblockusergrp");
        optypgrpactivate = Utils.getproperty("operationTypeactivateusergrp");
        passchanged = Utils.getproperty("passchanged");

        emailid_admin=Utils.getproperty("admin");
        pass_admin= Utils.getproperty("passadmin");
        passworduser_admin= Utils.getproperty("passworduser_admin");
        space_admin=Utils.getproperty("spaceQAadmin");
        Groupnameuser = Utils.getproperty("Groupnameuser");

    }

//***********************************BAT TestCases******************************************//

    @Test(description = "login")
    public static void login() {

        try {
            //Admin user
            useradmin = Helper.getCustomerKey(emailid_admin,space_admin);
            userauthadmin = Helper.getAuthToken(emailid_admin,pass_admin, space_admin);
            spaceKeyadmin = useradmin.getSpacekey();
            uidadmin = user.getId();
            authTokenadmin = userauthadmin.getAuthToken();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createUser,Validation Level:Status code,Id not null,Success is true and Message")
    public void createUser() {

        try {
            createnewuser(spaceKeyadmin,uidadmin,authTokenadmin,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authTokenadmin,spaceKeyadmin);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getAllMenuContext,Validation Level:Status code,Success is true")
    public void getAllMenuContext() {

        try {
            getAllMenuContext(spaceKeyadmin,uidadmin,authTokenadmin);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createUserGroup,Validation Level:Status code,Success is true and Message")
    public void createUserGroup() {

        try {
            //******************Createnewusergroup**********************//
            createnewGroupPerm(spaceKeyadmin,uidadmin,authTokenadmin,Groupnameuser+Helper.generateRandomString(), newuseriduser,HttpStatus.SC_OK);
            LOGGER.info("NEWCREATEGRPID==" + newgroupid);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getuserlist,Validation Level:Status code,Success is true and Id not null")
    public void getuserlist() {
        try {
            getuserlist(spaceKeyadmin,uidadmin,authTokenadmin,Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authTokenadmin,spaceKeyadmin,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getusergrouplist,Validation Level:Status code,Success is true and Id not null")
    public void getusergrouplist() {
        try {
            getusergrouplist(spaceKeyadmin,uidadmin,authTokenadmin,Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authTokenadmin,spaceKeyadmin,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "deleteUser,Validation Level:Status code,Id not null,Success is true and Message")
    public void deleteUser() {

        try {
            deleteuser(spaceKeyadmin,uidadmin,authTokenadmin, newuseriduser,optypdel,authTokenadmin,spaceKeyadmin,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getuserlistDel,Validation Level:Status code,Id not null,Success is true and Message")
    public void getuserlistDel() {

        try {
            login();
            getuserlistDel(spaceKeyadmin,uidadmin,authTokenadmin,Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authTokenadmin,spaceKeyadmin,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

//***********************************Functional TestCases*************************************//

    @Test(description = "NonAdmin")
    public void nonAdminLogin() {

        try {
           /* user = Helper.getCustomerKey(emailidcreate,space_admin);
            userauth = Helper.getAuthToken(emailidcreate,pass_admin,space_admin);
            spaceKey = user.getSpacekey();
            uid = user.getId();
            authToken = userauth.getAuthToken();*/


            user = Helper.getCustomerKey(Utils.getproperty("nonAdmin"),space_admin);
            userauth = Helper.getAuthToken(Utils.getproperty("nonAdmin"),Utils.getproperty("passnonAdmin"),space_admin);
            spaceKey = user.getSpacekey();
            uid = user.getId();
            authToken = userauth.getAuthToken();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getUserInfoByToken,Validation Level:Status code,Success is true")
    public void getUserInfoByTokenTestCase() {
        try {
            getUserInfoByToken(authToken, HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "Complete workflow of creating new user,updating that user,blocking activating reseting password and finally deleting that same user and have many Validation along with" +
            " Validation Level:Status code,Success is true and Message")
    public void createToDeleteFlowUser() {
        try {
            Thread.sleep(2000);
            //Craete a new user
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            //Login with new user to check able to login with new user or not.
            User usernew = Helper.getCustomerKey(emailidcreatefun,space_admin);
            User userobjauthnew = Helper.getAuthToken(emailidcreatefun,pass_admin, space_admin);
            String authnew = userobjauthnew.getAuthToken();
            String idnew = usernew.getId();

            Assert.assertNotNull(authnew);
            Assert.assertNotNull(idnew);

            //Calling getUserInfoByToken,getMenuPermissionForUser,pluginServiceLogin to validate new user is logged in.
            getUserInfoByToken(authnew,HttpStatus.SC_OK);

            Assert.assertEquals(authnew.toString(),tokenval.toString());

            getMenuPermissionForUser(idnew,authnew);

            pluginServiceLogin(idnew,authnew,HttpStatus.SC_OK);

            //Update new user
            updateProfile(spaceKey,uid,authToken,emailidcreatefun,updateusrname,fulnme,null, newuseridfunuser,authToken,spaceKey,HttpStatus.SC_OK);

            //Blockuser function called and done validation that blocked user ispresent in blocked bucket
            blockuser(spaceKey,uid,authToken, newuseridfunuser,optypblock,authToken,spaceKey,HttpStatus.SC_OK);

            getuserlist(spaceKey,uid,authToken,Utils.getproperty("from"),Utils.getproperty("rows"),blockfilter,authToken,spaceKey,HttpStatus.SC_OK);

            //Validating status to check that created user is of blocked state
            Assert.assertEquals(status,"3");

            //Activateuser function called
            activateuser(spaceKey,uid,authToken, newuseridfunuser,optypactivate,authToken,spaceKey,HttpStatus.SC_OK);

            //Fetches the active userlist
            getuserlist(spaceKey,uid,authToken,Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authToken,spaceKey,HttpStatus.SC_OK);

            //Validating status to check that activated user is of active state
            Assert.assertEquals(status,optypactivate);

            //Reset Password function called
            resetpassword(spaceKey,uid,authToken, newuseridfunuser,optypreset,authToken,spaceKey,HttpStatus.SC_OK);

            User userreset = Helper.getCustomerKey(emailID,space_admin);
            String userauthreset=Helper.getAuthTokenReset(emailID,pass_admin,space_admin);

            //Validation of reset password that after reset the user is not able to login with old pass
            Assert.assertEquals(userauthreset,"false");

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

            getuserlist(spaceKey,uid,authToken,Utils.getproperty("from"),Utils.getproperty("rows"),deletefilter,authToken,spaceKey,HttpStatus.SC_OK);

            //Validating status to check that deleted user is of delete state
            Assert.assertEquals(status,"2");


        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    @Test(description = "getallusers,Validation Level:Status code,Success is true and Id not null")
    public void getallusers() {
        try {

            getallusers(spaceKey,uid,authToken,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Give the detail of particular user,detail of admin user and list of usergroups
    @Test(description = "getuserdetails,Validation Level:Status code,Success is true")
    public void getuserdetails() {
        try {
            getuserlist(spaceKey,uid,authToken,Utils.getproperty("from"),Utils.getproperty("rows"),blockfilter,authToken,spaceKey,HttpStatus.SC_OK);

            getuserdetails(spaceKey,uid,authToken,usrid,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //***********************************AllUserGroupServices*************************************//

    @Test(description = "UserGroup flow from create user,Createusergroup,assign user to usergroup, blockusergroup,activate and have many Validation along with" +
            " Validation Level:Status code,Success is true and Message")
    public  void userGroupFlow() {
        try {
            Thread.sleep(2000);

            //create a new user which is assigned to usergroup
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            //******************Createnewusergroup**********************//
            createnewGroupPerm(spaceKey,uid,authToken,Groupnameuser+Helper.generateRandomString(), newuseridfunuser,HttpStatus.SC_OK);
            LOGGER.info("NEWCREATEGRPID==" + newuseridfunuser);

            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //********************Fetching list of permissions assigned to automate user after updation of a group************//
            urlpermit = Utils.getUrl("getallchildpermission");

            Response responsepermit =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", uidautmate)
                            .header("authToken", authtokenautmate)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpermit)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> userspermit = from(responsepermit.asString()).get("");

            LOGGER.info(("getallchildpermsn=" + responsepermit.asString()));

            //******************Fetches all the usergroup list************//
            getusergrouplist(spaceKey,uid,authToken,Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authToken,spaceKey,HttpStatus.SC_OK);

            //******************Update the newly created user group***********//
            updateusergroup(spaceKey,uid,authToken,Utils.getproperty("GroupnameUpdate"),Utils.getproperty("User"), Utils.getproperty("Create User"),Utils.getproperty("View User Details"),newgroupid,authToken,spaceKey, newuseridfunuser,HttpStatus.SC_OK);

            getusergroupdetails(newgroupid,HttpStatus.SC_OK);

            Assert.assertEquals(statusdetialgroup,"1");

            //Login with User whom dataconn is shared
            userautmate=Helper.getCustomerKey(emailidcreatefun,space_admin);
            userautmateauth=Helper.getAuthToken(emailidcreatefun,pass_admin,space_admin);
            authtokenautmate=userautmateauth.getAuthToken();
            uidautmate=userautmate.getId();

            //********************Fetching list of permissions assigned to automate user after updation of a group************//
            Response responsepermitt =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", uidautmate)
                            .header("authToken", authtokenautmate)
                            .param("token", authtokenautmate)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlpermit)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> userspermitt = from(responsepermitt.asString()).get("");

            LOGGER.info(("getallchildpermsn=" + responsepermit.asString()));

            String permitjsonactuall="{\"permissions\":{\"excludePermissionsToGroupUtils\":[],\"permissionsList\":[{\"subMenu\":\"User Management\",\"permissionUrl\":\"getallusers;getallchildpermissions\",\"icon\":898305,\"description\":\"User Management\",\"menuName\":\"User\",\"permissionCategory\":\"USER_MODULE\",\"parentId\":0,\"url\":\"..\\/..\\/modules\\/user-mgmt\\/user-mgmt.html#\\/\",\"spaceKey\":\""+spaceKey+"\",\"name\":\"User\",\"nameId\":\"userManagement\",\"id\":159318016,\"pKey\":10001,\"remarks\":\"User Management\",\"menuDisplayType\":1,\"status\":1},{\"subMenu\":\"Create User\",\"permissionUrl\":\"createuser;getUserGroupStatusList\",\"description\":\"Create User\",\"menuName\":\"User Management\",\"permissionCategory\":\"USER_MODULE\",\"parentId\":159318016,\"url\":\"createuser\",\"spaceKey\":\""+spaceKey+"\",\"name\":\"Create User\",\"nameId\":\"\",\"id\":159318032,\"pKey\":10020,\"remarks\":\"Create User\",\"menuDisplayType\":2,\"status\":1},{\"subMenu\":\"Create UserGroup\",\"permissionUrl\":\"createusergroup\",\"description\":\"Create UserGroup\",\"menuName\":\"User Management\",\"permissionCategory\":\"USER_MODULE\",\"parentId\":159318016,\"url\":\"createusergroup\",\"spaceKey\":\""+spaceKey+"\",\"name\":\"Create UserGroup\",\"nameId\":\"\",\"id\":159318033,\"pKey\":10021,\"remarks\":\"Create UserGroup\",\"menuDisplayType\":2,\"status\":1},{\"subMenu\":\"View User Details \",\"permissionUrl\":\"getAllActiveUsers;getuserslist;getuserdetails;getCustomUserProperties\",\"description\":\"View User Details\",\"menuName\":\"User Management\",\"permissionCategory\":\"USER_MODULE\",\"parentId\":159318016,\"url\":\"getuserslist\",\"spaceKey\":\""+spaceKey+"\",\"name\":\"View User Details\",\"nameId\":\"\",\"id\":159318034,\"pKey\":10022,\"remarks\":\"View User Details\",\"menuDisplayType\":2,\"status\":1},{\"subMenu\":\"Activate\\/Block User\",\"permissionUrl\":\"activeBlockUserOperations\",\"description\":\"Activate\\/Block User\",\"menuName\":\"User Management\",\"permissionCategory\":\"USER_MODULE\",\"parentId\":159318016,\"url\":\"activeBlockUserOperations\",\"spaceKey\":\""+spaceKey+"\",\"name\":\"Activate\\/Block User\",\"nameId\":\"\",\"id\":159318035,\"pKey\":10023,\"remarks\":\"Activate\\/Block User\",\"menuDisplayType\":2,\"status\":1},{\"subMenu\":\"Change Password\",\"permissionUrl\":\"resetPassordUserOperations\",\"description\":\"Change Password\",\"menuName\":\"User Management\",\"permissionCategory\":\"USER_MODULE\",\"parentId\":159318016,\"url\":\"resetPassordUserOperations\",\"spaceKey\":\""+spaceKey+"\",\"name\":\"Change Password\",\"nameId\":\"\",\"id\":159318036,\"pKey\":10024,\"remarks\":\"Change Password\",\"menuDisplayType\":2,\"status\":1},{\"subMenu\":\"Remove User\",\"permissionUrl\":\"removeUserOperations\",\"description\":\"Remove User\",\"menuName\":\"User Management\",\"permissionCategory\":\"USER_MODULE\",\"parentId\":159318016,\"url\":\"removeUserOperations\",\"spaceKey\":\""+spaceKey+"\",\"name\":\"Remove User\",\"nameId\":\"\",\"id\":159318037,\"pKey\":10025,\"remarks\":\"Remove User\",\"menuDisplayType\":2,\"status\":1},{\"subMenu\":\"Edit User\",\"permissionUrl\":\"updateprofile;getUserGroupStatusList;getuserdetails\",\"description\":\"Edit User\",\"menuName\":\"User Management\",\"permissionCategory\":\"USER_MODULE\",\"parentId\":159318016,\"url\":\"updateprofile\",\"spaceKey\":\""+spaceKey+"\",\"name\":\"Edit User\",\"nameId\":\"\",\"id\":159318038,\"pKey\":10026,\"remarks\":\"Edit User\",\"menuDisplayType\":2,\"status\":1},{\"subMenu\":\"View UserGroup Details\",\"permissionUrl\":\"getusergroupslist;getCustomUserProperties;getusergroupdetails\",\"description\":\"View UserGroup Details\",\"menuName\":\"User Management\",\"permissionCategory\":\"USER_MODULE\",\"parentId\":159318016,\"url\":\"getusergroupslist;getusergroupdetails\",\"spaceKey\":\""+spaceKey+"\",\"name\":\"View UserGroup Details\",\"nameId\":\"\",\"id\":159318039,\"pKey\":10027,\"remarks\":\"View UserGroup Details\",\"menuDisplayType\":2,\"status\":1},{\"subMenu\":\"Activate\\/Block UserGroup\",\"permissionUrl\":\"usergroupoperations\",\"description\":\"Activate\\/Block UserGroup\",\"menuName\":\"User Management\",\"permissionCategory\":\"USER_MODULE\",\"parentId\":159318016,\"url\":\"usergroupoperations\",\"spaceKey\":\""+spaceKey+"\",\"name\":\"Activate\\/Block UserGroup\",\"nameId\":\"\",\"id\":159318040,\"pKey\":10028,\"remarks\":\"Activate\\/Block UserGroup\",\"menuDisplayType\":2,\"status\":1},{\"subMenu\":\"Edit UserGroup\",\"permissionUrl\":\"updateusergroupdetails;updateGroupUsersCustomfields;getusergroupdetails;getUserGroupStatusList\",\"description\":\"Edit UserGroup\",\"menuName\":\"User Management\",\"permissionCategory\":\"USER_MODULE\",\"parentId\":159318016,\"url\":\"updateusergroupdetails\",\"spaceKey\":\""+spaceKey+"\",\"name\":\"Edit UserGroup\",\"nameId\":\"\",\"id\":159318041,\"pKey\":10029,\"remarks\":\"Edit UserGroup\",\"menuDisplayType\":2,\"status\":1},{\"subMenu\":\"Assign Custom Field\",\"permissionUrl\":\"updateGroupUsersCustomfields;getCustomFieldSettings\",\"description\":\"Assign Custom Field\",\"menuName\":\"Assign Custom Field\",\"permissionCategory\":\"USER_MODULE\",\"parentId\":159318016,\"url\":\"updateGroupUsersCustomfields\",\"spaceKey\":\""+spaceKey+"\",\"name\":\"Assign Custom Field\",\"nameId\":\"\",\"id\":159318042,\"pKey\":100100,\"remarks\":\"Edit UserGroup\",\"menuDisplayType\":2,\"status\":1}],\"success\":true}}";

            //Conversion of Hashmap to json form
            JSONObject permitjsonexpectedd = new JSONObject();
            permitjsonexpectedd.putAll(userspermitt);

            //*********************Blocking the newely created user group********************//
            blockgroup(spaceKey,uid,authToken,newgroupid,optypgrpblock,authToken,spaceKey,HttpStatus.SC_OK);

            getusergroupdetails(newgroupid,HttpStatus.SC_OK);

            //Validate that newly created user group activated by checking status
            Assert.assertEquals(statusdetialgroup,"2");

            //  createnewuserFunctional(spaceKey,uidautmate,authtokenautmate,uniqueid+ Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authtokenautmate,spaceKey);

             // getuserlist(spaceKey,uidautmate,authtokenautmate, Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authtokenautmate,spaceKey,HttpStatus.SC_USE_PROXY);
             // getusergrouplist(spaceKey,uidautmate,authtokenautmate,Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authtokenautmate,spaceKey,HttpStatus.SC_USE_PROXY);

            //***********************Activate the same blocked group***************************//
            activategroup(spaceKey,uid,authToken,newgroupid,optypgrpactivate,authToken,spaceKey,HttpStatus.SC_OK);

            //**************************Fetches the list of all active user group********************//
            getusergroupdetails(newgroupid,HttpStatus.SC_OK);

            //Validate that newly created user group activated by checking status
            Assert.assertEquals(statusdetialgroup,"1");

            //  getusergrouplist(spaceKey,uidautmate,authtokenautmate,Utils.getproperty("from"),Utils.getproperty("rows"),activefilter,authtokenautmate,spaceKey,305);

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //While creating a new user this function is called which give the list of active groups
    @Test(description = "getusergroupstatuslist,Validation Level:Status code,Success is true")
    public static void getusergroupstatuslist() {
        try {
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", uid)
                            .header("authToken", authToken)
                            .param("page", Utils.getproperty("from"))
                            .param("status", Utils.getproperty("status"))
                            .param("rows", Utils.getproperty("rows"))
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgrpstatuslist)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> userGroups = from(response.asString()).get("userGroups");
            List<HashMap<String, Object>> userGroupsList = (ArrayList<HashMap<String, Object>>) userGroups.get("userGroupsList");

            activegrpid = userGroupsList.get(0).get("id").toString();
            status= userGroupsList.get(0).get("status").toString();

            Assert.assertEquals(userGroups.get("success").toString(),"true");
            LOGGER.info(("getusrgrpstatuslist=" + response.asString()));
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getmyallprofiledetails,Validation Level:Status code,Success is true and FullName")
    public void getMyAllProfileDetails() {
        try {
            String url = Utils.getUrl("getmyallprofiledetails");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", uid)
                            .header("authToken", authToken)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            HashMap<String, Object> user = (HashMap<String, Object>) users.get("user");

            fullname = (String) user.get("fullName");
            success = users.get("success").toString();

            Assert.assertEquals( success,"true");

            LOGGER.info(("getmyallprofiledetails=" + response.asString()));
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "updateuserprofileinfo,create new user->login with it->update some info,Validation Level:Status code,Success is true and Msg")
    public void updateUserProfileInfo() {
        try {
            Thread.sleep(1000);
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            //Login with new user to check able to login with new user or not.
            User userNew = Helper.getCustomerKey(emailidcreatefun,space_admin);
            User userobjAuthnew = Helper.getAuthToken(emailidcreatefun,pass_admin, space_admin);
            String authntokenew = userobjAuthnew.getAuthToken();
            String uidnew = userNew.getId();

            String url = Utils.getUrl("updateuserprofileinfo");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", uidnew)
                            .header("authToken", authntokenew)
                            .param("fullName", updateuserprofilename)
                            .param("address", "Banglore")
                            .param("mobileNumber", "75643092983")
                            .param("landNumber", "32232423422")
                            .param("token", authntokenew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            success = users.get("success").toString();
            String msg = (String) users.get("message");

            Assert.assertEquals(msg,"User information updated successfully!!!");
            Assert.assertEquals(success,"true");

            LOGGER.info(("updateuserprofileinfo=" + response.asString()));

            //Delete user function called to delete the created user
            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getuserpreferencesbyid,Validation Level:Status code,Success is true")
    public void getUserPreferencesById() {
        try {
            String url = Utils.getUrl("getuserpreferencesbyid");
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> allpref = from(response.asString()).get("");
            HashMap<String, Object> users = (HashMap<String, Object>) allpref.get("users");
            HashMap<String, Object> preference = (HashMap<String, Object>) users.get("preference");
//            pref = preference.get("id");
            // LOGGER.info("pref===" + pref);

            success = users.get("success").toString();

            Assert.assertEquals(success,"true");

            LOGGER.info(("getuserpreferencesbyid=" + response.asString()));
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getthemes,Validation Level:Status code,Success is true")
    public void getThemes() {
        try {
            String url = Utils.getUrl("getthemes");
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .param("id", "")
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> themesall = from(response.asString()).get("");
            HashMap<String, Object> users = (HashMap<String, Object>) themesall.get("users");
            List<HashMap<String, Object>> themes = (ArrayList<HashMap<String, Object>>) users.get("allThemes");

            theme = themes.get(1).get("id");
            success = users.get("success").toString();

            //Conversion of Hashmap to json form
            JSONObject menuobjjson = new JSONObject();
            menuobjjson.putAll(themesall);
            Assert.assertEquals(success,"true");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "updateuserpreference,Validation Level:Status code,Success is true and Msg")
    public void updateUserPreference() {
        try {
            String url = Utils.getUrl("updateuserpreference");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", uid)
                            .header("authToken", authToken)
                            .param("themeID", theme)
                            .param("treeID", Utils.getproperty("from"))
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> usersall = from(response.asString()).get("");
            HashMap<String, Object> users = (HashMap)usersall.get("users");
            success = users.get("success").toString();
            String msg = users.get("message").toString();
            //  String expecteddata="{\"users\":{\"message\":\"Preferences updated successfully!\",\"success\":true,\"status\":0,\"themeID\":{\"id\":169803776,\"title\":\"Default Theme\",\"headerBGColor\":\"#535454\",\"headerTextAndIconColor\":\"Rgba(255, 255, 255, 0.8)\",\"headerTextAndIconHoverColor\":\"#f6f6f6\",\"headerTextAndIconBGHoverColor\":\"#f6f6f6\",\"navBarBGColor\":\"#a9a9a9\",\"navBarTextAndIconColor\":\"#777\",\"navBarTextAndIconHoverColor\":\"#f6f6f6\",\"navBarTextAndIconBGHoverColor\":\"Rgba(0, 0, 0, 0.1)\",\"menuPanelBGColor\":\"#a9a9a9\",\"menuPanelTextAndIconColor\":\"#555555\",\"menuPanelTextAndIconHoverColor\":\"#222\",\"menuPanelTextAndIconBGHoverColor\":\"#f9f9f9\",\"contextMenuBGColor\":\"#ffffff\",\"contextMenuTextAndIconColor\":\"#444444\",\"contextMenuTextAndIconHoverColor\":\"#f9f9f9\",\"contextMenuTextAndIconBGHoverColor\":\"#3c8dbc\",\"treeSlideBarColor\":\"5px solid rgba(192,192,192,1)\",\"folderTextColor\":\"#000000\",\"spaceKey\":\""+spaceKey+"\",\"status\":0,\"createdBy\":169672704},\"users\":[],\"permissions\":[],\"spaces\":[],\"allUserGroups\":[],\"assignedUserGroups\":[],\"allThemes\":[],\"trees\":[],\"apiToken\":false}}";

            // Assert.assertEquals(usersall.toString(),expecteddata);
            Assert.assertEquals( msg,"Preferences updated successfully!");
            Assert.assertEquals(success,"true");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "setPasswordExpiry,Validation Level:Status code,Success is true,Msg and Json Comparision")
    public void setPasswordExpiry() {
        try {
            String url = Utils.getUrl("setPasswordExpiry");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", uid)
                            .header("authToken", authToken)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .param("userid", uid)
                            .param("expirystate", 1)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> all = from(response.asString()).get("");
            HashMap<String, Object> users = (HashMap<String,Object>)all.get("users");
            HashMap<String, Object> user = (HashMap<String,Object>)users.get("user");

            success = users.get("success").toString();
            String msg = (String) users.get("message");

            Assert.assertEquals(msg,"User updated successfully!");
            Assert.assertEquals(success,"true");

            LOGGER.info(("setPasswordExpiry=" + response.asString()));

            String actualjson="{users={allUserGroups=[], assignedUserGroups=[], apiToken=false, allThemes=[], success=true, permissions=[], spaces=[], message=User updated successfully!, user={expiryState=1}, trees=[], users=[], status=0}}";
            Assert.assertEquals(all.toString(),actualjson);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "changepassword,created new user->changed its password->loggedin with changed password->deleted user validation along with Validation Level:Status code,Success is true,Msg ")
    public void changePasswordFlow() {
        try {
            Thread.sleep(2000);
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            String url = Utils.getUrl("changepassword");
            Response response =
                    given()
                            //Header
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .param("userID", newuseridfunuser)
                            .param("newPassword", "BizViz@1234567")
                            .param("oldPassword", pass_admin)
                            .param("projectPath", projectpath)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");

            Assert.assertEquals(users.get("message"),"Updated new password successfully!");
            Assert.assertEquals(users.get("success").toString(),"true");

            LOGGER.info(("changepassword=" + response.asString()));

            userpasschange = Helper.getCustomerKey(emailidcreatefun,space_admin);
            userauthpasschange = Helper.getAuthToken(emailidcreatefun, passchanged, space_admin);
            spaceKeypasschange = userpasschange.getSpacekey();
            uidpasschange = userpasschange.getId();
            authTokenpasschange = userauthpasschange.getAuthToken();

            getUserInfoByToken(authTokenpasschange,HttpStatus.SC_OK);

            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Contain user Custom Field Details.
    @Test(description = "getUserPropsByToken,Validation Level:Status code,Success is true")
    public void getUserPropsByToken() {
        try {
            login();
            String url = Utils.getUrl("getUserPropsByToken");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", uidadmin)
                            .header("authToken", authTokenadmin)
                            .param("token", authTokenadmin)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");

            Assert.assertEquals(users.get("success").toString(),"true");

            LOGGER.info(("getUserPropsByToken=" + response.asString()));
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "createApiToken,Validation Level:Status code,Success is true,Msg,Token not null and called getUserInfoByToken service to validate token")
    public void createApiTokenFlow() {
        try {
            String url = Utils.getUrl("createApiToken");
            Response response =
                    given()
                            .header("spaceKey", spaceKey)
                            .header("userid", uid)
                            .header("authToken", authToken)
                            .param("generateAPITokenType", Utils.getproperty("createapitoken"))
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            String msg = (String) users.get("message");
            String token=users.get("apitoken").toString();

            Assert.assertEquals( msg,"API Token created successfully!!!");
            Assert.assertEquals( users.get("success").toString(),"true");
            Assert.assertNotNull(token);

            getUserInfoByToken(authToken,HttpStatus.SC_OK);
            Assert.assertEquals(apitoken.toString(),token.toString());

            LOGGER.info(("createApiToken=" + response.asString()));

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "getApiandMobileTokenDetails,Validation Level:Status code,Success is true")
    public void getApiandMobileTokenDetails() {
        try {
            String url = Utils.getUrl("getapiandmobiletokendetails");
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", uid)
                            .header("authtoken", authToken)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(url)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> users = from(response.asString()).get("users");
            success = users.get("success").toString();
            Assert.assertEquals(success,"true");

            LOGGER.info(("getapiandmobiletokendetails=" + response.asString()));
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "saveOrUpdateEmailConfSettings,Validation Level:Status code,Success is true")
    public static void saveOrUpdateEmailConfSettings() {
        try {
            saveOrUpdateEmailConfSettings(spaceKey, uid, authToken,HttpStatus.SC_OK);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Test(description = "forgetpasswordresetlink,Validation Level:Status code,Success is true and Msg")
    public void forgetPasswordResetLink() {
        try {
            Thread.sleep(2000);
            createnewuserFunctional(spaceKey,uid,authToken,uniqueid+Helper.generateRandomString(),usrname,fulnme,pass_admin,"",authToken,spaceKey,HttpStatus.SC_OK);

            forgetPasswordResetLink(emailidcreatefun,spaceKey,HttpStatus.SC_OK);

            deleteuser(spaceKey,uid,authToken, newuseridfunuser,optypdel,authToken,spaceKey,HttpStatus.SC_OK);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
