package com.bdbizviz.restassured.platform.Admininstration;

import com.bdbizviz.restassured.platform.UserManagement.UserManagementHelper;
import com.bdbizviz.restassured.platform.Util.User;
import com.bdbizviz.restassured.platform.Util.Utils;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.net.URI;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static io.restassured.RestAssured.given;
import static io.restassured.path.json.JsonPath.from;

/**
 * Created by bizviz on 8/2/18.
 */
public class AdminHelper extends UserManagementHelper {
    public static final Logger LOGGER = Logger.getLogger(AdminHelper.class.getName());
    public static JSONObject prop;
    public static User usernan;
    public static User usernanauth;
    public static String authTokennan;
    public static String uidnan;
    public static String isSecure;
    public static String consumerName;
    public static String serviceNameGet;
    public static String serviceNameSave;
    public static String urlgetEmailConfSettings;
    public static String urlsaveOrUpdateEmailConfSettings;
    public static String urlgetPasswordStrategySettingsDetails;
    public static Object settings;
    public static String urlsaveOrUpdatePasswordSettings;
    public static String urlsaveOrUpdateCustomFieldsettings;
    public static String urlgetAuditTrailSettings;
    public static String urlsaveOrUpdateAuditTrailSettings;
    public static String urlgetAuditInformation;
    public static String urlCustomFieldSettings;
    public static String urlsaveOrUpdateDatamanagmentConfSettings;
    public static String urlgetDatamanagmentConfSettings;
    public static String urlpluginService;
    public static String urlgetWinADConfSettings;
    public static String urlgetAdUserGroups;
    public static String employeesGrpName;
    public static String urlgetWinADAttributes;
    public static String urlgetActiveUsers;
    public static String urlgetCustomFieldSettings;
    public static String urlgetAllGeoSpatialSettings;
    public static Integer google_id;
    public static Integer leaflet_id;
    public static String urlgetAllGeoShapeDatas;
    private static String geoShapeId;


    // @Test(description = "get the email server config details")@SuppressWarnings("unchecked")
    public static void editEmailConfSettings(String userId, String authToken, String spaceKey,int statusCode) {
        try {
            urlsaveOrUpdateEmailConfSettings = Utils.getUrl("saveOrUpdateEmailConfSettings");
            String dataStr = "{\"id\":\"\",\"type\":3,\"status\":1,\"settings\":\"{\\\"id\\\":\\\"\\\",\\\"enableTLS\\\":\\\"true\\\",\\\"enableSSL\\\":\\\"\\\",\\\"updatedDate\\\":\\\"\\\",\\\"spaceKey\\\":\\\""+spaceKey+"\\\",\\\"userID\\\":\\\"\\\",\\\"emailHost\\\":\\\"smtp.emailsrvr.com\\\",\\\"emailPort\\\":\\\"25\\\",\\\"emailUserName\\\":\\\"projectadmin@bdbizviz.com\\\",\\\"encryptnType\\\":\\\"tls\\\",\\\"emailPassword\\\":\\\"bizviz@12\\\",\\\"emailFrom\\\":\\\"projectadmin@bdbizviz.com\\\"}\",\"spaceKey\":\""+spaceKey+"\"}";
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            .param("consumerName", Utils.getproperty("consumerName").toString())
                            .param("serviceName", Utils.getproperty("serviceNameSave").toString())
                            .param("data", dataStr)
                            .param("isSecure", isSecure)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveOrUpdateEmailConfSettings)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK){
                HashMap<String, Object> responseMap = from(response.asString()).get("");
                String success = responseMap.get("success").toString();
                LOGGER.info(("responseMap:" + responseMap.toString()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // @Test(description = "get the email server config details")@SuppressWarnings("unchecked")
    public static void getEmailConfSettings(String userId, String authToken, String spaceKey,int statusCode) {
        try {
            urlgetEmailConfSettings = Utils.getUrl("getEmailConfSettings");
            String dataStr = "{\"id\":\"\",\"type\":\"3\",\"status\":1,\"spaceKey\":\""+spaceKey+"\",\"settings\":\"\"}";
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            .param("consumerName", consumerName)
                            .param("serviceName",serviceNameGet)
                            .param("data", dataStr)
                            .param("isSecure", isSecure)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetEmailConfSettings)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode==HttpStatus.SC_OK){
                HashMap<String, Object> responseMap = from(response.asString()).get("");
                String success = responseMap.get("success").toString();
                LOGGER.info(("responseMap:" + responseMap.toString()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Get password Strategy settings
    public static void getPasswordStrategySettingsDetails(String userId, String authToken, String spaceKey,int statusCode) {
        try {
            urlgetPasswordStrategySettingsDetails = Utils.getUrl("getpasswordstrategysettingsdetails");

            String dataStr = "{\"id\":\"\",\"type\":6,\"status\":1,\"settings\":\"\",\"spaceKey\":\""+spaceKey+"\"}";
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", userId)
                            .header("authtoken", authToken)
                            .param("consumerName", consumerName)
                            .param("serviceName", serviceNameGet)
                            .param("data", dataStr)
                            .param("isSecure", "true")
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetPasswordStrategySettingsDetails)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> resp_pwdSettings = from(response.asString()).get("");
                List<HashMap<String, Object>> settings_List = (ArrayList<HashMap<String, Object>>) resp_pwdSettings.get("settings");
                String success = resp_pwdSettings.get("success").toString();
                LOGGER.info(("response:" + resp_pwdSettings.toString()));
                for (HashMap<String, Object> settingsObj : settings_List) {
                    if (settingsObj.containsKey("settings")) ;
                    settings = settingsObj.get("settings");

                    LOGGER.info(("settings:" + settings_List.toString()));

                    //****To assert checking the success***//
                    Assert.assertEquals(success, "true");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    // Ecit Password Strategy settings
    public static void editPasswordStrategySettings(String dataStr, String userId, String authToken, String spaceKey,int statusCode) {
        try {
            urlsaveOrUpdatePasswordSettings = Utils.getUrl("saveOrUpdatePasswordPerferenceSettings");
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userid", userId)
                            .header("authtoken", authToken)
                            //params
                            .param("consumerName", consumerName)
                            .param("serviceName", serviceNameSave)
                            .param("data", dataStr)
                            .param("isSecure", isSecure)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveOrUpdatePasswordSettings)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK){
                HashMap<String, Object> resp = from(response.asString()).get("");
                Integer id = (Integer) resp.get("id");
                LOGGER.info(("resp:" + resp.toString()));

                //****To assert checking the ID is not null***//
                Assert.assertNotNull(id);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

   //edit the audit trail settings
    public static void editAuditTrailSettings(String dataStr, String userId, String authToken, String spaceKey,int statusCode) {
        try {
            urlsaveOrUpdateAuditTrailSettings = Utils.getUrl("saveOrUpdateAuditTrailSettings");
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            .param("consumerName", consumerName)
                            .param("serviceName", serviceNameSave)
                            .param("data", dataStr)
                            .param("isSecure", isSecure)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveOrUpdateAuditTrailSettings)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String, Object> resp_Audit = from(response.asString()).get("");
            LOGGER.info(("resp:" + resp_Audit.toString()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Audit Trail Settings
    public static void getAuditTrailSettings(String dataStr, String userId, String authToken, String spaceKey,int statusCode) {
        try {
            urlgetAuditTrailSettings = (Utils.getUrl("getAuditTrailSettings"));

            Response response =
                    given()
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            .header("spacekey", spaceKey)
                            .param("consumerName",Utils.getproperty("consumerName").toString())
                            .param("serviceName", Utils.getproperty("serviceNameGet").toString())
                            .param("data", dataStr)
                            .param("isSecure", isSecure)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetAuditTrailSettings)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if (statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> resp_Audit = from(response.asString()).get("");
                LOGGER.info(("resp:" + resp_Audit.toString()));

                //Asserions
                Assert.assertEquals(resp_Audit.get("success"), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Admin.java module2
    public static void getAllUsers(String spaceKey,String uidnew, String authtoknew, int statusCode) {
        try {
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(uidnew))
                            .header("authtoken", authtoknew)
                            //params
                            .param("isSecure", isSecure)
                            .param("token", authtoknew)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getallusers"))
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> resp = from(response.asString()).get("userGroups");

                //Asserts
                Assert.assertEquals(resp.get("success"), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Get the Audit log
    public static void getAuditInformation(String userId, String authToken, String spaceKey, int statusCode) {
        try {
            urlgetAuditInformation = Utils.getUrl("getAuditInformation");
            Date dt = new Date();
            Long didtime =  dt.getTime();
            Response response =
                    given() //headers
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            .header("spacekey", spaceKey)
                            //params
                            .param("user", Integer.valueOf(uid))
                            .param("fromDate", didtime)
                            .param("toDate", didtime)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetAuditInformation)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if (statusCode == HttpStatus.SC_OK) {
                List<HashMap<String, Object>> resp_Audit = (ArrayList<HashMap<String, Object>>)from(response.asString()).get("");
                for ( HashMap resp_AuditObj:resp_Audit) {
                    String success = resp_AuditObj.get("success").toString();

                    Assert.assertEquals(success, "true");
                }

                LOGGER.info(("resp:" + resp_Audit.toString()));


            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Edit CustomField Settings
    public static void editCustomFieldSettings(String dataStr, String userId, String authToken, String spaceKey,int statusCode){
        try{
            urlsaveOrUpdateCustomFieldsettings = Utils.getUrl("saveOrUpdateCustomFieldsettings");
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            //params
                            .param("data", dataStr)
                            .param("consumerName", consumerName)
                            .param("serviceName", serviceNameSave)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveOrUpdateCustomFieldsettings)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if (statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> resp = from(response.asString()).get("");
                // HashMap<String, Object> settn = (HashMap<String, Object>) resp.get("settings");
                //ArrayList<HashMap<String, Object>>  customProperties = (ArrayList<HashMap<String, Object>>) settn.get("customproperties");
                // HashMap<String, Object> obj = customProperties.get(0);
                Integer id = (Integer) resp.get("id");
                LOGGER.info(("resp:" + resp.toString()));
                //****To assert checking the success***//
                //  Assert.assertEquals("manager", obj.get("key"));
                Assert.assertNotNull(id);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    public static void getMonitorData(String spacekey,String userID,String authtoken,String container) {
        try {
            String urlserver=Utils.getUrl("getMonitorData");
            Response response=
                    given()
                            //Header
                            .header("spacekey", spacekey)
                            .header("userID", userID)
                            .header("authtoken", authtoken)
                            //Body
                            .param("container",container )
                            .param("token", authtoken)
                            .param("spacekey", spacekey)
                            .when()
                            .post(urlserver)
                            .then()
                            .assertThat()
                            .statusCode(HttpStatus.SC_OK)
                            .extract().response();
            HashMap<String, Object> dataSourcesListgetdatastoreinfo = from(response.asString()).get("");

            LOGGER.info("getMonitorData====="+response.asString());

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    // Editing the max fetch size of DB's
    public static void saveOrUpdateDataManagementSettings(String userId, String authToken, String spaceKey, String dataSource,int statusCode) {
        try {
            urlsaveOrUpdateDatamanagmentConfSettings = Utils.getUrl("saveOrUpdateDatamanagmentConfSettings");
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            //params
                            .param("data", dataSource)
                            .param("consumerName", Utils.getproperty("consumerName"))
                            .param("serviceName", Utils.getproperty("serviceNameSave"))
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlsaveOrUpdateDatamanagmentConfSettings)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode==HttpStatus.SC_OK){
                HashMap<String, Object> resp = from(response.asString()).get("");
                Integer id = (Integer) resp.get("id");
                LOGGER.info(("resp:" + resp.toString()));

                //****To assert checking the ID is not null***//
                Assert.assertNotNull(id);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //getting the max fetch size of DB's
    public static void getDataManagementDetails(String userId, String authToken, String spaceKey,String dataStr,int statusCode) {
        try {
            urlgetDatamanagmentConfSettings = Utils.getUrl("getDatamanagmentConfSettings");
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            //params
                            .param("data", dataStr)
                            .param("consumerName", Utils.getproperty("consumerName"))
                            .param("serviceName",Utils.getproperty("serviceNameGet"))
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetDatamanagmentConfSettings)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode==HttpStatus.SC_OK){
                HashMap<String, Object> resp = from(response.asString()).get("");
                LOGGER.info(("resp:" + resp.toString()));

                //****To assert checking the success***//
                String success = resp.get("success").toString();
                Assert.assertEquals(success, "true");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //getting getPredictiveSettings
    public static void getPredictiveSettings(String userId, String authToken, String spaceKey,String dataStr,int statusCode) {
        try {
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            //params
                            .param("consumerName",consumerName)
                            .param("serviceName",serviceNameGet)
                            .param("data", dataStr)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(Utils.getUrl("getPredictiveSettings"))
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if (statusCode == HttpStatus.SC_OK) {
                HashMap<String, Object> resp = from(response.asString()).get("");
                LOGGER.info(("resp:" + resp.toString()));
                //****To assert checking the success***//
                String success = resp.get("success").toString();
                Assert.assertEquals(success,"true" );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //getting  CustomField Settings
    public static void getCustomFieldSettings(String userId, String authToken, String spaceKey, String dataStr,int statusCode) {
        try {
            urlgetCustomFieldSettings = Utils.getUrl("getCustomFieldSettings");
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            //params
                            .param("consumerName",Utils.getproperty("consumerName"))
                            .param("serviceName",serviceNameGet)
                            .param("data", dataStr)
                            .param("isSecure", isSecure)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetCustomFieldSettings)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode==HttpStatus.SC_OK){
                HashMap<String, Object> resp = from(response.asString()).get("");
                LOGGER.info(("resp:" + resp.toString()));

                //****To assert checking the success***//
                String success = resp.get("success").toString();
                Assert.assertEquals(success,"true" );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // getWinADConfSettings
    public static void getWinADConfSettings(String userId, String authToken, String spaceKey, String dataStr,int statusCode) {
        try {
            urlgetWinADConfSettings = Utils.getUrl("getWinADConfSettings");
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            //params
                            .param("consumerName",Utils.getproperty("consumerName"))
                            .param("serviceName",serviceNameGet)
                            .param("data", dataStr)
                            .param("isSecure", isSecure)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetWinADConfSettings)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode==HttpStatus.SC_OK){
                HashMap<String, Object> resp = from(response.asString()).get("");
                LOGGER.info(("resp:" + resp.toString()));

                //****To assert checking the success***//
                String success = resp.get("success").toString();
                Assert.assertEquals(success,"true" );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //getAdUserGroups
    public static void getAdUserGroups(String userId, String authToken, String spaceKey,int statusCode) {
        try {
            urlgetAdUserGroups = Utils.getUrl("getAdUserGroups");
            //Todo here...
            String getAdUserGroupsId = prop.get("getAdUserGroupsId").toString();
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            //params
                            .param("id", getAdUserGroupsId)
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetAdUserGroups)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();

            if(statusCode==HttpStatus.SC_OK){
                HashMap<String, Object> resp_getAdUserGroups = from(response.asString()).get("");
                HashMap<String, Object> winADConfigResp = (HashMap<String,Object>) resp_getAdUserGroups.get("winADConfigResp");
                List<HashMap<String, Object>> winADInfos = (ArrayList<HashMap<String, Object>>) winADConfigResp.get("winADInfos");
                for (HashMap<String, Object> winADInfosObj : winADInfos) {
                    if (winADInfosObj.containsKey("groupName") && winADInfosObj.get("groupName").toString().equals("employees")) {
                        employeesGrpName = winADInfosObj.get("groupName").toString();
                    }
                }
                LOGGER.info(("resp_getAdUserGroups:" + resp_getAdUserGroups.toString()));
                LOGGER.info(("employeesGrpName:" + employeesGrpName));
                //****To assert checking the success***//
                String success = winADConfigResp.get("success").toString();
                Assert.assertEquals("true", success);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // getWinADAttributes
    public static void getWinADAttributes(String userId, String authToken, String spaceKey, String dataStr,int statusCode) {
        try {
            urlgetWinADAttributes = Utils.getproperty("getWinADAttributes");
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            //params
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetWinADAttributes)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode==HttpStatus.SC_OK){
                List<HashMap<String, Object>>resp = (ArrayList<HashMap<String, Object>>)from(response.asString()).get("");
                LOGGER.info(("resp:" + resp.toString()));

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // encryptionGetActiveUsers
    public static void getActiveUsers(String userId, String authToken, String spaceKey, int statusCode) {
        try {
            urlgetActiveUsers = Utils.getproperty("getActiveUsers");
            Response response =
                    given()
                            .header("spacekey", spaceKey)
                            .header("userID", Integer.valueOf(userId))
                            .header("authtoken", authToken)
                            //params
                            .param("userid", userId)
                            .param("usertype", "2")
                            .param("token", authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetActiveUsers)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            if(statusCode==HttpStatus.SC_OK){
                List<HashMap<String, Object>>resp = (ArrayList<HashMap<String, Object>>)from(response.asString()).get("");
                LOGGER.info(("resp:" + resp.toString()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //get all geospatial settings
    public static void getAllGeoSpatialSettingsAdmin(String userId, String authToken, String spaceKey, int statusCode){
        try{
         String geometryType = "";
            Response response_Geo =
                    given()  //headers
                            .header("userID", Integer.valueOf(userId))
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //req params
                            .param("geometryType", geometryType)
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .when()
                            .post(urlgetAllGeoSpatialSettings)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String,Object> resp = from(response_Geo.asString()).get("");
            HashMap<String,Object> geoSpatialResp = (HashMap)resp.get("geoSpatialResp");

            String msg = geoSpatialResp.get("success").toString();
            Assert.assertEquals(msg, "true");

        }catch(Exception e){
            e.printStackTrace();
        }

    }

    //get all geo shape datas
    public static void getAllGeoShapeDatas(String geometryType,String userId, String authToken, String spaceKey,int statusCode){
        try{
            urlgetAllGeoShapeDatas = Utils.getUrl("getAllGeoShapeDatas");
            Response response_Geo =
                    given()  //headers
                            .header("userID", Integer.valueOf(userId))
                            .header("spacekey", spaceKey)
                            .header("authtoken", authToken)
                            //req params
                            .param("token",authToken)
                            .param("spacekey", spaceKey)
                            .param("geometryType", geometryType)
                            .when()
                            .post(urlgetAllGeoShapeDatas)
                            .then()
                            .assertThat()
                            .statusCode(statusCode)
                            .extract().response();
            HashMap<String,Object> resp = from(response_Geo.asString()).get("");
            HashMap<String,Object> geoSpatialResp = (HashMap)resp.get("geoSpatialResp");
            List<HashMap<String,Object>> geoShapeDataList = (ArrayList<HashMap<String,Object>>)geoSpatialResp.get("geoShapeDataList");
            LOGGER.info(("resp:" +resp.toString()));

            for(HashMap<String, Object> geoShapeDataListObj:geoShapeDataList){
                if(geoShapeDataListObj.containsKey("name") && geoShapeDataListObj.get("name").equals("IndiaRoutes_Jan")){
                    geoShapeId =  geoShapeDataListObj.get("id").toString();
                }
            }

            //***Assert message to check  folder added to favouites***//
            String msg = geoSpatialResp.get("success").toString();
            Assert.assertEquals(msg,"true" );

        }catch(Exception e){
            e.printStackTrace();
        }

    }




}
